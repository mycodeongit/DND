VCF Verify (VxVerify for VCF & SDDC Manager)
Python code by Dave Reed with VxRail commands and queries by Billy Jenkins - VxRail Engineering

Copy the zip file to SDDC Manager via SSH:
Create /tmp/vcfv if it does not exist already and set the permissions to unrestricted.
E.g.
    mkdir -m 777 /tmp/vcfv
    cd /tmp/vcfv

Unpack the VCF-Verify package to the folder above, which should have at least the following in the same directory:
vcfverify.sh (Script to kick off the correct VCFV version, for when there are multiple vcfv Python files)
    vcfv4.py or .pyc (VCF-Verify for VCF3.9.1 and above; Python 3.7)
    vxv2.pyc (VxVerify for VxRail 4.5 and 4.7)
    vxv3.pyc (VxVerify for VxRail 7.0)
The root user is needed in VCF4 / vSphere 7, to have enough permissions for the additional Python packages:
    sudo ./vcfverify.sh -u priv_user@vsphere.local
VCF 4.3+ requires a SSO user with cloud-admin (example: administrator@vsphere.local) rights to be provided at startup
    ./vcfverify.sh -u cloudadmin@vsphere.local

Note that each version of VxVerify & VCF-Verify is time-limited to prevent outdated versions being used, so please check for a new version each week.

These versions can be downloaded from:
    https://central.dell.com/solutions/VxVerify

It is also possible to substitute the latest versions of VxVerify 2 & 3 for vxv2.pyc & vxv3.pyc (changing the names to match), if the existing versions have expired.

Recent changes:
No changes to tests in:
x.30.512 (expiry date: 2023 Jun 03)
x.30.428 (expiry date: 2023 May 19)
x.30.414 (expiry date: 2023 May 03)
x.30.331 (expiry date: 2023 Apr 22)
x.30.322 (expiry date: 2023 Apr 13)
x.30.310 (expiry date: 2023 Apr 01)
x.30.224 (expiry date: 2023 Mar 16)

x.30.220 (expiry date: 2023 Mar 12)
Merging fixes from x.30.211 not present in x.30.217 (VXV-793)

x.30.217, x.30.211 & x.30.210 (expiry date: 2023 Mar 03)
Change to timeouts to cope with large numbers of VxRM (VXV-777)

x.30.123 (expiry date: 2023 Feb 09)
Updated VCFVerify bundles with the matching VxVerify versions

x.30.106 (expiry date: 2023 Jan 26)
Updated VCFVerify with x.30 VxVerify versions

x.21.216
Updated VCFVerify bundles with the matching VxVerify versions.

x.21.202
Test 'sd_flop' now checks if files have at least a user permission of rw/6 except for backups (VXV-684)

x.21.121 - x.21.020
Updated VCFVerify bundles with the matching VxVerify versions.

x.20.930
Fixed issue with test 'sd_vxms' causing crash due to WLD order to be unexpected in SDDC db (VXV-644)

x.20.918 - x.20.819
Updated VCFVerify bundles with the matching VxVerify versions.

x.20.805
New test sd_mim to check if there is VCF SDDC Multi-Instance Management and warn if found (VXV-550 + KB201971)
New test nsx_fed to check via NSX-T api if NSX-T cluster is part of a NSX-T federation (VXV-550 + KB201978)
New NSX-T base api method introduced to automate NSX-T apis centrally in code (VXV-550)

x.20.722
Updated VCFVerify bundles with the matching VxVerify versions.

x.20.615 & x.20.608
Branding change to replace all Dell EMC references with Dell (VXV-551 & VXR-3450)

x.20.624
Add support for VxRail target code levels to be specified or specified tests profiles to be used (VXV-537)

x.20.617
Root passwords that are sent to VxVerify will now be octal encoded for VxRM and base64 encoded for VC, to avoid problems with escape characters like $ (VXV-518).

x.20.610
Added a workaround for bad characters in the VxRM root password, which will run most of VxVerify tests from the mystic user (VXV-518).

x.20.530 & x.20.520
Updated VCFVerify bundles with the matching VxVerify versions.

x.20.513
Changing the default test profile for VCF from 0 (all tests) to 3 (VCF upgrades) (VXV-489).
New test sd_vxms to cross check VxRail clusters version compared to Mgmt domain VxRail version (VXV-381)
New test sd_flop to check SDDC manager filesystem permissions using VMware KB 83837 (VXV-39)
New test svc_vcf_acc to check if all svc-vcf-<esxishortname> accounts exists on SDDC manager (VXV-44)

x.20.506
Increased output in vcfv.log on SDDC API Password Checker if not valid status is return (VXT-679)

x.20.429 & x.20.413
Updated VCFVerify bundles with the matching VxVerify versions.

x.20.329
Critical test responses for Python exceptions will instead return the status 'Py Crash', to make it clearer that these need a VXT to be raised, but by themselves do not prevent an upgrade (VXT-641 & VXT 676).

x.20.318 & x.20.309
Layout change for summary table to use longer test result status and fewer KB digits (VXT-581)
Fix for critical errors in test 'dva_esx', when processing incomplete records from failed nodes (VXT-654).

x.20.304 to x.20.211
Updated VCFVerify bundles with the matching VxVerify versions.

x.20.204
Improved expiry date mechanism to give a preliminary expiry date, to stop early, rather than waiting for VxVerify to complete with expired minions (VXT-557).

x.20.121
Switching VCFVerify to compiled Python for consistency with VxVerify.

x.20.107
Adding combined MD5 file (vcfv4.md5), to the VCFVerify zip bundle (VXT-325)
Added retry for credential lookup using alternative mechanism where possible.

x.11.220
Updated VCFVerify bundle with the matching VxVerify versions.

x.11.210
New validation at startup of VCFVerify to validate vxv2 and vxv3 pyc md5 hash calculations (VXT-325)
New test dva_esx to compare esxi version from minion vs SDDC database (VXT-396 KB194317)
New test ssh_en to validate is ssh enabled on all nodes and post VCF 4.4 if disabled (VXT-449 KB194318)
Updated log and report messages to reflect naming of VCFVerify, instead of VxVerify.
Timing changed for SDDC API calls, to prevent large SDDC environments getting overloaded with API calls.
Test sd_prechk now produces a full output of SDDC api precheck result per WLD sddc-precheck-<wld-name>.txt (VXT-358)

x.11.203
New test *_snap for system VMs vCSA's, PSC, SDDC manager, NSX-V manager (VXT-430)
Test vc_snap will check for snapshot usage with VC and ELM as per VMware KB85662

x.11.125
Change in summary table layout to remove the 0, 1 or 2 for pass, warn or fail (VXT-469).
New test sd_tinyvc to check for tiny VC is being present in the Mgmt cluster (VXT-423)
Updated VCFVerify bundle with the matching VxVerify versions.

x.11.119
Updated VCFVerify bundle with the matching VxVerify versions.

x.11.111
SQL verifies tables are present in the platform DB (the naming of which can vary between VCF releases), before querying the table. (VXT-371).

x.11.106
Based on VxVerify x.11.105
Fix for VCFVerify bundle which had the wrong vcfverify.sh script, which used the old python filenames.
MD5 files added to the VCFVerify bundle.

x.11.015
Improved the ZIP file parsing mechanism to cope with bad VxVerify results and report any missing files in the result table (VXT-416).
Fix for API password validationChecks which could result in a critical failure (VXT-406)
Fixed mechanism for reading the expiry days from VxVerify (VXT-416).

x.11.008
VCFVerify supports the VxVerify test profiles, but will default to all running tests (-n 0) (VXT-391)

x.10.930
VxRM will be listed as short host names (VXT-382)
Fixed credential issue for VCF 4.3+ preventing VCFverify to start due to SDDC hardening (VXT-388)

x.10.924
For partially upgraded VCF, there may be a mixture of VxVerify 2 & 3 needed for different domains. The test for which VxVerify version is sent is now done on a per domain basis (VXT-378)
Where some VC credentials are missing from each domain, for VxRail 7.x, credentials listed as PSC will be used instead (VXT-299).

x.10.917
VCF-Verify can run multiple VxVerify sessions at the same time, with a staggered start (VXT-349).
On VCF 4.x, a python module bundle can be pushed along with VxVerify to further reduce the need for Shell based commands.

x.10.910
Fix for credentials service based checks for issue in VCFV 4.10.902, which could result in no valid credentials being found.

x.10.902
SDDC checks will stop after a critical test failure, such as for illegal password characters, rather than running VxVerify on each VxRM (VXT-301)
Fixed issue 'vr_pw_char: VCSA tests not run: no root password supplied' warning for VCF 4.x (VXT-297 + VXT-299)
New VCF-Verify test 'sd_prechk' for SDDC UI precheck automatically triggered and analyzed by VCF-Verify (VXT-194)
New VCF-Verify test '*_crtval' for certificate checks from SDDC using VCF commonsvc and java certificate keystore (VXT-315)
Fixed issue for VCF 4.0.0.0 to 4.0.1.0, where the wrong VxVerify version was being sent to VxRM (VXT-324)

x.10.826
Changed the password expiry message to make it clear how many days ago it expired.
For VCF 4.2+, the token based API will be used for looking up credentials from SDDC Manager.

x.10.820
For VCF 4.2+, the SDDC password tests are more comprehensive and are based on the validation API.
Added used capacity test ('df_sddc'), for SDDC Manager mount points: '/','/tmp','/var/log/vmware','/opt/vmware/vcf' and '/nfs/vmware/vcf/nfs-mount'.
Added warnings when old VxVerify log files are being imported, rather than a new set.
Added an early exit for when vcfv4.py is run from a folder other than CWD or the log folder (/tmp/vcfv or specified with -l ...).  Using the VCFVerify.sh script avoids this issue.
Changed VCF-Verify log bundle filename to change with time, such as /tmp/VCFVerify_237a33.zip (VXT-292).

x.10.805
Added warnings for test sections skipped using the -x parameter, which should not be used for pre-upgrade healthchecks.
New VCF-Verify test 'liclib' for VCF licencing issues
New VCF-Verify test 'sd_task' for stuck SDDC tasks

x.10.713
Fixed pwe tests to make sure they do not run for logins that the local user does not have permissions to check.

x.10.709
Added 'pwe_root' and 'pwe_mystic' tests, to check for password expiry dates on VxRM (VXT-256).
Added test for NSX management passwords in VCF Verify (VXT-256).

x.10.527
Modified VxRM name check to ignore VCF clusters.

x.10.416
VCFVerify now passes the VCSA root password to VxVerify, to allow VCSA tests to be run from each domain.

x.10.409
Added SOS output parsing to VCFVerify

x.10.329
Added Datacenter name to global Vx class, to double check for former VxRacks, which need special upgrade procedures.

x.10.312
Beta testing the VxVerify for VCF and SDDC Manager, which will be known as VCFVerify.
 This will run SDDC manager tests; send VxVerify to each VxRM in the cluster and finally merging the results into one table.
