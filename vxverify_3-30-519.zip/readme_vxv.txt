VxVerify aims to simplify the pre-upgrade testing of VxRail clusters by checking of nodes and system VM by automatically
uploading scripts to each host and automating the analysis of the data that is returned.  VxVerify is written and maintained
by Escalation Engineering, in order to have tests for new issues within days of them being diagnosed.

- VxVerify 1.xx.xxx is for VxRail 4.0 only
- VxVerify 2.xx.xxx is for VxRail 4.5, 4.7 & 7.0.000
- VxVerify 3.xx.xxx is for VxRail 7.0.010+ (a new version is necessary due to the move to Python 3.6 from 2.7, in VxRail 7.0.010 onwards)
- VCFVerify is for SDDC Manager and runs the VxVerify versions above on each VxRM in VCF.

For help with downloading, installing and running VxVerify, see KB article:
    https://www.dell.com/support/kbdoc/000021527

Troubleshooting: See KB article:
    https://www.dell.com/support/kbdoc/000066460

Note: Tests marked with a * are in draft mode (no warnings or failures should be returned), to be fully released at a later date.

Recent changes:
x.30.519 (expiry date: 2023 Jun 10)
Test 'tpm_vers' updated to warn for upgrading to 8.0.100+, which would disable TPM 1.2 (VXV-851)
Test 'esx_vers' amended to fail for 13G nodes with a target code level of 7.0.45x (VXV-843)
Test 'ds_cluster' added for heath-checking cluster connected DVS (replaced ds_rev & ds_state) (VXV-568)
Test 'rep_partnr' added for heath-checking VC Replication between partner nodes (VXV-839)
Test 'op_status' in VxVerify2 will check for NULL values in the operation_status DB table (VXV-849)
Test 'esx_vers' amended to fail for 13G nodes with a target code level of 8.0.00 (VXV-856)
Grep of RecoverPoint VIB added to vxverify.sh for Core Support profiles (VXV-847)

x.30.512 (expiry date: 2023 Jun 03)
Nodes will report RP4VM VIB version under action items (VXV-847)
Node LACP status will be listed in the VxTii report (VXV-842)
Fix for '_cluster' tests, that were missing in VxVerify2, due to JSON merging issue (VXV-848)
Test 'ifcfg' result for "eth0 should have static IP", set to warning (VXT-618)
* Test 'sha_hash' added to check for weak signature algorithms on VC and ESXi 8 upgrades (VXV-844)

x.30.505 (expiry date: 2023 May 27)
Test 'flatvmdk' added to check for *flat.vmdk files in vSAN for ESXi 8.0 upgrades (VXV-838)
Test 'esx_vers' amended to fail for 13G nodes with a target code level of 7.0.450 (VXV-843)
Host tests using vSAN commands will be filtered out for nodes that do not have vSAN (VXP-69160)
Tests 'df_vtrace' & 'in_vtrace' renamed from "df_vsant" & "in_vsant" to avoid CEC conflicts (VXV-803)

x.30.428 & x.30.425 (expiry date: 2023 May 19)
Argument handling has been modified to all ADC/Radar to specify pre-upgrade test profiles (VXP-68033)
Test 'df_vtrace' added to check the free ramdisk capacity in the /vsantraces directory (VXV-803)
Test 'in_vtrace' added to check the free ramdisk inodes in the /vsantraces directory (VXV-803)

x.30.421 (expiry date: 2023 May 13)
Test 'ps_status' added to check the Platform Service health (VXV-837)
Test 'ps_restart' modified to not restart PS.Next if it is running correctly (VXV-837)
If no Platform Restart has to be done (7.0.240+ on 14G+ nodes), the minion runtime should be much quicker (VXV-837)
Test 'iplisten' modified to log more for esxcli errors, but not give a warning result (VXV-762)

x.30.414 (expiry date: 2023 May 03)
Test 'vx_cl' added to check if cluster moid corresponds to VXMs cluster membership (VXV-737)
Test 'scratch' modified to check if the local log path has been changed from /scratch/log (VXV-830)
VxVerify2 shell command function logging error fixed (VXV-831)
Test 'idc_hwi' modified to also fail for upgrades to 7.0.411 (VXV-787)

x.30.331 (expiry date: 2023 Apr 22)
Test 'mg_user' warning added if management user is within localos or VCSA SSO domain (VXV-708)
Test 'rp4vm' will warn if RP is on nodes but not in the VC extension manager (VXV-826)
DO query function logging fixed to correctly report rejected queries (VXV-827)
Added interactive mode argument ('-i', '--inter'), for use with vxverify.sh (VXV-825)
Search for RecoverPoint Splitter improved on nodes (VXV-826)
Modified VCF node check to ignore zero sized lcm-bundle-repo partitions (VXV-829)
Test 'dnslookup' added query for local manager IP to exclude this from the nslookup check (VXV-710)
* Test 'vc_vhc' added check for vSAN Health from VC (VXV-822)

x.30.322 (expiry date: 2023 Apr 13)
Fix for some host names to cause mismatches between the hostname and FQDN, causing additional host entries to be listed (VXV-823)
Test 'vodb' will check the timestamp of each checksum error and ignore those over 7 days old (VXV-760)
Test 'scratch' will check the timestamps of the latest lines to make sure it is current (VXV-519)

x.30.316 (expiry date: 2023 Apr 07)
Test 'df_service' modified the search string for '*1-service-datastore1', to pick up more formatting errors (VXV-798)
Auto-correction 'rac_fix' will run for profiles [0, 1, 2, 5, 6, 7, 8] for both VxVerify 2 & 3 (VXV-813)
Certificate verification check moved in the run order, to avoid missing credential issues (VXV-818)
Test 'sys_vm' modified to cope better with null responses from vCenter (VXV-817)
Auto-corrections will now all add entries to vxv-fix.log, including fixes done on nodes (VXV-816)
VxStat UUID to VM name mapping file will be included in the output zip file, if it is present (VXV-801)
VxTii table changed to list more VC plug-in versions, such NSX (VXV-772)

x.30.310 (expiry date: 2023 Apr 01)
Auto-fix / corrections test results will be listed in the summary table as _fixed and not a warning (VXV-750)
Pretest 'ism_check' modified to do a node type check if ISM is not running, to handle virtual nodes (VXV-725)
Test 'ssh_config' checks and corrects the SSH SHA levels for VxRail 4.7 to 7.0+ upgrades (VXV-734)
Logging of VC plug-ins changed to allow for these to be included in VxTii (VXV-772)
Tests 'df_root' & 'df_store2' enhanced to also check free inodes (VXV-811)
Mapping between hostname and FQDN improved with lookup tables added (VXV-812)
VCSA connections have added more fault tolerance and exception handling (VXV-814)
Test 'vc_api' fixed VC HA API call (VXV-806)

x.30.303 (expiry date: 2023 Mar 25)
VxVerify.sh menu updated to ask fewer questions for Core upgrade and healthcheck profiles (VXV-741)
Script vxverify.sh updated to support VxRail 8.x (VXV-807)
Test 'mapper' enhanced to add available inode checks on mapper partitions, such as /var/log (VXV-789)
Test 'mapper' fixed to avoid py_crash events (VXV-806)
Test 'ip9090' was mistakenly flagging 13G nodes as not reachable, which has been corrected (VXV-759)
Test 'idc_hwi' appended to check VxRail P670N backplane firmware (VXV-800)
The minion log data file will be read to check that it is complete, if the SSH session has completed (VXV-730)
When polling minions the vxv.log will add a suffix if one, but not all of the session, log and txt sessions are complete (VXV-730)
Test 'vc_pnid' corrected in VxVerify2 to match VxVerify3 (VXV-804)
Test 'certesx' added to more upgrade profiles check for checking the ESXi certificate on each node (VXV-663)

x.30.228 (expiry date: 2023 Mar 20)
Test 'idc_swi' fix for warnings on Dell 13G nodes (VXV-805)
Tests 'dns_node' & 'dnslookup' set to ignore false alarms for VxRail 8.0+ (VXV-710)

x.30.224 (expiry date: 2023 Mar 16)
iDRAC timeouts and retry counts from Redfish and racadm are combined to prevent the minion run-time being exceeded (VXV-797)
Test 'bmc' fixed for 13G nodes running 7.0.240+, which could return a py_crash (VXV-791)
Test 'vobd' will not return a fail if the vobd.log is readable but has no log entries (VXV-794)
Test 'vc_ntp' modified to have the same 300 second threshold for both VxVerify 2 & 3 (VXV-796)
Added retry and specific test failure for DO-host returning no results (VXV-788)
iDRAC HWinventory cross referencing improved to add data from Redfish direct queries to the XML export (VXV-783)
File transfer errors when uploading the minion will generate a new failure event (VXV-792)
Test 'idc_hwi' modified to only fail for drive firmware for upgrades to 7.0.410, 8.0.000 & 8.0.010 (VXV-787)
Rancher and docker tests are now silenced due to unexpected behaviour these test are being overhauled (VXV-764, VXV-765 & VXV-766)
VxVerify.sh menu updated to added Core upgrade and healthcheck profiles (VXV-741)
Host free capacity and inodes will be read before uploading minions or restarting iDRAC (VXV-779)

x.30.220 (expiry date: 2023 Mar 12)
Merging fixes from x.30.211 not present in x.30.217 (VXV-793)

x.30.217 (expiry date: 2023 Mar 10)
Autofix 'ism_fix' is now using ipmi to Hard/Cold reset iDrac instead of Invoke-iDRACHardReset (VXV-786)

x.30.211 (expiry date: 2023 Mar 03)
Test 'bcom5_25g' suspended pending review as to whether this setting still impacts upgrades (VXV-784)
Test 'bmc' will pause for Platform services to be fully back online for ESXi without PT agent (PT Agent based nodes already did this retry loop) (VXV-784)
VxTii drive part numbers corrected for Redfish formatting issue (VXV-785)
Test 'vc_nic' will check count of vNICs on VC (VXV-774)
Tests 'lcm_state' & 'lk_svc' added failure conditions for test profile 3 (VXV-775 & VXV-756)
Test 'pfx_vxm' added to check the VXM pfx certificate useability (VXV-709)

x.30.210 (expiry date: 2023 Mar 02)
Test 'idc_hwi' and VxTii corrected issue for missing hardware inventory system data (VXV-778)
Hardware Inventory can be read from a mixture of Redfish API, racadm and API XML export to give more complete output (VXV-738)
VxRail 7.0.200+ should have reduced minion run times, due to all racadm commands being replaced by API queries (VXV-738)
ESXi Python version will now be listed in the minion logs (VXV-731)
The minion txt and log data streams will be monitored for the last lines, so that the session can be kept open until they complete (VXV-730)
Test 'ip9090' was mistakenly flagging for 13G nodes, so this has been corrected by reading the node type from the JSON (VXV-759)

x.30.203 (expiry date: 2023 Feb 22)
VxTii and iDRAC tests moved to a hybrid of Redfish API and racadm queries (VXV-738)

x.30.130 (expiry date: 2023 Feb 19)
Modified additional checks for VxVerify3 minion completion to give more time for logs to sync (VXV-730)
Test 'idc_swi' moved from racadm to Redfish API for VxRail 7.0.200+ (VXV-738)

x.30.123 (expiry date: 2023 Feb 12)
Test 'idc_hwi' fixed for non-iDRAC based nodes to not report a test fail (VXV-755)
Minion log file search improved for hosts with overlapping names (VXV-751)

x.30.120 (expiry date: 2023 Feb 09)
Test 'idc_hwi' modified to check for SKHynix drive firmware levels (VXV-742)
Test 'tpm_vers' added to check each node's TPM version and status before upgrading to vSphere 8 (VXV-679)
Minion function fixed logging to report when no hosts are found, due to DO host errors (VXV-745)
Test 'vxm_cert' updated to not report errors for users without permissions for server.key in kubectl (VXV-743)
Auto-correction 'rac_fix' added to more profiles, which can restart iDRAC and rerun minion (VXV-597)
SEL log processing moved from racadm to Redfish API for VxRail 7.0.200+ (VXV-738)
Tests 'idc_as' & 'tls_idrac' moved from racadm to Redfish API for VxRail 7.0.200+ (VXV-738)
Secure Boot status will now be listed in each node's VxTii report, along with TPM (VXV-740)
Test 'ip9090' fixed for Dell node generation not being read correctly (VXV-747)
Test 'localos' added to all upgrade profiles (VXV-718)

x.30.113 (expiry date: 2023 Feb 02)
Example of how to use KB number added to VxVerify summary output (VXV-739)
Add Redfish API support for iDRAC queries as an alternative to remotecmd racadm (VXV-738)
ESXi minion checks should complete faster, because most of minion latency comes from the racadm commands (VXV-738)
Test 'idc_swi' updated for Redfish API and will return alternative headings in the JSON data (VXV-738)
Test 'certesx' updated to clarify failure results (VXV-663)
readme.txt renamed to readme_vxv.txt in zip bundle to avoid confusion with other documentation.

x.30.106 (expiry date: 2023 Jan 26)
Auto-correction 'rac_fix' added to restart iDRAC and related services, before rerunning minion (VXV-597)
Added additional checks for minion completion to VxVerify3 (VXV-730)
Test 'idc_swi' will return more information about any faults that are returned from iDRAC (VXV-597)
Test 'certesx' added to check the ESXi certificate on each node (VXV-663)
Test 'vxm_cert' modified to fail for an expired certificate if it is not self-signed (VXV-719)
Test 'tag_sfs' added, which reports SFS related Tags on VxRail upgrades to 8.0 (VXV-721)
Test 'localos' added to look for localos management users when upgrading to vSphere 8 (VXV-718)

x.21.223 (expiry date: 2023 Jan 12)
Test 'vlcm' added to highlight known any known issues when upgrading with vlcm enabled (VXV-727)
Added current and Python working directories to the logging and to the rule.db search path (VXV-720)
Logging improved in VxVerify 2 'ism_fix' to correctly log the ism status (VXV-724)
Test 'ip9090' modified to improve the logging of timeout events (VXV-671)
Test 'thump' modified to either show SHA1 or SHA256 (depending on which is received from VC), but not both (VXV-663)
Test 'vc_pnid' will check that both FQDN and PNID from VC are valid, before proceeding giving an alert (VXV-728)
Tests on host using iDRAC commands have been given a timeout to prevent them hanging indefinately (VXV-726)

x.21.220 (expiry date: 2023 Jan 09)
Argument --service or -s is updated to also opt out of auto-correction for ism and stale-sandbox (VXV-703)
Auto-correction 'ism_fix' updated to be triggered by the lack of an iDRAC IP in DO-host, in core profiles (VXV-717)
Auto-correction 'ism_fix' updated to run for all upgrade profiles (when iSM is offline), unless --service argument is specified (VXV-723)
Beta function 'minion_redo' has been updated to not log events, until 'rac_fix' is required (VXV-722)

x.21.216 (expiry date: 2023 Jan 05)
LogAI (vxdiag), will check the current working directory, as well as the logging folder, for the rule.db (VXV-713)
Auto-correction for stale sandbox issue added to test profiles 1 & 2 (VXV-716)
Test 'vc_pnid' in VxVerify2 modified to give a failure for all 4.x to 7.x upgrades, with mismatched PNID (VXV-696)
The function 'ism_check' will log counts of nodes with iSM running to confirm all nodes were tested (VXV-715)
Test 'vxtii_err' will no longer flag up an iDRAC error, if the iDRAC query retry is successful (VXV-714)
Host iDRAC query retry mechanism modified to do a delayed retry for more than just the hardware inventory (VXV-714)
Fix for the CEC being missing in some cluster tests, such as 'hoststatus' (VXV-649)
Test 'vmotion' modified to enhance logging to find empty entries (VXV-704)
Log for 'stale-sandbox' renamed, so that it is included in the VxVerify zip file (VXV-716)

x.21.209 (expiry date: 2022 Dec 29)
LogAI analysis added to VxVerify 3, which uses a separate 'rule.db' file to parse the VxRM logs (VXV-683)
Test 'dnslookup' fixed to correctly report a failure for nslookup timeouts (VXV-707)
Auto-correction 'ism_fix' will use ipmitool to restart iDRAC if HardReset script is not found (VXV-702)
Timeout for minions in VxVerify2 recalculated to exclude time running 'ism_fix' (VXV-702)
Test 'vc_pnid' set to only record failures for target code 7.0.400 or 401 (or if no target code is specified) (VXV-696)
Changed function for checking the current VxRM user to use getpwuid instead of getuser (VXV-705)
Host iDRAC queries modified to not run on nodes without racadm support (VXV-668)
Renamed vxverify.sh options to "VxRM healthcheck" & "General healthcheck" for test profiles 4 & 5 (VXV-692)

x.21.202 (expiry date: 2022 Dec 22)
Auto-correction added for stale sandbox issue found in VxRail 7.0.350 to 7.0.38x (VXV-609)
Auto-correction 'ism_fix' updated to run when necessary in VxVerify 3 profiles 6 and 7 (VXV-596)
Test 'df_zero' added to look for external storage mount points with zero capacity (VXV-681)
Test 'esx-vers' modified to also check for unsupported node types on the target code level (VXV-680)
Added test profile 8, for running after upgrades (VXV-692)
Test 'gpu_hwi' modified to give a failure event for upgrades to 8.0.000+ (VXV-698)
Tests with iDRAC queries updated to use a unified retry mechanism and troubleshooting KB (VXV-668)
* Test 'id_source' added to check vCenter Identity Source data from the vCenter (VXV-685)

x.21.125 (expiry date: 2022 Dec 16)
Auto-correction 'ism_fix' updated to run when necessary in VxVerify 2 profiles 6 and 7 (VXV-596)
The auto-fix log would have write permission issues for /var/log and so the will save an alternative file to the logging folder (VXV-623)
Fix for 'vc_pnid' test, where py_crash could appear instead of a test fail, due to target code formatting (VXV-691)
Changed KB reference for all minion tests with iDRAC queries failing to refer to article 205769 (VXV-668)
* Test 'dsk_vami' added to check health of VCSA storage and VCSA DB storage (VXV-689)

x.21.121 (expiry date: 2022 Dec 12)
Fixing Satellite node query, which can return DO-host errors for clusters that do not support it (VXV-678)

x.21.118 (expiry date: 2022 Dec 10)
The presence of Satellite nodes will be highlighted by VxTii under the heading 'Satt' (VXV-678)
Test 'scratch', will suppress 'too few lines' failure, if vmkernel.log is readable and the latest entry is under 2 hours old (VXV-687)
Test 'psc_chk' added to check if psc_host is a valid authentication source for VCSA (VXV-643)
Node configuredHosts records will be checked earlier for missing name and version information (VXV-682)
Adding node certificate information to minion JSON (VXV-663)
Certificate days-remaining-until-expiry & issuer-email added to node VxTii report (VXV-501)
Changing 'rp4vm' test to be a fail is the target code is 8.0.000+, pending RecoverPoint support for VxRail 8.0 (VXV-686)
Auto-correction for Dell iSM updated to stop services, prior to restarting iDRAC, and starting services again afterward (VXV-596)
The JSON merge process has been changed to add a retry with unsorted data if there are any keys which are not strings (VXV-634)
Current VxRM user added to vxv.log and JSON data (VXV-660)
Fix for 'dns_fqdn_ip' reverse DNS lookup, which could give error: 'ip' referenced before assignment (VXV-675)

x.21.111 (expiry date: 2022 Dec 02)
Auto-correction added for nodes not running Dell iSM, which will run prior to the minions (only if --fix option used) (VXV-596)
The option to force the Shell SSH, rather than Python Paramiko SSH, has been moved from --fix (-f), to --ssh (VXV-673)
VxVerify shell script prompts revised (VXV-665)
Fix for VxTii drive table and 'vxnode' test for VD series nodes (VXP-61159)
Auto-fix actions added to more test profiles, to run by default (VXV-677)
Added error code calculations to each minion, so that they are included in each minions JSON file (VXV-677)
Change made to the vxverify_tests.json export to save each level 1 dictionary as a separate tree (changed back in 3.21.118)
Fix for 'ipv6vmk' test, which could get errors when IPV6 was disabled on a node (VXV-676)

x.21.101 (expiry date: 2022 Nov 22)
Test 'ipv4vmk' auto-correction of vmk0 has been added to profiles 0, 1, 2, 3 and 5, unless --service is specified (VXV-670)
Test 'df_vc' will include more information in the logs by default and will give an alert if no mount points are found (VXV-669)
Test 'tls_idrac' added to check the TLS revision on each node is supported (VXV-638) [profiles 6 & 7]
Test 'vc_pnid' modified to not give a failure for target VxRail code under 7.0.400 (VXV-636)
Test 'sso_admin' added, which checks the validity of admin credentials, if they are supplied (VXV-639)
Test 'ntp_vami' (admin credentials required), to compare VCSA VAMI and VxRail NTP data (VXV-635)
Test 'vxm_cert' modified to also compare the modulus of server.crt and server.key (VXV-653)

x.21.020 (expiry date: 2022 Nov 11)
Wording on VxVerify downloads revised (VXV-655)
VxTii will now search for alternative NVMe Bay numbers, when the PCI Slot/Bay numbering from ESXi does not match iDRAC (VXV-659)
VxVerify3 changing permissions of '/tmp/logbundle_collection.log' to rw-rw-rw- to prevent issues with overwriting it (VXV-657)
Updated the VxRM critical fail function to include the same header information as the regular VxRM test function (VXV-588)
ESXi and vSAN licence errors will be reported by the 'hoststatus' test, if they returned by vCenter when enabling SSH (VXV-649)
Test 'vc_pnid' added to compare the VCSA FQDN vs PNID and report if they match (VXV-636) [profiles 6 & 7]
Fix for hosts with None listed in do_host, instead of their ESXi versions, causing critical test failures (VXV-661)
Fix for VxVerify summary table to display a warning for all headings that would otherwise list passes, if a critical error is present (VXV-658)

x.21.007 (expiry date: 2022 Oct 29) & x.21.011 (ADC only)
Changes to minion to account for different iDRAC naming conventions in the new VxRail_V series nodes (VXP-60180)
Persistent log file '/var/log/mystic/vxv_fix.log' will update each time VxVerify is run and will track any auto-corrections (VXV-623).
Test 'vcsize' modified to avoid CPU and memory values for the PSC being used instead of the VCSA (VXV-648)
Test 'px_vcsa' has increased logging and will only report on clear password expiry responses (VXV-636)
VM tests for 'iso', 'pcip' & 'vmdk_vsan' will be skipped, if there is not enough time remaining to run them (VXV-650)
Test 'hoststatus' responses in VxVerify3 clarified to give more detail of faults (VXV-588)
Updating default failed minion response severity from 2 to 3 (critical), for consistency with the definition of these event codes (VXV-588)

x.20.930 (expiry date: 2022 Oct 19)
Test 'ipv4vmk' enhanced to correct invalid vmk0 IPv4 addresses, when using core upgrade profiles or the --fix argument (VXV-618)
Timeout mechanism in VxVerify adjusted for consistency between versions and to take into account the staggered minion start times (VXV-631)
iDRAC based minion tests have a bypass mechanism added, for when there is little time remaining before a timeout (VXV-631)
Extending test 'privileges' to VxRail 4.7, which checks the VC management user role privileges (VXV-540).
Test 'privileges', on VxRail 7.0, enhanced to check additional privileges for VxRail 7.0.400+ (VXV-200)
Shell response decoding changed to ignore unprintable characters, rather than producing a UnicodeDecodeError (VXV-633)
The JSON merge process has been changed to better log unreadable JSON results and return a critical fail for that node (VXV-634)
Added extra debugging information to test 'mservices', to capture and unrecognised status (VXV-632)
Adjusted 'rancher' test to apply to 7.0.370+ instead of docker tests (VXV-645)
Additional vxv.log entries for fdisk and lvm via 'rm_dila' function (VXV-235)
Additional vxv.log entries for finding lcm Properties which can bypass pre-check options (VXV-622)

x.20.920 (expiry date: 2022 Oct 09)
Fix for VxTii, which was showing NVMe Cache drives as 'Unused' by vSAN (VXV-627)
Fix for 'cert_verification' that could result in VxVerify3 reporting 'insufficient permissions' (VXV-626)
Fix for a write permissions check in /var/log/mystic, which could result in the assumption of a lack of permissions to run root tests, if radar.log is missing (VXV-628)
Cluster Health Monitoring clarified in VxTii report (VXV-624)

x.20.916 (expiry date: 2022 Oct 05)
Persistent log added for auto-correction activities (VXV-623)
Test 'mservices' will suppress systemctl command errors if run from mystic user (VXV-602)
Test 'bootdisk' failure criteria narrowed to only 'Error', 'OK' or 'Degraded' boot drive primary status, when RAID1 is not 'Online' (VXV-562)
Test 'vc_trust' added to VCF test profile 3 (VXV-625)
VxTii VID:DID & SVID:SSID correction for interposed values (VXV-388)

x.20.909 (expiry date: 2022 Sep 28)
Test 'ipv4vmk' will monitor for nodes with invalid vmk0 IPv4 addresses that could be auto-corrected (VXV-618)
Support for vSAN ESA pool drives added to VxTii report (VXV-617)
Test 'dcism' fixed VxRail 8.0+, using alternative path for dcism/dellism (VXP-56899)
Test 'vmk_tag' fixed to prevent incorrect DNS lookups making vmk0 appear to be the IPv4 management interface (VXV-619)
File 'vx_api.json' added to the VxVerify log folder, to cache information from API queries, that may be needed for debugging (VXV-612 & VXV-113))
In VxTii drive table, where part number is unavailable, replace this with vmhba number (VXV-617)
NIC and NVMe drives have VID:DID SVID:SSID information added to their JSON data (VXV-388)
VxTii VID:DID & SVID:SSID table added for ease searching on vmware HCL (VXV-388)
Additional parameters will be sent to each minion in base 64, such as the management IP, for cross referencing against ESXi (VXV-619)

x.20.902 (expiry date: 2022 Sep 21)
Test 'rp4vm' enhanced to flag up if vLCM is also present or RP VIB are present on hosts (VXV-615)
Test 'pconf' enhanced to correct incorrect binding and to not use reverse DNS lookups (VXV-600)
Minion test running order changed to allow the platform bind to be fixed prior to the platform service restart (VXV-600)
Advanced mode flag added to the VxTii report for VxRM, listed as 'AdvM' (VXV-279)
Test 'ipv6vmk' adjusted to set warning level based on the target code level, rather than the current level (VXV-495)
Test 'rancher' modified to increase the timeout value for Shell commands (VXV-591)

x.20.826 (expiry date: 2022 Sep 15)
VxTii layout changed to add vLCM. VCSA-FQDN is moved to a lower row in vxtii.txt (VXV-232)
Test 'saved_pw' enhanced to correct mismatched saved credentials, when using core upgrade profiles (auto-remediation)(VXV-587)
Test 'vmk_tag' modified to check vmk2 has a management tag in all out-of-family upgrades and that the vmk2 IPv4 matches the forward DNS lookup for the node FQDN (VXV-592)
Test 'vmk_tag' modified to check that vSAN or vMotion are not present on vmk2, for out-of-family upgrades (VXV-592)
Test 'eth1_up' modified to exclude VxRail 4.5 (VXV-604)
VCSA test category to be split into vCenter_root & vCenter_admin, to be run when the root and/or admin credentials respectively, are supplied (VXV-612)
VxVerify summary report will contain the total time it took to run the testing, in seconds (VXV-593)
Test 'vc_size' modified to allow for non-standard CPU and memory allocations (VXV-606)
Additional node vmk information added to the 'esx' section of each nodes JSON and to the combined vxverify_tests.json (VXV-614)
Test 'dnslookup' will report a list of addresses the had DNS lookup errors, instead of just a count of these errors (VXV-610)
Test 'dnslookup' will no longer test reverse DNS lookup failures when VC is external (VXV-611)

x.20.819 (expiry date: 2022 Sep 08)
VxVerify2 management username and password decoding changed to keep the username and password pairs consistent from the DB and runtime (VXV-587)
VxVerify2 test 'thump' enhanced to correct thumbprints in server.crt, when using core upgrade profiles (auto-remediation)(VXV-595)
VxVerify3 test 'thump' enhanced use both SHA1 and SHA256 fingerprints and accept a match for either SHA level (VXV-607)
Node Vxtii reports enhanced to add status of: RP4VM, NSX, GPU, Maint-mode, NTP, Unmap:Guest/Fairness & Nameservers (VXV-563)
Test 'vc_size' updated to not run in Core profile 7 (in-family upgrade) (VXV-605)
Test 'ipv4vmk' added to alert if IPv4 is enabled on vmk0, which can cause upgrade problems for 7.0.350+ (VXV-115)

x.20.805 (expiry date: 2022 Aug 25)
Tests 'vibsx, witness, rp4vm, vc_external & vcf_type' will no longer give warnings in core profiles, because this information is listed in the VxTii cluster summary (VXV-581)
DNS lookup functions, which are based on Python socket, have been revised to avoid issues with canonical names (VXV-560)
Test 'bootdisk' updated to warn for include most upgrade profiles, if the node boot drives are not mirrored (VXV-229)

x.20.722 (expiry date: 2022 Aug 14)
VxTii report for nodes has had the iDRAC revision added (VXV-567)
Test 'unmap' added, to check if the vSAN unmap setting has been enabled (VXV-555)
Test 'rancher' amended to check multiple containers with the same label (VXV-566)
Colour scheme for VxTii cluster information changed to cyan (VXV-565)
VLCM status added to the Vx credentials output in vxverify_tests.json (VXV-232)
Fixed issues with VxRM test results, which occur when the marvin site_package cannot be reached (VXV-564)
Reduced unnecessary lines in vxv.log to improve readability (VXV-574)
Test 'bootdisk' updated to exclude all G series nodes (VXV-229)

x.20.715 (expiry date: 2022 Aug 05)
VxTii cluster report added to vxtii.txt, with vCenter and VxRM key information for Support (VXV-502)
The VxTii cluster information will now be echoed to the screen, between the LCM report and the healthcheck table (VXV-565)
Test 'dcism' disabled for VxRail 8.0+, due to change of service name to dellism (VXP-56899)
Test 'df_vc' has disk space warning thresholds increased from 70% to 80% (the failure threshold is still 85%). Mount points with 'archive' or 'backup' in the path are excluded from this test.  (VXV-557)
Test 'op_status' added, to check the size of mysticmanager operation_status DB table (VXV-553)

x.20.708 (expiry date: 2022 Jul 29)
Test 'vc_api' added, to consolidate failure messages for API failures into a single critical event (VXV-554)
Test 'nic_hwi' will now not give a warning for Intel NIC if no target code level is provided. Given that the target code levels with the relevent issue are no longer available, this test should now not trigger for Intel NIC (VXV-552).
Test names containing vrm (short for VxRail Manager), renamed to vxm (also short for VxRail Manager), for consistency (VXV-541).
Query 'adv_mod' added, to validate if the cluster is in a LCM advanced mode state (VXV-279)
* Test 'ds_state' updated to replace test 'dvs_out' (VXV-82)

x.20.630 (expiry date: 2022 Jul 20)
One issue that can cause false alarms for the node tests is a second copy of VxVerify that has been initiated from a different source. To avoid this, VxVerify will check for other recently updated VxVerify logs and will pause, for up to 200 sec, to let the other VxVerify complete (VXV-545)
File naming change for minion and host json files to avoid conflicts with other minions that may be triggered on the same host (VXV-545)
Changes in host file cleanup functions to avoid deleting files from other minions (VXV-545)
Test 'dvs_out' removed from upgrade profiles (VXV-549)
Fix for VCSA tests where SSH errors could just return the status 'True' (VXV-548)
Branding change to replace all Dell EMC references with Dell (VXV-551 & VXP-57991)

x.20.624 (expiry date: 2022 Jul 14)
Test 'dnslookup' will check each VxRM nameserver entry separately, with a forward DNS lookup of the vCenter FQDN (VXV-547)
For non-vSAN nodes, tests that use vSAN commands, such as 'witness', will be bypassed (VXV-544)
Fix for reverse DNS lookup, which can still return an IP instead, since IPv6 support was added in x.20.617 (VXV-543)
Fix for issue in VxV2 VCSA tests where a necessary parameter is missing, causing SSH to fail (VXV-546)
VCSA tests will not give a warning for no root password if there is an external vCenter or the core test profiles are used (VXV-506)
Test 'ip9090' event added for when either the SSL Cert or key file is missing (VXV-542, VXP-49188)

x.20.620 (limited release)
Test 'pconf' adapted to support IPv6, without or with IPv4 (dual stack).  The reverse IPv6 lookup of the bind entry will not be done for IPv6 nodes (VXP-49188)
Adding additional argument error handling, prior to starting the logs (VXV-537)
Fix for overall result of VxRM tests which can mistakenly return a 3 (VXP-49188)

x.20.617 (expiry date: 2022 Jul 07)
Changes to the way node names and the FQDN are used to reduce issues for customers with stale reverse DNS entries (VXV-535)
Tests 'px_vcsa', 'df_vc' & 'dvs_out' changed to give a unified response for VC SSH failures, which can be adjusted according to the test profile (VXV-506 & VXV-533)
Test 'saved_pw' to report a fail for out-of-family upgrades when the settings table encrypted password does not match runtime.properties (VXV-534)
Base64 password support added to VxVerify2, to match VxVerify3. This allows passwords with escape characters to be supplied as arguments, which otherwise would cause problems with the Shell (e.g. -w base64:UGFzc3dvcmQxMjMh) (VXV-518)
Fix in function 'dns_fqdn_ip' for an exception with the error handling string (VXV-539)
Test 'primnodes' excluded from core test profiles (VXV-529)

x.20.610 (expiry date: 2022 Jun 30)
Dual stack IPv4/IPv6 support added to VxVerify3 (VXP-49188)
Test 'mservices' fixed for blank systemctl responses, which indicates a service not running (VXP-54816)
Test 'vc_fqdn' added, which reads VirtualCenter.FQDN from VC mob via pyvomi (VXV-314)
Test 'dns_node' modified to allow IPv6 nameserver entries and to replace the reverse DNS lookup query, with forward lookup queries using each specified nameserver (VXV-121)
Arguments ''--in_family','-i' and '--oo_family','-o' are being removed. The test profile should be determined by the target code level or can be manually specified with the '--number','-n' arguments (VXV-489)
Test 'ntp-node' set to not run for IPv6 dual stack nodes, pending further testing in these environments (VXP-49188)
Test 'vxnode' modified to not run on nodes without iDRAC (VXP-49188)

x.20.530 (expiry date: 2022 Jun 20)
Profiles 6 & 7 added, which include the core upgrade tests only, for use by Dell Support in conjunction with other health-checks.  Note that for customer upgrades, the use of the in and out of family test profiles is still recommended (profiles 1 & 2) (VXV-516).
Added argument -c / --core <target_code>, to activate test profiles 6 or 7 to the specified target code.  This replaces the use of --target for these upgrade use cases (VXV-516).
Launch script 'vxverify.sh' has been updated to prompt for vSphere Administrator credentials (-u & -p arguments), which will be needed for some future tests (VXV-77)
Test 'nic710' has been renamed to 'nic_hwi' and expanded to include checking for combinations of BCM5741x & BCM5750x NIC, which can cause upgrades to fail, if BCM5750x are below firmware '21.85.21.92' (VXP-55093 & VXV-510)
Extra parsing added for entries in configuredHosts, without a valid host name (VXV-521)
Expanded 'hoststatus' test to cover invalid configuredHosts, which would be reported under '_cluster' (VXV-521)
Fix for NVMe drives in VXT, where there is more than one drive per PCI slot number (using different bay/bus numbers) (VXT-515)
Fix for 'dnslookup' to report forward DNS lookup failures, if there are any, instead of reverse failures (VXV-513)
Profile change for 'dnslookup' to not report reverse DNS failures in the core upgrade profiles (6 & 7) (VXV-505)
Profile change for all 'vsh_*' (vSAN Health), to not report in the core upgrade profiles (6 & 7) (VXV-517)
Fix for test profile numbers in VxVerify2, which were not always correctly generated from the target code level (VXV-514)
Additional information from the vxv.log will be saved into the vxverify_tests.json, for ease of searching, such as DNS information and the test profile number (VXV-507 & VXV-509)
In the VxTii report, NIC Slot names have been abbreviated to fit into the table (VXV-511)
In the VxTii report, faults that trigger the 'vxtii_err' health-check, will be included in the 'Recommendations For Support', if there are not already recommendations there from the LC log analysis (VXT-515).
Function 'tag_sfs' added, which logs SFS related Tags on VxRail (VXV-332)
Test 'vc_camode' added, which reads vpxd.certmgmt.mode from VC via pyvomi (vxv2 & vxv3) - VXV-500
* Test 'vc_trust' added for pre 7.0.240, which logs check for valid CRL files and is able to verify VC connection if VC certificate issued by SubCA (VXV-504)

x.20.520 (expiry date: 2022 Jun 12)
TxTii reports in VxVerify 3, will begin with a section for vSphere and VxRail cluster information, before the sections for each node, unless the single node report is specified (VXV-502)
When polling nodes using Python based SSH, a total number of tests completed will be listed, to give a better indication of progress (VXT-330)
Test 'lcm_state' silenced except for API errors and added additional logging (VXV-481)
Test 'ip9090' added certificate for 7.0.350+ mTLS requirement, which fixes handshake failures (VXV-491)
TxTii reports for single CPU models will not longer show the second CPU as: CPU info missing (VXV-389)
Log clearing procedure modified to have more granular error handling to cope better with zip files that the user does not have permission to rename (VXV-508)
Logging for functions prior to log files being opened has been enhanced.  These info. or error events will be cached and then replayed into the log files once they are open (VXV-508)
Test "vr_pw_char" will no longer include warnings for unspecified root passwords, which instead will be a separate warning (VXV-506)

x.20.513 (expiry date: 2022 Jun 05)
Fix for incorrect host results when an older run of VxVerify was left in a sub-directory of the new logging folder (VXV-493)
Test 'qedentv' changed to not apply to upgrade test profiles (VXV-484)
Test 'snoop' restricted to VxVerify3 only, with the VxRail 4.x upgrades being covered by notes in Solve (VXT-579)
Test 'mservices' changed to not report the 'active (exited)' status as a fault, pending further investigation (VXV-480)
Fix for test profile numbers in VxVerify3, which were not always correctly generated from the target code level (VXV-489)
Test 'ip_reserve' added to check for IP addresses that are reserved in specific code levels (VXT-727).
Test 'vxm_cert' fixed for variable referenced before assignment (VXV-490)
Test 'clom' changed to only run for VxRail 4.5 (VXV-126)
Test 'vcsize' changed to identify the 'VMware vCenter Server Appliance' VM from the vmx file or Annotation, rather than the VM name (VXT-744)
Test 'vcsize' removed from test profile 2 (in-family upgrade) (VXV-105)
VxTii memory event action plans updated (VXV-389)
ESXi host test profiles adjusted to make sure only the necessary tests are run (VXV-496)

x.20.506 (expiry date: 2022 May 29)
Change made to the VCSA password testing, to run a bad password character check only if the login fails, not if it logs in successfully (VXT-738).
VM names used for vMotion testing will be trimmed to remove unprintable characters (VXT-731).
Test 'vxnode' removed from upgrade test profiles (VXT-745)
Test 'vcsize' will no longer report a warning if the vCenter Server Appliance VM cannot be found (usually due to it being renamed) (VXT-744)
Test 'dns_node' will not test reverse DNS in upgrade test profiles (VXV-121)
Test 'ntp_node' will not be included in upgrade test profiles (VXT-742)
Test ‘vmk_tag’ adjusted to not give warnings for the management tag being on other vmk for additional profiles (VXT-208)

x.20.429 (expiry date: 2022 May 22)
Test 'bootdisk' added to check Boot drive RAID 1 mirroring (VXT-713).
Test 'dcism' modified to accept the response 'iSM is running' in addition to 'iSM is active (running)' (VXT-719).
Test 'sp_svm' fixed to handle a failed storage profile search for the management VM (VXT-725).
Test 'nic710' modified to take into account the target code level (VXT-439).
Test 'hoststatus' modified for Quanta nodes, which do not have the node name listed in the nodes DB table and therefore reported a DB entry missing (VXT-732).
VxTii node boot drive summary will now show a fault when the RAID 1 status on either drive is not Online, in addition to either drive not being listed as 'OK' (VXT-713)
Summary table changed to clarify invalid test records, caused by unprintable VM names (VXT-731)
Arguments -u and -p are being repurposed to input the VC Administrator user and password, rather than overriding the saved Management user and password (VXT-728)

x.20.413 (expiry date: 2022 May 06)
Test 'ifcfg' added to check the static IP configuration for VxRM (VXT-618).
Added tests 'vc_trust' - test if VXM can establish trusted connection to VC with certificates found in VXM trust folders (and it will log files found which are not in correct DER or PEM format), and certificates retrieved from VC (VXT-525, VXT-526).
Added test 'vxm_cert_check' - test if VXM certificate is: self-signed, FQDN match with ca.cnf if self-signed, can be validated against trust file, has expired (VXT-637).
Change to test 'dcism' to correctly report iSM is not running, rather than not responding (VXT-690).
Change to 'ds_pgroup' to use existing global variables without having to query VC unnecessarily (VXT-694).
Change to vxverify_history.gz archiving to avoid losing the internal vxverify_history.zip suffix (VXT-697).
Change to copyright notice to match the rest of the ADC/radar framework (VXT-699).
Change to 'lcm_status' test as pre 7.0.130 needs authentication to work (VXT-664).
Change to test 'thump', to handle thumbprint separator in 7.0.350+ correctly (VXT-701).
Host JSON filenames will change per release, to avoid conflicts from multiple VxVerify runs (VXT-714).

x.20.329 (expiry date: 2022 Apr 21)
Logging change being phased in to prefix log events with the test name that they are associated with (VXT-668).
Added ESXi HBA driver and firmware levels to the VxTii report (VXT-672).
Added test 'hbadriver' for problematic HBA driver levels on 15G nodes (VXT-670).
Added test 'privileges' which checks the VC management user role privileges (VXT-598).
Added test 'ds_perm' which checks that the vCenter management account has permission at datastore level (VXT-598).
Added test 'rancher' that replaces tests dockr_svc and dockr_ver for 7.0.370+ (VXT-639)
Test 'rp4vm' will return to only giving a warning, now that supported versions of RecoverPoint are available for VxRail 7.0.3xx (VXT-682).
Consolidated VxVerify log bundle will also be saved to a single file (vxverify_history.gz), for ease of collection (VXT-660).
Change behaviour for node1 argument (-a node1=...), to run no minions if its specified, but does not closely match any node name (VXT-683).
Fix for reporting in test 'mservice' (VXT-680).

x.20.318 (expiry date: 2022 Apr 10)
Change to 7.x microservice commands to account for variations in the ip command between releases (VXT-651).
Timeout added for the total time that all microservice queries are allowed (VXT-652).
Change to SSH in VxV3 to get public keys from hosts, rather than using the VxRM known_hosts keys (VXT-636).
Fix for test 'vc_ntp' to fail more clearly when DO is not responding to a '{vc {currentTime } }' query (VXT-662).
Added logging of additional config_service data, that is not yet used, as the basis of a health-check (VXT-566).
Test 'dohost' added to check the validity of the do-host package records (VXT-625). While this test is in beta, all responses will be 0-Pass.

x.20.309 (expiry date: 2022 Apr 01)
Fix for 'dns_xref', which had unclear log entries and did not correctly read punctuation correctly in the DB entry (VXT-644)
Fix for ‘dcism’ to exclude any nodes without iDRAC (VXT-642)
To prevent the test 'mservices' from incorrectly flagging up the rabbitmq having a status of active (exited), rabbitmq status will not be tested until its tolerable states are better documented (VXT-643)
Critical test responses for Python exceptions will instead return the status 'Py Crash', to make it clearer that these need a VXT to be raised, but by themselves do not prevent an upgrade (VXT-641).
Extra large writing added for critical events in summary table (VXT-641)
When critical failures occur, nodes that do not have the critical failures will also show a warning to emphasise that nothing has a clean bill of health when some tests may not have been run (VXT-641).  For example, when saved passwords are wrong, testing is aborted as a critical alert.

x.20.304 (expiry date: 2022 Mar 27).
Test 'mservices' added for running services on management VM, such as runjars (VXT-616 & VXT-429).
Fix for Python based SSH to set the ESXi SSH status back to the same Running/Stopped value it was at the start of VxVerify (VXT-632).
Zip log bundle renaming has been changed to find multiple vxverify zip bundles and renumber them all as vxv_previous-0?.zip (VXT-633).
Test 'ip9090' will not log failures for VxRail 7.0.350+ due to an SSL issue that is still under investigation (VXT-580)
Tests 'pwe_root' & 'pwe_mystic' are modified to not run for other users which would not have permissions to run the chage commands (VXT-634)

x.20.225 (expiry date: 2022 Mar 18)
Layout change for summary table to use longer test result status and fewer KB digits (VXT-581)
Tests 'df_tmp' & 'in_tmp' have free space warning thresholds increased to 70%, for /tmp on each node that is used for VCF (otherwise it is 20%) (VXT-577).
Test 'dns_xref' can produce false alarms if internal DNS is used, so having no entries in resolv.conf will no longer produce a test failure (VXT-549)
Test 'vxnode' added to check the vxnode.config file on VxRail 7.0.240+ nodes (VXT-516)
Test 'sys_vm' added to compare the VxRM VM information from the Management DB and vCenter (VXT-530).

x.20.221 (expiry date: 2022 Mar 14)
VxVerify2 has revised Python package importing to prevent errors on VxRail 4.5, which is missing packages that are necessary for new tests (VXT-611).
Added fallback option to internal queries for VxVerify3 if the Docker option fails (VXT-601).

x.20.218 (expiry date: 2022 Mar 11)
API calls for VxVerify3 changed to allow host based testing to run from the mystic user.  Many VC and VxRM based tests still require root permissions to run and will fail when run from mystic (VXT-585).
Timeouts added to Shell commands to prevent VxVerify stalling when there are insufficient permissions (VXT-585).
Added test 'snoop_dvs' to check that the DVS multicast-filtering-mode is set to 'snooping' (VXT-579).
Added new event to 'esx_vers' for when a node is missing version and build information in the VxRM DB, which can happen for converted VxRack VCF (VXT-491).
Added new event to 'esx_vers' to state if no valid host records are found, as opposed to no valid host results being received (VXT-491).
Fix for issue in test 'root_user', in VCF environments, that can return a critical error (VXT-590)

x.20.211 (expiry date: 2022 Mar 03)
Test 'dcism' changed to give a fail if the dcism-netmon-watchdog query fails (VXT-570).
LC log queries are reduced for upgrade health-checks to reduce each minion takes to run (VXT-571).
Wording changed after the VxVerify report to list all the saved zip files, including those from previous runs, requesting that they be uploaded to the SR.
Test 'vxrver' added to verify the vxrail_version listed in the config service (KB 196060 & VXT-530).
Test 'dns_xref' can produce false alarms if internal DNS is used so temporarily setting some responses as a pass until we have more use cases coded (VXT-549 & VXT-546)

x.20.205 (expiry date: 2022 Feb 23)
Fixed an error in VxVerify3 that produced the event: not all arguments converted during string formatting (VXEE-9697)
Test 'dns_xref' added for Nameserver comparison between DB and resolv.conf, to make sure no entries have been manually added (VXT-549 & VXT-546)
Test 'vmk-tag' changed to tolerate alternative management vmk, other than for VCF. A fail will still result if there is no management vmk (VXT-370)
Test 'clu_hemon' added to verify the VxRail Cluster Health Monitoring Status (VXT-515)
Fixed expiry date not being passed correctly to the completed JSON (VXT-557)
ESXi bootbank tests modified to make it a failure if imgdb.tgz is missing (VXT-562).
SSH error handling improved with more specific events in vxv.log replacing some exception traces (VXT-547)

x.20.128 (expiry date: 2022 Feb 16)
Added test profile 5 for post-upgrade healthchecks (including unsuccessful upgrades) (VXT-555).
Added test 'sp_svm' added to check that the VxRM Storage Policy is 'VXRAIL-SYSTEM-STORAGE-PROFILE' (VXT-530)
Added test 'dns_xref' to cross reference the DNS settings on VxRM with each of the nodes (VXT-546)
Added further canonical checking for user arguments, such as the logging path (VXP-49452).
Changes made to Python SSH timeout values (VXT-547).
Reduced the number of df queries used by the ESXi minion by caching the result of a single query (VXT-370)
Changing test 'vmk_tag' to apply to test profiles 0, 1 & 5 (VXT-370).

x.20.121 (expiry date: 2022 Feb 09)
Test 'root_user' added for VCF clusters, to detect the user root being used by VxRM for ESXi nodes, instead of a  management user (VXT-504)
Test 'lcm_state' added to check the current LCM Upgrade status (VXT-414).
Test 'tag_clust' added to verify the VxRail Cluster Tag (VXT-485).
Modified test 'IP9090' to ignore nodes that have not yet been upgraded to 7.x, even if VxRM is 7.x (VXT-539).
Improvements to the Python SSH/SFTP for completed JSON to match the Shell based commands (VXT-523).
VxV3 'df_root' and 'df_store2' tests rewritten to use Python, rather than Shell df commands (VXP-23912).

x.20.118 (expiry date: 2022 Feb 06)
Fix for issue with System VM naming that could cause the results of one node to be missing from the output table (VXT-531).

x.20.114 (expiry date: 2022 Feb 02)
Improvements to the minion polling for completed JSON to avoid stale file search results from the node causing the JSON upload to eventually timeout (VXT-523).
Added argument '-m' or '--map', which will generate a VM-UUID JSON file, for use by VxStat for performance analysis of stats.db files (VXT-514).
Added functions to read product names from the config service on VxRM and from IPMI on ESXi (VXP-48830).
No valid hosts returned from VxRM DO or DB, will return a critical failure and cut short any further minion actions (VXT-519).

x.20.107 (expiry date: 2022 Jan 26)
Improved VxTii node package now contains minions for both Python 3.8 (VxRail 7.0.200+) and 3.5 (other releases).
Changes to the product naming in logging and data structures (VXP-48830).
Added an additional flush for log data, before the minion logs are added to the zip file (VXT-207).
VxVerify 2 & 3 global credentials renamed for consistency between the two code streams (VXP-48830).
Reformatted the vSAN healthcheck in the minion txt file, to remove unnecessary characters (VXT-460).
Adding extra checks on arguments to prevent invalid user arguments being accepted (VXT-502).
Retiring test 'vc_build', which is also covered by the 'vc_drift' test (VXT-391).

... Update notes from previous releases prior to this are archived.
