# ----------------------------------------------------------------------------------------------------------
# FILE         : VxRail_STIG.ps1
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : Main script for hardening the VxRail Manager system
# DISCLAIMER   : Please refer to the VxRail STIG Hardening Guide for details on what is included
# ----------------------------------------------------------------------------------------------------------
#
# Change log - STIG 2.2.000
#
# VXP-73008 - Enable SSH post VCSA reboot if found disabled 
# VXP-72915 - Major/minor version issue fixed for the function CheckPscpPlink
# VXP-72829 - Fix password check over SSH
# VXP-72829 - Failed process count not being reflected accurately for vCenter rules
# VXP-72773 - Function checkGivenPasswordForSSH modified to accept (y) for SSH fingerprint and PIP install output message suppressed
# VXP-72251 - Added functions (checkPortStatus and checkGivenPasswordForSSH) to verify SSH port and given credential 
# VXP-71401 - VXSEC504 V-256736 Lookup Service must set the secure flag for cookies.
# VXP-71398 - VXSEC503 V-256723 Lookup Service must fail to a known safe state if system initialization fails, shutdown fails, or aborts fail.
# VXP-72197 - DSX06_0005 V-256557 The Photon operating system must configure sshd to limit the number of allowed login attempts per connection.
# VXP-71397 - VXSEC502 V-256710 Lookup Service must record user access in a format that enables monitoring of remote access.
# VXP-71396 - VXSEC501 V-256709 Lookup Service must protect cookies from cross-site scripting (XSS).
# VXP-72090 - V-256513 DSX06_0003 The Photon operating system must configure sshd to disconnect idle Secure Shell (SSH) sessions.
# VXP-72112 - DSX06_0004 V-256527  The Photon operating system must configure auditd to keep five rotated log files.
# VXP-72090 - DSX06_0003 V-256513  The Photon operating system must configure sshd to disconnect idle Secure Shell (SSH) sessions.
# VXP-71400 - VXSEC500 V-256728 Lookup Service must be configured to hide the server version.
# VXP-71399 - VXSEC499 V-256725 Lookup Service must set URIEncoding to UTF-8.
# VXP-71138 - VXSEC498 V-256712 Lookup Service log files must only be accessible by privileged users.
# VXP-71147 - VXSEC497 V-256765	The Security Token Service must use the "setCharacterEncodingFilter" filter.
# VXP-71145 - VXSEC496 V-256762 The Security Token Service must fail to a known safe state if system initialization fails, shutdown fails, or aborts fail.
# VXP-71633 - DSX06_0002 V-256507  The Photon operating system must enforce a minimum eight-character password length
# VXP-71144 - VXSEC495 V-256749 The Security Token Service must record user access in a format that enables monitoring of remote access.
# VXP-71146 - VXSEC494 V-256764 The Security Token Service must set "URIEncoding" to UTF-8.
# VXP-71160 - DSX06_0001 V-256480  Photon OS Rule - Standard Mandatory DOD Notice and Consent Banner before granting Secure Shell (SSH) access 
# VXP-71330 - Added function (CopyFileToVM) to copy a file to VM
# VXP-71331 - Added function (RestartService) to restart service for a given vm
# VXP-70747 - New Python Script and new funtions added to Monitor the VxRail Cluster Health Status Until Ok upon reboot 
# VXP-71157 - Replaced function CheckPlink with CheckPscpPlink
# VXP-70997 - Added function Start-Sleep to display a progress bar with the seconds counting down 
# VXP-68779 - Clean up DoD STIG VIB verbiage.
# VXP-69098 - Introduced enhancement to capture meaningful error in catch block
# VXP-68794 - Investigate and provide further details on port group values
# VXP-69305 - VXSEC493 V-256592 VMware Postgres log files must contain required fields
#
# Change log - STIG 2.1.001
# VXP-69137 - Prevent LCM upload/extract and iSM issue.
#
# Change log - STIG 2.1.000
# VXP-68259 - Prevent using root for management/SSH of nodes.
# VXP-67558 - Automation of VxRail Manager VM Startup procedure
# VXP-67696 - Updated the VxRail Manager Hardening Instructions to include py sub-directory
# VXP-60941 - Fixed two code defects, Removed "Continue" parameter from the catch statement and re-set "$outcome" value at the beginning of the loop
# VXP-67244 - Added Menu option to choose different Lockdown Mode
# VXP-58391 - Automation of vCenter Server VM Startup procedure 
# VXP-67108 - Log directory default path updated to C:\
# VXP-60939 - Enable calling script in Debug mode
# VXP-65102 - Output PS error when STIG first API call fails, in function GetVxRailVersion
# VXP-66272 - added - ESXI70000084, ESXI70000085, ESXI70000087, ESXI70000091, ESXI70000097, ESXI70000274
#			  Tweaked and added - ESXI70000094, ESXI70000095
#			  removed - VXSEC406 V-239270 ESXI-70-000014, VXSEC409 V-239273 ESXI-70-000018, VXSEC410 V-239274 ESXI-70-000019,
#						VXSEC415 V-239279 ESXI-70-000024, VXSEC424 V-239288 ESXI-70-000033, VXSEC468 N/A ESXI-70-000080
# VXP-66711 - Fix: enable hardening new nodes
# VXP-66486 - consume VMWare vCenter DRAFT V1R4 STIG Version Remediation script changes
# VXP-66902 - REMOVE DUPLICATES - 7.0 vCenter VMWare script
# VXP-66484 - Integrate 7.0 VM VMWare script changes
# VXP-67115 - VMware Virtual Machine (VM) Script changes per DISA 7.0 Official V1R1 publication
# VXP-67141 - VMware ESXi Script changes per DISA 7.0 Official V1R1 publication
# VXP-67142 - VMware vCenter Script changes per DISA 7.0 Official V1R1 publication
#
# Change log - STIG 2.0.001
# VXP-56604 - remove existing VIB Installation code
#			- Revert and keep existing VIB Installation code but applicable ONLY for 4.x branch
# VXP-56644 - remove any existing ESXi Dod vibs already installed on the system
# 			- The ESXi host SSH daemon must not allow host-based authentication
#			- remove the VMWare ESXi DoD STIG VIB on any VxRail version 7.
# VXP-56757 - (Partial) Add advanced param fails in 7.0U3d/7.0.400 when VM is powered on
# VXP-57651 - ESXI-70-000012 - The ESXi host SSH daemon must ignore .rhosts files
# VXP-57706 - Implemented ESXI-70-000014, ESXI-70-000015, ESXI-70-000016, ESXI-70-000020,
# 			      ESXI-70-000021, ESXI-70-000022, ESXI-70-000023, ESXI-70-000025, ESXI-70-000082
# VXP-57642 - PowerCLI command Get-View not working in vSphere 7.0U3d
# VXP-57763 - ESXI-70-000026, ESXI-70-000027 SSHd config implementations without VIB
# VXP-57708 - ESXI-70-000008 - Set banner in advanced param 'Config.Etc.issue'
# VXP-57985 - ESXI-70-000010 - The ESXi host SSH daemon must use FIPS 140-2 validated cryptographic modules...
# VXP-58115 - ESXI-70-000033 - The password hashes stored on the ESXi host must have been generated using a FIPS 140-2 approved cryptographic hashing algorithm
# VXP-58151 - ESXI-70-000009 - The ESXi host SSH daemon must be configured with the DoD logon banner
# VXP-57471 - SSO Admin module check added for vCenter hardening
#
# Change log - STIG 2.0.000
# VXP-54011 - VMware KB 88055- Prevent hardening if on affected VxRail versions, until VMware has work-around.
# VXP-50810 - Added rule for STIG ID: VMCH-70-000028 Prevent DirectPath I/O (pciPassthru)
# VXP-43537 - Use VMware's vCenter STIG PowerShell script when on vSphere 7.x platform
# VXP-43538 - Use VMware's Virtual Machines STIG PowerShell script
# VXP-38033 - Add vxsec map table and map function
# VXP-50379 - Use VMware's ESXi STIG 7.0 script (instead of 6.7) on a vSphere 7.x platform
# VXP-49343 - Processed results of beta2 3rd party testing.
# VXP-48193 - Processed results of beta1 3rd party testing.
# VXP-37954 - Using scripts from VMware's git repo dod-compliance-and-automation. The used scripts, including their 
#             full submodule path, are copied to subdirectory vmware-stig.
#             (The used version/commit of the submodule is documented in README.txt)
#             This introduces VMware STIG Remediation for VMware components, with the following notes:
#             - using only for ESXi hosts yet (not using VMware scripts for vCenter and VMs yet)
#             - this required some customization of the (copied) VMware ESXi hosts script
#             - lockdown function not performed by VMware ESXi script (remains unchanged in this script)
#             - added use of environment variable VXRAILSTIGDEBUG to enable extra output
#
# Change log - STIG 1.6.000
# - Added GetPrerunData function
# - Modified the way the pre-run data is collected by using the GetPrerunData function
# - Fixed bug in VIB installation function
# - Added logic to distinguish different VxRail versions in order for he script to support both 4.x (4.7.300 and newer) and 7.x (7.0.130 and newer)
# - Removed prompt for user account to access VxRail Manager. The script will use only "mystic" for access.
# - Fixed bug: undeclared variable $script:SSHUser found in function SetAdvancedHostParam
#
# Change log - STIG 1.5.001
# - V-39458, V-64057, V-64069, V-64071, V-64091 and V-64107 - Removed - controls no longer applicable
# - V-64073 - Updated - renamed to V-94595
# - V-64111 - Updated - renamed to V-94629
#
# Change log - STIG 1.5.000
# - New major release - Please refer to the VxRail STIG Hardening Guide for details on what is included in this release.
#
#
#
# ----------------------------------------------------------------------------------------------------------
param (
    [switch]$DEBUGSWITCH = $false
)

$VxRailPackageVersion = "2.2.000"

# Setting a default encoding of UTF-8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

# ENABLING DEBUG MODE:
# Debug mode for the script can be activated in 3 ways:
# 1. Call the script using the flag -Debug.
# 2. Set PowerShell Preference Variable $DebugPreference to 'Continue' before calling the script.
# 3. First set environment variable VXRAILSTIGDEBUG to true and then run the script.

if ( $DEBUGSWITCH -ne $true ) {
    # not called with -Debug flag; check other options
    if ( $DebugPreference -eq 'Continue' ) {
        # Using PowerShell Preference Variable
        $DEBUGSWITCH = $true
    } else {
        # Take the debug switch value from environment variable VXRAILSTIGDEBUG
        # (To set this from the PowerShell CLI, type: $Env:VXRAILSTIGDEBUG = $true)
        # Note that the result will be a variable of type String ('True') and not boolean.
        $DEBUGSWITCH=$Env:VXRAILSTIGDEBUG
    }
} 


# Removes all server connections except the last established one. 
# If no target servers are specified, cmdlets run only on the last connected server.
Set-PowerCLIConfiguration -DefaultVIServerMode single -Confirm:$false > $null

# ----------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------
#
############################################################################
# Start of Logging Functions
############################################################################
#########################################################
# FUNCTION: GetFolderForLogfile
# PURPOSE: Allow user to choose a folder where the logfile will be written.
# PARAMETERS: None.
#########################################################
function GetFolderForLogfile { 
	Write-Host
	Write-Host "Please select a directory where the logfile can be written..."

	[void] [System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
	$FolderBrowserDialog = New-Object System.Windows.Forms.FolderBrowserDialog 
	[void] $FolderBrowserDialog.ShowDialog()

	$script:LogDir = $FolderBrowserDialog.SelectedPath # will be used in Write-Log()
	if(!$script:LogDir){$script:LogDir = "C:\"}	

	Write-Host "Selected logfile directory is $script:LogDir" -ForegroundColor Green
}

<#
.Synopsis
   Write-Log writes a message to a specified log file with the current time stamp.
.DESCRIPTION
   The Write-Log function is designed to add logging capability to other scripts.
   In addition to writing output and/or verbose you can write to a log file for
   later debugging.
.NOTES
   Originally created by: Jason Wasser @wasserja
   Modified for VxRail to output (to Host and log) debug messages based on the value
   of environment variable VXRAILSTIGDEBUG being True or False.

   Changelog:
    * Code simplification and clarification - thanks to @juneb_get_help
    * Added documentation.
    * Renamed LogPath parameter to Path to keep it standard - thanks to @JeffHicks
    * Revised the Force switch to work as it should - thanks to @JeffHicks

   To Do:
    * Add error handling if trying to create a log file in a inaccessible location.
    * Add ability to write $Message to $Verbose or $Error pipelines to eliminate
      duplicates.
.PARAMETER Message
   Message is the content that you wish to add to the log file. 
.PARAMETER Path
   The path to the log file to which you would like to write. By default the function will 
   create the path and file if it does not exist. 
.PARAMETER Level
   Specify the criticality of the log information being written to the log (i.e. Debug, Error, Warning, Informational)
.PARAMETER NoClobber
   Use NoClobber if you do not wish to overwrite an existing file.
.EXAMPLE
   Write-Log -Message 'Log message' 
   Writes the message to c:\Logs\PowerShellLog.log.
.EXAMPLE
   Write-Log -Message 'Restarting Server.' -Path c:\Logs\Scriptoutput.log
   Writes the content to the specified log file and creates the path and file specified. 
.EXAMPLE
   Write-Log -Message 'Folder does not exist.' -Path c:\Logs\Script.log -Level Error
   Writes the message to the specified log file as an error message, and writes the message to the error pipeline.
.LINK
   https://gallery.technet.microsoft.com/scriptcenter/Write-Log-PowerShell-999c32d0
#>
function Write-Log {
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$false,
                   ValueFromPipeline=$true)]
                   #ValueFromPipelineByPropertyName=$true)]
        #[ValidateNotNullOrEmpty()]
        [Alias("LogContent")]
        [string]$Message,

        [Parameter(Mandatory=$false)]
        [Alias('LogPath')]
		[string]$Path=$script:LogFile,
		
        [Parameter(Mandatory=$false)]
        [ValidateSet("Debug","Error","Warn","Info")]
        [string]$Level="Info",

        [Parameter(Mandatory = $false)]
        [string]$VulnerabilityId,

        [Parameter(Mandatory = $false)]
        [string]$Result,

        [Parameter(Mandatory=$false)]
        [switch]$NoClobber
    )

    Begin
    {
        # Set VerbosePreference to Continue so that verbose messages are displayed.
        $VerbosePreference = 'None'
    }
    Process
    {
		# If it's a debug message and the debug switch is not set then skip this message
		if ( ($Level -eq 'Debug') -and ($DEBUGSWITCH -ne $True) ) {
			return
		}

        # If the file already exists and NoClobber was specified, do not write to the log.
        if ((Test-Path $Path) -AND $NoClobber) {
            Write-Error "Log file $Path already exists, and you specified NoClobber. Either delete the file or specify a different name."
            Return
            }

        # If attempting to write to a log file in a folder/path that doesn't exist create the file including the path.
        elseif (!(Test-Path $Path)) {
            Write-Verbose "Creating $Path."
            $NewLogFile = New-Item $Path -Force -ItemType File
            }

        else {
            # Nothing to see here yet.
            }

        # Format Date for our Log File
        $FormattedDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

        # Write message to error, warning, or verbose pipeline and specify $LevelText
        switch ($Level) {
            'Debug' {
                Write-Verbose $Message
                $LevelText = 'DEBUG:'
                }
            'Error' {
                Write-Error $Message -ErrorAction SilentlyContinue
                $LevelText = 'ERROR:'
                }
            'Warn' {
                Write-Warning $Message
                $LevelText = 'WARNING:'
                }
            'Info' {
                Write-Verbose $Message
                $LevelText = 'INFO:'
                }
            }

        #Vulnerability ID
        $VulnerabilityId = $VulnID

        #Result
        $Result = $Outcome
        
        # Write log entry to $Path
		"$FormattedDate `t$LevelText `t$VulnerabilityId `t$Result `t$Message" | Out-File -FilePath $Path -Append
		
		# Write to Host as well if Debug message
		if ( $Level -eq 'Debug' ) { Write-Host "$LevelText `t$Message" }
    }
    End
    {
    }
}

#########################################################
# FUNCTION: Write-Host-Log
# PURPOSE: Write a message to both screen and the logfile.
# PARAMETERS: Outcome value [optional]
#########################################################
function Write-Host-Log ($_msg, $_outcome) {

    if ($_outcome) {
        $Outcome = $_outcome
    } else {
        $Outcome = $script:OutcomeNA
    }

    Write-Host $_msg
    Write-Log -message $_msg
}

#########################################################
# FUNCTION: writeError
# PURPOSE: Write a meaningful error message in catch block.
# PARAMETERS: None.
#########################################################
function writeError {
	$linenr = $_.InvocationInfo.ScriptLineNumber
	$msg1 = "Error at line: ${linenr}"
	$msg2 = "Issue description: $_"
	Write-Log -Level 'Error' -Message "$msg1"
	Write-Log -Level 'Error' -Message "$msg2"
	Write-Host "$msg1 `n$msg2" -BackgroundColor Black -ForegroundColor Red
}

#########################################################
# FUNCTION: Get-FunctionName
# PURPOSE: Output the name of the function that is called.
#          Only output if the script is run in debug mode.
# PARAMETERS: None.
#########################################################
function Get-FunctionName ([int]$StackNumber = 1) {
	if ($DEBUGSWITCH -eq $True) {
		$funcName = $(Get-PSCallStack)[$StackNumber].FunctionName
		Write-Log -Level 'Debug' "Function $funcName"
	}
}

############################################################################
# End of Logging Functions
############################################################################

##############################################################################################
# Setup the script/logfile metadata
##############################################################################################
$SCRIPT_DIR=$pwd.Path
$pyOfflineModules="$SCRIPT_DIR\wheelhouse.tar.gz"  # Required Offline Python Modules zip file
$pyInstallModules="$SCRIPT_DIR\wheelhouse\requirements.txt"  # Required Python Modules list 
$PY_DIR="$SCRIPT_DIR\py"                    # python script location

# Python subscripts
# - a function module can be called for different rules
# - a rule module is only called for one particular rule
$MonitorVxRailClusterHealthUntilOK= "$PY_DIR\MonitorVxRailClusterHealthUntilOK.py"               # function module

######################
# Custom Declaration #
######################
# PlinkPath and PscpPath: How to use:
# - The script uses the following default values:
#   - Environment Path to PuTTY: C:\Program Files\PuTTY\
#   - The PuTTY directory contains Plink.exe and pscp.exe
# - Optional Modifications:
#   - If Plink.exe, pscp.exe or PuTTY are not in the C:\Program Files\PuTTY\ path,
#     change the value of $script:PlinkPath or $script:PscpPath to the appropriate path,
#     and make sure that Plink.exe and pscp.exe can still function properly by trying to execute it in PowerShell.
$script:PlinkPath = "C:\Program Files\PuTTY\Plink.exe"
$script:PscpPath = "C:\Program Files\PuTTY\pscp.exe"

# Disable NetFlow on all port groups; set to false if user prefers it enabled
$script:VCSA70000016disablepgs=$true 

############################################################################
# Used in log file name
$STIGStartTimestamp=Get-Date -Format "yyyy-MM-dd_HHmm"

# Relating to prereq items and versions
$SSOAdminModuleName="VMware.vSphere.SSOAdmin"
$powerCLIModuleName="VMware.PowerCLI"
$powerCLIMajorVersion="12"
$powerCLIMinorVersion="5"
$script:powerCLIVersion
$plinkMajorVersion="0"
$plinkMinorVersion="76"
$pscpMajorVersion="0"
$pscpMinorVersion="76"

# Rule vuln-id mapping related
$script:vxSecRow # object returned by the mapping function, from the mapping table, for one rule/vxsec-id

# Information to access VxRail Manager: FQDN, username and password
$script:VxMHasInternalDNS = $false
$script:VxMFQDN
$script:VxMSSHUser = "mystic"
$script:VxMSecurePassword
$script:VxRailVersion
$script:VxRailMajorVersion
$script:VxRailMinorVersion
$script:vCenterCredentials
$script:vCAdmUser
$script:vCAdmSecPass
$script:vCRootSecPass

# Pre-run data for script workflow
$script:PrerunData

# Information to access VxRail ESXi Nodes: username and password
$script:ESXiManagementAccount
$script:ESXiSSHUser
$script:ESXiSecurePassword
$script:vmESXiHost

# 
$script:VxRailDeployedVC = $false
$script:vCenter # string name
$script:VC # connected object
$script:dvs # DV switches object
$script:dvpg # DV PortGroups object
$script:Cluster
$script:VMHosts
$script:VMHostsSSHOn
$script:VMNames
$script:otherVMNames
$script:VxRailManagerVMName
$script:VCVMName
$script:PSCVMName

# Services
$script:NTPServers
$script:SyslogServers

$script:vibInstallYN
$script:ntpConfigYN
$script:syslogConfigYN
$script:newNTPServers
$script:newSyslogServers

# Misc settings:
$script:VMShutdownMonitorSleep = 30 # seconds
$script:vxrailBootMonitorInitialSleep = 120 # seconds
$script:MonitorVxRailClusterHealthInitialSleep = 60 # seconds

# Setting flag to $true in respective rules if service restart required
$script:sshdServiceRestartFlag = $false
$script:stsServiceRestartFlag = $false
$script:lookupServiceRestartFlag = $false

# vCSA Services Restart Command variables
$script:sshdServiceRestartCommand = 'systemctl restart sshd.service'
$script:stsServiceRestartCommand = "vmon-cli --restart sts"
$script:lookupServiceRestartCommand = 'vmon-cli --restart lookupsvc'
$script:auditdServiceStartCommand = "systemctl start auditd"

# Logging
$script:VulnIdNA  = "--"
$script:OutcomeNA = "--"

# VxRM shell script
$vxmScriptFileName = "VxRail_STIG_VxRManager.sh"

# ESXi File Paths
$script:ESXisshdConfigFilePath = '/etc/ssh/sshd_config'
$script:ESXipasswdFilePath = '/etc/pam.d/passwd'
$script:ESXiIssueFilePath = '/etc/issue'

#vCSA File Paths
$script:vCSAPamPasswordFilePath = '/etc/pam.d/system-password'
$script:vCSAAppliancePasswordFilePath = '/etc/applmgmt/appliance/system-password'
$script:vCenterUsrLibVmwareSsoStsConfServerXML  = '/usr/lib/vmware-sso/vmware-sts/conf/server.xml'
$script:vCenterVmwareLookupConfServerXML  = '/usr/lib/vmware-lookupsvc/conf/server.xml'
$script:vCenterUsrLibVmwareSsoStsConfCatalinaProperties = "/usr/lib/vmware-sso/vmware-sts/conf/catalina.properties"
$script:vCentersshdConfigFilePath = '/etc/ssh/sshd_config'
$script:vCSALookupsvcFilePath = '/var/log/vmware/lookupsvc/'
$script:vCenterVMwareLookupConfContextXML = '/usr/lib/vmware-lookupsvc/conf/context.xml'
$script:vCenterauditConfigFilePath = '/etc/audit/auditd.conf'
$script:vCenterUsrLibVMwareLookupsvcConfCatalinaProperties = "/usr/lib/vmware-lookupsvc/conf/catalina.properties"

# VMware DoD Remediation scripts
$VMware67STIGESXiScript="$PSScriptRoot\vmware-stig\vsphere\6.7\vsphere\powercli\VMware_vSphere_6.7_STIG_ESXi_Remediation-VxRail_STIG.ps1"
# No VMware67 STIG VC script is available, as it had no sso-admin module yet in 6.7
# All VMware67 STIG VM rules are included in this script itself
$VMware70STIGESXiScript="$PSScriptRoot\vmware-stig\vsphere\7.0\vsphere\powercli\VMware_vSphere_7.0_STIG_ESXi_Remediation-VxRail_STIG.ps1"
$VMware70STIGvCScript="$PSScriptRoot\vmware-stig\vsphere\7.0\vsphere\powercli\VMware_vSphere_7.0_STIG_vCenter_Remediation-VxRail_STIG.ps1"
# All VMware70 STIG VM rules are included in this script itself

# VMware vCenter Remediation Python Script
$VxRailSTIGLoggingFile = "VxRailSTIGLogging.py"
$setKeyOfElementAttributeInXMLfile = "setKeyOfElementAttributeInXMLfile.py"
$setCharacterEncodingFilterFile = "setCharacterEncodingFilter.py"
$setSecureFlagForCookiesLookupSvcFile = "setSecureFlagForCookiesLookupSvc.py"

$VxRailSTIGLoggingFileLocal = "$PY_DIR\$VxRailSTIGLoggingFile"
$setKeyOfElementAttributeInXMLfileLocal = "$PY_DIR\$setKeyOfElementAttributeInXMLfile"
$setCharacterEncodingFilterFileLocal = "$PY_DIR\$setCharacterEncodingFilterFile"
$setSecureFlagForCookiesLookupSvcFileLocal = "$PY_DIR\$setSecureFlagForCookiesLookupSvcFile"

#Destination file path to copy local python file
$VxRailSTIGLoggingFileRemote = "/tmp/$VxRailSTIGLoggingFile"
$setKeyOfElementAttributeInXMLfileRemote = "/tmp/$setKeyOfElementAttributeInXMLfile"
$setCharacterEncodingFilterFileRemote = "/tmp/$setCharacterEncodingFilterFile"
$setSecureFlagForCookiesLookupSvcFileRemote = "/tmp/$setSecureFlagForCookiesLookupSvcFile"

#/etc/profile is used to load the system-wide profile script in the current shell session.
$script:etcProfile = ". /etc/profile"  

# These vars will be assigned the correct 67 or 70 value, after getting the VxRail version
$script:VMwareSTIGESXiScript
$script:VMwareSTIGvCScript

# The VIB path is set in GetVIBFile and used in InstallVIB
$script:VIBPATH

# VxRail ulitilizes custom attributes as indicators of hardening status of individual components 
# relevant to the VxRail depoyment and in the applicable scope of the hardening guide.
# The applicable components in the current guide include:
# 1. vCenter
# 2. ESXi nodes
# 3. VxRail Manager VM + OS
# 4. VCS VM (only if deployed by VxRail)
# 5. PSC VM (only if deployed by VxRail)
#
# VxRail uses the following target types for the custom attributes:
# 1. Cluster for vCenter custom attributes
# 2. VMHost for ESXi nodes custom attributes
# 3. VirtualMachine for VMs custom attributes
#
# The custom attributes used by VxRail include:
# 1. vxrail_hardening_package_version
# 2. vxrail_hardening_date_hardened
# 3. vxrail_hardening_standard
# 4. vxrail_hardening_history

$script:VxRailTargetType = "Cluster"
$script:NodeTargetType = "VMHost"
$script:VMTargetType = "VirtualMachine"

$script:caPackageVersion = "VxRail_Hardening_Package_Version"
$script:caDateHardened = "VxRail_Hardening_Date"
$script:caStandard = "VxRail_Hardening_Standard"
$script:caHistory = "VxRail_Hardening_History"

$script:caVxMPackageVersion = "VxRail_Manager_Hardening_Package_Version"
$script:caVxMDateHardened = "VxRail_Manager_Hardening_Date"
$script:caVxMStandard = "VxRail_Manager_Hardening_Standard"
$script:caVxMHistory = "VxRail_Manager_Hardening_History"

$script:caPackageVersionValue = "VxRail Hardening v$VxRailPackageVersion"
$script:caDateHardenedValue = Get-Date -Format "MM/dd/yyyy HH:mm:ss"
$script:caStandardValue = "STIG"
$script:caHistoryValue = ""
# ----------------------------------------------------------------------------------------------------------

# Mapping table construction
# The code below the table will put this into an array of mapping objects.
# This array will then be used to retrieve a mapping for a given vxsec-id.
# Columns:
# - vxsecid   = internal, meaningless id, that is common to a rule (which can occur in any of STIG 6.7 and/or 7.0)
# - enabled   = is the rule enabled (='Y') or disabled (<>'Y')
# - vulnid67  = vuln-id of rule in STIG vSphere 6.7
# - vulnid70  = vuln-id of rule in STIG vSphere 7.0
# - vulntitle = STIG rule title
# Rules in both STIG 6.7 and 7.0 will have all columns populated with a value.
# Rules NOT in 7.0 will have vulnid70 set to "".
# Rules NEW in 7.0 will have vulnid67 set to "".
# Since the 7.0 STIG is still draft at the point of writing this, the rules' vuln-ids are still "draft".
# The (assumed future) vuln-id for those rules is derived from the STIG rule-id.
# Some new 7.0 rules have no rule-id at all yet, in which case the vuln-id is set to the stig-id value.
#
$mapColumnTitles = @("vxsecid", "enabled","vulnid67", "vulnid70", "vulntitle")
$mapDataCells = @(
	# VIRTUAL MACHINES
	"VXSEC301","Y","V-239332","V-256450","Copy operations must be disabled on the virtual machine (VM).",
	"VXSEC302","Y","V-239333","V-256451","Drag and drop operations must be disabled on the virtual machine (VM).",
	"VXSEC303","Y","V-239334","V-256452","Paste operations must be disabled on the virtual machine (VM).",
	"VXSEC304","Y","V-239335","V-256453","Virtual disk shrinking must be disabled on the virtual machine (VM).",
	"VXSEC305","Y","V-239336","V-256454","Virtual disk wiping must be disabled on the virtual machine (VM).",
	"VXSEC306","Y","V-239337","V-256455","Independent, non-persistent disks must be not be used on the virtual machine (VM).",
	"VXSEC307","Y","V-239338","V-256456","Host Guest File System (HGFS) file transfers must be disabled on the virtual machine (VM).",
	"VXSEC308","Y","V-239339","V-256457","Unauthorized floppy devices must be disconnected on the virtual machine (VM).",
	"VXSEC309","Y","V-239340","V-256458","Unauthorized CD/DVD devices must be disconnected on the virtual machine (VM).",
	"VXSEC310","Y","V-239341","V-256459","Unauthorized parallel devices must be disconnected on the virtual machine (VM).",
	"VXSEC311","Y","V-239342","V-256460","Unauthorized serial devices must be disconnected on the virtual machine (VM).",
	"VXSEC312","Y","V-239343","V-256461","Unauthorized USB devices must be disconnected on the virtual machine (VM).",
	"VXSEC313","Y","V-239344","V-256462","Console connection sharing must be limited on the virtual machine (VM).",
	"VXSEC314","Y","V-239345","","Console access through the VNC protocol must be disabled on the virtual machine (VM).",
	"VXSEC315","Y","V-239346","V-256463","Informational messages from the virtual machine to the VMX file must be limited on the virtual machine (VM).",
	"VXSEC316","Y","V-239347","V-256464","Unauthorized removal, connection and modification of devices must be prevented on the virtual machine (VM).",
	"VXSEC317","Y","V-239348","V-256465","The virtual machine (VM) must not be able to obtain host information from the hypervisor.",
	"VXSEC318","Y","V-239349","V-256466","Shared salt values must be disabled on the virtual machine (VM).",
	"VXSEC319","Y","V-239350","V-256467","Access to virtual machines (VM) through the dvfilter network APIs must be controlled.",
	"VXSEC320","Y","V-239351","V-256468","System administrators must use templates to deploy virtual machines (VM) whenever possible.",
	"VXSEC321","Y","V-239352","V-256469","Use of the virtual machine (VM) console must be minimized.",
	"VXSEC322","Y","V-239353","V-256470","The virtual machine (VM) guest operating system must be locked when the last console connection is closed.",
	"VXSEC323","Y","V-239354","V-256471","All 3D features on the virtual machine (VM) must be disabled when not required.",
	"VXSEC324","Y","V-242469","V-256472","Encryption must be enabled for vMotion on the virtual machine (VM).",
	"VXSEC325","Y","","V-256473","Logging must be enabled on the virtual machine (VM).",
	"VXSEC326","Y","","V-256474","Log size must be properly configured on the virtual machine (VM).",
	"VXSEC327","Y","","V-256475","Log retention must be properly configured on the virtual machine (VM).",
	"VXSEC328","Y","","V-256476","DirectPath I/O must be disabled on the virtual machine (VM) when not required.",
	"VXSEC329","Y","","V-256477","Encryption must be enabled for Fault Tolerance on the virtual machine (VM).",
	# VCENTER
	"VXSEC330","Y","V-243072","V-256326","The vCenter Server must prohibit password reuse for a minimum of five generations.",
	"VXSEC331","Y","V-243073","","The vCenter Server must not automatically refresh client sessions.",
	"VXSEC332","Y","V-243074","V-256332","The vCenter Server must enforce a 60-day maximum password lifetime restriction.",
	"VXSEC333","Y","V-243075","V-256334","The vCenter Server must terminate vSphere Client sessions after 10 minutes of inactivity.",
	"VXSEC334","Y","V-243076","V-256335","The vCenter Server users must have the correct roles assigned.",
	"VXSEC335","Y","V-243077","V-256336","The vCenter Server must manage excess capacity, bandwidth, or other redundancy to limit the effects of information-flooding types of denial-of-service (DoS) attacks by enabling Network I/O Control (NIOC).",
	"VXSEC336","Y","V-243078","","The vCenter Server must provide an immediate real-time alert to the SA and ISSO, at a minimum, of all audit failure events.",
	"VXSEC337","Y","V-243079","","The vCenter Server must implement Active Directory authentication.",
	"VXSEC338","Y","V-243080","","The vCenter Server must limit the use of the built-in SSO administrative account.",
	"VXSEC339","Y","V-243081","V-256347","The vCenter Server must disable the distributed virtual switch health check.",
	"VXSEC340","Y","V-243082","V-256348","The vCenter Server must set the distributed port group Forged Transmits policy to reject.",
	"VXSEC341","Y","V-243083","V-256349","The vCenter Server must set the distributed port group Media Access Control (MAC) Address Change policy to Reject.",
	"VXSEC342","Y","V-243084","V-256350","The vCenter Server must set the distributed port group Promiscuous Mode policy to reject.",
	"VXSEC343","Y","V-243085","V-256351","The vCenter Server must only send NetFlow traffic to authorized collectors.",
	"VXSEC344","Y","V-243086","V-256352","The vCenter Server must configure all port groups to a value other than that of the native virtual local area network (VLAN).",
	"VXSEC345","Y","V-243087","V-256353","The vCenter Server must not configure VLAN Trunking unless Virtual Guest Tagging (VGT) is required and authorized.",
	"VXSEC346","Y","V-243088","V-256354","The vCenter Server must not configure all port groups to virtual local area network (VLAN) values reserved by upstream physical switches.",
	"VXSEC347","Y","V-243089","V-256355","The vCenter Server must configure the vpxuser auto-password to be changed every 30 days.",
	"VXSEC348","Y","V-243090","V-256356","The vCenter Server must configure the vpxuser password meets length policy.",
	"VXSEC349","Y","V-243091","","The vCenter Server must disable the managed object browser (MOB) at all times when not required for troubleshooting or maintenance of managed objects.",
	"VXSEC350","Y","V-243092","","The vCenter Server must check the privilege reassignment after restarts.",
	"VXSEC351","Y","V-243093","","The vCenter Server must enable all tasks to be shown to Administrators in the Web Client.",
	"VXSEC352","Y","V-243094","","The vCenter Server must restrict the connectivity between Update Manager and public patch repositories by use of a separate Update Manager Download Server.",
	"VXSEC353","Y","V-243095","","The vCenter Server must use a least-privileges assignment for the vCenter Server database user.",
	"VXSEC354","Y","V-243096","V-256358","The vCenter Server must use unique service accounts when applications connect to vCenter.",
	"VXSEC355","Y","V-243097","","vCenter Server plugins must be verified.",
	"VXSEC356","Y","V-243098","V-256321","The vCenter Server must produce audit records containing information to establish what type of events occurred.",
	"VXSEC357","Y","V-243099","V-256325","The vCenter Server passwords must be at least 15 characters in length.",
	"VXSEC358","Y","V-243100","V-256327","The vCenter Server passwords must contain at least one uppercase character.",
	"VXSEC359","Y","V-243101","V-256328","The vCenter Server passwords must contain at least one lowercase character.",
	"VXSEC360","Y","V-243102","V-256329","The vCenter Server passwords must contain at least one numeric character.",
	"VXSEC361","Y","V-243103","V-256330","The vCenter Server passwords must contain at least one special character.",
	"VXSEC362","Y","V-243104","V-256319","The vCenter Server must enforce the limit of three consecutive invalid logon attempts by a user.",
	"VXSEC363","Y","V-243105","V-256338","The vCenter Server must set the interval for counting failed login attempts to at least 15 minutes.",
	"VXSEC364","Y","V-243106","V-256346","The vCenter Server must require an administrator to unlock an account locked due to excessive login failures.",
	"VXSEC365","Y","V-243107","","The vCenter Server users must have the correct roles assigned.",
	"VXSEC366","Y","V-243108","V-256359","The vCenter Server must protect the confidentiality and integrity of transmitted information by isolating Internet Protocol (IP)-based storage traffic.",
	"VXSEC367","Y","V-243109","","The vCenter Server must enable the vSAN Health Check.",
	"VXSEC368","Y","V-243110","V-256361","The vCenter Server must disable or restrict the connectivity between vSAN Health Check and public Hardware Compatibility List (HCL) by use of an external proxy server.",
	"VXSEC369","Y","V-243111","V-256362","The vCenter Server must configure the vSAN Datastore name to a unique name.",
	"VXSEC370","Y","V-243112","V-256318","The vCenter Server must use TLS 1.2, at a minimum, to protect the confidentiality of sensitive data during electronic dissemination using remote access.",
	"VXSEC371","Y","V-243113","V-256342","The vCenter Server Machine Secure Sockets Layer (SSL) certificate must be issued by a DoD certificate authority.",
	"VXSEC372","Y","V-243114","","The vCenter Server must enable certificate based authentication.",
	"VXSEC373","Y","V-243115","V-256333","The vCenter Server must enable revocation checking for certificate-based authentication.",
	"VXSEC374","Y","V-243116","V-256363","The vCenter Server must disable Username/Password and Windows integrated authentication.",
	"VXSEC375","Y","V-243117","","The vCenter Server must enable the login banner for vSphere Client.",
	"VXSEC376","Y","V-243118","V-256364","The vCenter Server must restrict access to the cryptographic role.",
	"VXSEC377","Y","V-243119","V-256365","The vCenter Server must restrict access to cryptographic permissions.",
	"VXSEC378","Y","V-243120","V-256366","The vCenter Server must have Mutual Challenge Handshake Authentication Protocol (CHAP) configured for vSAN Internet Small Computer System Interface (iSCSI) targets.",
	"VXSEC379","Y","V-243121","V-256367","The vCenter Server must have new Key Encryption Keys (KEKs) reissued at regular intervals for vSAN encrypted datastore(s).",
	"VXSEC380","Y","V-243122","V-256343","The vCenter Server must disable the Customer Experience Improvement Program (CEIP).",
	"VXSEC381","Y","V-243123","V-256368","The vCenter Server must use secure Lightweight Directory Access Protocol (LDAPS) when adding an SSO identity source.",
	"VXSEC382","Y","V-243124","V-256369","The vCenter Server must use a limited privilege account when adding an Lightweight Directory Access Protocol (LDAP) identity source.",
	"VXSEC383","Y","","V-256370","The vCenter Server must limit membership to the SystemConfiguration.BashShellAdministrators Single Sign-On (SSO) group.",
	"VXSEC384","Y","","V-256371","The vCenter Server must limit membership to the TrustedAdmins Single Sign-On (SSO) group.",
	"VXSEC385","Y","","V-256339","The vCenter Server must be configured to send logs to a central log server.",
	"VXSEC386","Y","","V-256337","The vCenter Server must provide an immediate real-time alert to the system administrator (SA) and information system security officer (ISSO), at a minimum, on every Single Sign-On (SSO) account action.",
	"VXSEC387","Y","","V-256372","The vCenter server configuration must be backed up on a regular basis.",
	"VXSEC388","Y","","V-256360","The vCenter server must be configured to send events to a central log server.",
	"VXSEC389","Y","","V-256345","The vCenter server must disable SNMPv1/2 receivers.",
	"VXSEC390","Y","","V-256344","The vCenter server must enforce SNMPv3 security features where SNMP is required.",
	"VXSEC391","Y","","V-256373","vCenter task and event retention must be set to at least 30 days.",
	"VXSEC392","Y","","V-256374","vCenter Native Key Providers must be backed up with a strong password.",
	"VXSEC486","Y","","V-256320","The vCenter Server must display the Standard Mandatory DoD Notice and Consent Banner before logon.",
	"VXSEC487","Y","","V-256322","vCenter Server plugins must be verified.",
	"VXSEC488","Y","","V-256323","The vCenter Server must uniquely identify and authenticate users or processes acting on behalf of users.",
	"VXSEC489","Y","","V-256324","The vCenter Server must require multifactor authentication.",
	"VXSEC490","Y","","V-256331","The vCenter Server must enable FIPS validated cryptography.",
	"VXSEC491","Y","","V-256341","The vCenter Server must compare internal information system clocks at least every 24 hours with an authoritative time server.",
	"VXSEC492","Y","","V-256357","The vCenter Server must be isolated from the public Internet but must still allow for patch notification and delivery.",
	"VXSEC493","Y","","V-256592","VMware Postgres log files must contain required fields.",
	"VXSEC494","Y","","V-256764","The Security Token Service must set URIEncoding to UTF-8.",
	"VXSEC495","Y","","V-256749","The Security Token Service must record user access in a format that enables monitoring of remote access.",
	"VXSEC496","Y","","V-256762","The Security Token Service must fail to a known safe state if system initialization fails, shutdown fails, or aborts fail.",
	"VXSEC497","Y","","V-256765","The Security Token Service must use the 'setCharacterEncodingFilter' filter.",
	"VXSEC498","Y","","V-256712","Lookup Service log files must only be accessible by privileged users.",
	"VXSEC499","Y","","V-256725","Lookup Service must set URIEncoding to UTF-8.",
	"VXSEC500","Y","","V-256728","Lookup Service must be configured to hide the server version.",
	"VXSEC501","Y","","V-256709","Lookup Service must protect cookies from cross-site scripting (XSS).",
	"VXSEC502","Y","","V-256710","Lookup Service must record user access in a format that enables monitoring of remote access.",
	"VXSEC503","Y","","V-256723","Lookup Service must fail to a known safe state if system initialization fails, shutdown fails, or aborts fail.",
	"VXSEC504","Y","","V-256736","Lookup Service must set the secure flag for cookies.",
	# ESXI
	"VXSEC394","Y","V-239258","V-256375","Access to the ESXi host must be limited by enabling Lockdown Mode.",
	"VXSEC395","Y","V-239259","V-256376","The ESXi host must verify the DCUI.Access list.",
	"VXSEC396","Y","V-239260","V-256377","The ESXi host must verify the exception users list for Lockdown Mode.",
	"VXSEC397","Y","V-239261","V-256378","Remote logging for ESXi hosts must be configured.",
	"VXSEC398","Y","V-239262","V-256379","The ESXi host must enforce the limit of three consecutive invalid logon attempts by a user.",
	"VXSEC399","Y","V-239263","V-256380","The ESXi host must enforce the unlock timeout of 15 minutes after a user account is locked out.",
	"VXSEC400","Y","V-239264","V-256381","The ESXi host must display the Standard Mandatory DoD Notice and Consent Banner before granting access to the system via the Direct Console User Interface (DCUI).",
	"VXSEC401","Y","V-239265","V-256382","The ESXi host must display the Standard Mandatory DoD Notice and Consent Banner before granting access to the system via Secure Shell (SSH).",
	"VXSEC402","Y","V-239266","V-256383","The ESXi host SSH daemon must be configured with the DoD logon banner.",
	"VXSEC403","Y","V-239267","V-256384","The ESXi host Secure Shell (SSH) daemon must use DoD-approved encryption to protect the confidentiality of remote access sessions.",
	"VXSEC404","Y","V-239268","V-256385","The ESXi host Secure Shell (SSH) daemon must ignore .rhosts files.",
	"VXSEC405","Y","V-239269","V-256386","The ESXi host Secure Shell (SSH) daemon must not allow host-based authentication.",
	"VXSEC407","Y","V-239271","V-256387","The ESXi host Secure Shell (SSH) daemon must not allow authentication using an empty password.",
	"VXSEC408","Y","V-239272","V-256388","The ESXi host Secure Shell (SSH) daemon must not permit user environment settings.",
	"VXSEC411","Y","V-239275","V-256389","The ESXi host Secure Shell (SSH) daemon must perform strict mode checking of home directory configuration files.",
	"VXSEC412","Y","V-239276","V-256390","The ESXi host Secure Shell (SSH) daemon must not allow compression or must only allow compression after successful authentication.",
	"VXSEC413","Y","V-239277","V-256391","The ESXi host Secure Shell (SSH) daemon must be configured to not allow gateway ports.",
	"VXSEC414","Y","V-239278","V-256392","The ESXi host Secure Shell (SSH) daemon must be configured to not allow X11 forwarding.",
	"VXSEC416","Y","V-239280","V-256393","The ESXi host Secure Shell (SSH) daemon must not permit tunnels.",
	"VXSEC417","Y","V-239281","V-256394","The ESXi host Secure Shell (SSH) daemon must set a timeout count on idle sessions.",
	"VXSEC418","Y","V-239282","V-256395","The ESXi host Secure Shell (SSH) daemon must set a timeout interval on idle sessions.",
	"VXSEC419","Y","V-239283","","The ESXi host SSH daemon must limit connections to a single session.",
	"VXSEC420","Y","V-239284","","The ESXi host must remove keys from the SSH authorized_keys file.",
	"VXSEC421","Y","V-239285","V-256396","The ESXi host must produce audit records containing information to establish what type of events occurred.",
	"VXSEC422","Y","V-239286","V-256397","The ESXi host must be configured with a sufficiently complex password policy.",
	"VXSEC423","Y","V-239287","V-256398","The ESXi host must prohibit the reuse of passwords within five iterations.",
	"VXSEC425","Y","V-239289","V-256399","The ESXi host must disable the Managed Object Browser (MOB).",
	"VXSEC426","Y","V-239290","V-256400","The ESXi host must be configured to disable nonessential capabilities by disabling Secure Shell (SSH).",
	"VXSEC427","Y","V-239291","V-256401","The ESXi host must disable ESXi Shell unless needed for diagnostics or troubleshooting.",
	"VXSEC428","Y","V-239292","V-256402","The ESXi host must use Active Directory for local user authentication.",
	"VXSEC429","Y","V-239293","V-256403","ESXi hosts using Host Profiles and/or Auto Deploy must use the vSphere Authentication Proxy to protect passwords when adding themselves to Active Directory.",
	"VXSEC430","Y","V-239294","V-256404","Active Directory ESX Admin group membership must not be used when adding ESXi hosts to Active Directory.",
	"VXSEC431","Y","V-239295","","The ESXi host must use multifactor authentication for local DCUI access to privileged accounts.",
	"VXSEC432","Y","V-239296","V-256405","The ESXi host must set a timeout to automatically disable idle shell sessions after two minutes.",
	"VXSEC433","Y","V-239297","V-256406","The ESXi host must terminate shell services after 10 minutes.",
	"VXSEC434","Y","V-239298","V-256407","The ESXi host must log out of the console UI after two minutes.",
	"VXSEC435","Y","V-239299","","The ESXi host must enable kernel core dumps.",
	"VXSEC436","Y","V-239300","V-256408","The ESXi host must enable a persistent log location for all locally stored logs.",
	"VXSEC437","Y","V-239301","V-256409","The ESXi host must configure NTP time synchronization.",
	"VXSEC438","Y","V-239302","V-256410","The ESXi Image Profile and vSphere Installation Bundle (VIB) Acceptance Levels must be verified.",
	"VXSEC439","Y","V-239303","V-256411","The ESXi host must protect the confidentiality and integrity of transmitted information by isolating vMotion traffic.",
	"VXSEC440","Y","V-239304","V-256412","The ESXi host must protect the confidentiality and integrity of transmitted information by protecting ESXi management traffic.",
	"VXSEC441","Y","V-239305","V-256413","The ESXi host must protect the confidentiality and integrity of transmitted information by isolating IP-based storage traffic.",
	"VXSEC442","Y","V-239306","","The ESXi host must protect the confidentiality and integrity of transmitted information by using different TCP/IP stacks where possible.",
	"VXSEC443","Y","V-239307","V-256414","Simple Network Management Protocol (SNMP) must be configured properly on the ESXi host.",
	"VXSEC444","Y","V-239308","V-256415","The ESXi host must enable bidirectional Challenge-Handshake Authentication Protocol (CHAP) authentication for Internet Small Computer Systems Interface (iSCSI) traffic.",
	"VXSEC445","Y","V-239309","V-256416","The ESXi host must disable Inter-Virtual Machine (VM) transparent page sharing.",
	"VXSEC446","Y","V-239310","V-256417","The ESXi host must configure the firewall to restrict access to services running on the host.",
	"VXSEC447","Y","V-239311","V-256418","The ESXi host must configure the firewall to block network traffic by default.",
	"VXSEC448","Y","V-239312","V-256419","The ESXi host must enable Bridge Protocol Data Units (BPDU) filter on the host to prevent being locked out of physical switch ports with Portfast and BPDU Guard enabled.",
	"VXSEC449","Y","V-239313","V-256420","All port groups on standard switches must be configured to reject forged transmits.",
	"VXSEC450","Y","V-239314","V-256421","All port groups on standard switches must be configured to reject guest Media Access Control (MAC) address changes.",
	"VXSEC451","Y","V-239315","V-256422","All port groups on standard switches must be configured to reject guest promiscuous mode requests.",
	"VXSEC452","Y","V-239316","V-256423","Use of the dvFilter network application programming interfaces (APIs) must be restricted.",
	"VXSEC453","Y","V-239317","V-256424","All port groups on standard switches must be configured to a value other than that of the native virtual local area network (VLAN).",
	"VXSEC454","Y","V-239318","V-256425","All port groups on standard switches must not be configured to virtual local area network (VLAN) 4095 unless Virtual Guest Tagging (VGT) is required.",
	"VXSEC455","Y","V-239319","V-256426","All port groups on standard switches must not be configured to virtual local area network (VLAN) values reserved by upstream physical switches.",
	"VXSEC456","Y","V-239320","","For physical switch ports connected to the ESXi host, the non-negotiate option must be configured for trunk links between external physical switches and virtual switches in Virtual Switch Tagging (VST) mode.",
	"VXSEC457","Y","V-239321","","All ESXi host-connected physical switch ports must be configured with spanning tree disabled.",
	"VXSEC458","Y","V-239322","","All ESXi host-connected virtual switch VLANs must be fully documented and have only the required VLANs.",
	"VXSEC459","Y","V-239323","V-256427","The ESXi host must not provide root/administrator-level access to Common Information Model (CIM)-based hardware monitoring tools or other third-party applications.",
	"VXSEC460","Y","V-239324","","The SA must verify the integrity of the installation media before installing ESXi.",
	"VXSEC461","Y","V-239325","V-256428","The ESXi host must have all security patches and updates installed.",
	"VXSEC462","Y","V-239326","V-256429","The ESXi host must exclusively enable Transport Layer Security (TLS) 1.2 for all endpoints.",
	"VXSEC463","Y","V-239327","V-256430","The ESXi host must enable Secure Boot.",
	"VXSEC464","Y","V-239328","V-256431","The ESXi host must use DoD-approved certificates.",
	"VXSEC465","Y","V-239329","V-256432","The ESXi host must not suppress warnings that the local or remote shell sessions are enabled.",
	"VXSEC466","Y","V-239330","","The ESXi host must centrally review and analyze audit records from multiple components within the system by configuring remote logging.",
	"VXSEC467","Y","V-239331","","The ESXi host SSH daemon must be configured to only use FIPS 140-2 approved ciphers.",
	"VXSEC469","Y","","V-256433","The ESXi host must not suppress warnings about unmitigated hyperthreading vulnerabilities.",
	"VXSEC470","Y","","V-256434","The ESXi host Secure Shell (SSH) daemon must disable port forwarding.",
	"VXSEC471","Y","","V-256435","The ESXi host OpenSLP service must be disabled.",
	"VXSEC472","Y","","V-256438","The ESXi host must verify certificates for SSL syslog endpoints.",
	"VXSEC473","Y","","V-256440","The ESXi host must configure a session timeout for the vSphere API.",
	"VXSEC474","Y","","V-256441","The ESXi Host Client must be configured with a session timeout.",
	"VXSEC475","Y","","V-256442","The ESXi host rhttpproxy daemon must use FIPS 140-2 validated cryptographic modules to protect the confidentiality of remote access sessions.",
	"VXSEC476","Y","","V-256444","The ESXi host must not be configured to override virtual machine (VM) configurations.",
	"VXSEC477","Y","","V-256445","The ESXi host must not be configured to override virtual machine (VM) logger settings.",
	"VXSEC478","Y","","V-256436","The ESXi host must enable audit logging.",
	"VXSEC479","Y","","V-256437","The ESXi host must enable strict x509 verification for SSL syslog endpoints.",
	"VXSEC480","Y","","V-256439","The ESXi host must enable volatile key destruction.",
	"VXSEC481","Y","","V-256443","The ESXi host must be configured with an appropriate maximum password age.",
	"VXSEC482","Y","","V-256446","The ESXi host must require TPM-based configuration encryption.",
	"VXSEC483","Y","","V-256447","The ESXi host must implement Secure Boot enforcement.",
	"VXSEC484","Y","","V-256448","The ESXi Common Information Model (CIM) service must be disabled.",
	"VXSEC485","Y","","V-256449","The ESXi host SSH daemon must be configured to only use FIPS 140-2 validated ciphers.",
	# vCSA Photon OS
	"DSX06_0001","Y","","V-256480","The Photon operating system must display the Standard Mandatory DOD Notice and Consent Banner before granting Secure Shell (SSH) access.",
	"DSX06_0002","Y","","V-256507","The Photon operating system must enforce a minimum eight-character password length.",
	"DSX06_0003","Y","","V-256513","The Photon operating system must configure sshd to disconnect idle Secure Shell (SSH) sessions.",
	"DSX06_0004","Y","","V-256527","The Photon operating system must configure auditd to keep five rotated log files.",
	"DSX06_0005","Y","","V-256557","The Photon operating system must configure sshd to limit the number of allowed login attempts per connection."
)

# Populate the mapping table with the content
# The mapDataCells param is just one single long list of comma-separated values.
# There is no difference between field and line separator.
# Visually, above, each line contains the 5 values that apply to one STIG rule.
# A loop will be used to run over all the data cells.
# For each element in mapColumnTitles, a property will be assigned a mapDataCells value. 
# Every set of properties (one for each in mapColumnTitles) will be become one rule map object.
# Each rule map object will be added to the vxSecMapTable array.
$vxSecMapTable = @()
for ($i = 0; $i -lt $mapDataCells.Count; ) {

	# Instantiate new object
    $row = new-object -TypeName PSObject

	# Loop over each column title
    $mapColumnTitles | ForEach-Object { 
		# Add a property with this column's name to the object 
		# and assign it the next map data cell value.
		# Note: This loop also increments the map data cell counter
		$row | Add-Member -Type NoteProperty -Name $_ -Value $mapDataCells[$i++]
    }

	# The new rule map object is complete - add it to the vxSecMapTable$vxSecMapTable array
    $vxSecMapTable += $row
}

# --------------------------------------------------------------------------

############################################################################
# Start of Supporting Functions
############################################################################
#

###################################
# Checking if Python is Installed? 
###################################
function CheckPythonInstalled {
	Get-FunctionName

	$python = &{python --version} 2>&1
	
	if($python -is [System.Management.Automation.ErrorRecord]){
		
		# grab the version string from the error message
		$python_status = $python.Exception.Message
		Write-Log -Level 'Info' -Message "$python_status"
		Write-Host-Log "Python not found, hence exiting the script"  -ForegroundColor Red
		Write-Host "Please follow the Instruction below"
		Write-Host "`n--------------------------------------------------------------------------"
		Write-Host "Instructions for Installing Python Online" -ForegroundColor Yellow
		Write-Host "1 - Open a Command Prompt, a Powershell window, or click the Windows Start button"
		Write-Host "2 - Type python"
		Write-Host "3 - Hit enter, which will open the Microsoft Store"
		Write-Host "4 - Click the Get button to install"
		Write-Host "`n--------------------------------------------------------------------------"
		Write-Host "Instructions for Installing Python Offline" -ForegroundColor Yellow
		Write-Host "1 - Download the offline python package from: https://www.python.org/downloads/"
		Write-Host "2 - Follow the instruction in the STIG guide`n"		
		exit
	} else {
		Write-Host-Log "Python is installed:" $python
	}
}	

#########################################################
# FUNCTION: PauseIfDebug
# PURPOSE:  Function to allow pausing and displaying information, only when in debug mode.
#           To enable debug mode, set a variable at the PowerShell command-line, before
#           starting the script, as follows:
#              $Env:VXRAILSTIGDEBUG = $true
# Input: any (string) parameter (will be displayed)
# Output: --
#########################################################

function PauseIfDebug () {
	if ($DEBUGSWITCH -eq $True) { 
		Write-Log -Level 'Debug' "Debug pause: $args"
		Read-Host "...Debug pause... (press Enter to continue)" 
	}
}

#########################################################
# FUNCTION: getVulnMap
# PURPOSE:  Retrieve mapping for a given vxsec-id. The returned object will have an additional 
#           property 'vulnid' that is correct for the vSphere platform it is running on.
# Input:  $vxSecIn         = vxsec-id to find in table
# Output: $true/$false     = mapping successful? (returned value)
#         $script:vxSecRow = map object for this vxsecid (global var)
#########################################################
function getVulnMap( $vxSecIn ) {
	Get-FunctionName

	# find the mapping rule to be returned (using global var)
	$script:vxSecRow = $vxSecMapTable.where({$_.vxsecid -eq $vxSecIn})

	# set _vulnid67/_vulnid70
	$_vulnid67 = $script:vxSecRow.vulnid67
	$_vulnid70 = $script:vxSecRow.vulnid70
	#Write-Log -Level 'Debug' "VxMajorVersion=$script:VxRailMajorVersion, vxsecid=$vxSecIn, vulnid67=$_vulnid67, vulnid70=$_vulnid70"

	# Check which platform its running on and if the mapping is successful
	if (($script:VxRailMajorVersion -eq "7") -AND ($_vulnid70)) {
		# running on VMware vSphere 7.0 platform and mapping successful
		# set new property vulnid to the vulnid70 value
		$script:vxSecRow | Add-Member -Type NoteProperty -Name "vulnid" -Value $_vulnid70 -Force
		#Write-Log -Level 'Debug' "Mapped $vxsecIn to $script:vxSecRow.vulnid ($_vulnid70)"
		return $true
	} elseif (($script:VxRailMajorVersion -eq "4") -AND ($_vulnid67)) {
		# running on VMware vSphere 6.7 platform and mapping successful
		# set new property vulnid to the vulnid67 value
		$script:vxSecRow | Add-Member -Type NoteProperty -Name "vulnid" -Value $_vulnid67 -Force
		#Write-Log -Level 'Debug' "Mapped $vxsecIn to $script:vxSecRow.vulnid ($_vulnid67)"
		return $true
	} else {
		# catch-all: not a successful map
		if (($_vulnid67) -OR ($_vulnid70)) {
			# There was a mapping but not for the current platform
			Write-Log -Level 'Debug' "$vxSecIn is not mapped on VxRail version $script:VxRailMajorVersion"
		} else {
			# Both vulnid67 and vulnid70 are empty
			$VulnID = $script:VulnIdNA
			$Outcome = "FAIL"
			Write-Host-Log "Mapping for $vxsecIn failed"
			Write-Log -Level 'Debug' "Mapping for $vxsecIn failed"
		}
		return $false
	}
}

#########################################################
# FUNCTION: TestFileExistence
# PURPOSE:  Check if a given required file exists. Exit if not.
# Input: filepath
# Output: --
#########################################################
function TestFileExistence ( $inputFilePath ) {
	Write-Log -Level 'Debug' "Checking file existence for: $inputFilePath"
	if (Test-Path -Path $inputFilePath) {
		Write-Log -Level 'Debug' "File is found: $inputFilePath"
	} else {
		$Message="ERROR: Required file not found: $inputFilePath"
		Write-Host $Message -ForegroundColor Red
		Write-Log -Level 'Error' -Message $Message
		Exit
	}
}

#
#########################################################
# FUNCTION: TestModuleInstall
# PURPOSE:  Check if a given module is installed in PowerShell.
#           Verify both in Get-InstalledModule and in Get-Module.
#			If the module is not found it exits the script.
# Input: module name
#########################################################
function TestModuleInstall( $prereqModName ) {
	Write-Host "Checking if prerequisite PowerShell module $PrereqModName is installed."
	# Check using Get-InstalledModule
	Try {
		$moduleVersion=(Get-InstalledModule $PrereqModName -ErrorAction Stop).Version | Select-Object -Last 1
		$reqModFound=$true
	} Catch {
		# Required package not found using Get-InstalledModule
		$reqModFound=$false
	}
	if ( ! $reqModFound ) {
		# Check using Get-Module
		$moduleVersion=(Get-Module $PrereqModName -ErrorAction Stop).Version | Select-Object -Last 1
		# Get-Module doesn't throw an exception when not found, so not using try-catch here
		if (! $moduleVersion) {
			# Required package not found using Get-Module
			$Message="ERROR: Required module $PrereqModName not found."
			Write-Host $Message -ForegroundColor Red
			Write-Log -Level 'Error' -Message $Message
			Exit
		}
	}
	Write-Log -Level 'Debug' "Found prerequisite PowerShell module $PrereqModName, version $moduleVersion"
}

#########################################################
# FUNCTION: TestVersionSupport
# PURPOSE:  Check if the given found version is equal to or later than the given major and minor version.
#           The found version must be from a module package, and contain the major and minor properties.
#           Function Exits if version compare is not successful.
# Input: 1. found version
#        2. major version
#        3. minor version
# Output: --
#########################################################
function TestVersionSupport ($foundVersion, $majorVersion, $minorVersion) {
	Write-Log -Level 'Debug' "Testing if version $foundVersion >= $majorVersion.$minorVersion"
	if (! ( ($foundVersion.Major -gt $majorVersion) -or ($foundVersion.Major -eq $majorVersion -and $foundVersion.Minor -ge $minorVersion) ) ) {
		$Message="ERROR: Version is NOT supported! (found $foundVersion, supported $majorVersion.$minorVersion)"
		Write-Host $Message -ForegroundColor Red
		Write-Log -Level 'Error' -Message $Message
		Exit
	}
	Write-Log -Level 'Debug' "Version is supported! ($foundVersion)"
}

#########################################################
# FUNCTION: TrimLower
# PURPOSE: Return given string parameter, trimmed and in lower case.
# PARAMETERS: a string value
#########################################################
function TrimLower {
	[CmdletBinding()]
	param( 
		[Parameter(Position=0,Mandatory=$false)] [string] $RawString
	)
	return $RawString.Trim().ToLower()
}

###################################################################
# Function	: Invoke-STIGvCSAScript
# Purpose	: This function will launch a script in a Photon guest OS
# Parameters:
#	1. ScriptText - Provides the text of the script you want to run
####################################################################
Function Invoke-STIGvCSAScript ($scriptText) {
	Get-FunctionName

	$VM = $script:VCVMName
	$GuestUser = "root"
	$GuestPassword = $script:vCRootSecPass
	$ScriptType = "Bash"
	
	Try {
		# Invoke-VMScript to check,apply and restart service on a VM
		Invoke-VMScript -VM $VM -ScriptText $scriptText -GuestUser $GuestUser -GuestPassword $GuestPassword -scripttype $ScriptType
		Write-Log -Level Info -Message "Successfully run the Invoke-VMScript"	
	} catch {
			$script:failProcess++
			writeError
			Write-Log -Level Info -Message "Failed to the run the Invoke-VMScript"
		} 	
}

#####################################
# Installing Required Python Modules
#####################################
function InstallPyModules {
	Get-FunctionName

	try {
			#Extracting the wheelhouse for the required Pyhton Modules
			Write-Host "Ensuring dependent python modules are installed"
			Write-Host-Log "Extracting wheelhouse file"
			tar -zxf $pyOfflineModules
			Write-Log -Level Info -Message "Installing the Dependent Python Modules"		
			$pipInstalllog = pip install -r $pyInstallModules --no-warn-script-location 2>$null
			Write-Host-Log "Check log file for Install status" "$pipInstalllog"
			Write-Host-Log "Finished python module installation check"
		}
	catch {
			Write-Host-Log "Failure trying to extract and install required python modules from wheelhouse file ('$pyOfflineModules')"
			writeError
	}
}

#####################################
# End of Installing Python Modules
#####################################

############################################################################
# Init
############################################################################
function init {
	
	# First ask user where to place the logfile
	GetFolderForLogfile
	$script:Logfile = "$script:LogDir\VxRail_STIG.$STIGStartTimestamp.log"

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "*******************************************"
	Write-Log -Message "*** Start VxRail STIG Hardening Process ***"
	Write-Log -Message "*******************************************"
	Write-Log -Message "VxRail STIG package version: $VxRailPackageVersion"
	Write-Log -Message "User selected log file directory: $script:LogDir"

	# Check prerequisites:
	# Check installed module PowerCLI
	TestModuleInstall $powerCLIModuleName
	$script:powerCLIVersion=(Get-InstalledModule $powerCLIModuleName -ErrorAction Stop).Version | Select-Object -Last 1
	TestVersionSupport $script:powerCLIVersion $powerCLIMajorVersion $powerCLIMinorVersion

	# Check Files existence

	TestFileExistence $VMware67STIGESXiScript
	TestFileExistence $VMware70STIGESXiScript
	TestFileExistence $VMware70STIGvCScript

	TestFileExistence $MonitorVxRailClusterHealthUntilOK
	TestFileExistence $pyOfflineModules

	TestFileExistence $VxRailSTIGLoggingFileLocal
	TestFileExistence $setKeyOfElementAttributeInXMLfileLocal
	TestFileExistence $setCharacterEncodingFilterFileLocal
	TestFileExistence $setSecureFlagForCookiesLookupSvcFileLocal

	# Check Plink executable
	CheckPscpPlink -tool 'plink' -toolMajorVersion $plinkMajorVersion -toolMinorVersion $plinkMinorVersion
	
	# Check Pscp executable
	CheckPscpPlink -tool 'pscp' -toolMajorVersion $pscpMajorVersion -toolMinorVersion $pscpMinorVersion

	
	# Ensure no VIServers are connected yet
	try {
		Disconnect-VIServer * -Confirm:$false -ErrorAction Ignore | Out-Null
	} catch {}

	# Get VxM Creds and check VxRail version
	GetVxMCredential
	GetVxRailVersion
	$script:VxRailMajorVersion = $script:VxRailVersion.Split(".")[0]
	$script:VxRailMinorVersion = $script:VxRailVersion.Split(".")[1]

	# Check VxRail is at a supported version
	if (!($script:VxRailMajorVersion -eq '4' -and $script:VxRailVersion -ge '4.7.300') -and
		!($script:VxRailMajorVersion -eq '7' -and $script:VxRailVersion -ge '7.0.131')) {
		$Message = "Exit - unsupported VxRail version.
Supported versions: VxRail 4.7.x (4.7.300 or greater) or VxRail 7.0.x (7.0.131 or greater).
Version found: VxRail $script:VxRailVersion"
   		Write-Log -Level 'Error' -Message $Message
		Write-Host $Message -ForegroundColor Red
		exit
	}

	if ($script:VxRailMajorVersion -eq '4') {
		# set the names of the corresponding VMware vSphere 6.7 scripts to use
		$script:VMwareSTIGESXiScript=$VMware67STIGESXiScript
		# v6.7 VC STIG script is not available for 6.7
		# v6.7 VM STIG rules are included in this script
	} else {
		# VxRailMajorVersion 7
		GetPrerunData
		
		# set the names of the corresponding VMware vSphere 7.0 scripts to use
		$script:VMwareSTIGESXiScript=$VMware70STIGESXiScript
		$script:VMwareSTIGvCScript=$VMware70STIGvCScript
		# v7.0 VM STIG rules are included in this script
	}

	CheckVxMHasInternalDNS
	GetvCenter
	ConnectvCenter
	GetDVSandPGs
	GetClusterAndVMHosts
	GetVMHostsConfigedSSHStatus
	GetVirtualMachines
	GetESXiCredential
	GetServiceServers
	CheckPythonInstalled
	InstallPyModules

	# Ensure the custom attributes exist on the relevant object types
	AddCustomAttribute $script:caPackageVersion $script:VxRailTargetType | Out-Null
	AddCustomAttribute $script:caDateHardened   $script:VxRailTargetType | Out-Null
	AddCustomAttribute $script:caStandard       $script:VxRailTargetType | Out-Null
	AddCustomAttribute $script:caHistory        $script:VxRailTargetType | Out-Null

	AddCustomAttribute $script:caPackageVersion $script:NodeTargetType | Out-Null
	AddCustomAttribute $script:caDateHardened   $script:NodeTargetType | Out-Null
	AddCustomAttribute $script:caStandard       $script:NodeTargetType | Out-Null
	AddCustomAttribute $script:caHistory        $script:NodeTargetType | Out-Null

	AddCustomAttribute $script:caPackageVersion $script:VMTargetType | Out-Null
	AddCustomAttribute $script:caDateHardened   $script:VMTargetType | Out-Null
	AddCustomAttribute $script:caStandard       $script:VMTargetType | Out-Null
	AddCustomAttribute $script:caHistory        $script:VMTargetType | Out-Null

	AddCustomAttribute $script:caVxMPackageVersion $script:VxRailTargetType | Out-Null
	AddCustomAttribute $script:caVxMDateHardened   $script:VxRailTargetType | Out-Null
	AddCustomAttribute $script:caVxMStandard       $script:VxRailTargetType | Out-Null
	AddCustomAttribute $script:caVxMHistory        $script:VxRailTargetType | Out-Null
}

############################################################################
# Start of Supporting Functions
############################################################################

############################################################################
# FUNCTION: Start-Sleep with Progress bar
# PURPOSE: Wait for a given number of seconds and while counting down
#		   display a progress bar
# PARAMETERS:
#	1. seconds - This is the number of seconds to sleep before returning 
# RETURNS:
#	--
############################################################################
function Start-Sleep($seconds) {
    $doneDT = (Get-Date).AddSeconds($seconds)
    while($doneDT -gt (Get-Date)) {
        $secondsLeft = $doneDT.Subtract((Get-Date)).TotalSeconds
        $percent = ($seconds - $secondsLeft) / $seconds * 100
        Write-Progress -Activity "Waiting" -Status "Checking In $seconds seconds..." -SecondsRemaining $secondsLeft -PercentComplete $percent
        [System.Threading.Thread]::Sleep(500)
    }
    Write-Progress -Activity "Sleeping" -Status "Sleeping..." -SecondsRemaining 0 -Completed
}

#########################################################
# FUNCTION: SetCustomAttributeHistory
# PURPOSE: Retain the previous values of the VxRail hardening custom attributes.
#          Concatenate any non-empty previous values (version, date and standard)
#          and save that in the history attribute.
# PARAMETERS: Entity's name
#########################################################
function SetCustomAttributeHistory {
	param ([Parameter(Position=0,Mandatory)] [String] $entityName)
	Get-FunctionName

	Write-Host "`nUpdating VxRail Hardened State custom attributes for $entityName"
	
	if ($entityName -eq "VxM") {
		Write-Host "(For the VxRail Manager app, the custom attributes are set on the cluster level)"
		$entityName = $script:Cluster
		$ca = Get-Annotation -Entity $entityName -CustomAttribute $script:caVxMPackageVersion -ErrorAction Ignore
		if ( ($null -ne $ca) -and ($ca.Value.Trim() -ne "") ) {
			$caHistoryValue = $ca.Value
		}
		$ca = Get-Annotation -Entity $entityName -CustomAttribute $script:caVxMDateHardened -ErrorAction Ignore
		if ( ($null -ne $ca) -and ($ca.Value.Trim() -ne "") ) {
			$caHistoryValue = $caHistoryValue + '; ' + $ca.Value
		}
		$ca = Get-Annotation -Entity $entityName -CustomAttribute $script:caVxMStandard -ErrorAction Ignore
		if ( ($null -ne $ca) -and ($ca.Value.Trim() -ne "") ) {
			$caHistoryValue = $caHistoryValue + '; ' + $ca.Value
		}

		$script:caDateHardenedValue = Get-Date -Format "MM/dd/yyyy HH:mm:ss"

		SetCustomAttributeValue $entityName $script:caVxMHistory        $caHistoryValue               #| Out-Null
		SetCustomAttributeValue $entityName $script:caVxMPackageVersion $script:caPackageVersionValue #| Out-Null
		SetCustomAttributeValue $entityName $script:caVxMDateHardened   $script:caDateHardenedValue   #| Out-Null
		SetCustomAttributeValue $entityName $script:caVxMStandard       $script:caStandardValue       #| Out-Null
	} else {
		$ca = Get-Annotation -Entity $entityName -CustomAttribute $script:caPackageVersion -ErrorAction Ignore
		if ( ($null -ne $ca) -and ($ca.Value.Trim() -ne "") ) {
			$caHistoryValue = $ca.Value
		}
		$ca = Get-Annotation -Entity $entityName -CustomAttribute $script:caDateHardened -ErrorAction Ignore
		if ( ($null -ne $ca) -and ($ca.Value.Trim() -ne "") ) {
			$caHistoryValue = $caHistoryValue + '; ' + $ca.Value
		}
		$ca = Get-Annotation -Entity $entityName -CustomAttribute $script:caStandard -ErrorAction Ignore
		if ( ($null -ne $ca) -and ($ca.Value.Trim() -ne "") ) {
			$caHistoryValue = $caHistoryValue + '; ' + $ca.Value
		}

		$script:caDateHardenedValue = Get-Date -Format "MM/dd/yyyy HH:mm:ss"
		
		SetCustomAttributeValue $entityName $script:caHistory        "$caHistoryValue"              #| Out-Null
		SetCustomAttributeValue $entityName $script:caPackageVersion "$script:caPackageVersionValue"#| Out-Null
		SetCustomAttributeValue $entityName $script:caDateHardened   "$script:caDateHardenedValue"  #| Out-Null
		SetCustomAttributeValue $entityName $script:caStandard       "$script:caStandardValue"      #| Out-Null
	}

}

###################################################################
# FUNCTION: MonitorVxRailClusterHealthUntilOK
# PURPOSE: Monitor and wait until the VxRail UI status is healthy
# PARAMETERS: None
####################################################################
function MonitorVxRailClusterHealthUntilOK {
	Get-FunctionName

	$vcfqdn = ($script:VC).name
	$vcusername = ($script:vCenterCredentials).UserName
	$vcpassword = [System.Net.NetworkCredential]::new("", $script:vCAdmSecPass).Password
	$VxMIP = $script:VxMFQDN

	Write-Log -Message "Using vCenter admin credentials (${vcusername}:${vcfqdn}) to monitor VxRail Manager cluster health"

	do	{
		Write-Host-Log "VxRail Manager UI is still not ready, re-checking the status in $MonitorVxRailClusterHealthInitialSleep secs..."	
		Start-Sleep -Seconds $script:MonitorVxRailClusterHealthInitialSleep;
    	try {
			Write-Log -Level 'Debug' "Calling Python script $MonitorVxRailClusterHealthUntilOK"
			python $MonitorVxRailClusterHealthUntilOK "--" "$Script:Logfile" $DEBUGSWITCH $VxMIP $vcusername "$vcpassword"
        } catch {
             	writeError
             	return $False
        }
	} until ($LASTEXITCODE -eq 0)	
}

#########################################################
# FUNCTION: StartSSHOnVMHosts
# PURPOSE: Start the SSH service on all connected VMHosts
# PARAMETERS: None.
#########################################################
function StartSSHOnVMHost {
	[CmdletBinding()]
	param( $myVMHost )
	Get-FunctionName
	
	Start-VMHostService -HostService ($myVMHost | Get-VMHostService | Where { $_.Key -eq "TSM-SSH"} ) | Format-Table -AutoSize
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Start SSH service on $myVMHost"
}

#########################################################
# FUNCTION: StopSSHOnVMHosts
# PURPOSE: Stop the SSH service on all connected VMHosts
# PARAMETERS: None.
#########################################################
function StopSSHOnVMHost {
	[CmdletBinding()]
	param( $myVMHost )
	Get-FunctionName
	
	Stop-VMHostService -HostService ($myVMHost | Get-VMHostService | Where { $_.Key -eq "TSM-SSH"} ) -Confirm:$false | Format-Table -AutoSize
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Stop SSH service on $myVMHost"
}

############################################################################
# FUNCTION: CheckPscpPlink
# PURPOSE: Test to make sure plink.exe and pscp.exe functions properly
# PARAMETERS: Tool name - plink or pscp
# Input: Parameteres need to be entered
# Output : None
############################################################################
function CheckPscpPlink {
    param(
        [Parameter(Mandatory=$true)]
        [ValidateSet('plink', 'pscp')]
        [string]$tool,
        [String]$toolMajorVersion,
        [String]$toolMinorVersion
    )
    
    Get-FunctionName

    if ($tool -eq 'plink') {
        $toolPath = $script:PlinkPath
    } elseif ($tool -eq 'pscp') {
        $toolPath = $script:PscpPath
    } else {
        Write-Host "Invalid tool specified." -ForegroundColor Red
        return
    }
	
    Write-Host "`nThe default path of $tool.exe is $toolPath" -ForegroundColor Green

    Do {
        $changeToolPath = Read-Host "Press Enter to continue. Press c, then Enter to change"
        $changeToolPath = TrimLower($changeToolPath)
    } While ( ($changeToolPath -ne "c") -and ($changeToolPath -ne "") )
    
    Do {
        While ($changeToolPath -eq "c") {
            Add-Type -AssemblyName System.Windows.Forms
            $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
                Title = "Select the $tool File"
                Filter = "EXE files (*.exe)|*.exe"
                InitialDirectory = [Environment]::GetFolderPath('MyComputer')
            }
            $null = $FileBrowser.ShowDialog()
        
            if ($null -eq $FileBrowser -or $FileBrowser.FileName -eq "") {
                Write-Host "No file was selected. The default path of $tool.exe is $toolPath" -ForegroundColor Red
                Do {
                    $changeToolPath = Read-Host "Press Enter to accept the default path. Press c, then Enter to change"
                    $changeToolPath = TrimLower($changeToolPath)
                } While ( ($changeToolPath -ne "c") -and ($changeToolPath -ne "") )
            } else {
                $toolPath = $FileBrowser.FileName
                Write-Host "Path of $tool.exe is set to $toolPath" -ForegroundColor Green
                $VulnID = $script:VulnIdNA
                $Outcome = $script:OutcomeNA
                Write-Log -Message "Path of $tool.exe is set to $toolPath"
                $changeToolPath = ""
            }
        }

        try {
            Write-Host "" |& $toolPath | Out-Null
            if ($tool -eq 'plink') {
                $script:PlinkPath = $toolPath
            } elseif
               ($tool -eq 'pscp') {
               $script:PscpPath = $toolPath
            }
            Write-Host "`nTested $tool.exe successfully" -ForegroundColor Green
            $VulnID = $script:VulnIdNA
            $Outcome = "SUCCESS"
            Write-Log -Message "Tested $tool.exe at $toolPath"
        } catch {
            $changePscpPath = "c"
            Write-Host "Failed to execute $toolPath" -ForegroundColor Red
            Write-Host "Make sure that the file still exists and permissions are configured correctly" -ForegroundColor Red
            $VulnID = $script:VulnIdNA
            $Outcome = "FAIL"
            Write-Log -Message "Test $tool.exe at $toolPath"
            writeError
        }
        
        # Test minimum version of the tool
        $toolRelStr = (& $toolPath -V | Select-String -Pattern 'Release')
        $null = $toolRelStr -match '(?<name>[^\d]+): Release (?<version>\d.+)'
        $toolName, $toolVersion = $Matches['name'].TrimEnd('.'), [version]$Matches['version']
        TestVersionSupport $toolVersion $toolMajorVersion $toolMinorVersion

    } While ($changeToolPath -eq "c") 

}

 
function ConnectvCenter {
	Get-FunctionName

	$vCenterConnected = $false
	$count = 1
	Do {
		$vc = Connect-VIServer -server $script:vCenter -Credential $script:vCenterCredentials
		
		if ($null -ne $vc -and $vc.Name -ne "") {
			$vCenterConnected = $true
			$script:VC = $vc
			Write-Host "`nConnected to vCenter $script:vCenter" -ForegroundColor Green
			$VulnID = $script:VulnIdNA
			$Outcome = "SUCCESS"
			Write-Log -Message "Connect to vCenter $script:vCenter"
		} else {
			Write-Host "Failed to connect to $script:vCenter."
			$VulnID = $script:VulnIdNA
			$Outcome = "FAIL"
			Write-Log -Message "Connect to vCenter $script:vCenter"
			if ($count -lt 3) {
				$count++
			} else {
				Write-Host "Attempts to connect to $script:vCenter have failed multiple times." -ForegroundColor Red
				$resp = Read-Host "Press Enter to retry, or e to exit the script"
				if ($resp.ToLower() -eq "e") {
					exit
				}
				$count = 0
			}
		}
	} While (!$vCenterConnected)
}

############################################################################
# FUNCTION: GetVCAPIToken
# PURPOSE:  Getting vCenter Server API session Token
# PARAMETERS: None.
# Output : Returns vCenter API session Token Value
############################################################################

function GetVCAPIToken {
	Get-FunctionName
	$user = ($script:vCenterCredentials).UserName
	$pass = ($script:vCenterCredentials).Password
	$creds = New-Object System.Management.Automation.PSCredential ($user, $pass)
	Write-Log -Level 'Debug' 'Getting Credentials'
	$sessionUri = "https://$script:vCenter/rest/com/vmware/cis/session"
	$authResponse = Invoke-RestMethod -Method Post -Uri $sessionUri -Credential $creds
	if ($authResponse.Value) {
		 Write-Host "Authentication Token acquired successfully" -ForegroundColor Green
		 Start-Sleep -Seconds 2
	}	else {
		 Write-Host "Authentication Token not acquired successfully" -ForegroundColor Red
	}
	return $authResponse
}

############################################################################
# FUNCTION: GetDVSandPGs
# PURPOSE:  Make VDS and PG objects available for use in the rules later
# NOTE:     Only needed for VxRail 4.7 (vSphere 6.7) platform, as on the
#           VxRail 7.0 (vSphere 7) platform the VMware script will be run.
# PARAMETERS: None.
############################################################################
function GetDVSandPGs {
	Get-FunctionName

	if ($script:VxRailMajorVersion -eq '4') {
		# Get vcenter DVS and PG objects
		Try{
			Write-Host "...Getting PowerCLI objects for all virtual distributed switches in vCenter: $script:vCenter"
			$script:dvs = Get-VDSwitch | Sort-Object Name
			Write-Host "...Getting PowerCLI objects for all virtual distributed port groups in vCenter: $script:vCenter"
			$script:dvpg = Get-VDPortgroup | Where-Object{$_.IsUplink -eq $false} | Sort-Object Name
		}
		Catch{
			Write-Host "...Failed to get DVS and PG objects from vCenter" -BackgroundColor Black -ForegroundColor Red
			writeError
			Disconnect-VIServer -Server $script:vCenter -Force -Confirm:$false
			Exit
		}
		Write-Log -Level 'Debug' "dvs = $script:dvs"
		Write-Log -Level 'Debug' "dvpg = $script:dvpg"
	}
}

function GetvCenter {
	Get-FunctionName

	Write-Host "`nAttempting to connect to vCenter..."
	if ($script:VxRailMajorVersion -eq '4') {
		$vcQuery = "psql -t -U postgres mysticmanager -c 'select vcenter_ip from settings'"
		$vc = QueryDatabase $vcQuery
		$script:vCenter=$vc[0].Trim() # assign the vcenter_ip
	} elseif ($script:VxRailMajorVersion -eq '7') {
		ForEach ($line in $script:PrerunData) {
			if ($line -match "vcenter_ip:") {
				$script:vCenter = ($line.Split(":"))[1]
				break
			}
		}
	}
	Write-Log -Level 'Debug' "script:vCenter = $script:vCenter"
}


function GetVirtualMachines {
	Get-FunctionName

	# initialize empty list (array)
	$script:VMNames      = @() # for ALL VM names
	$script:otherVMNames = @() # for OTHER VM names (other than VxM, VC, PSC)

	if ($script:VxRailMajorVersion -eq '4') {
		$vxmType = "VXRAIL_MANAGER"
		$vcType  = "VCSA"
		$pscType = "PSC"
		
		$vmQuery = "psql -t -U postgres marvin -c 'select vm_name, system_vm_type from virtual_machine'"
		$vms = QueryDatabase $vmQuery

		# extract VM names and find flag if vc is vxm deployed
		foreach ( $vm in $vms ) {

			if ( $null -eq $vm -or $vm -eq "" ) { continue } # skip empty line, could be last line

			# extract the elements from the column values
			$vmName = $vm.Split("|")[0].Trim()
			$vmtype = $vm.Split("|")[1].Trim()

			$script:VMNames += $vmName # build the array of ALL VM names

			# derive the required values based on vmtype
			switch ( $vmtype ) {
				$vxmType { $script:VxRailManagerVMName = $vmName; break }
				$pscType { $script:PSCVMName           = $vmName; break }
				$vcType  { $script:VCVMName            = $vmName
						$script:VxRailDeployedVC    = $true
						break
						}
				default  { $script:otherVMNames += $vmName # build the array of OTHER VM names
						}
			}
		}
	} elseif ($script:VxRailMajorVersion -eq '7') {
		ForEach ($line in $script:PrerunData) {
			if ($line -match "vxm_vm_id:") {
				$script:VxRailManagerVMName = (Get-VM -Id ($line.Split(":"))[1]).Name
				$script:VMNames += $script:VxRailManagerVMName
				break
			}
		}
		ForEach ($line in $script:PrerunData) {
			if ($line -match "vcsa_vm_id:") {
				$vcsa_vm_id = ($line.Split(":"))[1]
				if ($vcsa_vm_id -eq "" -or $vcsa_vm_id -eq "none") {
					$script:VCVMName = ""
				} else {
					$script:VCVMName = (Get-VM -Id $vcsa_vm_id).Name
					$script:VMNames += $script:VCVMName
					$script:VxRailDeployedVC = $true
				}
				break
			}
		}
		ForEach ($line in $script:PrerunData) {
			if ($line -match "other_vm_ids:") {
				$other_vm_ids = (($line.Split(":"))[1]).Split(",")
				break
			}
		}
		ForEach ($other_vm_id in $other_vm_ids) {
			$other_vm_name = (Get-VM -Id $other_vm_id).Name
			$script:VMNames += $other_vm_name
			$script:otherVMNames += $other_vm_name
		}
	}

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "VxRail deployed VMs ($($script:VMNames.Count)): $($script:VMNames -join ', ')"
	Write-Log -Message "'Other' (non VxM, VC, PSC) VxRail deployed VMs ($($script:OtherVMNames.Count)): $($script:OtherVMNames -join ', ')"
	Write-Log -Message "VxR VM name: $script:VxRailManagerVMName"
	if ($script:VxRailMajorVersion -eq '4') {
		Write-Log -Message "PSC VM name: $script:PSCVMName"
	}
	Write-Log -Message "VC VM name : $script:VCVMName"
	Write-Log -Message "vCenter is deployed by VxRail: $script:VxRailDeployedVC"
}


############################################################################
# FUNCTION: GetVMHostsConfigedSSHStatus
# PURPOSE: Get the SSH status of the ESXi nodes prior to applying the STIG hardening 
# in order for setting the nodes' SSH back to their original configurations
# PARAMETERS: None.
############################################################################
function GetVMHostsConfigedSSHStatus {
	Get-FunctionName
	$script:VMHostsSSHOn = @{}
	$SSHStatus
	foreach ($vmHost in $script:VMHosts) {
		
		$SSHStatus = (Test-NetConnection $vmHost -Port 443 -ErrorAction Ignore -WarningAction silentlyContinue).TcpTestSucceeded
		$script:VMHostsSSHOn.Add($vmHost, $SSHStatus)
	}
}

############################################################################
# FUNCTION: GetClusterAndVMHosts
# PURPOSE: Get ESXi nodes from the VxRail Manager database and 
# set the variables $script:VMHosts and $script:Cluster
# to be the VxRail ESXi nodes and the parent cluster of the nodes, respectively.
# PARAMETERS: None.
############################################################################
function GetClusterAndVMHosts {
	Get-FunctionName

	$script:VMHosts = @()
	if ($script:VxRailMajorVersion -eq '4') {
		# query all management accounts
		$hostQuery = "psql -t -U postgres mysticmanager -c 'select host, username, component from management_account order by host'"
		$rs = QueryDatabase $hostQuery
		
		# extract the host names and management account
		$index = 0
		foreach ( $r in $rs ) {

			if ( $null -eq $r -or $r -eq "" ) { continue } # where clause: skip empty line, could be last line

			# extract the individual fields
			$esxhost   = $r.Split("|")[0].Trim()
			$username  = $r.Split("|")[1].Trim()
			$component = $r.Split("|")[2].Trim()

			if ( $component -ne 'ESXi' ) { continue } # skip all non-ESXi components

			$script:VMHosts += Get-VMHost $esxhost # add this host to the array
			$script:ESXiManagementAccount = $username

			$index++
		}

		$script:Cluster = $script:VMHosts[0].Parent	# set cluster to the parent of any (the first) host
	} elseif ($script:VxRailMajorVersion -eq '7') {

		ForEach ($line in $script:PrerunData) {
			if ($line -match "esxi_host_names:") {
				$esxi_host_names = (($line.Split(":"))[1]).Split(",")
				break
			}
		}
		ForEach ($line in $script:PrerunData) {
			if ($line -match "esxi_management_user:") {
				$script:ESXiManagementAccount = ($line.Split(":"))[1]
				break
			}
		}
		ForEach($esxi_host_name in $esxi_host_names|Sort) {
			$script:VMHosts += Get-VMHost $esxi_host_name # add this host to the array
		}

		$script:Cluster = $script:VMHosts[0].Parent	# set cluster to the parent of any (the first) host
	}
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "VxRail ESXi Nodes: $($script:VMHosts -join ', ')"
	Write-Log -Message "VxRail cluster: $script:Cluster"
}

############################################################################
# FUNCTION: GetESXiCredential
# PURPOSE: Get the credential to access ESXi nodes to use Plink and execute SSH commands
# PARAMETERS: None.
############################################################################
function GetESXiCredential {
	Get-FunctionName
	
	$changeUsername = "c"
	$firstPrompt = $true
    Do {
		$sshSuccess = $false

		if ( $firstPrompt -and ($script:ESXiManagementAccount.Trim() -ne "" ) -and ($script:ESXiManagementAccount.Trim() -ne "root" ) ) {
			$script:ESXiSSHUser = $script:ESXiManagementAccount
			Write-Host "The following ESXi default management account was found in system configuration: $script:ESXiSSHUser" -ForegroundColor Green

			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA
			Write-Log -Message "ESXi default management account: $script:ESXiManagementAccount"
			Do {
				$changeUsername = Read-Host "Press Enter to continue. Press c, then Enter to change"
				$changeUserName = TrimLower($changeUserName)
			} While ( ($changeUserName -ne "c") -and ($changeUserName -ne "") )

			if ($changeUserName -eq "") {
				Write-Log -Message "User accepted default ESXi management account: $script:ESXiSSHUser"
			}
			$firstPrompt = $false
		}

		# Prompt for ESXi Management account
		While ($changeUsername -eq "c") {
			Write-Host
			$sSHUser = Read-Host "Please enter the user name that is authorized to execute SSH command on the ESXi node(s)"
			$sSHUser = $sShUser.Trim()
			if (($sSHUser -eq "") -or ($sShUser -eq "root")) {
				Write-Host "User name cannot be blank or root" -ForegroundColor Yellow
			} else {
				Write-Host "The user name entered is $sSHUser" -ForegroundColor Green
				$script:ESXiSSHUser = $sSHUser
				$changeUsername = ""
				$VulnID = $script:VulnIdNA
				$Outcome = $script:OutcomeNA
				Write-Log -Message "User changed ESXi default management account to: $script:ESXiSSHUser"
			}
		}

		# Prompt for password
		Do {
			Write-Host
			
			$password1 = Read-Host -AsSecureString "Please enter the $script:ESXiSSHUser account's password"
			$password2 = Read-Host -AsSecureString "Please confirm the password"
			$unSecPass1 = [System.Net.NetworkCredential]::new("", $password1).Password
			$unSecPass2 = [System.Net.NetworkCredential]::new("", $password2).Password

			if ($unSecPass1 -ne $unSecPass2) {
				Write-Host "Passwords not the same, please try again" -ForegroundColor Yellow
			} else {
				$script:ESXiSecurePassword = $password2
			}
		} While ($unSecPass1 -ne $unSecPass2)

		$numberSSHPass = 0
		
		foreach ($esx in $script:VMHosts) {
			Write-Host "`nTest connection to $esx"
			StartSSHOnVMHost $esx | Out-Null
			try {
				$nop = Write-Output "y"|& $script:plinkpath -ssh $esx # Accept host's SSH key fingerprint
				$cmdOut = Write-Output $unSecPass1|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx 'echo ''y'''
				if ( $cmdOut[-1].trim() -eq "y" ) {
					Write-Host "`nSSH test to $esx successful" -ForegroundColor Green
					$numberSSHPass++
					$sshSuccess = $true
					$VulnID = $script:VulnIdNA
					$Outcome = "SUCCESS"
					Write-Log -Message "SSH test to $esx"
				} else {
					$VulnID = $script:VulnIdNA
					$Outcome = "FAIL"
					Write-Log -Level 'Warn' -Message "SSH test to $esx"
				}
			} catch {
				Write-Host "`nSSH test to $esx failed." -ForegroundColor Yellow
				writeError
			} finally {
				if (! $script:VMHostsSSHOn[$esx]) {
					StopSSHOnVMHost $esx | Out-Null
				}
			}
		}
		
		Write-Host "SSH test successful: $numberSSHPass host(s)"

		if ($sshSuccess) {
			Clear-Variable -Name "password1"
			Clear-Variable -Name "password2"
			Clear-Variable -Name "unSecPass1"
			Clear-Variable -Name "unSecPass2"
		} else {
			Write-Host "`nAll connections failed" -ForegroundColor Yellow
			Write-Host "User name entered $script:ESXiSSHUser" -ForegroundColor Green
			Do {
				$changeUsername = Read-Host "Press Enter to continue. Press c, then Enter to change"
				$changeUserName = TrimLower($changeUserName)
			} While ( ($changeUserName -ne "c") -and ($changeUserName -ne "") )
		}
    } While (!$sshSuccess)
}

############################################################################
# FUNCTION: GetServiceServers
# PURPOSE: Get service servers (NTP, Syslog)
# PARAMETERS: None.
############################################################################
function GetServiceServers {
	Get-FunctionName

	if ($script:VxRailMajorVersion -eq '4') {
		# expect 1 data row from this query
		$serviceQuery = "psql -t -U postgres marvin -c 'select ntp_server_csv, syslog_server_csv from cluster_properties'"
		$services = QueryDatabase $serviceQuery

		$row1 = $services[0] # first row returned contains the data

		if ( $row1.Contains("|") ) {
			# found a row; extract values
			$script:NTPServers    = $row1.Split('|')[0].Trim()
			$script:SyslogServers = $row1.Split('|')[1].Trim()
		} else {
			# none found so set to empty
			$script:NTPServers    = ""
			$script:SyslogServers = ""
		}
	} elseif ($script:VxRailMajorVersion -eq '7') {

		ForEach ($line in $script:PrerunData) {
			if ($line -match "ntp_server:") {
				$script:NTPServers = ($line.Split(":"))[1]
				if ($script:NTPServers -eq "none") {
					$script:NTPServers = ""
				}
				break
			}
		}
		ForEach ($line in $script:PrerunData) {
			if ($line -match "syslog_server:") {
				$script:SyslogServers = ($line.Split(":"))[1]
				if ($script:SyslogServers -eq "none") {
					$script:SyslogServers = ""
				}
				break
			}
		}
	}

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA

	if ($script:NTPServers -eq "") {
		Write-Log -Message "NTP servers found in VxRail Manager database: <none>"
	} else {
		Write-Log -Message "NTP servers found in VxRail Manager database: $script:NTPServers"
	}
	if ($script:SyslogServers -eq "") {
		Write-Log -Message "Syslog servers found in VxRail Manager database: <none>"
	} else {
		Write-Log -Message "Syslog servers found in VxRail Manager database: $script:SyslogServers"
	}
}


############################################################################
# FUNCTION: GetPrerunData
# PURPOSE: Get the system data in VxRail to help set up the script's workflow
# PARAMETERS: None.
############################################################################
function GetPrerunData {
	Get-FunctionName
	$unSecPass = [System.Net.NetworkCredential]::new("", $script:VxMSecurePassword).Password
	$script:PrerunData = Write-output $unSecPass |& $script:plinkpath -ssh -l $script:VxMSSHUser $script:VxMFQDN "sudo /mystic/stig/info"
	Write-Log -Level 'Debug' "PrerunData = $script:PrerunData"
	Clear-Variable -Name unSecPass
}


############################################################################
# FUNCTION: GetVxRailVersion
# PURPOSE: Get the VxRail's version via the VxRail Manager's API
# PARAMETERS: None.
############################################################################
function GetVxRailVersion {
	Get-FunctionName
	
	$changeUsername = "c"

    Do {
		$RESTCallSuccess = $false
		
		# Prompt for vCenter administrator's account user name
		While ($changeUsername -eq "c") {
			Write-Host
			
			$vCenterAdminUsername = Read-Host "Please enter the vCenter administrator account's user name"
			$vCenterAdminUsername = $vCenterAdminUsername.Trim()

			if ($vCenterAdminUsername -eq "") {
				Write-Host "User name cannot be blank" -ForegroundColor Yellow
			} else {
				Write-Host "`nThe user name entered is $vCenterAdminUsername" -ForegroundColor Green
				$changeUsername = ""
				$VulnID = $script:VulnIdNA
				$Outcome = $script:OutcomeNA
				Write-Log -Message "User entered vCenter administrator account's user name: $vCenterAdminUsername"
			}
		}

		# Prompt for password
		Do {
			$password1 = Read-Host -AsSecureString "`nPlease enter the vCenter administrator account's password"
			$password2 = Read-Host -AsSecureString "Please confirm the password"
			$unSecPass1 = [System.Net.NetworkCredential]::new("", $password1).Password
			$unSecPass2 = [System.Net.NetworkCredential]::new("", $password2).Password
			
			if ( $unSecPass1 -ne $unSecPass2 ) {
				Write-Host "Passwords not the same, please try again" -Foregroundcolor Yellow
			}
		} While ($unSecPass1 -ne $unSecPass2)

		# Ignore self-signed certificate
		if (-not ([System.Management.Automation.PSTypeName]'ServerCertificateValidationCallback').Type)
		{
			# The following statement must not have leading spaces
			$certCallback = @"
				using System;
				using System.Net;
				using System.Net.Security;
				using System.Security.Cryptography.X509Certificates;
				public class ServerCertificateValidationCallback
				{
					public static void Ignore()
					{
						if(ServicePointManager.ServerCertificateValidationCallback ==null)
						{
							ServicePointManager.ServerCertificateValidationCallback +=
								delegate (Object obj, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
								{
									return true;
								};
						}
					}
				}
"@
			Add-Type $certCallback
		}
		[ServerCertificateValidationCallback]::Ignore()
		
		$Error.clear() # clear error variable - possibly output in the Catch block below

		try {
			Write-Log -Level 'Debug' 'About to execute REST call'
			$Base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $vCenterAdminUsername, $unSecPass1)))
			$Headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
			$Headers.Add('Authorization',('Basic {0}' -f $Base64AuthInfo))
			$Headers.Add('Accept','application/json')
			$Method = 'GET'

			$URI = "https://$script:VxMFQDN/rest/vxm/v3/system"
			Write-Log -Level 'Debug' "URI: $URI"

			$Response = Invoke-RestMethod -Headers $Headers -Method $Method -Uri $URI
			Write-Log -Level 'Debug' "Response: $Response"

			$script:VxRailVersion = ($Response.version).trim()
			Write-Log -Level 'Debug' "VxRailVersion: $script:VxRailVersion"

            if ($script:VxRailVersion.Split(".")[0] -eq '4' -or $script:VxRailVersion.Split(".")[0] -eq '7') {
				Write-Host "VxRail version: $script:VxRailVersion" -Foregroundcolor Green
				
				$script:vCenterCredentials = New-Object System.Management.Automation.PSCredential ($vCenterAdminUsername, $password1)
				$script:vCAdmUser = $vCenterAdminUsername
				$script:vCAdmSecPass = $password1
				$RESTCallSuccess = $true
				Clear-Variable -Name "password1"
				Clear-Variable -Name "password2"
				Clear-Variable -Name "unSecPass1"
				Clear-Variable -Name "unSecPass2"
				Clear-Variable -Name "Base64AuthInfo"
				Clear-Variable -Name "Headers"
				$VulnID = $script:VulnIdNA
				$Outcome = "SUCCESS"
				Write-Log -Message "Supported VxRail version found: $script:VxRailVersion"
			} else {
				$VulnID = $script:VulnIdNA
				$Outcome = "FAIL"
				Write-Log -Message "Supported VxRail version not found"
			}
		} catch {
			# Only if in debug, then output the PowerShell Error message for more info
			if ( $DEBUGSWITCH -eq $True ) {
				Write-Host "ERROR: API call failure:"
				$Error
			}

			Write-Host "`nSupported VxRail version not found. User name or password incorrect? Please try again." -Foregroundcolor Yellow
			Write-Host "`n`tvCenter administrator account's user name: $vCenterAdminUsername" -ForegroundColor Green
			$changeUsername = Read-Host "`tPress Enter to continue. Press c, then Enter to change"
			$changeUserName = TrimLower($changeUserName)
		}
    } While (!$RESTCallSuccess)
}


############################################################################
# FUNCTION: GetVxMCredential
# PURPOSE: Get the credential to access VxRail Manager to use Plink and execute SSH commands
# PARAMETERS: None.
############################################################################
function GetVxMCredential {
 	Get-FunctionName
   
	$changeFQDN = "c"

    Do {
		$sshSuccess = $false
		# Prompt for VxRail Manager VM FQDN

		While ($changeFQDN -eq "c") {
			Write-Host
			$vxrmFQDN = Read-Host "Please enter the FQDN or IP address of the VxRail Manager"
			$vxrmFQDN = $vxrmFQDN.Trim()
			Write-Host "`nVxRail Manager FQDN or IP address entered is $vxrmFQDN" -ForegroundColor Green

			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA

			if ($vxrmFQDN -eq "") {
				Write-Host "FQDN cannot be blank" -ForegroundColor Yellow
				Write-Log -Message "VxRail Manager FQDN or IP address entered is blank"
			} else {
				$script:VxMFQDN = $vxrmFQDN
				$changeFQDN = ""
				Write-Log -Message "VxRail Manager FQDN or IP address entered is $vxrmFQDN"
			}
		}

		# Prompt for password
		Do {
			$password1 = Read-Host -AsSecureString "`nPlease enter $script:VxMSSHUser account's password"
			$password2 = Read-Host -AsSecureString "Please confirm the password"
			$unSecPass1 = [System.Net.NetworkCredential]::new("", $password1).Password
			$unSecPass2 = [System.Net.NetworkCredential]::new("", $password2).Password
			
			if ( $unSecPass1 -ne $unSecPass2 ) {
				Write-Host "Passwords not the same, please try again" -Foregroundcolor Yellow
			}
		} While ($unSecPass1 -ne $unSecPass2)

		try {
			$nop = Write-Output "y"|& $script:plinkpath -ssh $script:VxMFQDN # Accept host's SSH key fingerprint
			$cmdOutput = Write-Output $unSecPass1|& $script:plinkpath -ssh -l $script:VxMSSHUser $script:VxMFQDN 'echo ''y'''
            if ($cmdOutput.Trim() -eq "y") {
				Write-Host "SSH test to $script:VxMFQDN successful" -Foregroundcolor Green
				$script:VxMSecurePassword = $password1
				$sshSuccess = $true
				Clear-Variable -Name "password1"
				Clear-Variable -Name "password2"
				Clear-Variable -Name "unSecPass1"
				Clear-Variable -Name "unSecPass2"
				$VulnID = $script:VulnIdNA
				$Outcome = "SUCCESS"
				Write-Log -Message "SSH test to $script:VxMFQDN"
			} else {
				$VulnID = $script:VulnIdNA
				$Outcome = "FAIL"
				Write-Log -Message "SSH test to $script:VxMFQDN"
			}
		} catch {
			Write-Host "`n"
			writeError
			Write-Host "`nSSH test to $script:VxMFQDN failed. Servername or password incorrect? Please try again." -Foregroundcolor Yellow
			Write-Host "`n`tVxRail Manager's FQDN or IP address: $script:VxMFQDN" -ForegroundColor Green
			$changeFQDN = Read-Host "`tPress Enter to continue. Press c, then Enter to change"
			$changeFQDN = TrimLower($changeFQDN)
		}
    } While (!$sshSuccess)
}

############################################################################
# FUNCTION: QueryDatabase
# PURPOSE: Get the credential to access VxRail Manager to use Plink and execute SSH commands
# PARAMETERS: $query
############################################################################
function QueryDatabase {
    param([String] $Query)
 	Get-FunctionName
   
	$unSecPass = [System.Net.NetworkCredential]::new("", $script:VxMSecurePassword).Password
    try {
        try {
			$rs = Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:VxMSSHUser $script:VxMFQDN $Query
			
			$VulnID = $script:VulnIdNA
			$Outcome = "SUCCESS"
			Write-Log -Message "Executing query..."

		} catch [Exception] {
			$exceptionName = $_.Exception.GetType().FullName
			$exceptionMessage = $_.Exception.Message

			$VulnID = $script:VulnIdNA
			$Outcome = "FAIL"
			Write-Log -Level 'Warn' -Message "Failing query: ($Query), $exceptionName, $exceptionMessage"
            Write-Host "Failed to query VxRail Manager's database." -ForegroundColor Yellow
            Write-Host "$exceptionName, $exceptionMessage"
        }
    } catch {
		$exceptionName = $_.Exception.GetType().FullName
		$exceptionMessage = $_.Exception.Message

		$VulnID = $script:VulnIdNA
		$Outcome = "FAIL"
		Write-Log -Message "Failing query: ($Query), $exceptionName, $exceptionMessage"
        Write-Host "Failed to setup an SSH session." -ForegroundColor Yellow
    } finally {
		Clear-Variable -Name "unSecPass"
	}
	# Need to remove the ssh password prompt that was returned in the first row/element.
	# So remove element 0 from the array
	$rs = $rs[1..($rs.count-1)]
    return $rs
}
#
#
#
############################################################################
# Start of VxRail ESXi Nodes Hardening Section
############################################################################

##################################################
# FUNCTION: SetAdvancedHostParam
# PURPOSE: Set the given advanced parameter to the given value on all connected ESXi hosts.
# PARAMETERS:
#	- advParamName  : Name of the advanced parameter
# 	- advParamValue : Value to set advanced parameter to
#	- advParamType  : Type of value: 'int' or 'string' (optional - only for UserVars)
#                     Only specify 'int' for integer UserVars, otherwise do not specify.
##################################################
function SetAdvancedHostParam {
	[CmdletBinding()]
	param( 
		[Parameter(Position=0,Mandatory)] [array] $vmHosts,
		[Parameter(Position=1,Mandatory)] [string] $advParamName, 
		[Parameter(Position=2,Mandatory)] [string] $advParamValue, 
		[Parameter(Position=3,Mandatory=$false)] $advParamType
		)
	Get-FunctionName

	$nrHosts = $vmHosts.Count
	
	# Convert secure password to plain text for use in plink
	$unsecPassword = [System.Net.NetworkCredential]::new("", $script:ESXiSecurePassword).Password
	
	# Get and set the requested param to requested value
	$cmd1 = "`$vmHosts | Get-AdvancedSetting -Name $advParamName | Set-AdvancedSetting -Value `"$advParamValue`" -Confirm:`$false | Format-Table -AutoSize| Out-String -Width 256"
	$cmdResp1 = Invoke-expression "$cmd1" 2>&1
	
	# Check if it was found on all hosts (ie occurs the same nr of times as there are hosts)
	$paramAddedAndSet = $false
	if ( ! (($cmdResp1 | Out-String) -match "($advParamName.*\n){$nrHosts}" )) {
		# Param not found on all hosts
		# Split the param in its category and its name, because if it is a UserVar category, it can be added if needed
		$paramCat  = $advParamName.Split(".")[0]
		$paramName = $advParamName.Split(".")[1]
		
		if ( $paramCat = "UserVars" ) {
			# This is a UserVar -> add this parameter to the hosts. Logic:
			# For each connected host:
			#   1.	Enable SSH on host	
			#	2.	Add parameter on Host command-line  using esxcfg-advcfg -A
			#   3.	Verify that new parameter is in the list using esxcfg-advcfg --list
			#	4.	Disable SSH on host
			
			Write-Host "Advanced parameter $advParamName not on all $nrHosts hosts. Adding..." -ForegroundColor Yellow
			$vmHosts | Sort | ForEach-Object {
				$esx = $_ 

				#Write-Output "# 1. Enable SSH on host"
				StartSSHOnVMHost $esx | Out-Null

				#Write-Output "# 2. Add parameter on Host command-line  using esxcfg-advcfg -A"
				# Set the param type spec: either string (default) or int
				if ( $advParamType -eq 'int' ) { 
					$paramTypeSpec = "--add-type int --add-min 0 --add-max 10000"
				} else {
					$paramTypeSpec = "--add-type 'string'"
				}
				# Now add the UserVar 
				$command = "esxcfg-advcfg --add-option $paramName $paramTypeSpec --add-desc $advParamName --add-default ' ' 2>`&1"
				$cmdOut = Write-Output $unsecPassword|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx $command ';echo $?'
				$addStatus = $cmdOut[-1]
				$cmdOut = $cmdOut[-2]
				$found=$false
				if ( $cmdOut -eq "Option with the name $paramName already exists" ) {
					#Write-Host "Parameter $advParamName already exists on host $esx.name - Setting value..." -ForegroundColor Yellow
					$found=$true # in this case we still want to try and set the value next
				}
				if (( $addStatus -eq "0" ) -OR $found ) {
					# Added successfully, Now set the new param to its value
					$command = "esxcfg-advcfg --user-var $paramName --set-user-var $advParamValue"
					$cmdOut = Write-Output $unsecPassword|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx $command

					#Write-Output "# 3. Verify that new parameter is in the list using esxcfg-advcfg --list"
					$command = "esxcfg-advcfg --list|grep -c $advParamName"
					$cmdOut = Write-Output $unsecPassword|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx $command ';echo $?'
					$chkStatus = $cmdOut[-1]
					$cmdOut = $cmdOut[-2]
					if (( $chkStatus -eq "0" ) -AND ( $cmdOut -eq "1" )) {
						# Setting value succeeded
						Write-Host "Setting $advParamName on host $esx.name to its value ($advParamValue) succeeded" -ForegroundColor Green
						$paramAddedAndSet = $true
						$VulnID = $script:VulnIdNA
						$Outcome = "SUCCESS"
						Write-Log -Message "Setting $advParamName on host $esx.name to its value ($advParamValue)"
					} else {
						# Setting value failed
						Write-Host "Setting $advParamName on host $esx.name to its value ($advParamValue) failed" -ForegroundColor Red
						$paramAddedAndSet = $false
						$VulnID = $script:VulnIdNA
						$Outcome = "FAIL"
						Write-Log -Message "Setting $advParamName on host $esx.name to its value ($advParamValue)"
					}
				} else {
					# Adding failed
					Write-Host "Adding $advParamName on host $esx.name failed" -ForegroundColor Red
					$paramAddedAndSet = $false
					$VulnID = $script:VulnIdNA
					$Outcome = "FAIL"
					Write-Log -Message "Setting $advParamName on host $esx.name to its value ($advParamValue)"
				}
				$paramOnHosts = $paramAddedAndSet
				# 4. Disable SSH on host
				if (! $script:VMHostsSSHOn[$esx]) {
					StopSSHOnVMHost $esx | Out-Null
				}
			}
		} else {
			# Not a UserVar -> cannot add this parameter
			$paramOnHosts = $false
			$script:failProcess++
			Write-Host "Setting $advParamName`: parameter not found on all $nrHosts hosts:" -ForegroundColor Red
			($cmdResp1|Out-String).Trim()
		}
	} else {
		# Param found on all hosts
		$paramOnHosts = $true
	}
	if ( $paramOnHosts -AND ! $paramAddedAndSet ) {
		# Param is on all hosts (and it wasn't just added and already set)
		# Now check if the value is set the same on all hosts
		# If the param value is very long, then only compare the first 200 chars only
		# (The width of cmd1.Output was already limited to 256, so matchStr will fit inside srcStr later)
		if ( $advParamValue.Length -gt 200 ) {
			$advParamValue = $advParamValue.Substring(0,200)
		}
		# Ensure the match doesn't fail due to brackets in the text
		$srcStr   = ($cmdResp1 | Out-String).Trim() -replace '(\(|\))',''
		$matchStr = "$advParamName $advParamValue"  -replace '(\(|\))',''

		# Match?
		if ( $srcStr -match "($matchStr.*\n?){$nrHosts}" ) {
			$script:passProcess++
			Write-Host "Setting $advParamName value to $advParamValue complete" -ForegroundColor Green
			$VulnID = $script:VulnIdNA
			$Outcome = "SUCCESS"
			Write-Log -Message "Setting $advParamName value to $advParamValue complete"
		} else {
			$script:failProcess++
			Write-Host "$advParamName is on all $nrHosts hosts, but not all set the value to: $advParamValue" -ForegroundColor Red
			($cmdResp1|Out-String).Trim()
			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA
			Write-Log -Message "$advParamName is on all $nrHosts hosts, but not all set the value to: $advParamValue"
		}
	}
}


##################################################
# FUNCTION: SetAdvancedVMParam
# PURPOSE: Set the given advanced parameter to the given value on the given VM.
# PARAMETERS:
#   - hardenVm      : VM object
#	- advParamName  : Name of the advanced parameter
# 	- advParamValue : Value to set advanced parameter to
##################################################
function SetAdvancedVMParam {
	param( 
		[Parameter(Position=0,Mandatory)] $hardenVm,
		[Parameter(Position=1,Mandatory)] [string] $advParamName, 
		[Parameter(Position=2,Mandatory)] $advParamValue
		)
	Get-FunctionName

	Write-Log -Level 'Debug' "SetAdvancedVMParam: VM name     = $hardenVm"
	Write-Log -Level 'Debug' "SetAdvancedVMParam: Param name  = $advParamName"
	Write-Log -Level 'Debug' "SetAdvancedVMParam: Param value = $advParamValue"

	Try {
		## Checking to see if current setting exists
		If ( $asetting = $hardenVm | Get-AdvancedSetting -Name $advParamName -EA Stop ) {
			If ( $asetting.value -eq $advParamValue ) {
				# value is already set
				$Outcome="SUCCESS"; Write-Log "...Setting $advParamName is already configured correctly on $hardenVm...value: $advParamValue"
			} Else {
				# value set incorrectly
				$Outcome="SUCCESS"; Write-Log "...Setting $advParamName was incorrectly set on $hardenVm...setting to $advParamValue"
				# set the advanced setting
				$asetting | Set-AdvancedSetting -Value $advParamValue -Confirm:$false -EA Stop
			}
		} Else {
			# did not find a value
			$Outcome="SUCCESS"; Write-Log "...Setting $advParamName does not exist on $hardenVm...creating setting..."
			# create a new advanced setting
			$hardenVm | New-AdvancedSetting -Name $advParamName -Value $advParamValue -Confirm:$false -EA Stop
		}
		$script:passProcess++
	}
	Catch {
		$script:failProcess++
		Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenVm" "FAIL"
		writeError
		continue
	}
}


##################################################
# FUNCTION: SetVxSecAdvancedVMParam
# PURPOSE: Apply this VxSec rule, which will handle an advanced parameter on a VM.
# PARAMETERS:
#   - VxSecId       : VxSec mapping id
#   - hardenVm      : VM object
#	- advParamName  : Name of the advanced parameter
# 	- advParamValue : Value to set advanced parameter to
##################################################
function SetVxSecAdvancedVMParam {
	param( 
		[Parameter(Position=0,Mandatory)] [string] $vxsecId,
		[Parameter(Position=1,Mandatory)] $hardenVm,
		[Parameter(Position=2,Mandatory)] [string] $advParamName, 
		[Parameter(Position=3,Mandatory)] $advParamValue
	)
	Get-FunctionName

	if ( getVulnMap $vxsecId ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		# If the Vul mapping is set to 'Y' check and fix the Vul
		If($script:vxSecRow.enabled){
			Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID for $advParamName with Title: $Title"
			SetAdvancedVMParam $hardenVm $advParamName $advParamValue
		} else {
			$Outcome = $script:OutcomeNA
			Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
		}
	}
}

###############################################################################
# FUNCTION  : PromptVIBInstall
# PURPOSE   : Prompt user if VIB must be installed on the 4.x nodes
# RETURNS   : $script:vibInstallYN
# NOTES     : If Yes, then this function will call function GetVIBFile, 
#             to get the VIB file and store it on the VxRail cluster storage.
###############################################################################
Function PromptVIBInstall {
	Get-FunctionName
	Write-Host "Do you wish to install the VMware STIG VIB?"
	Do {
		$resp = Read-Host "Press Enter to continue. Press s, then Enter to skip"
		$resp = TrimLower($resp)
	} While ( ($resp -ne "s") -and ($resp -ne "") )

	if ($resp -ne "s") {
		$script:vibInstallYN = "Y"
		GetVIBFile $vmHosts[0] # get the vib and store it on the vSAN storage
	} else {
		$script:vibInstallYN = "N"
	}
}

##################################################
# FUNCTION  : GetVIBFile
# PURPOSE   : Get the VIB from the user and put it on the vSAN (any ESX can be passed to use for that)
# PARAMETERS: ESXi object of any of the nodes
##################################################
function GetVIBFile {
	param ($esx)
	Get-FunctionName

	Write-Host "`nObtaining VMware STIG VIB to store on the VxRail cluster storage" -ForegroundColor Green

	$ConfirmPreference = "None"

	# Allow user to select the VIB and then store that VIB on the datastore

	try {
		# Prompt to select a .vib file
		$unSecPass = [System.Net.NetworkCredential]::new("", $script:ESXiSecurePassword).Password
		$vibFolder = "vxrail_stig_vibs"
		$vibFolderUUID = ""
		$vibFileName = ""

		StartSSHOnVMHost $esx | Out-Null

		Add-Type -AssemblyName System.Windows.Forms
		$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
			Title = "Select the VMware VIB File"
			Filter = "VIB files (*.vib)|*.vib"
			InitialDirectory = [Environment]::GetFolderPath('MyComputer')
		}
		$null = $FileBrowser.ShowDialog()

		# Return to end function if no file was selected
		if ($null -eq $FileBrowser -or $FileBrowser.FileName -eq "") {
			Write-Host "No file was selected" -ForegroundColor Red
			return
		} else {
			$vibFileName = ($FileBrowser.FileName).Split("\")[-1]

			$vsanName = Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx 'esxcli vsan datastore name get'
			$vsanName = ($vsanName[-1].Split(" "))[-1]

			$vsanMount = Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx "esxcli storage filesystem list | grep '$vsanName'"
			$vsanMount = ($vsanMount[-1].Split(" "))[0]
			$nop = Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx "cd $vsanMount;mkdir $vibFolder 2>/dev/null"

			$vibFolderUUID = Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx "ls -l $vsanMount/$vibFolder"
			$vibFolderUUID = ($vibFolderUUID[-1].Split(" "))[-1]

			$datastore = Get-Datastore -Name $vsanName
			New-PSDrive -Location $datastore -Name DS -PSProvider VimDatastore -Root "\" | Out-Null
			Copy-DatastoreItem -Item $FileBrowser.FileName -Destination DS:\$vibFolderUUID
			$script:VIBPATH = "$vsanMount/$vibFolder/$vibFileName"
			Write-Log -Level 'Debug' "script:VIBPATH = $script:VIBPATH"
		}

	} catch {
		writeError
	} finally {
		Remove-PSDrive -Name DS -ErrorAction Ignore
		if (! $script:VMHostsSSHOn[$esx]) {
			StopSSHOnVMHost $esx | Out-Null
		}
	}
}

##################################################
# FUNCTION  : InstallVIB
# PURPOSE   : Install the VIB on the passed-in ESXi host.
# PARAMETERS: Name of ESXi host, where vib must be installed
##################################################
function InstallVIB {
	param ($vmHostName)
	Get-FunctionName

	Write-Host "`nStart Installing VMware STIG VIB on VxRail" -ForegroundColor Green

	$failProcess=0
	$passProcess=0

	$ConfirmPreference = "None"

	# Install VIB on the host
	$msg = "Installing VIB on $vmHostName using $script:VIBPATH"
	Write-Host "`n$msg`n"
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "$msg"

	# Install the VIB
	$ESXCLI = Get-EsxCli -VMHost $vmHostName -V2 -ErrorAction Stop
	$arg = $esxcli.software.vib.install.CreateArgs()
	$arg.viburl = $script:VIBPATH 
	$arg.nosigcheck = $true
	$action = $esxcli.software.vib.install.invoke($arg)

	if ( ($action.Message -like "Operation finished successfully.") -Or  ($action.Message -like "Host is not changed.") )
	{
		Write-host "Action Completed successfully on $vmHostName (or host is already using correct VIB)" -ForegroundColor Green
		$VulnID = $script:VulnIdNA
		$Outcome = $script:OutcomeNA
		Write-Log -Message "Action Completed successfully on $vmHostName (or host is already using correct VIB)"
		$passProcess++
	} else {
		Write-host $action.Message -ForegroundColor Red
		$failProcess++
		return $false
	}

	# SUMMARY
	Write-Host "`n****************************"
	Write-Host "* VIB installation summary *"
	Write-Host "****************************"
	Write-Host "$passProcess process(es) completed successfully" -ForegroundColor Green
	Write-Host "$failProcess process(es) failed`n" -ForegroundColor Red

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "VIB installation summary"
	Write-Log -Message "$passProcess process(es) completed successfully"
	Write-Log -Message "$failProcess process(es) failed"

	Clear-Variable -Name "failProcess"
	Clear-Variable -Name "passProcess"

	return
}

###################################################################
# FUNCTION  : CheckVxMHasInternalDNS
# PURPOSE   : Check if the VxM is configured with an internal DNS
###################################################################
function CheckVxMHasInternalDNS {
	Get-FunctionName

	# Findout if the VxRail has an internal DNS, if so do not proceed with VM STIG.
	$URI = "https://localhost/rest/vxm/v1/system/dns"
	$unSecPass1 = [System.Net.NetworkCredential]::new("", $script:vCAdmSecPass).Password
	$Query = "curl --user "+$script:vCAdmUser+":"+$unSecPass1+" "+$URI+" -k"
	$unSecPass2 = [System.Net.NetworkCredential]::new("", $script:VxMSecurePassword).Password

	$result = Write-Output $unSecPass2|& $script:plinkpath -ssh -l $script:VxMSSHUser $script:VxMFQDN $Query
	$pwdPromptLine, $remResult = $result
	
	Clear-Variable -Name "unsecPass1"
	Clear-Variable -Name "unSecPass2"

	if ($remResult) {
		$script:VxMHasInternalDNS = ($remResult | ConvertFrom-Json).is_internal

		$msg = "The VxM internal DNS flag value is $script:VxMHasInternalDNS"
		Write-Host "$msg" -ForegroundColor Green
		Write-Log -Message "$msg"
	}
}


##################################################
# FUNCTION  : RemoveESXiVIBFile
# PURPOSE   : Check if the VMware ESXi DoD STIG VIB is installed and uninstall if present
# PARAMETERS: ESXi object of any of the nodes
##################################################
function RemoveESXiVIBFile {
	param ($esx)
	Get-FunctionName

	$msg = "Checking if VMware ESXi DoD STIG VIB is installed on $esx"
	Write-Host "`n $msg" -ForegroundColor Green
	Write-Log -Message "$msg"

	try {
		# Initialize
		$unSecPass = [System.Net.NetworkCredential]::new("", $script:ESXiSecurePassword).Password

		# Connect and Query to check if the ESXi DoD STIG VIB is installed on the ESXi
		# returns the list of ESXi DOD STIG VIBs found with the SSH Query result password prompt as the first line
		$VibQueryResult = Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx 'esxcli software vib list | grep "dod-esxi..-stig-r."'
		$pwdPromptLine, $foundVibLines = $VibQueryResult
		
		if ($foundVibLines.Count -gt 0) {
			foreach ($DodVibFound in $foundVibLines){
				# Extract the VIB name from the list of ESXi DOD STIG VIBs found
				$DodVibFound = $foundVibLines.Split(" ")[0]
				$msg = "VMware ESXi DoD STIG VIB was found installed on $esx, will be uninstalled now first. VIB: $DodVibFound"
				Write-Host "`n $msg" -ForegroundColor Yellow
				Write-Log -Message "$msg"
				
				# VIB uninstall
				$VibUninstallResult = Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx "esxcli software vib remove -n $DodVibFound"
				# Remove the password prompt from the uninstall result
				$pwdPromptLine, $uninstallResultLines = $VibUninstallResult

				$result = "The VMware ESXi DoD STIG VIB has been uninstalled. Please check your vCenter and reboot node $esx using the official reboot procedure. `n"
				Write-Host "`n $result" -ForegroundColor Green
				Write-Log -Message "$result"
				Write-Host "$uninstallResultLines" -ForegroundColor Green
				Write-Log -Message "$uninstallResultLines"
			}
		} else {
			# No ESXi DOD STIG VIBs found
			$msg = "VMware ESXi DoD VIB was not found on $esx"
			Write-Host "`n $msg" -ForegroundColor Green
			Write-Log -Message "$msg"
		}

	} catch {
		writeError
	}
}


##################################################################
# FUNCTION:   CheckESXiRebootPending
# PURPOSE:    Check if the VxRail node has a pending Reboot flag set
# PARAMETERS: $esx
# RETURNS   : Boolean value of node reboot pending flag status
##################################################################
function CheckESXiRebootPending {
    param($esx)
 	Get-FunctionName
   
	# Check if the node needs a reboot
	$unsecPass = [System.Net.NetworkCredential]::new("", $script:ESXiSecurePassword).Password
	Write-Host "Checking if the VxRail ESXi Node has a pending reboot" -ForegroundColor Green
	$Result =  Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $hardenHost "vim-cmd hostsvc/hostsummary|grep -i rebootrequired"
	Clear-Variable -Name "unsecPass"
	$ESXiRebootStatus = (((($Result.Split("=")[-1]).Trim()).Split(","))[0])
	Write-Host "Pending reboot status for node $hardenHost is $ESXiRebootStatus"
	$ESXiRebootStatus = [System.Convert]::ToBoolean($ESXiRebootStatus)
	return $ESXiRebootStatus
}

##################################################
# FUNCTION  : PromptNTPConfig
# PURPOSE   : Prompt user if NTP servers must be (re)configured on the nodes
# RETURNS   : $script:ntpConfigYN, $script:newNTPServers
##################################################
function PromptNTPConfig {
	Get-FunctionName
	$changeNTPServers = "y"
	$NTPServers = $script:NTPServers.Trim()
	if ($NTPServers -ne "") {
		Write-Host "`nThe following NTP server(s) were found in the system configuration: $NTPServers" -ForegroundColor Green
		$VulnID = $script:VulnIdNA
		$Outcome = $script:OutcomeNA
		Write-Log -Message "The following NTP server(s) were found in the system configuration: $NTPServers"
		Do {
			$changeNTPServers = Read-Host "Press Enter to continue. Press c, then Enter to change"
			$changeNTPServers = TrimLower($changeNTPServers)
		} While ( ($changeNTPServers -ne "c") -and ($changeNTPServers -ne "") )
	}

	if ($changeNTPServers -eq "c" ) {
		$script:ntpConfigYN = "Y"
		$ntpServer1 = Read-Host -Prompt "Enter primary   NTP server FQDN or IP address (e.g. 0.us.pool.ntp.org)"
		$ntpServer1 = $ntpServer1.Trim()
		if ($ntpServer1 -eq "") {
			Write-Host "`nNTP server FQDN or IP address is blank. Skip NTP settings" -ForegroundColor Green
			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA
			Write-Log -Message "NTP server FQDN or IP address is blank. Skip NTP settings"
			$script:ntpConfigYN = "N"
			$script:newNTPServers = ""
		} else {		
			Write-Host "Primary NTP server is:   $ntpServer1" -ForegroundColor Green
			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA
			Write-Log -Message "User entered primary NTP server: $ntpServer1"
			$ntpServer2 = Read-Host -Prompt "Enter secondary NTP server FQDN or IP address (e.g. 1.us.pool.ntp.org)"
			$ntpServer2 = $ntpServer2.Trim()
			if ($ntpServer2 -ne "") {
				Write-Host "Secondary NTP server is: $ntpServer2" -ForegroundColor Green
				$NTPServers = "$ntpServer1,$ntpServer2"
				$VulnID = $script:VulnIdNA
				$Outcome = $script:OutcomeNA
				Write-Log -Message "User entered secondary NTP server: $ntpServer2"
			} else {
				$NTPServers = $ntpServer1
			}
			$script:newNTPServers = $NTPServers
		}
	} else {
		$script:ntpConfigYN = "N"
		$script:newNTPServers = " "
	}
}

##################################################
# FUNCTION  : PromptSysLogConfig
# PURPOSE   : Prompt user if syslog servers must be (re)configured on the nodes
# RETURNS   : $script:syslogConfigYN, $script:newSyslogServers
##################################################
function PromptSysLogConfig {
	Get-FunctionName
	Write-Host "Do you wish to configure a syslog server?"
	Do {
		$resp = Read-Host "Press Enter to continue. Press s, then Enter to skip"
		$resp = TrimLower($resp)
	} While ( ($resp -ne "s") -and ($resp -ne "") )

	If ($resp -eq "s") {
		$script:syslogConfigYN = "N"
		$script:newSyslogServers = " "
		$VulnID = $script:VulnIdNA
		$Outcome = $script:OutcomeNA
		Write-Log -Message "User selected to skip configuring a syslog server"
	} else {
		$changeLogServers = "c"
		$log_host_server = $script:SyslogServers.Trim()

		if ($log_host_server -ne "") {
			Write-Host "`nThe following syslog server(s) were found in the system configuration: $log_host_server" -ForegroundColor Green
			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA
			Write-Log -Message "The following syslog server(s) were found in the system configuration: $log_host_server"
			Do {
				$changeLogServers = Read-Host "Press Enter to continue. Press c, then Enter to change"
				$changeLogServers = TrimLower($changeLogServers)
			} While ( ($changeLogServers -ne "c") -and ($changeLogServers -ne "") )
		}

		# Configure a Syslog Server
		if ($changeLogServers -eq "c") {
			$log_host_server = Read-Host -Prompt "Enter log host (syslog) server IP (e.g. 0.0.0.0)"
			$log_host_server = $log_host_server.Trim()
			Write-Host "Log host (syslog) server is $log_host_server" -ForegroundColor Yellow	
		}

		if ($log_host_server -eq "") {
			$script:syslogConfigYN = "N"
			$script:newSyslogServers = " "

			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA
			Write-Log -Message "The log host server IP is blank. No syslog host was changed."
			Write-Host "The log host server IP is blank. No syslog host was changed." -ForegroundColor Red
		} else {
			$script:syslogConfigYN = "Y"
			$script:newSyslogServers = "$log_host_server"

			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA
			Write-Log -Message "User entered secondary NTP server: $log_host_server"
		}
	}
}


###########################################################################
# FUNCTION  : getESXiNameForVmName
# PURPOSE   : Get a VM's host, based on the VM name.
# PARAMETERS: VM name
# RETURNS   : ESXi Host name in $script:vmESXiHost (or $false if unsuccessful)
###########################################################################
function getESXiNameForVmName {
	param (
		[Parameter(Mandatory = $true)] $vmName
	)
	Get-FunctionName

	try {
		return (Get-VM -Name "$vmName" -EA Stop).VMHost.Name
	}
	catch {
		$OutCome = "FAIL"
		$msg = "Failed to Get-VM with name $vmName"
		Write-Host "$msg" -ForegroundColor Red
		Write-Log "$msg"
		writeError
		return $false
	}
}


##################################################
# FUNCTION  : promptVmShutDownAllowed
# PURPOSE   : Prompt user if shutdown of VM is allowed so it can be hardened
# PARAMETER : optionalText
# RETURNS   : $true or $false
##################################################
function promptVmShutDownAllowed {
	param (	[Parameter(Mandatory = $true )] [string] $vmName,
			[Parameter(Mandatory = $false)] [string] $optionalText)
	Get-FunctionName

	Write-Host "`nVM name: $vmName" -ForegroundColor Yellow
	Write-Host "vSphere requires the VM to be shut down before advanced configuration parameters can be set." -ForegroundColor Yellow
	$promptText = "Can the VM be shut down for this hardening task (and started up again after)?"
	if ($optionalText) {
		$promptText = $promptText + "`n" + $optionalText
	}
	Write-Host "$promptText" -ForegroundColor Yellow

	Do {
		$isVMShutdownAllowed = Read-Host "Enter y to allow, or n to skip hardening and return to the menu: "
		$isVMShutdownAllowed = TrimLower($isVMShutdownAllowed)
	} While ($isVMShutdownAllowed -notmatch "y|n")

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "$promptText $isVMShutdownAllowed"

	return ($isVMShutdownAllowed -eq 'y')
}


##################################################
# FUNCTION  : getSecurePassword
# PURPOSE   : Prompt user for a password
# RETURNS   : password (as a securestring)
##################################################
function getSecurePassword {
	Get-FunctionName

	# Prompt for password
	Do {
		$password1 = Read-Host -AsSecureString "`nPlease enter the password"
		$password2 = Read-Host -AsSecureString "Please confirm the password"
		$unSecPass1 = [System.Net.NetworkCredential]::new("", $password1).Password
		$unSecPass2 = [System.Net.NetworkCredential]::new("", $password2).Password
		
		if ( $unSecPass1 -ne $unSecPass2 ) {
			Write-Host "Passwords not the same, please try again" -Foregroundcolor Yellow
		}
	} While ($unSecPass1 -ne $unSecPass2)

	Clear-Variable -Name ("password1","password2","unSecPass1","unSecPass2")

	return ($password1)
}

###########################################################################
# FUNCTION  : getConfigParamInESXiHostFile
# PURPOSE   : To get a configuration parameter value in a given ESXi file
# PARAMETERS: ESXi host name
#			  File path where the param needs to be retrieved
#			  Name of the attribute which needs to be retrieved
###########################################################################
function getConfigParamInESXiHostFile {
	param (
		[Parameter(Mandatory = $true)] $esx,
		[Parameter(Mandatory = $true)] [string] $fileName,
        [Parameter(Mandatory = $true)] [string] $paramName
	)
	Get-FunctionName

	try {
		$unSecPass = [System.Net.NetworkCredential]::new("", $script:ESXiSecurePassword).Password

		# set the command that filters out the parameter setting
		$command = "grep -i '^\s*$paramName\s' $fileName"

		# run the command via SSH on the host, capturing the output
		$result = Write-Output $unSecPass | & $script:plinkpath -ssh -l $script:ESXiSSHUser $esx "$command"

		if ($result){
			# parameter found
			$pwdFirstLine, $keyValue = $result          # Remove the first from the result (due to SSH) and return remainder in $keyValue
			$paramValue = ($keyValue -split('\s'))[-1]  # Extract the value from the retrieved Key Value pair
			$returnValue = $paramValue
		} else {
			# parameter not found
			$returnValue = $false
		}
		#Write-Log -Level 'Debug' "Returning: $returnValue"
		return ($returnValue)
	}
	catch {
		writeError
		return $false
	}
}


####################################################################
# FUNCTION  : setConfigParamInESXiHostFile
# PURPOSE   : To set a configuration parameter in a given ESXi file
# PARAMETERS: ESXi host name
#			  File path where the param needs to be set
#			  Name of the attribute which needs to be set
#			  Attribute value to be set
#             Action [UPD|INS] for update existing or insert new parameter
# RETURNS:    0 (success) or !=0 (fail)
####################################################################
function setConfigParamInESXiHostFile {
	param (
		[Parameter(Mandatory = $true)] $esx,
		[Parameter(Mandatory = $true)] [string] $fileName,
        [Parameter(Mandatory = $true)] [string] $paramName,
        [Parameter(Mandatory = $true)] [string] $requiredValue,
        [Parameter(Mandatory = $true)] [string] $action
	)
	Get-FunctionName

	try {
		$unSecPass = [System.Net.NetworkCredential]::new("", $script:ESXiSecurePassword).Password

		# set the command to the correct action: update or insert
		if ( $action -eq 'UPD') {
			# replace the value in-line in the file
			$command = "sed -i 's/^\s*$paramName\s\s*.*`$/$paramName\t$requiredValue/' $fileName; echo `$?"
		} else {
			# append a new entry to the file for this parameter
			$command = "sed -i -e '`$a$paramName\t$requiredValue' $fileName; echo `$?"
		}

		# run the command via SSH on the host, capturing the output
		# The 'echo $?' at end of $command value will return 0 if sed was successful, and !=0 otherwise
		$result = Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $esx "$command"
		$pwdFirstLine, $sedResult = $result # Remove the first from the result (due to SSH) and return the sed result

		#Write-Log -Level 'Debug' "Returning result = $result"
		return $result  # 0 == success
	}
	catch {
		writeError
		return 1  # fail
	}
}

####################################################################
# FUNCTION  : controlConfigParamInESXiHostFile
# PURPOSE   : To set a configuration parameter in a given ESXi file
# PARAMETERS: ESXi host name
#			  File path where the param needs to be set
#			  Attribute name
#			  Attribute value
# RETURNS   : $True or $False
####################################################################
function controlConfigParamInESXiHostFile {
	param (
		[Parameter(Mandatory=$true)] $esxiName,
		[Parameter(Mandatory=$true)] $filePath,
		[Parameter(Mandatory=$true)] $paramName,
		[Parameter(Mandatory=$true)] $tgtParamValue # target parameter value
	)
	Get-FunctionName

	## retrieve current value
	$currValue = getConfigParamInESXiHostFile $esxiName $filePath $paramName
	Write-Log -Level 'Debug' "currValue=$currValue"

	if ($currValue) {
		# found a value
		if ($currValue.ToLower() -eq $tgtParamValue.ToLower()) {
			# value is already set
			Write-Log -Level 'Debug' "Requested value ($tgtParamValue) already set"
			$Outcome="SUCCESS"; Write-Log "...Setting $paramName is already configured correctly to $tgtParamValue on $esxiName"
			$result=0 # success
		} else {
			# value set incorrectly
			Write-Log -Level 'Debug' "Requested value ($tgtParamValue) set incorrectly, updating"
			$Outcome="SUCCESS"; Write-Log "...Setting $paramName was incorrectly set to $currValue on $esxiName...setting to $tgtParamValue"
			# set the parameter to requested value (update)
			$result=setConfigParamInESXiHostFile $esxiName $filePath $paramName $tgtParamValue 'UPD'
		}
	} else {
		# did not find a value
		# make a new entry in the file for this parameter
		Write-Log -Level 'Debug' "Requested value ($tgtParamValue) not found, inserting"
		$Outcome="SUCCESS"; Write-Log "...Setting $paramName  does not exist on $esxiName...creating setting..."
		# set the parameter to requested value (append)
		$result=setConfigParamInESXiHostFile $esxiName $filePath $paramName $tgtParamValue 'INS'
	}
	
	return ($result -eq 0) # return true if successful
}

####################################################################
# FUNCTION  : ConnectToESXiForVM
# PURPOSE   : Connect to the ESXi host of a given VM
# PARAMETERS: VM name
# RETURNS   : $false if connect or shutdown fails; ESXi hostname otherwise
####################################################################
function ConnectToESXiForVM {
    param (
		[Parameter(Position=0,Mandatory)] [String] $vmName
    )
	Get-FunctionName

	# Connect to the ESXi host (because in case the VM is the VCSA VM, we need to maintain control once vCenter is shutdown)
	Try {
		# Set the credential to use
		$script:ESXiCredentials = New-Object System.Management.Automation.PSCredential ($script:ESXiSSHUser, $script:ESXiSecurePassword)

		# Get the ESXi host name for this VM
		$script:vmESXiHost = getESXiNameForVmName $vmName
		if (-not ($script:vmESXiHost)) { $script:vmESXiHost = $False; return }
	
		Write-Log -Level 'Debug' "vmESXiHost = $script:vmESXiHost"
		Write-Log -Level 'Debug' "Only connecting to ESXi host if $global:DefaultVIServer == $script:vmESXiHost"

		# Only reconnect if the VM's host is different than the current connection
		if ( $script:vmESXiHost -ne $global:DefaultVIServer ) {
			Write-Host-Log "Connecting to ESXi Host..."
			Connect-VIServer -Server $script:vmESXiHost -Credential $script:ESXiCredentials -EA Stop
		}
	} Catch {
		$OutCome = "FAIL"
		$msg = "Failed to connect to ESXi host $script:vmESXiHost using user $script:ESXiSSHUser to shutdown VM $vmName"
		Write-Host "$msg" -ForegroundColor Red
		Write-Log "$msg"
		writeError
		return $false
	}
}

####################################################################
# FUNCTION  : shutdownVM
# PURPOSE   : Shutdown VM of given name.
#             Startup/shutdown needs to be done using the VM's ESXi
#             host connection, as the VM can be the VCSA as well.
#             Leaves connected to ESXi when shutdown is done (for hardening).
# PARAMETERS: VM name
# RETURNS   : $false if connect or shutdown fails; $true otherwise
####################################################################
function shutdownVM {
    param (
		[Parameter(Position=0,Mandatory)] [String] $vmName
    )
	Get-FunctionName

	Write-Log -Level 'Debug' "VM Name = $vmName"
	
	# Connect to the ESXi host (because in case the VM is the VCSA VM, we need to maintain control once vCenter is shutdown)
	ConnectToESXiForVM $vmName # sets $script:vmESXiHost
	if (-not ($script:vmESXiHost)) { return $false }

	# Shutdown the VM
	Try {
		$msg = "Shutting down $vmName..."
		Write-Host "$msg" -ForegroundColor Yellow
		Write-Log "$msg" 

		$vm = Get-VM -Name $vmName
		$vm | Shutdown-VMGuest -Confirm:$False -EA Stop | Select-Object state,hostname,vmName
		Write-Log -Level 'Debug' "Shutdown-VMGuest task on host is done..."
	} Catch {
		$OutCome = "FAIL"
		$msg = "Failed to shutdown VM $vmName, while connected to ESXi host $script:vmESXiHost using user $script:ESXiSSHUser"
		Write-Host "$msg" -ForegroundColor Red
		Write-Log "$msg"
		writeError
		return $false
	}

	# Wait until the status shows its powered off
	Write-Host-Log "Waiting until the status shows its powered off"
	do { Start-Sleep -Seconds $script:VMShutdownMonitorSleep } while ( (Get-VM $vm).PowerState -ne "PoweredOff" )

	Return $true
}

####################################################################
# FUNCTION  : startupVM
# PURPOSE   : Start up VM of given name.
#             Startup/shutdown needs to be done using the VM's ESXi
#             host connection, as the VM can be the VCSA as well.
#             Reconnect to vCenter after startup is done.
# PARAMETERS: VM name
#             VM type ::= [VXM|VCSA]
# RETURNS   : $false if connect or startup fails; $true otherwise
####################################################################
function startupVM {
    param (
		[Parameter(Position=0,Mandatory)] [String] $vmName,
		[Parameter(Position=1)] [String] $vmType = "notspecified"
    )
	Get-FunctionName

	Write-Log -Level 'Debug' "VM Name = $vmName"
		
	# Since function HardenVMs may have connected and disconnected from vCenter, we need to reconnect to the ESXi host first
	ConnectToESXiForVM $vmName # sets $script:vmESXiHost
	if (-not ($script:vmESXiHost)) { return $false }

	# Start up the VM
	Try {
		$msg = "Restarting $vmName..."
		Write-Host "$msg" -ForegroundColor Yellow
		Write-Log "$msg" 

		$vm = Get-VM -Name $vmName
		$vm | Start-VM -Server $script:vmESXiHost -Confirm:$False -EA Stop | Select-Object name,powerstate,vmhost
		Write-Log -Level 'Debug' "Start-VM task on host is done..."
	} Catch {
		$OutCome = "FAIL"
		$msg = "Failed to start VM $vmName, while connected to ESXi host $script:vmESXiHost using user $script:ESXiSSHUser"
		Write-Host "$msg" -ForegroundColor Red
		Write-Log "$msg"
		writeError
		return $false
	}

	# Wait at least until the VMTools have started up
	Write-Log -Level 'Debug' "Wait at least until the VMTools have started up"
	Write-Host "Checking : " $vmName
	do{
		Start-Sleep -Seconds 10;
		$VM = Get-VM $vmName
		$ToolsStatus = $VM.extensionData.Guest.ToolsStatus;
		Write-Host $VM "VM Status : " $ToolsStatus 
	}while($ToolsStatus -ne "toolsOk");
	Write-Host -ForegroundColor Green "Done Booting : " $vmName
	Write-Log -Level 'Debug' "$VM VM Status: " $ToolsStatus
	switch ( $vmType )
	{
		'VCSA'	{
					#waitUntilVcenterIsUp # wait until the vCenter Server has fully started
					Write-Host "Checking the vSphere Client/UI State." -ForegroundColor Yellow
					do	{
						Start-Sleep -Seconds 30;
						try	{
							Write-Log -Level 'Debug' 'About to execute REST call'							
							$AuthenticationToken = GetVCAPIToken
							$vsphereui = "https://$script:vCenter/rest/appliance/vmon/service/vsphere-ui"
							$sessionHeader = @{"vmware-api-session-id" = $AuthenticationToken.value}
							Write-Log -Level 'Debug' 'API Header Generated'
							$uiresponse = (Invoke-RestMethod -Method Get -Uri $vsphereui -Headers $sessionHeader).value
							Write-Host "vSphere UI/Client : " $uiresponse.State
							Write-Log -Level 'Debug' "vSphere UI/Client : " $uiresponse.State
							Write-Log -Level 'Debug' 'Getting vSphere web client/UI Response'
						} catch {
								$_.Exception.Response;
								Write-Host "vCenter IP is still not reachable. Re-checking..." -ForegroundColor Yellow
								Write-Log -Level 'Debug' 'vCenter IP is still not reachable. Re-checking...'
								}
						}while ($uiresponse.state -ne "STARTED")  
						Write-Host "vSphere Web Client is Started"
						Write-Host "Proceeding to Harden vCenter Server"
						Write-Log -Level 'Debug'  "Proceeding to Harden vCenter Server"
				}
		'VXM'	{
						#waitUntilVxMIsUp # wait until the VxRail Manager has fully started
						Write-Host-Log "Checking the VxRail Manager UI State in $script:vxrailBootMonitorInitialSleep seconds."
						Start-Sleep -Seconds $script:vxrailBootMonitorInitialSleep;
						try	{
							Write-Log -Level 'Debug' "Calling Python function"
							MonitorVxRailClusterHealthUntilOK
						} catch {
							Write-Host-Log "Unable to verify the VxRail Manager UI Status, please check the UI status before proceeding to harden the VxRail Manager VM"
							writeError						
						}
						Write-Host-Log "VxRail UI Status is Healthy"	
						Write-Host "Proceeding to Harden VxRail Manager VM"
						Write-Log -Level 'Debug'  "Proceeding to Harden VxRail Manager VM"
		}
		default {
					Write-Host "Please wait until the web client/UI are responding, then press Enter to continue..." -ForegroundColor Yellow
					Read-Host
					Write-Log "User pressed Enter after wait/check for UI to be back fully"
				}
	}

	# Disconnect from ESXi host
	Write-Log -Level 'Debug' "Disconnecting from ESXi Host..."
	Disconnect-VIServer -Server $script:vmESXiHost -Confirm:$false

	# Ensure vCenter is connected again
	Write-Host-Log "Reconnecting to vCenter..."
	ConnectvCenter

	Return $true
}

############################################################################
# FUNCTION	: askUserForAPassword
# PURPOSE	: Ask user to provide password for a requested user account
# Input		: Text to display at the password prompt [e.g.: $PromptText]
# Output 	: Returns requested user account's password
############################################################################
function askUserForAPassword {
	param([String] $PromptText)
	Get-FunctionName
	
	# Prompt for password
	Do {
		$password1 = Read-Host -AsSecureString "$PromptText"
		$password2 = Read-Host -AsSecureString "Please confirm the password"
		$unSecPass1 = [System.Net.NetworkCredential]::new("", $password1).Password
		$unSecPass2 = [System.Net.NetworkCredential]::new("", $password2).Password
		
		if ( $unSecPass1 -ne $unSecPass2 ) {
			Write-Host "Passwords not the same, please try again" -Foregroundcolor Yellow
		}
	} While ($unSecPass1 -ne $unSecPass2)
	
	Clear-Variable -Name "unsecPass1"
	Clear-Variable -Name "unSecPass2"
	
	return $password1
}

############################################################################
# FUNCTION	  : CopyFileToVM
# PURPOSE	  : Copy a script file to a VM
# Input		  : - VmIpOrFqdn
#      		  : - Username
#      		  : - Password
#      		  : - LocalFilePath   
#     		  : - RemoteFilePath
# Output 	  : Given file is copied to given VM's path
############################################################################
function CopyFileToVM {
	param (
		[String]$VmIpOrFqdn,
		[String]$Username,
		[String]$Password,
		[String]$LocalFilePath,
		[String]$RemoteFilePath
		)
	Get-FunctionName
	
	try {
		# Command to Copy file to a remote server
		$command = "& '$script:PscpPath' -pw '$Password' '$LocalFilePath' '${Username}@${VmIpOrFqdn}:${RemoteFilePath}' 2>&1"
		
		# Copying file using PSCP
		Invoke-Expression $command | Out-Null
		
		# Capture copy status 
		$exitCode = $LASTEXITCODE
		
		# Display appropirate message based on copy status
		if ( $exitCode -eq 0) {
			Write-Host-Log "File '$LocalFilePath' copied to '${VmIpOrFqdn}:${RemoteFilePath}'"
			$script:passProcess++
		} else {
			Write-Host-Log "Failed to copy '$LocalFilePath' to '${VmIpOrFqdn}:${RemoteFilePath}' (exitcode:$exitCode)"
			$script:failProcess++
		}
		Write-log -Level 'Debug' "File Copy Status: $exitCode"
		return $exitCode 
	}
	Catch {
		$script:failProcess++
		Write-Host-Log "Failed to copy '$LocalFilePath' to '${VmIpOrFqdn}:${RemoteFilePath}'"
		writeError 
	}
}

############################################################################
# FUNCTION	  : RestartService
# PURPOSE	  : This function restarts given service for a VM
# Input		  : - serviceRestartCommand   - e.g.: [systemctl sshd restart|vmon-cli --restart sts]
#      		    - serviceName             - e.g.: [SSH|STS]
# Output 	  : Given service restarted
############################################################################
function RestartService {

	param(
		[String] $VmIpOrFqdn,
		[String] $Username,
		[String] $Password,
		[String] $serviceName,
		[String] $serviceRestartCommand
	)
	Get-FunctionName

	try {
		# SSH to VM and restart the given service
		"y"| & $script:PlinkPath -ssh $VmIpOrFqdn -l $Username -pw $Password $serviceRestartCommand 
		Write-Host-Log "Service '$serviceName' restarted."
	}
	Catch {
		$script:failProcess++
		Write-Host-Log "Failure restarting '${serviceName}' service via SSH as '${Username}@${VmIpOrFqdn}'"
		writeError
	}
}

############################################################################
# FUNCTION	  : checkPortStatus
# PURPOSE	  : Validates given port is open or closed
# Input		  : - VmIpOrFqdn
#      		    - port
#      		    - Protocol
# Output	  : It returns 'True' or 'False' flag
############################################################################
function checkPortStatus {
	param (	
		[Parameter(Mandatory = $true )] [string] $VmIpOrFqdn,
		[Parameter(Mandatory = $true )] [string] $Port,
		[Parameter(Mandatory = $true )] [string] $Protocol
	)
	Get-FunctionName

	try {
		$portStatus = Test-NetConnection -ComputerName $VmIpOrFqdn -Port $Port -ErrorAction Stop
		if ( $portStatus.TcpTestSucceeded -eq "True" ) {
			Write-Host "Port '$Port($Protocol)' is open on '$VmIpOrFqdn'." -ForegroundColor Green
			Write-Log -Level 'Info' "Port '$Port($Protocol)' is open on '$VmIpOrFqdn'."
		}
		else {
			Write-Host "Port '$Port($Protocol)' is closed or not accessible on '$VmIpOrFqdn'." -ForegroundColor Yellow
		}
		Write-log -Level 'Debug' "$Protocol Port Status for '$VmIpOrFqdn': $portStatus.TcpTestSucceeded"
		return $portStatus.TcpTestSucceeded
	} catch {
		writeError
	}
}

############################################################################
# FUNCTION	  : checkGivenPasswordForSSH
# PURPOSE	  : Validate if given password is valid
# Input		  : - VmIpOrFqdn
#      		    - Username
#      		    - Password
# Output 	  : It returns 'True' or 'False' flag
############################################################################
function checkGivenPasswordForSSH {
	param(
		[Parameter(Mandatory = $true )] [string] $VmIpOrFqdn,
		[Parameter(Mandatory = $true )] [string] $Username,
		[Parameter(Mandatory = $true )] [string] $Password
	)
	Get-FunctionName

	try {
		# Use plink to check SSH connection and exit from the session
		# We need to enter "y" here, because if the SSH key is not stored yet, it will prompt it that needs to be done.
		$plinkOutput = "y" | & $script:PlinkPath -ssh $VmIpOrFqdn -l $Username -pw $Password "exit" 2>$null

		# Set a result flag to indicate success(true) or failure(false)
		$resultFlag = (! $plinkOutput)

		if ( $resultFlag ) {
			$msg = "SSH connection test for $VmIpOrFqdn with given password is successful."
			Write-Host $msg -ForegroundColor Green
			Write-Log -Level 'Info' $msg
		} else {
			Write-Log -Level 'Warn' "SSH connection test for $VmIpOrFqdn with given password failed."
		}
		return $resultFlag
	}catch {
		writeError
	}
}

#################################################################################################################################
# MAIN
#################################################################################################################################

############################################################################
# Start of VxRail ESXi Nodes Hardening Section
############################################################################
function HardenESXiNodes {
	param ([Parameter(Mandatory)] [Boolean] $hardenAll)
	Get-FunctionName

	Write-Host "`nStart VxRail ESXi Nodes Hardening" -ForegroundColor Green

	$failProcess=0
	$passProcess=0

	$ConfirmPreference = "None"

	#################
	# Get host list #
	#################
	if ( $hardenAll ) {
		# Set $vmHosts to the full list of hosts
		$vmHosts = $script:VMHosts
	} else {
		# Set $vmHosts to only the unhardened hosts
		$vmHosts = @() # initialize

		foreach ($h in $script:VMHosts) {
			$a = Get-Annotation -Entity $h -CustomAttribute $script:caPackageVersion -ErrorAction Ignore
			if ( ($null -eq $a) -or ($a[0].Value.Trim() -eq "") ) {
				$vmHosts = $vmHosts + $h
			}
		}

		# Are all hosts already hardened?
		if ($vmHosts.Count -eq 0) {
			Write-Host "There is no unhardened VxRail ESXi Node." -ForegroundColor Green
			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA
			Write-Log -Message "There is no unhardened VxRail ESXi Node"
			return
		}
	}

	#####################
	# Confirm host list #
	#####################
	$nrHosts = ($script:VMHosts).Count
	Write-Host "Connected VxRail ESXi Nodes overview:"
	$script:VMHosts | Format-Table -AutoSize -Property name,connectionstate
	Write-Host "Connected VxRail ESXi Nodes count: $nrHosts"

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Connected VxRail ESXi Nodes count: $nrHosts"

	$nrHosts = $vmHosts.Count
	if (!$hardenAll) {
		Write-Host "`nUnhardened VxRail ESXi Nodes:"
		$vmHosts | Format-Table -AutoSize -Property name,connectionstate
		Write-Host "Unhardened VxRail ESXi Nodes count: $nrHosts"

		$VulnID = $script:VulnIdNA
		$Outcome = $script:OutcomeNA
		Write-Log -Message "Unhardened VxRail ESXi Nodes count: $nrHosts"
	}

	Do {
		$resp = Read-Host "Press Enter to continue. Press s, then Enter to skip"
		$resp = TrimLower($resp)
	} While ( ($resp -ne "s") -and ($resp -ne "") )

	if ($resp -eq "s") {
		$VulnID = $script:VulnIdNA
		$Outcome = $script:OutcomeNA
		Write-Log -Message "User selected to skip VxRail ESXi Nodes hardening"
		return
	}
	
	##################################################
	# Prep calling the VMware script with parameters #
	# (so it doesn't happen repeatedly in the loop)  #
	##################################################
	# Where required/not available yet, prompt for the following info:
	# 1. vcenter	- available
	# 2. vccred		- available
	# 3. hostname	- available
	# 4. cluster	- optional (not needed; hostname is the alternative that we use)
	# 5. esxAdminGroup  - VMware STIG ID ESXI-70-000039 - Active Directory ESX Admin group membership
	$esxAdminGroup = " " # in vmware script: required param, but function disabled for VxRail
	# 6. allowedIPs     - VMware STIG ID ESXI-70-000056 - Allows IP ranges for the ESXi firewall
	$allowedIPs = " "	# in vmware script: required param, but function disabled for VxRail
	# 7. syslog servers	- VMware STIG ID ESXI-70-000004 - Only if passed to VMw ESXi STIG script - default from prerundata available
	PromptSysLogConfig  # returns $script:newSyslogServers
						# vmware script: will skip it if space(s) is passed in, otherwise will first check logInsight switch
	# 8. logInsight		- Supports VMware STIG ID ESXI-70-000004, which only executes if the logInsight switch is $false
	$logInsightSwitch = $false
	# 9. NTP servers	- VMware STIG ID ESXI-70-000046 - Only if passed to VMw ESXi STIG script - default from prerundata
	PromptNTPConfig     # returns $script:newNTPServers
						# vmware script: will skip it if space(s) is passed in
	#10. Native vLAN?	- VMware STIG ID ESXI-70-000063 - Only if passed to VMw ESXi STIG script - default 1
	#11. lockdownlevel  - VMware STIG ID ESXI-70-000001 - VMw ESXi STIG script applies lockdownNormal by default
	                    # Skipping this input, so default lockdownNormal will be applied to the host(s)


	#12. vib install? y/n
	# VMWare ESXi DoD STIG VIB installation is supported for 4.x branch
	if ($script:VxRailMajorVersion -eq '4') {
		$msg="This VxRail is at version $script:VxRailMajorVersion.$script:VxRailMinorVersion where VMWare ESXi DoD STIG VIB installation is supported."
		Write-Host "$msg`n" -ForegroundColor Green
		Write-Log -Message "$msg"
		PromptVIBInstall    # returns $script:vibInstallYN
							# in the host loop below, the vib will be installed before calling the vmware script
	} else {
		$msg1 = "This VxRail is at version $script:VxRailMajorVersion.$script:VxRailMinorVersion where VMWare ESXi DoD STIG VIB installation is NOT supported due to the issue described in VMware KB article 88055."
		$msg2 = "To resolve this issue, the VxRail Hardening Package has implemented the corresponding controls through our script."
		$msg3 = "If necessary, please follow the procedure and manually remove the VMware ESXi STIG VIB as outlined in the Known Issues section in the Dell VxRail STIG Hardening Guide"
		
		Write-Host "$msg1`n$msg2`n$msg3`n" -ForegroundColor Yellow
		Write-Log -Message "$msg1"
		Write-Log -Message "$msg2"
		Write-Log -Message "$msg3"
	}
	
	# Now harden all hosts in the $vmHosts array
	foreach ($hardenHost in $vmHosts) {

		# Host Log Header
		$Outcome = $script:OutcomeNA
		Write-Log -Message "------------------------------------------"
		Write-Log -Message "Hardening hostname: $hardenHost"
		Write-Log -Message "------------------------------------------"   

		# start SSH on the host
		StartSSHOnVMHost $hardenHost

		# Install VIB if required
		if ( $script:vibInstallYN -eq "Y" ) {
			try {
				InstallVIB $hardenHost 
				Write-Host "VMware STIG VIB installation succeeded on $hardenHost`n" -ForegroundColor Green
				$passProcess++
			}
			catch {
				$VulnID = $script:VulnIdNA
				$Outcome = "FAIL"
				Write-Log -Level 'Error' -Message "Caught an exception error during VMware STIG VIB installation on $hardenHost"
				Write-Host "VMware STIG VIB installation failed on $hardenHost`n" -ForegroundColor Red
				writeError
				$failProcess++
				continue
			}
		}

		#####################################################################################
		# Check and remove the VMWare ESXi DoD STIG VIB File for each ESXi host if installed
		#####################################################################################
		# If VxRail version is a 7.x.x version then remove VMWare ESXi DoD VIB if installed.
		if ($script:VxRailMajorVersion -ge '7') {
			RemoveESXiVIBFile $hardenHost
		}

		# Check if there is a pending reboot on the ESXi node
		$ESXiRebootStatus = CheckESXiRebootPending $hardenHost

		if ($ESXiRebootStatus) {
			Write-Host-Log "Hardening can't be applied at this point on $hardenHost, as is in a state that requires a reboot. Please retry hardening this node after a reboot has been performed."
			# stop SSH on the host
			StopSSHOnVMHost $hardenHost
			continue
		}

		###############################################################
		# Remediate ESXi nodes with controls from VMWare ESXi STIG ViB
		###############################################################

		# --------------------------------------------------------------------------------------------------------------------------------------------------------#
		# VXSEC401 ESXI-70-000008 - The ESXi host must display the Standard Mandatory DoD Notice and Consent Banner before granting access to the system via SSH. #
		# --------------------------------------------------------------------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC401' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"
					$name  = 'Config.Etc.issue'
					$value = 'You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only. By using this IS (which includes any device attached to this IS), you consent to the following conditions: -The USG routinely intercepts and monitors communications on this IS for purposes including, but not limited to, penetration testing, COMSEC monitoring, network operations and defense, personnel misconduct (PM), law enforcement (LE), and counterintelligence (CI) investigations. -At any time, the USG may inspect and seize data stored on this IS. -Communications using, or data stored on, this IS are not private, are subject to routine monitoring, interception, and search, and may be disclosed or used for any USG-authorized purpose. -This IS includes security measures (e.g., authentication and access controls) to protect USG interests--not for your personal benefit or privacy. -Notwithstanding the above, using this IS does not constitute consent to PM, LE or CI investigative searching or monitoring of the content of privileged communications, or work product, related to personal representation or services by attorneys, psychotherapists, or clergy, and their assistants. Such communications and work product are private and confidential. See User Agreement for details.'

					## Checking to see if current setting exists
					If($asetting = $hardenHost | Get-AdvancedSetting -Name $name){
						If($asetting.value -eq $value){
							# value is already set
							$Outcome="SUCCESS"; Write-Log "...Setting $name is already configured correctly on $hardenHost...value: $value"
						}Else{
							# value set incorrectly
							$Outcome="SUCCESS"; Write-Log "...Setting $name was incorrectly set on $hardenHost...setting to $value"
							# set the advanced setting
							$asetting | Set-AdvancedSetting -Value $value -Confirm:$false
						}
					}Else{
						# did not find a value
						$Outcome="SUCCESS"; Write-Log "...Setting $name does not exist on $hardenHost...creating setting..."
						# create a new advanced setting
						$hardenHost | New-AdvancedSetting -Name $name -Value $value -Confirm:$false
					}
					$passProcess++
				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}

		# ----------------------------------------------------------------------------------------------#
		# VXSEC402 ESXI-70-000009 The ESXi host SSH daemon must be configured with the DoD logon banner.
		# ----------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC402' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If ($script:vxSecRow.enabled) {
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "Banner" $script:ESXiIssueFilePath
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}

		# -----------------------------------------------------------------------------------------------------------------------------------------------------------------#
		# VXSEC403 ESXI-70-000010 - The ESXi host SSH daemon must use FIPS 140-2 validated cryptographic modules to protect the confidentiality of remote access sessions. #
		# -----------------------------------------------------------------------------------------------------------------------------------------------------------------#
		
		if ( getVulnMap 'VXSEC403' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If ($script:vxSecRow.enabled) {
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					# Checking to see if FIPS 140-2 validated cryographic module is enabled
					$unSecPass = [System.Net.NetworkCredential]::new("", $script:ESXiSecurePassword).Password
					$Result = Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $hardenHost "esxcli system security fips140 ssh get"
					Clear-Variable -Name "unSecPass"

					$pwdFirstLine, $fipssetting = $Result
					$fipssetting = (($fipssetting -split(':')).Trim())[-1]
					$fipsflag = [System.Convert]::ToBoolean($fipssetting)
					If ($fipsflag) {
						$Outcome="SUCCESS"; Write-Log "...FIPS 140-2 validated cryographic module is already enabled on $hardenHost"
					} Else {
						# Enable FIPS 140-2 validated cryographic module
						$Outcome="SUCCESS"; Write-Log "...FIPS 140-2 validated cryographic module is disabled on $hardenHost...enabling now..."
						Write-Output $unSecPass|& $script:plinkpath -ssh -l $script:ESXiSSHUser $hardenHost "esxcli system security fips140 ssh set -e true"
					}
					$passProcess++
				} Else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}

		# ------------------------------------------------------------------------------#
		# VXSEC404 ESXI-70-000012 - The ESXi host SSH daemon must ignore .rhosts files. #
		# ------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC404' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If ($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "IgnoreRhosts" "yes"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}

		# -------------------------------------------------------------------------------------------- #
		# VXSEC405 ESXI-70-000013 - The ESXi host SSH daemon must not allow host-based authentication. #
		# -------------------------------------------------------------------------------------------- #
		if ( getVulnMap 'VXSEC405' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try {
				# If the Vul mapping is set to 'Y' check and fix the Vul
				if ($script:vxSecRow.enabled) {
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "HostbasedAuthentication" "yes"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}

		# ----------------------------------------------------------------------------------------------------------#
		# VXSEC407 ESXI-70-000015	The ESXi host SSH daemon must not allow authentication using an empty password.
		# ----------------------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC407' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "PermitEmptyPasswords" "no"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}

		# ----------------------------------------------------------------------------------------------#
		# VXSEC408 ESXI-70-000016	The ESXi host SSH daemon must not permit user environment settings.
		# ----------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC408' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "PermitUserEnvironment" "no"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}
		
		# ----------------------------------------------------------------------------------------------------------------------------#
		# VXSEC411 ESXI-70-000020	The ESXi host SSH daemon must perform strict mode checking of home directory configuration files.
		# ----------------------------------------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC411' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "StrictModes" "yes"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}
		
		# ---------------------------------------------------------------------------------------------------------------------------------------------#
		# VXSEC412 ESXI-70-000021	The ESXi host SSH daemon must not allow compression or must only allow compression after successful authentication.
		# ---------------------------------------------------------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC412' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "Compression" "no"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}
		
		# -------------------------------------------------------------------------------------------------#
		# VXSEC413 ESXI-70-000022	The ESXi host SSH daemon must be configured to not allow gateway ports.
		# -------------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC413' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "GatewayPorts" "no"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}
		
		# --------------------------------------------------------------------------------------------------#
		# VXSEC414 ESXI-70-000023	The ESXi host SSH daemon must be configured to not allow X11 forwarding.
		# --------------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC414' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "X11Forwarding" "no"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}
		
		# ---------------------------------------------------------------------------#
		# VXSEC416 ESXI-70-000025	The ESXi host SSH daemon must not permit tunnels.
		# ---------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC416' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "PermitTunnel" "no"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}

		# ---------------------------------------------------------------------------------------------#
		# VXSEC417 ESXI-70-000026	The ESXi host SSH daemon must set a timeout count on idle sessions.
		# ---------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC417' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "ClientAliveCountMax" "3"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}
		
		# ------------------------------------------------------------------------------------------------#
		# VXSEC418 ESXI-70-000027	The ESXi host SSH daemon must set a timeout interval on idle sessions.
		# ------------------------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC418' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "ClientAliveInterval" "200"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}

		# --------------------------------------------------------------------------------#
		# VXSEC470 ESXI-70-000082	The ESXi host SSH daemon must disable port forwarding.
		# --------------------------------------------------------------------------------#
		if ( getVulnMap 'VXSEC470' ) {
			$VulnID = $script:vxSecRow.vulnid
			$Title  = $script:vxSecRow.vulntitle

			Try{
				# If the Vul mapping is set to 'Y' check and fix the Vul
				If($script:vxSecRow.enabled){
					Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

					$result = controlConfigParamInESXiHostFile $hardenHost $script:ESXisshdConfigFilePath "AllowTcpForwarding" "no"
					if ($result) { $passProcess++ } else { $failProcess++ }

				} else {
					$Outcome = $script:OutcomeNA
					Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				}
			}
			Catch{
				$failProcess++
				Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $hardenHost" "FAIL"
				writeError
				continue
			}
		}

		$VulnID = $script:VulnIdNA
		$Outcome = $script:OutcomeNA
		#####################################################################
		# END - Remediate ESXi nodes with controls from VMWare ESXi STIG ViB
		#####################################################################

		# stop SSH on the host
		StopSSHOnVMHost $hardenHost
		
		################################################
		# Call VMware DoD STIG ESXi remediation script #
		################################################

		# Splat the parameters
		$myargs = @{
			vcenter       = "$script:vCenter"
			vccred        = $script:vCenterCredentials
			hostname      = "$hardenHost"
			esxAdminGroup = "$esxAdminGroup"
			allowedIPs    = "$allowedIPs"
			syslogServer  = "$script:newSyslogServers"
			logInsight    = $logInsightSwitch
			ntpServers    = "$script:newNTPServers"
		}

		# Log call and params if in Debug mode
		$myargsStr=($myargs|Out-String)
		Write-Log -Level 'Debug' "CALL: $VMwareSTIGESXiScript $myargsStr"
		PauseIfDebug

		# Disconnect (as the VMware script connects itself) and reconnect after the ESXi script call
		# Prevent prompt about working with multiple default servers
		Disconnect-VIServer * -Confirm:$false | Out-Null

		# - In PowerShell 5.0+ an Error stream 6 was added for 'information', which is ***also used for the Write-Host output***
		try {
			& $VMwareSTIGESXiScript @myargs 6>&1 | Write-Log
			Write-Host "Apply VMware ESXi STIG finished on $hardenHost`n" -ForegroundColor Green
			$passProcess++
		}
		catch {
			$VulnID = $script:VulnIdNA
			$Outcome = "FAIL"
			Write-Log -Level 'Error' -Message "Caught an exception error during VMware ESXi STIG application on $hardenHost"
			Write-Host "Apply VMware ESXi STIG failed on $hardenHost`n" -ForegroundColor Red
			writeError
			$failProcess++
		}

		# Re-connect as the VMware script disconnects
		ConnectvCenter
		#######################################################
		# End Calling VMware DoD STIG ESXi remediation script #
		#######################################################
	}

	Write-Log -Message "------------------------------------------"
	
		
	############
	# Lockdown #
	############
	Write-Host "`nLockdown Mode:"
	Write-Host "If the host is a VxRail node, the script will also add the vxpsvc_ptagent_op account to the exception list. " -ForegroundColor Yellow 
	Write-Host "`nFor other users not to lose their permissions when the host enters lockdown mode,`n add user accounts to the Exception Users list from the vSphere Web Client prior to enabling lockdown mode. " -ForegroundColor Yellow 

	Write-Host "Do you wish to enable lockdown mode to hosts?"
	Do {
		$resp = Read-Host "Press Enter to choose lockdown mode. Press s, then Enter to skip"
		$resp = TrimLower($resp)
	} While ( ($resp -ne "s") -and ($resp -ne "") )

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA

	If ($resp -eq "s"){
		Write-Log -Message "User selected to skip enabling lockdown mode on the hosts"
	} else {
		$askagain = $true
		# Enable lockdown mode
		Write-Log -Message "Enable lockdown mode"
		### Ask the user to select the lockdown level
		Write-Host `n
		Write-Host "Please select the lockdown mode and press enter to continue..."
		Write-Host "`n Menu "
		Write-Host "========`n"
		Write-Host "1 - Normal Lockdown Mode"
		Write-Host "2 - Strict Lockdown Mode"
		Write-Host "3 - Disable Lockdown Mode"
		do {
			Write-Host "Enter 1 - 3" 
			$options = Read-Host
			Switch ($options) {
				### If task #1 is chosen, Enable Normal Lockdown Mode
				1 {
					Write-Host -ForegroundColor Yellow `n "Enable Normal Lockdown Mode"
					$lockdownlevel = "lockdownNormal"
					Write-Host "`nSetting all the hosts in `"Normal`" lockdown mode`n"
					$askagain = $false		
				}
				2 {
					Write-Host -ForegroundColor Yellow `n "Enable Strict Lockdown Mode"
					$lockdownlevel = "lockdownStrict"
					Write-Host "`nSetting all the hosts in `"Strict`" lockdown mode`n"
					$askagain = $false
				}	
				3 {
					Write-Host -ForegroundColor Yellow `n "Disabling Lockdown Mode"
					$lockdownlevel = "lockdownDisabled"
					Write-Host "`nSetting all the hosts in `"Disabled`" lockdown mode`n"
					$askagain = $false
				}
				default {
					Write-Host -ForegroundColor Red ">>> Invalid input. Please select option 1-3."
					$askagain = $true
				}
			}
		} while ($askagain)

		# Exception for a VxRail host
		$exceptUsers = New-Object 'System.Collections.Generic.List[String]'
		$exceptUsers.add("root")
		$exceptUsers.add("vxpsvc_ptagent_op")
		$exceptUsers.add($script:ESXiManagementAccount)
		$exceptUsers.add($script:ESXiSSHUser)

		# Exception for a non-VxRail host - the execption list does not include vxpsvc_ptagent_op
		$exceptUsersForNonVxRailHost = New-Object 'System.Collections.Generic.List[String]'
		$exceptUsersForNonVxRailHost.add("root")
		$exceptUsersForNonVxRailHost.add($script:ESXiManagementAccount)
		$exceptUsersForNonVxRailHost.add($script:ESXiSSHUser)


		ForEach ($vmHost in $vmHosts) {
			$hostname = $vmHost.Name
			$vmhostView =  $vmHost | Get-View
			$lockdown = Get-View $vmhostView.ConfigManager.HostAccessManager
			
			try {
				# Use ESXCli to get the host's vendor name
				$esxcli = Get-EsxCli -V2 -VMHost $vmHost 
				$productName = ($esxcli.hardware.platform.get.invoke().productname).toUpper()
				$VulnID = $script:VulnIdNA
				$Outcome = $script:OutcomeNA
				Write-Log -Message "ESXi node: $hostname. ESXi node's product name: $productName"
				# If Disabled lockdown Mode is selected ten no User exceptions list in needed.
				if ($lockdownlevel -eq "lockdownDisabled") {
					Write-Log -Message "`nIn Disable Lockdown Mode no user exception list is needed`n"
				}
				else {
					# If the product's name contains "VXRAIL", add the exception list that includes vxpsvc_ptagent_op.
					if ($productName.Contains("VXRAIL")) {
						$lockdown.UpdateLockdownExceptions($exceptUsers)
						if ($exceptUsers -match "root") {
							Write-Host "WARNING: The root account will be added to the exception list." -ForegroundColor Yellow
						}
					} else {
						$lockdown.UpdateLockdownExceptions($exceptUsersForNonVxRailHost)
						if ($exceptUsersForNonVxRailHost -match "root") {
							Write-Host "WARNING: The root account will be added to the exception list." -ForegroundColor Yellow
						}
					}
				}	
				# Set the lockdown level and the exception user list on the host
				$lockdown.ChangeLockdownMode($lockdownlevel)
				
				$VulnID = $script:VulnIdNA
				$Outcome = "SUCCESS"
				Write-Log -Message "Set lockdown mode on $hostname"
			}
			catch {
				$VulnID = $script:VulnIdNA
				$Outcome = "FAIL"
				Write-Log -Message "Set lockdown mode on $hostname"
				Write-Host "Lockdown failed on $hostname`n" -ForegroundColor Red
				writeError
				$failProcess++
				continue
			}    
			Write-Host "Lockdown succeeded on $hostname`n" -ForegroundColor Green
			$passProcess++
		}

		ForEach ($vmHost in $vmHosts) {
			$hostname = $vmHost.Name
			$ldMode = $vmHost.ExtensionData.Config.LockdownMode

			$vmhostView =  $vmHost | Get-View
			$lockdown = Get-View $vmhostView.ConfigManager.HostAccessManager
			$configedExceUsers = $lockdown.QueryLockdownExceptions()
			$configedExceUsers = $configedExceUsers -join ","     

			Write-Host "Host: $hostname, Lockdown mode: $ldMode,  exception users: $configedExceUsers"
		}
	}
	
	# Mark the hosts as hardened, using the custom attributes
	ForEach ($vmHost in $vmHosts) {
		SetCustomAttributeHistory $vmHost.Name
	}

	###########
	# SUMMARY #
	###########

	Write-Host "`n***********************"
	Write-Host "* ESXi config summary *"
	Write-Host "***********************"
	Write-Host "$passProcess process(es) completed successfully" -ForegroundColor Green
	Write-Host "$failProcess process(es) failed`n" -ForegroundColor Red

	Clear-Variable -Name "failProcess"
	Clear-Variable -Name "passProcess"
}

############################################################################
# End of VxRail ESXi Nodes Hardening Section
############################################################################

############################################################################
# Start of vCenter Hardening Section
############################################################################

############################################################################
# FUNCTION  : HardenVCShutdownRules
# PURPOSE   : Apply the VC STIG rules that require the VC VM to be shutdown
# PARAMETERS: VC (object)
############################################################################
function HardenVCShutdownRules {
	Get-FunctionName
		
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA

	$msg="Applying vCenter STIG rules"
	Write-Host "`n$msg" -ForegroundColor Green
	Write-Log -Message "$msg"
	
	$vm = Get-VM $script:VCVMName

	# ====================================
	# Rules from the VMware VC STIG script
	# ------------------------------------

	# VXSEC347 The vCenter Server must configure the vpxuser auto-password to be changed every 30 days
	SetVxSecAdvancedVMParam 'VXSEC347' $vm "VirtualCenter.VimPasswordExpirationInDays" "30"

	# VXSEC348 The vCenter Server must configure the vpxuser password meets length policy
	SetVxSecAdvancedVMParam 'VXSEC348' $vm "config.vpxd.hostPasswordLength" "32"

	# VXSEC356 The vCenter Server must produce audit records containing information to establish what type of events occurred
	SetVxSecAdvancedVMParam 'VXSEC356' $vm "config.log.level" "info"

	# VXSEC388 The vCenter server must be configured to send events to a central log server
	SetVxSecAdvancedVMParam 'VXSEC388' $vm "vpxd.event.syslog.enabled" "true"

	# VXSEC391 vCenter task and event retention must be set to at least 30 days
	SetVxSecAdvancedVMParam 'VXSEC391' $vm "event.maxAge" "30"
	SetVxSecAdvancedVMParam 'VXSEC391' $vm "task.maxAge"  "30"

	# ------------------------------------------
	# End - Rules from the VMware VC STIG script
	# ==========================================

}

########################################################################
# FUNCTION  : HardenVCRunningRules
# PURPOSE   : Apply the VC STIG rules that allow the VC VM to be running
# PARAMETERS: VC (object)
########################################################################
function HardenVCRunningRules {
	Get-FunctionName
	
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA

	# Script to unmask, enable, and start SSH service
	$scriptText = 'sudo systemctl unmask sshd.service; sudo systemctl enable sshd.service; sudo systemctl start sshd.service'
	
	# Checking if SSH port is open in vCenter
	$vcsaSshStatus = Invoke-STIGvCSAScript "sudo systemctl status sshd.service"
	
	# Extract the "Active" status using regular expressions
	$sshStatus = [regex]::Matches($vcsaSshStatus, "Active:\s+(\w+)")
	$activeStatusValue = $sshStatus.Groups[1].Value

	if ( $activeStatusValue -eq "inactive" ) {
		# Start SSH service in VCSA
		Invoke-STIGvCSAScript $scriptText | out-null
		Write-log "$script:vCenter : SSH found disabled post VCSA reboot. Enabling SSH to continue with STIG Hardening"
	}

	$msg="Applying vCenter STIG rules"
	Write-Host "`n$msg" -ForegroundColor Green
	Write-Log -Message "$msg"

	Write-Host-Log "Applying portgroup values"
	$pgs = Get-VDPortgroup | Get-View
	ForEach($pg in $pgs) {
		try {
			Write-Log "- portgroup $($pg.Name)"
			$spec = New-Object VMware.Vim.DVPortgroupConfigSpec
			$spec.ConfigVersion = $pg.Config.ConfigVersion
			$spec.Policy = New-Object VMware.Vim.VMwareDVSPortgroupPolicy
			$spec.Policy.VlanOverrideAllowed = $False
			$spec.Policy.UplinkTeamingOverrideAllowed = $False
			$spec.Policy.SecurityPolicyOverrideAllowed = $False
			$spec.Policy.IpfixOverrideAllowed = $False
			$spec.Policy.BlockOverrideAllowed = $False
			$spec.Policy.ShapingOverrideAllowed = $False
			$spec.Policy.VendorConfigOverrideAllowed = $False
			$spec.Policy.TrafficFilterOverrideAllowed = $False
			$spec.Policy.PortConfigResetAtDisconnect = $True
			$log_portgroup = $pg.ReconfigureDVPortgroup_Task($spec)
			Write-Log -Message "$log_portgroup"

			$script:passProcess++
			$Outcome = "SUCCESS"
			Write-Log -Message "Applying portgroup policy values for $($pg.Name)"
		} catch {
			$script:failProcess++
			$Outcome = "FAIL"
			Write-Log -Message "Applying portgroup policy values for $($pg.Name)"
			writeError
		}
	}
	Write-Host "Setting portgroup values done"

	# ------------------------------------------------------------------------------------------------------------------------------------ #
	# VXSEC336 The vCenter Server must provide an immediate real-time alert to the SA and ISSO, at a minimum, of all audit failure events. #
	# ------------------------------------------------------------------------------------------------------------------------------------ #
	if ( getVulnMap 'VXSEC336' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

				# Prompt for the ISSO email address
				Do {
					$mailTo = Read-Host -Prompt "Enter ISSO/SA DL email address (Ex: 'stig_alerts@email.tld')"
					if ( $mailTo -eq "" ) { 
						Write-Host "Email address cannot be empty" -ForegroundColor Yellow 
					} else {
						Write-Host "The email address entered is $mailTo" -ForegroundColor Green
					}
				} While ( $mailTo -eq "" )

				$Outcome = "SUCCESS"
				Write-Log -Message "The ISSO/SA distribution list email address = $mailTo"

				# Set entity to be the vCenter Server
				$entity = New-Object VMware.Vim.ManagedObjectReference
				$entity.Type = 'Folder'
				$entity.Value = 'group-d1'

				# Set name for the alarm and call to test for existence
				$alarmName = "STIG alarm 'Remote Syslog Failure'"
				$remoteSyslogFailure = 'Get-AlarmDefinition -Name "$alarmName"'
				$cmdResp1 = Invoke-expression $remoteSyslogFailure -EA SilentlyContinue 2>&1

				if ( !($cmdResp1 -like "$alarmName") ) {
					write-host $cmdResp1' run if alarm does not exist'
					Write-Log -Message "$cmdResp1 run if alarm does not exist"
					# AlarmSpec
					$spec = New-Object VMware.Vim.AlarmSpec
					$spec.Expression = New-Object VMware.Vim.OrAlarmExpression
					$spec.Expression.Expression = New-Object VMware.Vim.AlarmExpression[] (1)

					# Expression 1 - Remote Syslog Failure
					$spec.Expression.Expression[0] = New-Object VMware.Vim.EventAlarmExpression
					$spec.Expression.Expression[0].EventTypeId = 'esx.problem.vmsyslogd.remote.failure'
					$spec.Expression.Expression[0].EventType = 'Event'
					$spec.Expression.Expression[0].ObjectType = 'HostSystem'
					$spec.Expression.Expression[0].Status = 'red'
					
					# Set the action repeat and name the definition
					$spec.ActionFrequency = 3600
					$spec.Name = $alarmName
					
					# Create action
					$spec.Action = New-Object VMware.Vim.GroupAlarmAction
					$spec.Action.Action = New-Object VMware.Vim.AlarmAction[] (1)
					$spec.Action.Action[0] = New-Object VMware.Vim.AlarmTriggeringAction
					$spec.Action.Action[0].TransitionSpecs = New-Object VMware.Vim.AlarmTriggeringActionTransitionSpec[] (1)
					$spec.Action.Action[0].TransitionSpecs[0] = New-Object VMware.Vim.AlarmTriggeringActionTransitionSpec
					$spec.Action.Action[0].TransitionSpecs[0].Repeats = $true
					$spec.Action.Action[0].TransitionSpecs[0].StartState = 'yellow'
					$spec.Action.Action[0].TransitionSpecs[0].FinalState = 'red'
					$spec.Action.Action[0].Yellow2green = $false
					$spec.Action.Action[0].Yellow2red = $false
					$spec.Action.Action[0].Red2yellow = $false
					$spec.Action.Action[0].Action = New-Object VMware.Vim.SendEmailAction
					$spec.Action.Action[0].Action.Subject = 'Alarm {alarmName} on Host : {targetName} is {newStatus}'
					$spec.Action.Action[0].Action.CcList = ''
					$spec.Action.Action[0].Action.ToList = $mailTo
					$spec.Action.Action[0].Action.Body = ''
					$spec.Action.Action[0].Green2yellow = $false
					
					# Addl spec properties
					$spec.Description = "Alert when an ESXi host can no longer reach its syslog server. Vulnerability $VulnID"
					$spec.Enabled = $true
					$spec.Setting = New-Object VMware.Vim.AlarmSetting
					$spec.Setting.ToleranceRange = 0
					$spec.Setting.ReportingFrequency = 300
					
					# Create alarm
					$_this = Get-View -Id 'AlarmManager-AlarmManager'
					$_this.CreateAlarm($entity, $spec)
					
					# Test that the alarm is present
					$cmdResp2 = Invoke-expression $remoteSyslogFailure -ErrorAction SilentlyContinue
					if ( !($cmdResp2 -like "$alarmName") ) {
						$script:failProcess++
						Write-Host 'Creating '$alarmName' alarm definition failed!' -ForegroundColor Red
						$Outcome = "FAIL"
						Write-Log -Message "Creating $alarmName alarm definition"
					} else {
						$script:passProcess++
						Write-Host $alarmName' alarm definition complete' -ForegroundColor Green
						$Outcome = "SUCCESS"
						Write-Log -Message "Creating $alarmName alarm definition"
					}
				} else {
					$script:passProcess++
					Write-Host $alarmName' alarm definition already exists, skipping...' -ForegroundColor Green
					$Outcome = $script:OutcomeNA
					Write-Log -Message "$alarmName alarm definition already exists, ignoring entry!"
				}
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
				$script:passProcess++
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ---------------------------------------------------------------- #
	# VXSEC493 VMware Postgres log files must contain required fields. #
	# ---------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC493' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"
							
				# VMware Postgres log file expected configuration
				$expectedOutput = "%m %c %x %d %u %r %p %l"

				# Get the VMware Postgres log file configuration
				$checkScript = '. /etc/profile; /opt/vmware/vpostgres/current/bin/psql -U postgres -A -t -c "SHOW log_line_prefix;"'
				
				# Set the VMware Postgres log file configuration							
				$applyScript = ". /etc/profile; /opt/vmware/vpostgres/current/bin/psql -U postgres -c ""ALTER SYSTEM SET log_line_prefix TO '$expectedOutput';""; /opt/vmware/vpostgres/current/bin/psql -U postgres -c ""SELECT pg_reload_conf();"";"
				
				# Run the $checkScript to get the VMware Postgres log file configuration
				$result = Invoke-STIGvCSAScript $checkScript
				$actualOutput = $result.ScriptOutput.trim()
				
				# If $actualOutput doesn't match with $expectedOutput, set the VMware Postgres log file configuration 
				If ( $actualOutput -eq $expectedOutput ) {
					Write-Host-Log "INFO $VulnID -- VMware Postgres log files are already configured correctly with the required fields (COMPLIANT, UNCHANGED)"
				} Else {
					# Run the $applyScript to set the VMware Postgres log file configuration
					Write-Host-Log "INFO $VulnID -- VMware Postgres log files incorrectly configured, setting required fields (NON-COMPLIANT, APPLIED:UPDATED)"
					$output = Invoke-STIGvCSAScript $applyScript
					Write-Log -Level 'Debug' "Output = $output"
				}
				Write-Host-Log "INFO $VulnID -- SUCCESS  $Title"
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# -------------------------------------------------------------------- #
	# VXSEC494 The Security Token Service must set 'URIEncoding' to UTF-8. #
	# -------------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC494' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"
				
				# Custom port attribute to find the right connector for URIEncoding check
				$bioCustomPort = "'`$`{bio-custom.http.port}'"

				# Command to Execute the python file on the remote server
				$applyScript = "python $setKeyOfElementAttributeInXMLfileRemote $VulnID logfile.log true '$Title' $script:vCenterUsrLibVmwareSsoStsConfServerXML 'Connector' 'port' $bioCustomPort  'URIEncoding' 'UTF-8'"

				# Copy the required python files on the remote server
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$VxRailSTIGLoggingFileLocal" -RemoteFilePath "$VxRailSTIGLoggingFileRemote" | Out-Null
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$setKeyOfElementAttributeInXMLfileLocal" -RemoteFilePath "$setKeyOfElementAttributeInXMLfileRemote" | Out-Null
				
				# Execute the setKeyOfElementAttributeInXMLfile.py file on the remote server
				$URIEncodingOutput  = "y"| & $script:PlinkPath -ssh $script:vCenter -l root -pw $script:vCRootSecPass $applyScript
				
				# Setting stsServiceRestartFlag to true to restart the sts service
				if ( $URIEncodingOutput -match 'APPLIED:(INSERTED|UPDATED)\s*' ) {
					$script:stsServiceRestartFlag = $true
				}
				
				Write-Log -Level 'Debug' "stsServiceRestartFlag = $script:stsServiceRestartFlag"

				# Log the Python script's output
				Write-Host-Log "$URIEncodingOutput"
			
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ----------------------------------------------------------------------------------------------------------------- #
	# VXSEC495 The Security Token Service must record user access in a format that enables monitoring of remote access. #
	# ----------------------------------------------------------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC495' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		
		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"
				
				# Class name to find the right valve for pattern check
				$className = "org.apache.catalina.valves.AccessLogValve"
				
				# Expected pattern element 
				$expectedPattern = "%t %I [RemoteIP] %{X-Forwarded-For}i %u [Request] %h:%{remote}p to local %{local}p - %H %m %U%q    [Response] %s - %b bytes    [Perf] process %Dms / commit %Fms / conn [%X]"

				# Command to Execute the python file on the remote server
				$applyScript = "python $setKeyOfElementAttributeInXMLfileRemote $VulnID logfile.log true '$Title' $vCenterUsrLibVmwareSsoStsConfServerXML 'Valve' 'className' '$className' 'pattern' '$expectedPattern'"
							
				# Copy the required python files on the remote server
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$VxRailSTIGLoggingFileLocal" -RemoteFilePath "$VxRailSTIGLoggingFileRemote" | Out-Null
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$setKeyOfElementAttributeInXMLfileLocal" -RemoteFilePath "$setKeyOfElementAttributeInXMLfileRemote" | Out-Null
				
				# Execute the setKeyOfElementAttributeInXMLfile.py file on the remote server
				$patternOutput  = "y"| & $script:PlinkPath -ssh $script:vCenter -l root -pw $script:vCRootSecPass $applyScript

				# Displaying execution result and setting stsServiceRestartFlag to true to restart the sts service
				if ($patternOutput -match 'APPLIED:INSERTED\s*') {
					$script:stsServiceRestartFlag = $true
					Write-Host-Log "INFO $VulnID -- The Security Token Service is not configured to record user access in a format that enables monitoring of remote access (NON-COMPLIANT, APPLIED:INSERTED)"
				} elseif ($patternOutput -match 'APPLIED:UPDATED\s*') {
					$script:stsServiceRestartFlag = $true
					Write-Host-Log "INFO $VulnID -- The Security Token Service is updated to record user access in a format that enables monitoring of remote access (NON-COMPLIANT, APPLIED:UPDATED)"
				} else { 
					Write-Host-Log "INFO $VulnID -- The Security Token Service already recording user access in a format that enables monitoring of remote access (COMPLIANT, UNCHANGED)"
				}

				Write-Log -Level 'Debug' "stsServiceRestartFlag = $script:stsServiceRestartFlag"

				# Log the Python script's output
				Write-Log -Level 'Debug' "Output = $patternOutput"

				Write-Host-Log "INFO $VulnID -- SUCCESS  $Title"
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ----------------------------------------------------------------------------------------------------------------------------------- #
	# VXSEC496 The Security Token Service must fail to a known safe state if system initialization fails, shutdown fails, or aborts fail. #
	# ----------------------------------------------------------------------------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC496' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		
		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"
				
				# Define the command to retrieve the attribute with value
				$checkScript = "$script:etcProfile; grep EXIT_ON_INIT_FAILURE $script:vCenterUsrLibVmwareSsoStsConfCatalinaProperties"
				$attribute = "org.apache.catalina.startup.EXIT_ON_INIT_FAILURE"
				$expectedResult  = "org.apache.catalina.startup.EXIT_ON_INIT_FAILURE=true"
				
				# Append the file with one empty line followed by the new line 
				$appendScript = "echo '' >> $script:vCenterUsrLibVmwareSsoStsConfCatalinaProperties; echo '' >> $script:vCenterUsrLibVmwareSsoStsConfCatalinaProperties; echo '$expectedResult ' >> $script:vCenterUsrLibVmwareSsoStsConfCatalinaProperties"

				# Replace the existing attribute's value to 'true'
				$replaceScript = "sed -i 's/^$attribute.*/$expectedResult/' $script:vCenterUsrLibVmwareSsoStsConfCatalinaProperties"

				# Execute the command on the vCenter Server
				$result = Invoke-STIGvCSAScript $checkScript
				
				# Extract the attribute with value from the result
				$output = $result.ScriptOutput.Trim()

				# Check if the output matches the expected result
				if ( [string]::IsNullOrWhiteSpace($output) ) {
					# Add the expected result at the end of the catalina.properties file
					Invoke-STIGvCSAScript $appendScript | Out-Null

					# Setting stsServiceRestartFlag to true to restart the sts service
					$script:stsServiceRestartFlag = $true

					Write-Log -Level 'Debug' "stsServiceRestartFlag = $script:stsServiceRestartFlag"
					Write-Host-Log "INFO $VulnID -- Attribute '$expectedResult' was not present in '$script:vCenterUsrLibVmwareSsoStsConfCatalinaProperties', setting it now... (NON-COMPLIANT, APPLIED:INSERTED)"					
				} elseif ( $output -notmatch $expectedResult ) {
					# Change the existing attribute with the expected result in catalina.properties file
					Invoke-STIGvCSAScript $replaceScript | Out-Null
					
					# Setting stsServiceRestartFlag to true to restart the sts service
					$script:stsServiceRestartFlag = $true

					Write-Log -Level 'Debug' "stsServiceRestartFlag = $script:stsServiceRestartFlag"
					Write-Host-Log "INFO $VulnID -- Attribute '$expectedResult' was not present in '$script:vCenterUsrLibVmwareSsoStsConfCatalinaProperties', setting it now... (NON-COMPLIANT, APPLIED:UPDATED)"					
				} else {
					Write-Host-Log "INFO $VulnID -- Attribute '$expectedResult' was present and already set correctly in '$script:vCenterUsrLibVmwareSsoStsConfCatalinaProperties' (COMPLIANT, UNCHANGED)"					
				} 
				Write-Host-Log "INFO $VulnID -- SUCCESS  $Title"
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ------------------------------------------------------------------------------------- #
	# VXSEC497 The Security Token Service must use the "setCharacterEncodingFilter" filter. #
	# ------------------------------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC497' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		
		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"
				
				# Command to Execute the python file on the remote server
				$applyScript = "python $setCharacterEncodingFilterFileRemote $VulnID logfile.log true '$Title'"
				
				# Copy the required python files on the remote server
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$VxRailSTIGLoggingFileLocal" -RemoteFilePath "$VxRailSTIGLoggingFileRemote" | Out-Null
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$setCharacterEncodingFilterFileLocal" -RemoteFilePath "$setCharacterEncodingFilterFileRemote" | Out-Null
				
				# Execute the setCharacterEncodingFilterFileRemote.py file on the remote server
				$EncodingFilterOutput  = "y"| & $script:PlinkPath -ssh $script:vCenter -l root -pw $script:vCRootSecPass $applyScript

				# Validating result and setting stsServiceRestartFlag to true to restart the sts service
				if ($EncodingFilterOutput -match 'APPLIED:INSERTED\s*') {
					$script:stsServiceRestartFlag = $true
				}

				Write-Log -Level 'Debug' "stsServiceRestartFlag = $script:stsServiceRestartFlag"

				# Log the Python script's output
				Write-Host-Log "$EncodingFilterOutput"
			
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ------------------------------------------------------------------------------ #
	# VXSEC498 Lookup Service log files must only be accessible by privileged users. #
	# ------------------------------------------------------------------------------ #
	if ( getVulnMap 'VXSEC498' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title"

				# Creating variables for file permission and ownership
				$filePermission = "640"
				$fileOwnership = "root:root"

				# Get the VCSA lookup service log file configuration
				$checkScript = "find $script:vCSALookupsvcFilePath -xdev -type f -a '(' -perm /137 -o -not -user root -o -not -group root ')' -exec ls -ld {} \;"

				# Run the $checkScript to get the VCSA lookup service log file configuration
				$nonCompliantLogFiles = Invoke-STIGvCSAScript $checkScript

				# Creating a nonCompliantFileArray from nonCompliantLogFiles and counting the log files
				$nonCompliantFileArray = $nonCompliantLogFiles.Scriptoutput -split "`r?`n"
				$nonCompliantFileArray = $nonCompliantFileArray | Where-Object { $_ -ne $null -and $_ -ne '' }

				$nonCompliantFileCount = $nonCompliantFileArray | Measure-Object -Line | Select-Object -ExpandProperty Lines
				
				If ( $nonCompliantFileCount -eq 0 ) {
					Write-Host-Log "INFO $VulnID -- Lookup Service log files are already accessible by privileged users only (COMPLIANT, UNCHANGED)"
				}
				Else {
					Write-Host-Log "INFO $VulnID -- Lookup Service log files ($nonCompliantFileCount) are incorrectly configured, setting right ownership and permission (NON-COMPLIANT, APPLIED:UPDATED)"
 					# Process each line
					foreach ( $line in $nonCompliantFileArray ) {
						# Extract the filename and subsequent folders
						$relativePath = $line.Substring($line.IndexOf($script:vCSALookupsvcFilePath) + $script:vCSALookupsvcFilePath.Length)

						# Set the VCSA lookup service log file configuration
						$applyScript = "chmod $filePermission $script:vCSALookupsvcFilePath$relativePath; chown $fileOwnership $script:vCSALookupsvcFilePath$relativePath"
						Write-Log -Level 'Debug' "Setting correct ownership and permission on: $script:vCSALookupsvcFilePath$relativePath"
						
						# Run the $checkScript to set the VCSA lookup service log file configuration
						Invoke-STIGvCSAScript $applyScript | Out-Null
					}
					Write-Host-Log "INFO $VulnID -- SUCCESS $Title"
					$script:passProcess++
				}
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ------------------------------------------------------ #
	# VXSEC499 Lookup Service must set URIEncoding to UTF-8. #
	# ------------------------------------------------------ #
	if ( getVulnMap 'VXSEC499' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title"
				
				# Custom port attribute to find the right connector for URIEncoding check
				$bioCustomPort = "'`$`{bio-custom.http.port}'"

				# Command to Execute the python file on the remote server
				$applyScript = "python $setKeyOfElementAttributeInXMLfileRemote $VulnID logfile.log true '$Title' $script:vCenterVmwareLookupConfServerXML 'Connector' 'port' $bioCustomPort  'URIEncoding' 'UTF-8'"

				#Copy the required python files on the remote server
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$VxRailSTIGLoggingFileLocal" -RemoteFilePath "$VxRailSTIGLoggingFileRemote" | Out-Null
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$setKeyOfElementAttributeInXMLfileLocal" -RemoteFilePath "$setKeyOfElementAttributeInXMLfileRemote" | Out-Null

				# Execute the setKeyOfElementAttributeInXMLfile.py file on the remote server
				$URIEncodingOutput  = "y"| & $script:PlinkPath -ssh $script:vCenter -l root -pw $script:vCRootSecPass $applyScript

				# Setting lookupServiceRestartFlag to true to restart the lookup service
				if ( $URIEncodingOutput -match 'APPLIED:(INSERTED|UPDATED)\s*' ) {
					$script:lookupServiceRestartFlag = $true
				}

				Write-Log -Level 'Debug' "lookupServiceRestartFlag = $script:lookupServiceRestartFlag"

				# Log the Python script's output
				Write-Host-Log "$URIEncodingOutput"

				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ---------------------------------------------------------------------- #
	# VXSEC500 Lookup Service must be configured to hide the server version. #
	# ---------------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC500' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title"

				# Custom port attribute to find the right connector for server version check
				$bioCustomPort = "'`$`{bio-custom.http.port}'"

				# Command to Execute the python file on the remote server
				$applyScript = "python $setKeyOfElementAttributeInXMLfileRemote $VulnID logfile.log true '$Title' $script:vCenterVmwareLookupConfServerXML 'Connector' 'port' $bioCustomPort  'server' 'Anonymous'"

				# Copy the required python files on the remote server
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$VxRailSTIGLoggingFileLocal" -RemoteFilePath "$VxRailSTIGLoggingFileRemote" | Out-Null
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$setKeyOfElementAttributeInXMLfileLocal" -RemoteFilePath "$setKeyOfElementAttributeInXMLfileRemote" | Out-Null

				# Execute the setKeyOfElementAttributeInXMLfile.py file on the remote server
				$serverOutput  = "y"| & $script:PlinkPath -ssh $script:vCenter -l root -pw $script:vCRootSecPass $applyScript

				# Setting lookupServiceRestartFlag to true to restart the lookup service
				if ( $serverOutput -match 'APPLIED:(INSERTED|UPDATED)\s*' ) {
					$script:lookupServiceRestartFlag = $true
				}

				Write-Log -Level 'Debug' "lookupServiceRestartFlag = $script:lookupServiceRestartFlag"

				# Log the Python script's output
				Write-Host-Log "$serverOutput"

				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ----------------------------------------------------------------------------- #
	# VXSEC501 Lookup Service must protect cookies from cross-site scripting (XSS). #
	# ----------------------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC501' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		
		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title"
				
				# Define the command to retrieve the attribute with value
				$checkScript = "$script:etcProfile; xmllint --format $script:vCenterVMwareLookupConfContextXML | xmllint --xpath '/Context/@useHttpOnly' -"
				
				$attribute = "Context"
				$expectedAttribute  = 'Context useHttpOnly="true"'
				$expectedResult = 'useHttpOnly="true"'

				# Replace the existing attribute to expectedAttribute
				$replaceScript = "sed -i 's/^<$attribute.*>/<$expectedAttribute>/' $script:vCenterVMwareLookupConfContextXML"
				
				# Execute the command on the vCenter Server
				$result = Invoke-STIGvCSAScript $checkScript
				
				# Extract the attribute with value from the result
				$output = $result.ScriptOutput.Trim()
				
				# Check if the output matches the expected result
				if ( $output -notmatch $expectedResult ) {
					# Change the existing attribute with the expected result in catalina.properties file
					Invoke-STIGvCSAScript $replaceScript | Out-Null
					
					# Setting lookupServiceRestartFlag to true to restart the lookup service
					$script:lookupServiceRestartFlag = $true

					Write-Log -Level 'Debug' "lookupServiceRestartFlag = $script:lookupServiceRestartFlag"
					Write-Host-Log "INFO $VulnID -- Attribute '$expectedResult' was not present in '$script:vCenterVMwareLookupConfContextXML', setting it now. (NON-COMPLIANT, APPLIED:UPDATED)"
				}
				else {
					Write-Host-Log "INFO $VulnID -- Attribute '$expectedResult' was present and already set correctly in '$script:vCenterVMwareLookupConfContextXML' (COMPLIANT, UNCHANGED)"
				}
				Write-Host-Log "INFO $VulnID -- SUCCESS $Title"
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ----------------------------------------------------------------------------------------------------- #
	# VXSEC502 Lookup Service must record user access in a format that enables monitoring of remote access. #
	# ----------------------------------------------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC502' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		
		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title"
				
				# Class name to find the right valve for pattern check
				$className = "org.apache.catalina.valves.AccessLogValve"
				
				# Expected pattern element 
				$expectedPattern = "%t %I [RemoteIP] %{X-Forwarded-For}i %u [Request] %h:%{remote}p to local %{local}p - %H %m %U%q    [Response] %s - %b bytes    [Perf] process %Dms / commit %Fms / conn [%X]"

				# Command to Execute the python file on the remote server
				$applyScript = "python $setKeyOfElementAttributeInXMLfileRemote $VulnID logfile.log true '$Title' $vCenterVmwareLookupConfServerXML 'Valve' 'className' '$className' 'pattern' '$expectedPattern'"
							
				# Copy the required python files on the remote server
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$VxRailSTIGLoggingFileLocal" -RemoteFilePath "$VxRailSTIGLoggingFileRemote" | Out-Null
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$setKeyOfElementAttributeInXMLfileLocal" -RemoteFilePath "$setKeyOfElementAttributeInXMLfileRemote" | Out-Null
				
				# Execute the setKeyOfElementAttributeInXMLfile.py file on the remote server
				$patternOutput  = "y"| & $script:PlinkPath -ssh $script:vCenter -l root -pw $script:vCRootSecPass $applyScript

				# Displaying execution result and setting lookupServiceRestartFlag to true to restart the Lookup service
				if ($patternOutput -match 'APPLIED:INSERTED\s*') {
					$script:lookupServiceRestartFlag = $true
					Write-Host-Log "INFO $VulnID -- The Security Token Service is not configured to record user access in a format that enables monitoring of remote access (NON-COMPLIANT, APPLIED:INSERTED)"
				} elseif ($patternOutput -match 'APPLIED:UPDATED\s*') {
					$script:lookupServiceRestartFlag = $true
					Write-Host-Log "INFO $VulnID -- The Security Token Service is updated to record user access in a format that enables monitoring of remote access (NON-COMPLIANT, APPLIED:UPDATED)"
				} else { 
					Write-Host-Log "INFO $VulnID -- The Security Token Service already recording user access in a format that enables monitoring of remote access (COMPLIANT, UNCHANGED)"
				}

				Write-Log -Level 'Debug' "lookupServiceRestartFlag = $script:lookupServiceRestartFlag"

				# Log the Python script's output
				Write-Log -Level 'Debug' "Output = $patternOutput"

				Write-Host-Log "INFO $VulnID -- SUCCESS $Title"
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate vCenter Lookup Service STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ----------------------------------------------------------------------------------------------------------------------------------- #
	# VXSEC503 The Security Token Service must fail to a known safe state if system initialization fails, shutdown fails, or aborts fail. #
	# ----------------------------------------------------------------------------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC503' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

				# Define the command to retrieve the attribute with value
				$checkScript = "$script:etcProfile; grep EXIT_ON_INIT_FAILURE $script:vCenterUsrLibVMwareLookupsvcConfCatalinaProperties"

				$attribute = "org.apache.catalina.startup.EXIT_ON_INIT_FAILURE"
				$expectedResult  = "org.apache.catalina.startup.EXIT_ON_INIT_FAILURE=true"

				# Append the file with one empty line followed by the new line 
				$appendScript = "echo '' >> $script:vCenterUsrLibVMwareLookupsvcConfCatalinaProperties; echo '' >> $script:vCenterUsrLibVMwareLookupsvcConfCatalinaProperties; echo '$expectedResult ' >> $script:vCenterUsrLibVMwareLookupsvcConfCatalinaProperties"

				# Replace the existing attribute's value to 'true'
				$replaceScript = "sed -i 's/^$attribute.*/$expectedResult/' $script:vCenterUsrLibVMwareLookupsvcConfCatalinaProperties"

				# Execute the command on the vCenter Server
				$result = Invoke-STIGvCSAScript $checkScript

				# Extract the attribute with value from the result
				$output = $result.ScriptOutput.Trim()

				# Check if the output matches the expected result
				if ( [string]::IsNullOrWhiteSpace($output) ) {
					# Add the expected result at the end of the catalina.properties file
					Invoke-STIGvCSAScript $appendScript | Out-Null

					# Setting lookupServiceRestartFlag to true to restart the Lookup service
					$script:lookupServiceRestartFlag = $true

					Write-Log -Level 'Debug' "lookupServiceRestartFlag = $script:lookupServiceRestartFlag"
					Write-Host-Log "INFO $VulnID -- Attribute '$expectedResult' was not present in '$script:vCenterUsrLibVMwareLookupsvcConfCatalinaProperties', setting it now. (NON-COMPLIANT, APPLIED:INSERTED)"
				} elseif ( $output -notmatch $expectedResult ) {
					# Change the existing attribute with the expected result in catalina.properties file
					Invoke-STIGvCSAScript $replaceScript | Out-Null

					# Setting lookupServiceRestartFlag to true to restart the Lookup service
					$script:lookupServiceRestartFlag = $true

					Write-Log -Level 'Debug' "lookupServiceRestartFlag = $script:lookupServiceRestartFlag"
					Write-Host-Log "INFO $VulnID -- Attribute '$expectedResult' was not present in '$script:vCenterUsrLibVMwareLookupsvcConfCatalinaProperties', setting it now. (NON-COMPLIANT, APPLIED:UPDATED)"
				} else {
					Write-Host-Log "INFO $VulnID -- Attribute '$expectedResult' was present and already set correctly in '$script:vCenterUsrLibVMwareLookupsvcConfCatalinaProperties' (COMPLIANT, UNCHANGED)"
				}

				Write-Host-Log "INFO $VulnID -- SUCCESS  $Title"
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# ------------------------------------------------------------- #
	# VXSEC504 Lookup Service must set the secure flag for cookies. #
	# ------------------------------------------------------------- #
	if ( getVulnMap 'VXSEC504' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		
		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"
				
				# Command to Execute the python file on the remote server
				$applyScript = "python $setSecureFlagForCookiesLookupSvcFileRemote $VulnID logfile.log true '$Title'"
				
				# Copy the required python files on the remote server
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$VxRailSTIGLoggingFileLocal" -RemoteFilePath "$VxRailSTIGLoggingFileRemote" | Out-Null
				CopyFileToVM -VmIpOrFqdn "$script:vCenter" -Username root -Password "$script:vCRootSecPass" -LocalFilePath "$setSecureFlagForCookiesLookupSvcFileLocal" -RemoteFilePath "$setSecureFlagForCookiesLookupSvcFileRemote" | Out-Null
				
				# Execute the setSecureFlagForCookiesLookupSvcFileRemote.py file on the remote server
				$secureFlag  = "y"| & $script:PlinkPath -ssh $script:vCenter -l root -pw $script:vCRootSecPass $applyScript

				# Validating result and setting lookupServiceRestartFlag to true to restart the Lookup service
				if ($secureFlag -match 'APPLIED:INSERTED\s*') {
					$script:lookupServiceRestartFlag = $true
				}

				Write-Log -Level 'Debug' "lookupServiceRestartFlag = $script:lookupServiceRestartFlag"

				# Log the Python script's output
				Write-Host-Log "$secureFlag"
			
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	# Resetting VulnID and Outcome before calling VMware vCenter STIG remediation script for accurate logging
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA

	# There is only a VMware vCenter STIG remediation script for vSphere 7.0 (not for vSphere 6.7)
	if ( $script:VxRailMajorVersion -ge "7") {

		# on VxRail 7.x using vSphere 7.x
		# Call $script:VMwareSTIGvCScript
		# Splat the parameters
		$myargs = @{
			vcenter = $script:vCenter
			vccred  = $script:vCenterCredentials
			ssouser = $script:vCAdmUser
			ssopass = $script:vCAdmSecPass
		}

		# Log call and params if in Debug mode
		$myargsStr=($myargs|Out-String)
		Write-Log -Level 'Debug' "CALL: $VMwareSTIGvCScript $myargsStr"
		PauseIfDebug

		# Disconnect (as the VMware script connects itself) and reconnect after the vCenter script call
		# Prevent prompt about working with multiple default servers
		Disconnect-VIServer * -Confirm:$false | Out-Null

		# Call VMware DoD STIG vCenter remediation script
		# - In PowerShell 5.0+ an Error stream 6 was added for 'information', which is ***also used for the Write-Host output***
		try {
			& $VMwareSTIGvCScript @myargs 6>&1 | Write-Log
			Write-Host "Apply VMware vCenter STIG finished on $script:vCenter`n" -ForegroundColor Green
			$script:passProcess++
		}
		catch {
			$VulnID = $script:VulnIdNA
			$Outcome = "FAIL"
			Write-Log -Level 'Error' -Message "Caught an exception error during VMware vCenter STIG application on $script:vCenter"
			Write-Host "Apply VMware vCenter STIG failed on $script:vCenter`n" -ForegroundColor Red
			$script:failProcess++
			writeError
			continue
		}

		PauseIfDebug "before reconnecting to vCenter"
		# Re-connect as the VMware script disconnects
		ConnectvCenter
	}

	# Validate flag and restart the required services
	If ( $script:stsServiceRestartFlag ) {
		RestartService -VmIpOrFqdn $script:vCenter -Username root -Password $script:vCRootSecPass  -serviceName "sts" -serviceRestartCommand "$script:stsServiceRestartCommand"
	} 
	If ( $script:lookupServiceRestartFlag ) {
		RestartService -VmIpOrFqdn $script:vCenter -Username root -Password $script:vCRootSecPass  -serviceName "lookup" -serviceRestartCommand "$script:lookupServiceRestartCommand"
	}

	# Clear the plain text password variables
	Clear-Variable -Name "vCRootSecPass"
}
############################################################################
# End of vCenter Hardening Section
############################################################################

################################################################################
# Function  : HardenPhotonOSRules
# PURPOSE   : Apply the Photon OS STIG Rules that allow the VC VM to be running
# PARAMETERS: VC (object)
#################################################################################  
function HardenPhotonOSRules {
	Get-FunctionName

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA

	$msg="Applying vCSA Photon OS STIG rules"
	Write-Host "`n$msg" -ForegroundColor Green
	Write-Log -Message "$msg"

	#----------------------------------------------------------------------------------------------------------------------------------------------------#
	# DSX06_0001 The Photon operating system must display the Standard Mandatory DOD Notice and Consent Banner before granting Secure Shell (SSH) access.
	#----------------------------------------------------------------------------------------------------------------------------------------------------#
	if ( getVulnMap 'DSX06_0001' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating Photon OS STIG Vulnerability ID: $VulnID with Title: $Title"

				# Variables defined for checking and applying the Photon OS STIG Vulnerability rules
				$filePath = '/etc/issue'
				$checkScript = "cat $filePath"
				$applyScript =@'
            	echo 'You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only. By using this IS (which includes any device attached to this IS), you consent to the following conditions:The USG routinely intercepts and monitors communications on this IS for purposes including, but not limited to, penetration testing, COMSEC monitoring, network operations and defense, personnel misconduct (PM), law enforcement (LE), and counterintelligence (CI) investigations.At any time, the USG may inspect and seize data stored on this IS.Communications using, or data stored on, this IS are not private, are subject to routine monitoring, interception, and search, and may be disclosed or used for any USG authorized purpose.This IS includes security measures (e.g., authentication and access controls) to protect USG interests--not for your personal benefit or privacy.Notwithstanding the above, using this IS does not constitute consent to PM, LE or CI investigative searching or monitoring of the content of privileged communications, or work product, related to personal representation or services by attorneys, psychotherapists, or clergy, and their assistants. Such communications and work product are private and confidential. See User Agreement for details.' >> /etc/issue			
'@
				$expectedOutput = '*You are accessing a U.S. Government (USG) Information System (IS)*'
				
				# Run the $checkScript to get the Current Output of the file under cat /etc/issue.
				$currentOutput = Invoke-STIGvCSAScript $checkScript
				$actualOutput = $currentOutput.ScriptOutput
			
				# If $actualOutput doesn't match with the $expectedOutput, set the DOD Notice and Consent Banner.
				If ( $actualOutput -like $expectedOutput ) {
					Write-Host-Log "INFO $VulnID -- The Standard Mandatory DOD Notice and Consent Banner is already set (COMPLIANT, UNCHANGED)"		
				} 
				Else {
					# Run the $applyScript to set the Mandatory DOD Notice and Consent Banner before granting Secure Shell (SSH) access.
					Write-Host-Log "Setting the Standard Mandatory DOD Notice and Consent Banner under $filePath"
					Invoke-STIGvCSAScript $applyScript | out-null
					$script:sshdServiceRestartFlag = $true 
					Write-Host-Log "INFO $VulnID -- Successfully set the Standard Mandatory DOD Notice and Consent Banner (NON-COMPLIANT, APPLIED:INSERTED)"
				}
				Write-Host-Log "INFO  $VulnID -- SUCCESS $Title"
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}		
		} 
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate Photon OS STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	#-----------------------------------------------------------------------------------------------#
	# DSX06_0002 The Photon operating system must enforce a minimum eight-character password length.
	#-----------------------------------------------------------------------------------------------#
	if ( getVulnMap 'DSX06_0002' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating Photon OS STIG Vulnerability ID: $VulnID with Title: $Title"

				# Minimum password length needed.
				$expectedOutput = '8'

				# Variables defined for checking and applying the Photon OS STIG Vulnerability rules on pam.d password file
				$pamCheckScript = "grep pam_cracklib $script:vCSAPamPasswordFilePath | grep -o 'minlen=[0-9]*' | cut -d '=' -f 2"

				$currentPamOutput = Invoke-STIGvCSAScript $pamCheckScript
				[int]$actualPamOutput = $currentPamOutput.ScriptOutput

				$pamApplyScript = "sed -i s/minlen=$actualPamOutput/minlen=$expectedOutput/g $script:vCSAPamPasswordFilePath"

				# Equivalent Variables defined for vCenter Appliances password file
				$appCheckScript = "grep pam_cracklib $script:vCSAAppliancePasswordFilePath | grep -o 'minlen=[0-9]*' | cut -d '=' -f 2"

				$currentAppOutput = Invoke-STIGvCSAScript $appCheckScript
				[int]$actualAppOutput = $currentAppOutput.ScriptOutput

				$appApplyScript = "sed -i s/minlen=$actualAppOutput/minlen=$expectedOutput/g $script:vCSAAppliancePasswordFilePath"

				# If $actualPamOutput is less than $expectedOutput, set the minimum password length under /etc/pam.d/system-password.
				if ( $actualPamOutput -lt $expectedOutput ) {
					Write-Host-Log "Applying the Vulnerabilty ID - $VulnID, as the minimum password length criteria is not satisfied"
					Invoke-STIGvCSAScript $pamApplyScript | out-null
					Write-Host-Log "INFO $VulnID -- Successfully set the minimum password length to $expectedOutput under $script:vCSAPamPasswordFilePath (NON-COMPLIANT, APPLIED:UPDATED)"
				}
				Else {
					 Write-Host-Log "INFO $VulnID -- The minimum pam.d password length criteria is already satisfied (COMPLIANT, UNCHANGED)"
				}
				
				# On vCenter appliances, the equivalent file must be edited under /etc/applmgmt/appliance", if one exists, for the changes to persist after a reboot 
				if ( $actualAppOutput -lt $expectedOutput ) {
					Write-Host-Log "Applying the Vulnerabilty ID - $VulnID, as the minimum password length criteria is not satisfied"
					Invoke-STIGvCSAScript $appApplyScript | out-null
					Write-Host-Log "INFO $VulnID -- Successfully set the minimum password length to $expectedOutput under $script:vCSAAppliancePasswordFilePath (NON-COMPLIANT, APPLIED:UPDATED)"
				}
				Else {
					Write-Host-Log "INFO $VulnID -- The minimum vCenter appliance password length criteria is already satisfied (COMPLIANT, UNCHANGED)"	
			   }
			   Write-Host-Log "INFO $VulnID -- SUCCESS $Title"
			   $script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}		
		} 
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate Photon OS STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	#-----------------------------------------------------------------------------------------------------------#
	# DSX06_0003 The Photon operating system must configure sshd to disconnect idle Secure Shell (SSH) sessions.
	#-----------------------------------------------------------------------------------------------------------#
	if ( getVulnMap 'DSX06_0003' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating Photon OS STIG Vulnerability ID: $VulnID with Title: $Title"

				# Minimum idle Secure Shell (SSH) sessions connection timeout
				$expectedOutput = '900'

				#Variables defined for checking and applying the Photon OS STIG Vulnerability rules
				$checkScript = "grep -o 'ClientAliveInterval [0-9]*' $script:vCentersshdConfigFilePath | cut -d ' ' -f 2 |head -c -1"

				$currentOutput = Invoke-STIGvCSAScript $checkScript
				[int]$actualOutput = $currentOutput

				$applyScript = "sed -i 's/^.*ClientAliveInterval.*$/ClientAliveInterval $expectedOutput/g' $script:vCentersshdConfigFilePath"

				# If $actualOutput like $expectedOutput is false, set the minimum ClientAliveInterval time.
				If ( $actualOutput -eq $expectedOutput ) {
					Write-Host-Log "INFO $VulnID -- The Minimum idle Secure Shell (SSH) sessions timeout(ClientAliveInterval) is already set (COMPLIANT, UNCHANGED)"
				} 
				Else {
					# Run the $applyScript to set the idle Secure Shell (SSH) sessions timeout(ClientAliveInterval).
					Write-Host-Log "Setting the Minimum idle Secure Shell (SSH) sessions timeout(ClientAliveInterval) under $script:vCentersshdConfigFilePath"
					Invoke-STIGvCSAScript $applyScript | out-null
					$script:sshdServiceRestartFlag = $true 
					Write-Host-Log "INFO $VulnID -- Successfully set the Minimum idle Secure Shell (SSH) sessions timeout(ClientAliveInterval) (NON-COMPLIANT, APPLIED:UPDATED)"
				}
				Write-Host-Log "INFO $VulnID -- SUCCESS $Title" 
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		} 
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate Photon OS STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	#---------------------------------------------------------------------------------------------#
	# DSX06_0004 The Photon operating system must configure auditd to keep five rotated log files.
	#---------------------------------------------------------------------------------------------#
	if ( getVulnMap 'DSX06_0004' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating Photon OS STIG Vulnerability ID: $VulnID with Title: $Title"

				#System must configure auditd to keep five rotated log files
				$expectedOutput = '5'

				#Variables defined for checking and applying the Photon OS STIG Vulnerability rules
				$checkScript = "grep -o 'num_logs = [0-9]*' $script:vCenterauditConfigFilePath | cut -d '=' -f 2 |head -c -1"

				$currentOutput = Invoke-STIGvCSAScript $checkScript
				[int]$actualOutput = $currentOutput

				$applyScript = "sed -i 's/^.*num_logs.*$/num_logs = $expectedOutput/g' $script:vCenterauditConfigFilePath"

				# Need to kill the process Term in auditd for the changes to be persistent
				$auditTermScript = "killproc auditd -TERM"

				# If $actualOutput equals $expectedOutput is false, set the auditd to keep five rotated log files.
				If ( $actualOutput -eq $expectedOutput ) {
					Write-Host-Log "INFO $VulnID -- The System is already configured the auditd to keep five rotated log files (COMPLIANT, UNCHANGED)"
					}
				Else {
					# Run the $applyScript to set the auditd to keep five rotated log files.
					Write-Host-Log "Configuring the system auditd to keep five rotated log files under $script:vCenterauditConfigFilePath"
					Invoke-STIGvCSAScript $applyScript | Out-Null

					# For the changes to be in effect, need to Invoke the $auditTermScript.
					Invoke-STIGvCSAScript $auditTermScript | Out-Null

					# Start the auditd service
					Invoke-STIGvCSAScript $script:auditdServiceStartCommand | Out-Null
					Write-Host-Log "Auditd service started"

					Write-Host-Log "INFO $VulnID -- Successfully configured the auditd system to keep five rotated log files (NON-COMPLIANT, APPLIED:UPDATED)"
				}
				Write-Host-Log "INFO $VulnID -- SUCCESS $Title"
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		} 
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate Photon OS STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}

	#------------------------------------------------------------------------------------------------------------------------#
	# DSX06_0005 The Photon operating system must configure sshd to limit the number of allowed login attempts per connection.
	#------------------------------------------------------------------------------------------------------------------------#
	if ( getVulnMap 'DSX06_0005' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle

		Try {
			# If the Vul mapping is set to 'Y' check and fix the Vul
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating Photon OS STIG Vulnerability ID: $VulnID with Title: $Title"

				#System must configure sshd to limit the number of allowed login attempts per connection
				$expectedOutput = '6'

				$keyArg   = "MaxAuthTries"
				$valueArg = "[0-9][0-9]*\s*$"

				#Variables defined for checking and applying the Photon OS STIG Vulnerability rules
				$checkScript = "grep -o '^$keyArg $valueArg' $script:vCentersshdConfigFilePath | cut -d ' ' -f 2 |head -1"

				$currentOutput = Invoke-STIGvCSAScript $checkScript
				[int]$actualOutput = $currentOutput

				$applyScript = "sed -i 's/^$keyArg $valueArg/$keyArg $expectedOutput/g' $script:vCentersshdConfigFilePath"

				# If $actualOutput equals $expectedOutput is false, set the sshd value 6 to limit the number of allowed login attempts per connection
				If ( $actualOutput -eq $expectedOutput ) {
					Write-Host-Log "INFO $VulnID -- The System is already configured the sshd value $expectedOutput to limit the number of allowed login attempts per connection (COMPLIANT, UNCHANGED)"
					}
				Else {
					# Run the $applyScript to set the sshd value to limit the number of allowed login attempts per connection
					Write-Host-Log "Configuring the system sshd value to limit the number of allowed login attempts per connection under $script:vCenterauditConfigFilePath"
					Invoke-STIGvCSAScript $applyScript | Out-Null
					$script:sshdServiceRestartFlag = $true
					Write-Host-Log "INFO $VulnID -- Successfully configured the system sshd value to limit the number of allowed login attempts per connection (NON-COMPLIANT, APPLIED:UPDATED)"
				}
				Write-Host-Log "INFO $VulnID -- SUCCESS $Title"
				$script:passProcess++
			}
			Else {
				$Outcome = $script:OutcomeNA
				Write-Host-Log "...Skipping disabled control STIG Vulnerability ID: $VulnID with Title: $Title" 
			}
		} 
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate Photon OS STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}
	# Restarting Required vCSA Services
	# Validate flag and restart the required services
	if ( $script:sshdServiceRestartFlag ) {  
		RestartService -VmIpOrFqdn $script:vCenter -Username root -Password $script:vCRootSecPass  -serviceName "sshd" -serviceRestartCommand "$script:sshdServiceRestartCommand"
	 }
}	

#
#
#
############################################################################
# Start of VxRail Deployed VMs Hardening Section
############################################################################

####################################################################
# FUNCTION  : HardenVMShutdownRules
# PURPOSE   : Apply the VM STIG rules that require the VM to be shutdown
# PARAMETERS: VM (object)
####################################################################
function HardenVMShutdownRules {
	param ([Parameter(Position=0,Mandatory)] $vmName)
	Get-FunctionName
	
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA

	$msg="Applying Virtual Machine STIG rules"
	Write-Host "`n$msg" -ForegroundColor Green
	Write-Log -Message "$msg"

	$vm = Get-VM $vmName

	## Test mapping function failure with a non-existent vxsec id
	#if ( $DEBUGSWITCH -eq $True ) { SetVxSecAdvancedVMParam 'VXSEC000' $vm 'test' $true }

	# VXSEC301 Copy operations must be disabled on the virtual machine #VMCH-70-000001
	SetVxSecAdvancedVMParam 'VXSEC301' $vm 'isolation.tools.copy.disable' $true

	# VXSEC302 Drag and drop operations must be disabled on the virtual machine #VMCH-70-000002
	SetVxSecAdvancedVMParam 'VXSEC302' $vm "isolation.tools.dnd.disable" $true

	# VXSEC303 Paste operations must be disabled on the virtual machine #VMCH-70-000003
	SetVxSecAdvancedVMParam 'VXSEC303' $vm "isolation.tools.paste.disable" $true

	# VXSEC304 Virtual disk shrinking must be disabled on the virtual machine #VMCH-70-000004
	SetVxSecAdvancedVMParam 'VXSEC304' $vm "isolation.tools.diskShrink.disable" $true

	# VXSEC305 Virtual disk erasure must be disabled on the virtual machine #VMCH-70-000005
	SetVxSecAdvancedVMParam 'VXSEC305' $vm "isolation.tools.diskWiper.disable" $true

	# VXSEC307 HGFS file transfers must be disabled on the virtual machine #VMCH-70-000007
	SetVxSecAdvancedVMParam 'VXSEC307' $vm "isolation.tools.hgfsServerSet.disable" $true

	# VXSEC313 Console connection sharing must be limited on the virtual machine #VMCH-70-000013
	SetVxSecAdvancedVMParam 'VXSEC313' $vm "RemoteDisplay.maxConnections" "1"

	# VXSEC314 Console access through the VNC protocol must be disabled on the virtual machine #Removed in 7.0
	SetVxSecAdvancedVMParam 'VXSEC314' $vm "RemoteDisplay.vnc.enabled" $false

	# VXSEC315 Informational messages from the virtual machine to the VMX file must be limited on the virtual machine #VMCH-70-000015
	SetVxSecAdvancedVMParam 'VXSEC315' $vm "tools.setinfo.sizeLimit" "1048576"

	# VXSEC316 Unauthorized removal, connection and modification of devices must be prevented on the virtual machine #VMCH-70-000016
	SetVxSecAdvancedVMParam 'VXSEC316' $vm "isolation.device.connectable.disable" $true

	# VXSEC317 The virtual machine must not be able to obtain host information from the hypervisor #VMCH-70-000017
	SetVxSecAdvancedVMParam 'VXSEC317' $vm "tools.guestlib.enableHostInfo" $false

	# VXSEC322 The virtual machine guest operating system must be locked when the last console connection is closed  #VMCH-70-000022
	SetVxSecAdvancedVMParam 'VXSEC322' $vm "tools.guest.desktop.autolock" $true

	# VXSEC323 3D features on the virtual machine must be disabled when not required #VMCH-70-000023
	SetVxSecAdvancedVMParam 'VXSEC323' $vm "mks.enable3d" $false

	# VXSEC326 Log size must be properly configured on the virtual machine #VMCH-70-000026
	SetVxSecAdvancedVMParam 'VXSEC326' $vm "log.rotateSize" "2048000"

	# VXSEC327 Log retention must be properly configured on the virtual machine #VMCH-70-000027
	SetVxSecAdvancedVMParam 'VXSEC327' $vm "log.keepOld" "10"

	# -------------------------------------------------------------------
	# VXSEC318 Shared salt values must be disabled on the virtual machine
	# -------------------------------------------------------------------
	if ( getVulnMap 'VXSEC318' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		Try{
			If($script:vxSecRow.enabled){
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

				$name = "sched.mem.pshare.salt"

				#Checking to see if current setting exists
				If ( $asetting = $vm | Get-AdvancedSetting -Name $name) {
					$Outcome="SUCCESS"; Write-Log "...Setting $name exists on $vm...removing setting"
					$asetting | Remove-AdvancedSetting -Confirm:$false -EA Stop
				}
				else {
					$Outcome="SUCCESS"; Write-Log "...Setting $setting does not exist on $vm"
				}
				$script:passProcess++
			}
		}
		Catch{
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}		

	# ---------------------------------------------------------------------------------
	# VXSEC328 DirectPath I/O must be disabled on the virtual machine when not required
	# ---------------------------------------------------------------------------------
	if ( getVulnMap 'VXSEC328' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		Try{
			If($script:vxSecRow.enabled){
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

				# This rule is slightly different than the default set-advancedsetting rule, in that 
				# 1) the parameter name is a variable pattern, and
				# 2) if the param is not found, then its not a finding, so it doesnt need to be created.

				$pciPassthru = "`$vm | Get-AdvancedSetting -Name `"pciPassthru*.present`""
				$cmdResp1 = Invoke-expression $pciPassthru | Format-Table | Out-String
		
				if ($cmdResp1 -match "pciPassthru" ) {
					$pciPassthru = "`$vm | Get-AdvancedSetting -Name `"pciPassthru*.present`" | Set-AdvancedSetting -Value `"`" -Confirm:`$False"
					$cmdResp1 = Invoke-expression $pciPassthru

					$Outcome="SUCCESS"; Write-Log  "Setting pciPassthru (updated)"
				} else {
					$Outcome="SUCCESS"; Write-Log  "Setting pciPassthru (not found, not a finding)"
				}
				$script:passProcess++
			}
		}
		Catch{
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $script:vCenter" "FAIL"
			writeError
			continue
		}
	}		
}


#####################################################################
# FUNCTION  : HardenVMRunningRules
# PURPOSE   : Apply the VM STIG rules that allow the VM to be running
# PARAMETERS: VM (object)
#####################################################################
function HardenVMRunningRules {
	param ([Parameter(Position=0,Mandatory)] $vmName)
	Get-FunctionName
	
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA

	$msg="Applying Virtual Machine STIG rules"
	Write-Host "`n$msg" -ForegroundColor Green
	Write-Log -Message "$msg"

	$vm = Get-VM $vmName -ErrorAction Stop

	# ----------------------------------------------------------------------
	# VXSEC324 Encryption must be enabled for vMotion on the virtual machine
	# ----------------------------------------------------------------------
	if ( getVulnMap 'VXSEC324' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		Try {
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

				$value = "opportunistic" # disabled, required, opportunistic

				# Set virtual machine vMotion Encryption
				If ( $vm.extensiondata.Config.MigrateEncryption -eq $value ) {
					$Outcome="SUCCESS"; Write-Log  "...vMotion encryption set correctly on $vm to $value"
				} else {
					$vmv = $vm | get-view
					$config = new-object VMware.Vim.VirtualMachineConfigSpec
					$config.MigrateEncryption = New-object VMware.Vim.VirtualMachineConfigSpecEncryptedVMotionModes
					$config.MigrateEncryption = "$value"
					$vmv.ReconfigVM($config)
				}
				$script:passProcess++
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $VM" "FAIL"
			writeError
			continue
		}
	}

	# -------------------------------------------------------
	# VXSEC325 Logging must be enabled on the virtual machine
	# -------------------------------------------------------
	if ( getVulnMap 'VXSEC325' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		Try {
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

				$value = $true

				If ( $vm.ExtensionData.Config.Flags.EnableLogging -eq $value ) {
					$Outcome="SUCCESS"; Write-Log  "...Logging set correctly on $vm to $value"
				} else {
					$Outcome="SUCCESS"; Write-Log  "...Logging was incorrectly set to $($vm.ExtensionData.Config.Flags.EnableLogging) on $vm"
					$vmv = $vm | get-view
					$config = new-object VMware.Vim.VirtualMachineConfigSpec
					$config.Flags = New-Object VMware.Vim.VirtualMachineFlagInfo
					$config.Flags.enableLogging = $value
					$vmv.ReconfigVM($config)
				}
				$script:passProcess++
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $VM" "FAIL"
			writeError
			continue
		}
	}

	# -----------------------------------------------------------------------------------------------
	# VXSEC329 Encryption must be enabled for Fault Tolerance on the virtual machine #VMCH-70-000029
	# -----------------------------------------------------------------------------------------------
	if ( getVulnMap 'VXSEC329' ) {
		$VulnID = $script:vxSecRow.vulnid
		$Title  = $script:vxSecRow.vulntitle
		Try {
			If ( $script:vxSecRow.enabled ) {
				Write-Host-Log "Remediating STIG Vulnerability ID: $VulnID with Title: $Title"

				$value = "ftEncryptionOpportunistic"

				If ( $vm.ExtensionData.Config.FtEncryptionMode -eq $value ) {
					$Outcome="SUCCESS"; Write-Log  "...Fault tolerance encryption set correctly on $vm to $value"
				} else {
					$Outcome="SUCCESS"; Write-Log  "...Fault tolerance encryption was incorrectly set to $($vm.extensiondata.Config.FtEncryptionMode) on $vm"
					$vmv = $vm | get-view
					$config = new-object VMware.Vim.VirtualMachineConfigSpec
					$config.FTEncryption = New-Object VMware.Vim.VMware.Vim.VirtualMachineConfigSpecEncryptedFtModes
					$config.FT = $value
					$vmv.ReconfigVM($config)
				}
				$script:passProcess++
			}
		}
		Catch {
			$script:failProcess++
			Write-Host-Log "Failed to remediate STIG Vulnerability ID: $VulnID with Title: $Title on $VM" "FAIL"
			writeError
			continue
		}
	}	
}

############################################################################
# End of VxRail Deployed VMs Hardening Section
############################################################################


############################################################################
# Start of VxRail Custom Attribute Management Section
############################################################################

function AddCustomAttribute {
    param (
		[Parameter(Position=0,Mandatory)] [String] $customAttributeName,
		[Parameter(Position=1,Mandatory)] [String] $targetType
    )
	Get-FunctionName

	$badInputs = $false
    # If the custom attribute name is null or an empty string, return false.
    # Although $caName is a mandatory parameter and cannot be empty, 
    # a value containing only whitespaces should still be considered as empty.
    # Therefore, the value needs to be trimmed and validated.
    if ($null -eq $customAttributeName -or $customAttributeName.trim().length -eq 0) {
        Write-Host "Custom attribute name is null or an empty string." -ForegroundColor Red
        $badInputs = $true
	}
	
	# VxRail hardening applies to the following target types: Cluster, VMHost and Virtual Machine
	if ($targetType -ne "Cluster" -and $targetType -ne "VMHost" -and $targetType -ne "VirtualMachine") {
		Write-Host "`nVxRail hardening applies to the following target types:" -ForegroundColor Red
		Write-Host "Cluster, VMHost and Virtual Machine" -ForegroundColor Red
		$badInputs = $true
	}

	if ($badInputs) {return}
	
    if ($null -ne $(New-CustomAttribute -Name $customAttributeName -TargetType $targetType -ErrorAction Ignore)) {
        Write-Host "Attribute $customAttributeName, Target Type $targetType is added." -ForegroundColor Green
        return $true
    } elseif ($null -ne $(Get-CustomAttribute -Name $customAttributeName -TargetType $targetType -ErrorAction Ignore)) {
		Write-Host "Attribute $customAttributeName, Target Type $targetType already exists." -ForegroundColor Green
		return $true
	} else {
		Write-Host "Attribute $customAttributeName Target Type $targetType failed to add." -ForegroundColor Red
        return $false
	}
}

function SetCustomAttributeValue {
    param (
		[Parameter(Position=0,Mandatory)] [String] $entityName,
		[Parameter(Position=1,Mandatory)] [String] $customAttributeName,
        [Parameter(Position=2,Mandatory=$false)] [AllowEmptyString()] [String] $newValue
    )
	Get-FunctionName

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA

	# If the entity name is null or an empty string, return false.
    if ($null -eq $entityName -or $entityName.length -eq 0) {
		Write-Host "Entity name is null or an empty string."
		Write-Log -Message "SetCustomAttributeValue: not set because entity name is empty."
        return
	}
	
    # If the custom attribute name is null or an empty string, return false.
    if ($null -eq $customAttributeName -or $customAttributeName.length -eq 0) {
		Write-Host "Attribute name is null or an empty string."
		Write-Log -Message "SetCustomAttributeValue not set because attribute name is empty."
        return
    }
    
	# Replace current value with new value
	Try {
		Set-Annotation -Entity $entityName -CustomAttribute $customAttributeName -Value $newValue -ErrorAction Stop | Out-Null
		if ($null -eq $newValue -or $newValue.length -eq 0) {
			$msg = "Value of attribute $customAttributeName is set to blank (empty)."
			Write-Host "$msg"
			Write-Log -Message "$msg"
		} else {
			$msg = "Value of attribute $customAttributeName is set to $newValue."
			Write-Host "$msg"
			Write-Log -Message "$msg"
		}
	} Catch {
		$script:failProcess++
		Write-Host-Log "Failed to set hardening status in custom attributes for $entityName" "FAIL"
		writeError
		continue
	}
}

############################################################################
# End of VxRail Custom Attribute Management Section
############################################################################

#
#
#
############################################################################
# Start of Menu Management Section
############################################################################

function MenuDisplayAllTargets {
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Menu option Display All Targets"
	
	Write-Host "`nAll Targets"
	Write-Host "===========`n"
	Write-Host "`nvCenter:"
	Write-Host "    $($script:vCenter)" -ForegroundColor Green

	Write-Host "`nVxRail ESXi Nodes:"
	foreach ($node in $script:VMHosts) {
		Write-Host "    $($node.Name)" -ForegroundColor Green
	}

	Write-Host "`nVMs deployed by VxRail:"
	foreach ($vmName in $script:vmNames) {
		Write-Host "    $($vmName.Trim())" -ForegroundColor Green
	}
}

function MenuDisplayUnhardenedTargets {
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Menu option Display Unhardened Targets"

	Write-Log -Level 'Debug' "cluster    = $script:Cluster"
	Write-Log -Level 'Debug' "pkgVersion = $script:caPackageVersion"
	Write-Log -Level 'Debug' "vCenter    = $script:vCenter"

	Write-Host "`nUnhardened Targets"
	Write-Host "==================`n"
	Write-Host "`nvCenter:"

	# caValue = Custom Attribute Value
	$caValue = (Get-Cluster -Name $script:Cluster | Get-Annotation | Where-Object {$_.Name -eq $script:caPackageVersion}).Value
	if ($caValue.Trim() -eq "") {
		Write-Host "    $($script:vCenter)" -ForegroundColor Green
	} else {
		Write-Host "    There is no unhardened vCenter." -ForegroundColor Green
	}

	$count = 0
	Write-Host "`nVxRail ESXi Nodes:"
	foreach ($node in $script:VMHosts) {
		$caValue = (Get-VMHost -Name $node | Get-Annotation | Where-Object {$_.Name -eq $script:caPackageVersion}).Value
		if ($caValue.Trim() -eq "") {
			$count++
			Write-Host "    $($node.Name)" -ForegroundColor Green
		}
	}
	if ($count -eq 0) {
		Write-Host "    There is no unhardened VxRail ESXi Node." -ForegroundColor Green
	}

	$count = 0
	Write-Host "`nVMs deployed by VxRail:"
	foreach ($vmName in $script:vmNames) {
		$caValue = (Get-VM -Name $vmName | Get-Annotation | Where-Object {$_.Name -eq $script:caPackageVersion}).Value
		Write-Log -Level 'Debug' "vmName=$vmName"
		Write-Log -Level 'Debug' "caValue=$caValue"

		if ($caValue.Trim() -eq "") {
			$count++
			Write-Host "    $($vmName.Trim())" -ForegroundColor Green
		}
	}
	if ($count -eq 0) {
		Write-Host "    There is no unhardened VM." -ForegroundColor Green
	}
}

function MenuHardenAll {
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Menu option Harden All"

	MenuHardenVC           # harden VC and possibly PSC
	MenuHardenAllESXiNodes # harden ESXi nodes
	MenuHardenOtherVMs     # harden other VMs (not VC, PSC or VxM)
	MenuHardenVxM $script:VxRailManagerVMName # harden the VxM VM
}

function MenuHardenAllESXiNodes {
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Menu option Harden All VxRail ESXi Nodes"

	HardenESXiNodes $true
}

function MenuHardenNewESXiNodes {
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Menu option Harden New VxRail ESXi Nodes"

	HardenESXiNodes $false
}

function MenuHardenVC {

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Menu option Harden VxRail Deployed vCenter"

	# Checking if SSH port is open in vCenter else returning to the option menu
	$sshStatus = checkPortStatus -VmIpOrFqdn $script:vCenter -port 22 -Protocol SSH
	if (-not $sshStatus) {
		Write-host "Please refer the VxRail STIG hardening guide and enable SSH to harden 'VxRail Deployed vCenter (VM+vCenter)'." -ForegroundColor Yellow
		return
    }

	#Asking user to provide vCenter root account password
	$SecPass = askUserForAPassword "`nPlease enter the vCenter root account's password"
	$script:vCRootSecPass = [System.Net.NetworkCredential]::new("", $SecPass).Password

	# Checking if given password is valid to establish a SSH connection to the vCenter
	$authStatus = checkGivenPasswordForSSH -VmIpOrFqdn $script:vCenter -Username root -Password $script:vCRootSecPass
	if (-not $authStatus) {
		Write-host "Authentication failed due to incorrect vCenter root credentials. Please verify your credentials and try again." -ForegroundColor Yellow
		Write-host "Exiting 'Harden VxRail Deployed vCenter (VM+vCenter)'..." -ForegroundColor Yellow
		return
    }
	
	# Reset status counters
	$script:failProcess = 0
	$script:passProcess = 0

	if ($script:VxRailDeployedVC) {
		# ---------------------------------------------------------------------------------------------
		# vCenter Hardening - check the conditions
		# ---------------------------------------------------------------------------------------------
		# From vSphere 7.0U3d (VxRail 7.0.370), vSphere requires the VM to be shutdown before applying advanced configuration parameters
		if ($script:VxRailVersion -ge '7.0.370') {
			# Only harden if allowed by user to shut down the VM
			if (promptVmShutDownAllowed "$script:VCVMName") {
				Write-Log -Level 'Debug' "Shutdown is ALLOWED"
				$vmIsShutdown = $true
				$doHardenVM = $true

				# Shutdown the VC VM. Return to the menu if not successful
				if (-not (shutdownvm $script:VCVMName)) { return }

			} else {
				# Shutdown not allowed - not hardening VM
				Write-Host-Log "Shutdown is REJECTED - not hardening the VM"
				$vmIsShutdown = $false
				$doHardenVM = $false
			}
		} else {
			# vSphere version is less than 7.0U3d, so its not required to shut down the VM before applying advanced configuration parameters
			$vmIsShutdown = $false
			$doHardenVM = $true
		}

		# bit of formatting for summary text
		$summaryMsg  = ""
		$summaryLine = ""

		# Can the VM be hardened?
		if ( $doHardenVM ) {
			# ---------------------------------------------------------------------------------------------
			# vCenter Hardening
			# ---------------------------------------------------------------------------------------------
			$msg = "Hardening $script:VCVMName"
			Write-Host $msg -ForegroundColor Green
			Write-Log -Level 'Debug' $msg

			HardenVCShutdownRules                  # harden the VC app
			HardenVMShutdownRules $script:VCVMName # harden the VC VM
	
			# Was the VM shutdown for hardening?
			if ( $vmIsShutdown ) {
				# No need to set esxi connection, as there is no PSC on v7+
				# Startup the VM. Return to the menu if not successful
				if (-not (startupVM $script:VCVMName 'VCSA')) { return }
				# startup will have set the connection back from ESXi to vCenter
			}
			HardenVCRunningRules                  # harden the VC app
			HardenVMRunningRules $script:VCVMName # harden the VC VM
			HardenPhotonOSRules					  # harden the vCSA Photon OS

			# Mark as hardened - VC
			SetCustomAttributeHistory $script:VCVMName # vCenter VM  (custom attributes at VM level)
			SetCustomAttributeHistory $script:Cluster  # vCenter app (custom attributes at cluster level)

			# ---------------------------------------------------------------------------------------------
			# PSC Hardening
			# ---------------------------------------------------------------------------------------------
			# When on vSphere 6.7, include the PSC
			if ( $script:VxRailMajorVersion -eq '4' ) {
				$msg = "Hardening $script:PSCVMName"
				Write-Host $msg -ForegroundColor Green
				Write-Log -Level 'Debug' $msg
	
				# harden PSC VM
				HardenVMShutdownRules $script:PSCVMName
				HardenVMRunningRules  $script:PSCVMName 

				# Mark as hardened - PSC
				SetCustomAttributeHistory $script:PSCVMName # PSC VM (custom attributes at VM level)

				# bit of formatting for summary text
				$summaryMsg  = " and PSC"
				$summaryLine = "********"
			}
		}
		###########
		# SUMMARY #
		###########
		Write-Host "`n*****************${summaryLine}*******************"
		Write-Host   "* vSphere vCenter${summaryMsg} - config summary *"
		Write-Host   "*****************${summaryLine}*******************"

		$VulnID = $script:VulnIdNA
		$Outcome = $script:OutcomeNA
		Write-Host-Log "$script:VCVMName${summaryMsg} config summary"

		Write-Host "$script:passProcess process(es) completed successfully" -ForegroundColor Green
		Write-Log -Message "$script:passProcess process(es) completed successfully"

		Write-Host "$script:failProcess process(es) failed" -ForegroundColor Red
		Write-Log -Message "$script:failProcess process(es) failed"

		# Reset status counters
		$script:passProcess = 0
		$script:failProcess = 0

	} else {
		Write-Host "This hardening script supports VxRail deployed targets. It looks like the vCenter in this system is not VxRail deployed." -ForegroundColor Red
	}
}
function MenuHardenVxM {

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Menu option Harden VxRail Manager"

	# Reset status counters
	$script:failProcess = 0
	$script:passProcess = 0

	# ---------------------------------------------------------------------------------------------
	# VxRail Manager Hardening - check the conditions
	# ---------------------------------------------------------------------------------------------
	# From vSphere 7.0U3d (VxRail 7.0.370), vSphere requires the VM to be shutdown before applying advanced configuration parameters
	if ($script:VxRailVersion -ge '7.0.370') {
		# Also check if this cluster has internal DNS. If so, the VxM can't be shut down, as it would make all components unreachable.
		if ( -not ($script:VxMHasInternalDNS)) {
			# DNS is external, so VM shutdown is possible
			# Only harden if allowed by user to shut down the VM
			if (promptVmShutDownAllowed "$script:VxRailManagerVMName") {
				Write-Host-Log "Shutdown is ALLOWED"
				$vmIsShutdown = $true
				$doHardenVM = $true

				# Shutdown the VM. Return to the menu if not successful
				if (-not (shutdownvm $script:VxRailManagerVMName)) { return }
				
			} else {
				# Shutdown not allowed - not hardening VM
				Write-Host-Log "Shutdown is REJECTED - not hardening the *VM*"
				$vmIsShutdown = $false
				$doHardenVM = $false
			}
		} else {
			# DNS is internal, so VM shutdown is not possible
			$doHardenVM = $false
			Write-Log -Level Warn "The VxRail cluster is at version $script:VxRailVersion and the VxRail Manager is configured with an *internal* DNS, so VxM VM hardening is not supported."
			Write-Log -Level Warn "Skipping VxM *VM* STIG Hardening. For details refer the *Introduction* section of the Dell VxRail STIG Hardening Guide."
		}
	} else {
		# vSphere version is less than 7.0U3d, so its not required to shut down the VM before applying advanced configuration parameters
		$vmIsShutdown = $false
		$doHardenVM = $true
	}

	# Can the VM be hardened?
	if ( $doHardenVM ) {
		# ---------------------------------------------------------------------------------------------
		# VxRail Manager Hardening
		# ---------------------------------------------------------------------------------------------
		$msg = "Hardening $script:VxRailManagerVMName"
		Write-Host $msg -ForegroundColor Green
		Write-Log -Level 'Debug' $msg

		HardenVMShutdownRules $script:VxRailManagerVMName # harden the VxM VM

		# Was the VM shutdown for hardening?
		if ( $vmIsShutdown ) {
			# Startup the VM. Return to the menu if not successful
			if (-not (startupVM $script:VxRailManagerVMName 'VXM')) { return }
		}
		HardenVMRunningRules $script:VxRailManagerVMName # harden the VM
	}

	# Lastly, always harden the VxM OS
	Write-Host-Log "Starting VxM *SLES-OS* STIG Hardening ..."
	MenuRunSLESShellScript

	# Only mark as hardened, if both VM STIG and SUSE STIG were applied
	if ( $doHardenVM ) {
		# Mark VxM VM as hardened (custom attributes at VM level)
		SetCustomAttributeHistory $script:VxRailManagerVMName
	}

	###########
	# SUMMARY #
	###########
	Write-Host "`n***********************************"
	Write-Host   "* VxRail Manager - config summary *"
	Write-Host   "***********************************"

	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Host-Log "$script:VxRailManagerVMName Virtual Machine config summary"

	Write-Host "$script:passProcess process(es) completed successfully" -ForegroundColor Green
	Write-Log -Message "$script:passProcess process(es) completed successfully"

	Write-Host "$script:failProcess process(es) failed" -ForegroundColor Red
	Write-Log -Message "$script:failProcess process(es) failed"

	# Reset status counters
	$script:passProcess = 0
	$script:failProcess = 0
}

function MenuRunSLESShellScript {
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Menu option Run SLES STIG Shell Script File"

	Write-Host "`n--------------------------------------------------------------------------"
	Write-Host "Instructions for hardening the VxRail Manager OS" -ForegroundColor Yellow
	Write-Host "`nPlease locate the $vxmScriptFileName file on the workstation and follow the steps below:" -ForegroundColor Yellow
	Write-Host "1 - Copy script and the py sub-directory to VxRail Manager VM as mystic"
	Write-Host "2 - Login using SSH to the VxRail Manager VM as user mystic"
	Write-Host "3 - su to change to root and update the script's permissions to executable"
	Write-Host "4 - Follow the VxRail STIG Hardening Guide to harden the VxRail Manager operating system" -ForegroundColor Yellow
	
	Read-Host "`nAfter the script has finished, return to this UI and press Enter to continue..."

	Write-Host "If the script has completed successfully, press Enter.         The VxRail Hardened State metadata will then be updated."
	Write-Host "If the script was not executed or failed, press n, then Enter. The VxRail Hardened State metadata will then NOT be updated."
	Do {
		$resultAnswer = Read-Host "Press Enter if completed successfully. Otherwise, press n, then Enter."
		$resultAnswer = TrimLower($resultAnswer)
	} While ( ($resultAnswer -ne "n") -and ($resultAnswer -ne "") )

	if ($resultAnswer -eq "") {
		# Mark VxM app (SLES OS) as hardened (custom attributes at cluster level)
		SetCustomAttributeHistory "VxM"
		$Outcome = "SUCCESS"
		Write-Log -Message "User indicated VxRail Manager OS STIG hardening script ran successfully."
	} else {
		$Outcome = "FAIL"
		Write-Log -Message "User indicated VxRail Manager OS STIG hardening script was not executed or failed."
	}
}

function MenuHardenOtherVMs {
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "Menu option Harden other VxRail deployed Virtual Machines"

	# Reset status counters
	$script:failProcess = 0
	$script:passProcess = 0

	if ( $script:otherVMNames.Count -eq 0 ) {
		$msg = "There are no other VxRail deployed Virtual Machines" 
		Write-Host "`n$msg`n" -ForegroundColor Yellow
		Write-Log -Message "$msg"
	} else {
		foreach ( $vmName in $script:otherVMNames ) {

			# From vSphere 7.0U3d (VxRail 7.0.370), vSphere requires the VM to be shutdown before applying advanced configuration parameters
			if ($script:VxRailVersion -ge '7.0.370') {
				# Only harden if allowed by user to shut down the VM
				if (promptVmShutDownAllowed "$vmName") {
					Write-Host-Log "Shutdown is ALLOWED"
					$vmIsShutdown = $true
					$doHardenVM = $true

					# Shutdown the VM. Return to the menu if not successful
					if (-not (shutdownVM $vmName)) { return }
					
				} else {
					# Shutdown not allowed - not hardening VM
					Write-Host-Log "Shutdown is REJECTED - not hardening the VM"
					$vmIsShutdown = $false
					$doHardenVM = $false
				}
			} else {
				# vSphere version is less than 7.0U3d, so its not required to shut down the VM before applying advanced configuration parameters
				$vmIsShutdown = $false
				$doHardenVM = $true
			}

			# Can the VM be hardened?
			if ( $doHardenVM ) {
				$msg = "Hardening $vmName"
				Write-Host $msg -ForegroundColor Green
				Write-Log -Level 'Debug' $msg

				HardenVMShutdownRules $vmName

				# Was the VM shutdown for hardening?
				if ( $vmIsShutdown ) {

					# Startup the VM. Return to the menu if not successful
					if (-not (startupVM $vmName)) { return }
				}

				HardenVMRunningRules $vmName

				# Mark this VM as hardened
				SetCustomAttributeHistory $vmName
			}

			###########
			# SUMMARY #
			###########
			Write-Host "`n***********************************"
			Write-Host   "* $vmName - config summary *"
			Write-Host   "***********************************"

			$VulnID = $script:VulnIdNA
			$Outcome = $script:OutcomeNA
			Write-Host-Log "$vmName Virtual Machine config summary"

			Write-Host "$script:passProcess process(es) completed successfully" -ForegroundColor Green
			Write-Log -Message "$script:passProcess process(es) completed successfully"

			Write-Host "$script:failProcess process(es) failed" -ForegroundColor Red
			Write-Log -Message "$script:failProcess process(es) failed"

			# Reset status counters
			$script:passProcess = 0
			$script:failProcess = 0
		}
	}
}


function MenuLevel1 {

	Write-Host "`n"
	Write-Host "  ||       ||          ||||||\\"
	Write-Host "  \\       //          ||     ))"
	Write-Host "   \\     //   \\  //  ||||||//     //\\     ||||||||  ||"
	Write-Host "    \\   //     \\//   ||  \\      //  \\       ||     ||"
	Write-Host "     \\ //      //\\   ||   \\    //||||\\      ||     ||"
	Write-Host "      \V/      //  \\  ||    \\  //      \\  ||||||||  |||||||"
	Write-Host "  ============================================================"
	Write-Host "              VxRail STIG Hardening version $VxRailPackageVersion             "
	
	Write-Host "`n  Main Menu"
	Write-Host "  =========`n"
	if ($script:VxRailMajorVersion -eq '4') {
		$menu=@(
			"Display All Targets"
			,"Display Unhardened Targets"
			,"Harden All"
			,"Harden All VxRail ESXi Nodes"
			,"Harden New VxRail ESXi Nodes"
			,"Harden VxRail Deployed vCenter/PSC (VM+vC/PSC)"
			,"Harden VxRail Manager (VM+OS)"
			,"Harden Other VxRail Deployed VMs (VM)"
			,"Exit")
	} elseif ($script:VxRailMajorVersion -eq '7') {
		$menu=@(
			"Display All Targets"
			,"Display Unhardened Targets"
			,"Harden All"
			,"Harden All VxRail ESXi Nodes"
			,"Harden New VxRail ESXi Nodes"
			,"Harden VxRail Deployed vCenter (VM+vCenter)"
			,"Harden VxRail Manager (VM+OS)"
			,"Harden Other VxRail Deployed VMs (VM)"
			,"Exit")
	}
    $menuCount = $menu.Count

    for ($i = 0; $i -lt $menuCount; $i++) {
        Write-Host "  $(($i+1)%$menuCount) - $($menu.get($i))"
    }

    [Int] $choice = -1

    Do {
        try {
			$temp = Read-Host "Enter 0 - $($menuCount - 1)"
			if ($temp.Trim() -ne "") {
				$choice = $temp
			}
			if ($choice -ne $temp) {
				$choice = -1
			}
        } catch {$choice = -1}
	} while ($choice -lt 0 -or $choice -gt ($menuCount - 1))
	
	# Log user selection in logfile
	# To get the last menu array item text to log when the user chooses 0 to exit, the choice nr has to be
	# manipulated, so that menu.get() will get the correct/corresponding menu item text.
	$VulnID = $script:VulnIdNA
	$Outcome = $script:OutcomeNA
	Write-Log -Message "*** User selected menu option $choice - $($menu.get(($choice+($menuCount-1))%$menuCount)) ***"

	return $choice
}

function ControlMenuLevel1 {

	try {
		Do {
			try {
				$choice = MenuLevel1
				if       ($choice -eq 1) {	MenuDisplayAllTargets
				} elseif ($choice -eq 2) {	MenuDisplayUnhardenedTargets
				} elseif ($choice -eq 3) {	MenuHardenAll
				} elseif ($choice -eq 4) {	MenuHardenAllESXiNodes
				} elseif ($choice -eq 5) {	MenuHardenNewESXiNodes
				} elseif ($choice -eq 6) {	MenuHardenVC
				} elseif ($choice -eq 7) {	MenuHardenVxM
				} elseif ($choice -eq 8) {	MenuHardenOtherVMs
				}

				if ($choice -ne 0) {
					Read-Host "`nPress Enter to return to main menu"
				}
			} catch {
				Write-Host "`nThere is a problem executing the script. Please check system connectivity or contact support for assistance." -ForegroundColor Red
				writeError
				Read-Host "`nPress Enter to return to main menu"
			}
		} While ($choice -ne 0)
	} 
	catch {
		writeError
	} 
	finally {
		Disconnect-VIServer * -Confirm:$false | Out-Null

		$VulnID = $script:VulnIdNA
		$Outcome = $script:OutcomeNA
		Write-Log -Message "******************************************"
		Write-Log -Message "*** Stop VxRail STIG Hardening Process ***"
		Write-Log -Message "******************************************"

		Write-Host "`nExited VxRail STIG Hardening version $VxRailPackageVersion" -ForegroundColor Green
	}
}

init
ControlMenuLevel1

############################################################################
# End of Menu Management Section
######################################################################
# SIG # Begin signature block
# MIIsBgYJKoZIhvcNAQcCoIIr9zCCK/MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBIXBx6tdglJNvw
# 99eFQtbQWzcsU2+8Bf80WKIVcDxnPqCCJaMwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwggXfMIIEx6ADAgECAhBOQOQ3VO3mjAAAAABR05R/MA0GCSqG
# SIb3DQEBCwUAMIG+MQswCQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwgSW5j
# LjEoMCYGA1UECxMfU2VlIHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5MDcG
# A1UECxMwKGMpIDIwMDkgRW50cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVkIHVz
# ZSBvbmx5MTIwMAYDVQQDEylFbnRydXN0IFJvb3QgQ2VydGlmaWNhdGlvbiBBdXRo
# b3JpdHkgLSBHMjAeFw0yMTA1MDcxNTQzNDVaFw0zMDExMDcxNjEzNDVaMGkxCzAJ
# BgNVBAYTAlVTMRYwFAYDVQQKDA1FbnRydXN0LCBJbmMuMUIwQAYDVQQDDDlFbnRy
# dXN0IENvZGUgU2lnbmluZyBSb290IENlcnRpZmljYXRpb24gQXV0aG9yaXR5IC0g
# Q1NCUjEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCngY/3FEW2YkPy
# 2K7TJV5IT1G/xX2fUBw10dZ+YSqUGW0nRqSmGl33VFFqgCLGqGZ1TVSDyV5oG6v2
# W2Swra0gvVTvRmttAudFrnX2joq5Mi6LuHccUk15iF+lOhjJUCyXJy2/2gB9Y3/v
# MuxGh2Pbmp/DWiE2e/mb1cqgbnIs/OHxnnBNCFYVb5Cr+0i6udfBgniFZS5/tcnA
# 4hS3NxFBBuKK4Kj25X62eAUBw2DtTwdBLgoTSeOQm3/dvfqsv2RR0VybtPVc51z/
# O5uloBrXfQmywrf/bhy8yH3m6Sv8crMU6UpVEoScRCV1HfYq8E+lID1oJethl3wP
# 5bY9867DwRG8G47M4EcwXkIAhnHjWKwGymUfe5SmS1dnDH5erXhnW1XjXuvH2OxM
# bobL89z4n4eqclgSD32m+PhCOTs8LOQyTUmM4OEAwjignPqEPkHcblauxhpb9Gdo
# BQHNG7+uh7ydU/Yu6LZr5JnexU+HWKjSZR7IH9Vybu5ZHFc7CXKd18q3kMbNe0WS
# kUIDTH0/yvKquMIOhvMQn0YupGaGaFpoGHApOBGAYGuKQ6NzbOOzazf/5p1nAZKG
# 3y9I0ftQYNVc/iHTAUJj/u9wtBfAj6ju08FLXxLq/f0uDodEYOOp9MIYo+P9zgyE
# Ig3zp3jak/PbOM+5LzPG/wc8Xr5F0wIDAQABo4IBKzCCAScwDgYDVR0PAQH/BAQD
# AgGGMBIGA1UdEwEB/wQIMAYBAf8CAQEwHQYDVR0lBBYwFAYIKwYBBQUHAwMGCCsG
# AQUFBwMIMDsGA1UdIAQ0MDIwMAYEVR0gADAoMCYGCCsGAQUFBwIBFhpodHRwOi8v
# d3d3LmVudHJ1c3QubmV0L3JwYTAzBggrBgEFBQcBAQQnMCUwIwYIKwYBBQUHMAGG
# F2h0dHA6Ly9vY3NwLmVudHJ1c3QubmV0MDAGA1UdHwQpMCcwJaAjoCGGH2h0dHA6
# Ly9jcmwuZW50cnVzdC5uZXQvZzJjYS5jcmwwHQYDVR0OBBYEFIK61j2Xzp/PceiS
# N6/9s7VpNVfPMB8GA1UdIwQYMBaAFGpyJnrQHu995ztpUdRsjZ+QEmarMA0GCSqG
# SIb3DQEBCwUAA4IBAQAfXkEEtoNwJFMsVXMdZTrA7LR7BJheWTgTCaRZlEJeUL9P
# bG4lIJCTWEAN9Rm0Yu4kXsIBWBUCHRAJb6jU+5J+Nzg+LxR9jx1DNmSzZhNfFMyl
# cfdbIUvGl77clfxwfREc0yHd0CQ5KcX+Chqlz3t57jpv3ty/6RHdFoMI0yyNf02o
# FHkvBWFSOOtg8xRofcuyiq3AlFzkJg4sit1Gw87kVlHFVuOFuE2bRXKLB/GK+0m4
# X9HyloFdaVIk8Qgj0tYjD+uL136LwZNr+vFie1jpUJuXbheIDeHGQ5jXgWG2hZ1H
# 7LGerj8gO0Od2KIc4NR8CMKvdgb4YmZ6tvf6yK81MIIGPzCCBCegAwIBAgIQC4j1
# jJz4rM7dqOuljMD9ZDANBgkqhkiG9w0BAQ0FADBPMQswCQYDVQQGEwJVUzEWMBQG
# A1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UEAxMfRW50cnVzdCBDb2RlIFNpZ25p
# bmcgQ0EgLSBPVkNTMjAeFw0yMjExMDQxOTA4NDFaFw0yMzEyMDExOTA4NDFaMIGC
# MQswCQYDVQQGEwJVUzEOMAwGA1UECBMFVGV4YXMxEzARBgNVBAcTClJvdW5kIFJv
# Y2sxHzAdBgNVBAoTFkRlbGwgVGVjaG5vbG9naWVzIEluYy4xDDAKBgNVBAsTA1Z4
# TTEfMB0GA1UEAxMWRGVsbCBUZWNobm9sb2dpZXMgSW5jLjCCAaIwDQYJKoZIhvcN
# AQEBBQADggGPADCCAYoCggGBALGQmzwNB6EzM2V0JoweIDSCQ7hQZYuyJ6d6FKeg
# P8tfo+0EL+RTwUN2QHSGGG6vZzodpGOHaPZbFSZkiq4/yEkCszTJU+uflxgo/1xX
# 2OtUcbTP0M397FOUunaAQj5uLTH/SHWKFaoOGSedf6EZ4ETrw2+kvKyU1045Aam5
# xVoKDCYya8IuBhj5cxz2Wm1Lkc9b1wPo0WkNhoZ4ocgzWDL8+BgSjstKLij2lGGz
# q4OAmlIysBlkU/oQNjg7kEqmCG7iKzq82nASIKGczBS3jmWVspPKCwjSPL91Skv6
# YFJ6NUkgJyJ46mR1C9a6uLhSSoKNl8UVy7lGnOMWDQXwmOY5AeE52NMARSU8sGf/
# n3DbENY+BadofYbM194PgxaCZbAyFySKMKG0oaIx9Hzmc9cg+plStXzn0bzLn44q
# BO+jLIu+NG8i6ynki16szomsil+gCBt4TMXtlYLTiKeDK9348QeTTHpEgFZW/4Kw
# jrWQJAmmR9QBfwq+gzY7RmAKdQIDAQABo4IBYTCCAV0wDAYDVR0TAQH/BAIwADAd
# BgNVHQ4EFgQUCA6+42yYxAUR3vRQ16qCbyDV76swHwYDVR0jBBgwFoAU75+6ebBz
# 8iUeeJwDUpwbU4Teje0wZwYIKwYBBQUHAQEEWzBZMCMGCCsGAQUFBzABhhdodHRw
# Oi8vb2NzcC5lbnRydXN0Lm5ldDAyBggrBgEFBQcwAoYmaHR0cDovL2FpYS5lbnRy
# dXN0Lm5ldC9vdmNzMi1jaGFpbi5wN2MwMQYDVR0fBCowKDAmoCSgIoYgaHR0cDov
# L2NybC5lbnRydXN0Lm5ldC9vdmNzMi5jcmwwDgYDVR0PAQH/BAQDAgeAMBMGA1Ud
# JQQMMAoGCCsGAQUFBwMDMEwGA1UdIARFMEMwNwYKYIZIAYb6bAoBAzApMCcGCCsG
# AQUFBwIBFhtodHRwczovL3d3dy5lbnRydXN0Lm5ldC9ycGEwCAYGZ4EMAQQBMA0G
# CSqGSIb3DQEBDQUAA4ICAQBPwr2Wx+2rQDEJo74iZ2x+LTMbxaVSCsn4uSTcRQ1m
# NodqeqLp+Y2lmy7QJpc9cyF/VybCOgF11A68Cuasu/GQEfJhJIbNIqIw3PzrYIcW
# sN6RBLcy2hRhJ3JsqWpxVJ2BgZenPG0Nqv6QfQTcQmyBolAkBs2sAAm6+zCBYruA
# v5MtAk5yzkElryQwK16vI2nbEZQdHLH00eRoB3OeDZa/FieHzYYrau2IBXeGPVde
# yOSL5BXXpfWc0gmwJpL1yctPwnuC6IUNqXyreie58dBGhicPWiWEYu3OG6CBVViZ
# OcWwKeLuSMmgYLWKtZ7o06BCrLyIl32nZDeKdAy6BGMoSbBEnCxeQVrzPkbo4Pxf
# u5B0TIQrpY3vt0zCA7QPlhQAI+F0RNzFYzwqDEg0l9U0fG1Y2Zi5o4T7es1x+/kd
# kTqSJ+3buVTSbI0Fm8jhkv6TfcVrdG0VKyHvRP6izIAkFEgnieGWbYJv6JXTmLnM
# hZZMtSUUWzXGvZEGFvBXiurPFuatSUxBPuoX1wSTpczDUcOhK/MWFBJAyIQiff10
# JpgR9O+bpzIb/65T7vkU9fAUn52sDr9I+SfkuknJMaMuaQJBKR57P9xWrOh0HZ0C
# 3b1e3JJ/qWgKgwaX6RdLam6dZMpEEGR8btvO9FiqDzUOprx41Tgbt458YXljKHEH
# 3zCCBnAwggRYoAMCAQICEHHvVXSvNVTDWixp9m9La80wDQYJKoZIhvcNAQENBQAw
# aTELMAkGA1UEBhMCVVMxFjAUBgNVBAoMDUVudHJ1c3QsIEluYy4xQjBABgNVBAMM
# OUVudHJ1c3QgQ29kZSBTaWduaW5nIFJvb3QgQ2VydGlmaWNhdGlvbiBBdXRob3Jp
# dHkgLSBDU0JSMTAeFw0yMTA1MDcxOTIwNDVaFw00MDEyMjkyMzU5MDBaME8xCzAJ
# BgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMuMSgwJgYDVQQDEx9FbnRy
# dXN0IENvZGUgU2lnbmluZyBDQSAtIE9WQ1MyMIICIjANBgkqhkiG9w0BAQEFAAOC
# Ag8AMIICCgKCAgEAnpl2FxqeVhcIYyyTTYNhhDM0ArbZYqDewg65IEzIV50P3VRb
# DQzWAd0vSOGRCeHbyBUEgrZ78NjWMDsZcXD7qKaX9ildpAyp9FM+V9sMTm78dttf
# JOmqX0Pjk+cOz8olvMRMMAtaD+YG9OVuDJlmWE+DYcJzfFwibwFFxQ/3QE9kS9AX
# CqkOHgIvoY9M8mdQ2z7kn8JPP3TrMaTQlNCZvDCSCWrLJM2i2HZS0E51mE9kWtJe
# g/RYwF1qdcTYP2Q6ixQN2Hbh6rlr5xFwSRE4YxNu8cb6vRBFNQfmdhXQdRaqwkNX
# /qv+Y3NGIqC48+THcEYJ+ak3QZqzS2wfcHKjB/Y1knQRZG75AtXAkpXxl1l+De6i
# JfJxVbibjb/N7q7d+wznrjJOUI2h39Fzv8HOf3Xaq7/QrYI4xeeI7aJtOoYRt9ew
# 4aiLOwxBF5pf5FuYyJ0An/dz0sPpnwWHeSGD1gvt0cwIn+DxxclYulNf1Iexi1mo
# 0l7NadA++sQ5Ca+0te3nPPoih9Zz+ReVasMc9VV4X9T6C8BbP4x4FQ5aTDpu5SaY
# 0CfMIN/Ahjt6jWVGftlhXqn0rj7U/K9FxzqzhQRKi8gJXbN7AihZ44Z9gKJYQGZi
# 4DhVg6ufKUEmurvp2GT4trsoc80VSteec+NmTLFRnYEji8iGd7K2LDcicCECAwEA
# AaOCASwwggEoMBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFO+funmwc/Il
# HnicA1KcG1OE3o3tMB8GA1UdIwQYMBaAFIK61j2Xzp/PceiSN6/9s7VpNVfPMDMG
# CCsGAQUFBwEBBCcwJTAjBggrBgEFBQcwAYYXaHR0cDovL29jc3AuZW50cnVzdC5u
# ZXQwMQYDVR0fBCowKDAmoCSgIoYgaHR0cDovL2NybC5lbnRydXN0Lm5ldC9jc2Jy
# MS5jcmwwDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMEUGA1Ud
# IAQ+MDwwMAYEVR0gADAoMCYGCCsGAQUFBwIBFhpodHRwOi8vd3d3LmVudHJ1c3Qu
# bmV0L3JwYTAIBgZngQwBBAEwDQYJKoZIhvcNAQENBQADggIBAF7zhpk1wXnu8BCv
# 15JD0oXQW+CYoOBxUckUy1CaYA6wBCZJsc/pupsIodpDXdRvI6K5+EDHR/5NAQtI
# kD/I3Gq0PlM1KL5ASkeFah53QMyAf2G0PE95qOajpqB+RIZxvxIblYFy9w2l0N5n
# n8aiuPFq+fz+dGbGZOZ5PWoDYU5LH8wgYssCGOxj7X5xP5a6C15oImfsH8DSBRZm
# sbKk6vzFlaONEqX1je8bIM2Z9+cy81lxH92U5nnlUiMQVir8WTi/v3klkmrH/atn
# d3GxBH01rRTBPqj8IxdWCBh813oia5FqzDVFbU87nUOdBbid8/w0IVwEGDJXODTB
# yoMjRqaIIyHGfhSAq7HvuwusCT/uU5Exs+JURKq1fTA8LCOc6D+jWOpACBejIF96
# wAzbqv8DFgMNdGQimpReMDV2E/XT4ePgB8rZ6kWIRpxU1RDi8zIJQLbnXBcy/syv
# 623PYDx18+5cYEBVG7VZr3IjaE2cdAQMEMmvUFunDWYPluWaleAgohrQsO44SZ4q
# Z56RlmyY28QQbWB8Hm5I57Z+rzMHEnHvvZU7vqmD1EJ9t6c011+GkbWvVljaVX0X
# vdu8zWRBFY0xUQZPtC6yiz2c803jWANUzKyI+FI8TktGCSUZ/xXnp5hGLn266uPj
# fP/5uRmVvna5DXmyAlEaSsifiMJDMIIGrjCCBJagAwIBAgIQBzY3tyRUfNhHrP0o
# ZipeWzANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjIwMzIzMDAwMDAwWhcNMzcwMzIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGlt
# ZVN0YW1waW5nIENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxoY1
# BkmzwT1ySVFVxyUDxPKRN6mXUaHW0oPRnkyibaCwzIP5WvYRoUQVQl+kiPNo+n3z
# nIkLf50fng8zH1ATCyZzlm34V6gCff1DtITaEfFzsbPuK4CEiiIY3+vaPcQXf6sZ
# Kz5C3GeO6lE98NZW1OcoLevTsbV15x8GZY2UKdPZ7Gnf2ZCHRgB720RBidx8ald6
# 8Dd5n12sy+iEZLRS8nZH92GDGd1ftFQLIWhuNyG7QKxfst5Kfc71ORJn7w6lY2zk
# psUdzTYNXNXmG6jBZHRAp8ByxbpOH7G1WE15/tePc5OsLDnipUjW8LAxE6lXKZYn
# LvWHpo9OdhVVJnCYJn+gGkcgQ+NDY4B7dW4nJZCYOjgRs/b2nuY7W+yB3iIU2YIq
# x5K/oN7jPqJz+ucfWmyU8lKVEStYdEAoq3NDzt9KoRxrOMUp88qqlnNCaJ+2RrOd
# OqPVA+C/8KI8ykLcGEh/FDTP0kyr75s9/g64ZCr6dSgkQe1CvwWcZklSUPRR8zZJ
# TYsg0ixXNXkrqPNFYLwjjVj33GHek/45wPmyMKVM1+mYSlg+0wOI/rOP015LdhJR
# k8mMDDtbiiKowSYI+RQQEgN9XyO7ZONj4KbhPvbCdLI/Hgl27KtdRnXiYKNYCQEo
# AA6EVO7O6V3IXjASvUaetdN2udIOa5kM0jO0zbECAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFLoW2W1NhS9zKXaaL3WMaiCPnshvMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQB9WY7Ak7ZvmKlEIgF+ZtbYIULhsBguEE0T
# zzBTzr8Y+8dQXeJLKftwig2qKWn8acHPHQfpPmDI2AvlXFvXbYf6hCAlNDFnzbYS
# lm/EUExiHQwIgqgWvalWzxVzjQEiJc6VaT9Hd/tydBTX/6tPiix6q4XNQ1/tYLaq
# T5Fmniye4Iqs5f2MvGQmh2ySvZ180HAKfO+ovHVPulr3qRCyXen/KFSJ8NWKcXZl
# 2szwcqMj+sAngkSumScbqyQeJsG33irr9p6xeZmBo1aGqwpFyd/EjaDnmPv7pp1y
# r8THwcFqcdnGE4AJxLafzYeHJLtPo0m5d2aR8XKc6UsCUqc3fpNTrDsdCEkPlM05
# et3/JWOZJyw9P2un8WbDQc1PtkCbISFA0LcTJM3cHXg65J6t5TRxktcma+Q4c6um
# AU+9Pzt4rUyt+8SVe+0KXzM5h0F4ejjpnOHdI/0dKNPH+ejxmF/7K9h+8kaddSwe
# Jywm228Vex4Ziza4k9Tm8heZWcpw8De/mADfIBZPJ/tgZxahZrrdVcA6KYawmKAr
# 7ZVBtzrVFZgxtGIJDwq9gdkT/r+k0fNX2bwE+oLeMt8EifAAzV3C+dAjfwAL5HYC
# JtnwZXZCpimHCUcr5n8apIUP/JiW9lVUKx+A+sDyDivl1vupL0QVSucTDh3bNzga
# oSv27dZ8/DCCBsIwggSqoAMCAQICEAVEr/OUnQg5pr/bP1/lYRYwDQYJKoZIhvcN
# AQELBQAwYzELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTsw
# OQYDVQQDEzJEaWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVT
# dGFtcGluZyBDQTAeFw0yMzA3MTQwMDAwMDBaFw0zNDEwMTMyMzU5NTlaMEgxCzAJ
# BgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjEgMB4GA1UEAxMXRGln
# aUNlcnQgVGltZXN0YW1wIDIwMjMwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIK
# AoICAQCjU0WHHYOOW6w+VLMj4M+f1+XS512hDgncL0ijl3o7Kpxn3GIVWMGpkxGn
# zaqyat0QKYoeYmNp01icNXG/OpfrlFCPHCDqx5o7L5Zm42nnaf5bw9YrIBzBl5S0
# pVCB8s/LB6YwaMqDQtr8fwkklKSCGtpqutg7yl3eGRiF+0XqDWFsnf5xXsQGmjzw
# xS55DxtmUuPI1j5f2kPThPXQx/ZILV5FdZZ1/t0QoRuDwbjmUpW1R9d4KTlr4HhZ
# l+NEK0rVlc7vCBfqgmRN/yPjyobutKQhZHDr1eWg2mOzLukF7qr2JPUdvJscsrdf
# 3/Dudn0xmWVHVZ1KJC+sK5e+n+T9e3M+Mu5SNPvUu+vUoCw0m+PebmQZBzcBkQ8c
# tVHNqkxmg4hoYru8QRt4GW3k2Q/gWEH72LEs4VGvtK0VBhTqYggT02kefGRNnQ/f
# ztFejKqrUBXJs8q818Q7aESjpTtC/XN97t0K/3k0EH6mXApYTAA+hWl1x4Nk1nXN
# jxJ2VqUk+tfEayG66B80mC866msBsPf7Kobse1I4qZgJoXGybHGvPrhvltXhEBP+
# YUcKjP7wtsfVx95sJPC/QoLKoHE9nJKTBLRpcCcNT7e1NtHJXwikcKPsCvERLmTg
# yyIryvEoEyFJUX4GZtM7vvrrkTjYUQfKlLfiUKHzOtOKg8tAewIDAQABo4IBizCC
# AYcwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYI
# KwYBBQUHAwgwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1Ud
# IwQYMBaAFLoW2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSltu8T5+/N0GSh
# 1VapZTGj3tXjSTBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5n
# Q0EuY3JsMIGQBggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1w
# aW5nQ0EuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCBGtbeoKm1mBe8cI1PijxonNgl
# /8ss5M3qXSKS7IwiAqm4z4Co2efjxe0mgopxLxjdTrbebNfhYJwr7e09SI64a7p8
# Xb3CYTdoSXej65CqEtcnhfOOHpLawkA4n13IoC4leCWdKgV6hCmYtld5j9smViuw
# 86e9NwzYmHZPVrlSwradOKmB521BXIxp0bkrxMZ7z5z6eOKTGnaiaXXTUOREEr4g
# DZ6pRND45Ul3CFohxbTPmJUaVLq5vMFpGbrPFvKDNzRusEEm3d5al08zjdSNd311
# RaGlWCZqA0Xe2VC1UIyvVr1MxeFGxSjTredDAHDezJieGYkD6tSRN+9NUvPJYCHE
# Vkft2hFLjDLDiOZY4rbbPvlfsELWj+MXkdGqwFXjhr+sJyxB0JozSqg21Llyln6X
# eThIX8rC3D0y33XWNmdaifj2p8flTzU8AL2+nCpseQHc2kTmOt44OwdeOVj0fHMx
# VaCAEcsUDH6uvP6k63llqmjWIso765qCNVcoFstp8jKastLYOrixRoZruhf9xHds
# FWyuq69zOuhJRrfVf8y2OMDY7Bz1tqG4QyzfTkx9HmhwwHcK1ALgXGC7KP845VJa
# 1qwXIiNO9OzTF/tQa/8Hdx9xl0RBybhG02wyfFgvZ0dl5Rtztpn5aywGRu9BHvDw
# X+Db2a2QgESvgBBBijGCBbkwggW1AgEBMGMwTzELMAkGA1UEBhMCVVMxFjAUBgNV
# BAoTDUVudHJ1c3QsIEluYy4xKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWduaW5n
# IENBIC0gT1ZDUzICEAuI9Yyc+KzO3ajrpYzA/WQwDQYJYIZIAWUDBAIBBQCggYQw
# GAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGC
# NwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQx
# IgQg/d9yu2tvM1M0mhFP2bgVP4Dh31RP4kRO+fboQKN79XIwDQYJKoZIhvcNAQEB
# BQAEggGAmYqA16s1oEOubjt5NAxbfxEXTQqYlDudKrGkv1ZqQbzSCXxTNO2lWcBJ
# P1RREup1sVud2K2EX0x/Nc04MpCByWQz4xFWCX2ujLqTzTUE8aSJkpqIZBJKWzcs
# PQkrzVgPtRV7qCIQHJImzVmLN3P0Hn/GlC+vyxYhcYqkgF1UKsmUjZt17SMsrQ5m
# x6UyQgWa7OOR9BAEsrXLhJTLgY6XVJI09xunpfcV4FQ8qI3zy16isNvWwGeRmOHU
# 8tVMe0ZpNTI+Cpze+jMof2o125+XobGE70WsMKlYTkeXTIbuGhlV7MHrY5YqM5M7
# 4bXigpr/5QgQc9i7Hn7z1CLyk+yfkUdleJKolANun5TRoYrISYIyuSYmUGYDDx6r
# nzWywXOX0bZ2F1GPVnBhHjYGdKZh9afeQuDd4/a57tXnio+xdF+uD3sjJM8li1qp
# 2ixViWH6p46T1awQnS97Hnvzxw8yVDu0DV7CVuhlrRAAk2KGOB95s7wXI5QrNEkx
# r0qUL6PZoYIDIDCCAxwGCSqGSIb3DQEJBjGCAw0wggMJAgEBMHcwYzELMAkGA1UE
# BhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdpQ2Vy
# dCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBDQQIQBUSv
# 85SdCDmmv9s/X+VhFjANBglghkgBZQMEAgEFAKBpMBgGCSqGSIb3DQEJAzELBgkq
# hkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTIzMDgxNDE1MTYzMVowLwYJKoZIhvcN
# AQkEMSIEIOss8xPNmvDT2ScIvtmJVhHkJd5n0pEgC9mYQspfDmZLMA0GCSqGSIb3
# DQEBAQUABIICACnOs4UcxJo4I8rlUEsCY/MXHPFhJuTxU4YyGasYEw38jeheZHvy
# vmNJaXXY2Rh9MKJHvKWjHTm+IGxZ4vTyhTQ4w62gFeQP2rdZdZQ28HgXUXLiL2lW
# yNnwIH6sEx4mur2cmcXHfG6F1UsDsgKs2nZt7AIyMqQ92rAmoh3JqY5GGN9e3Y8J
# pFduI2Ky2YJ6tTJZIbE1/CObAs/Nx00P0mGWffEq3amkjhBRP/lgsgiC9BEdiYZC
# 84gYYKyezLIZXMfEgcGXDaf4Ezyqbe98ytxJVmasSUKart0ex6sQp0MFKMDEvJmQ
# OiILppJG9mYen1ChYvSUnLmSFZacLslwA1v/+cIRouRw7m+BUJjUwXPFiLFovFBN
# ev2nCjQovUPLFDPzPFTnv6qrQH2+wDhJp25zlotmi4UP3cQXd0E55xphQMr5B/3x
# fPdDIsOMgTgx1hiJBNBJHPHPevYOr7ZqvmNdhjAnHGauXJ2asHR1nwPM5fjRMiIk
# +FB4WVbPgoechmTHeTs/i5gTzATzj88AfmI6/Gg+GQ1loJ3LO5Nb1tfLJi6JM0MV
# pdI1lfCKSn26FcBA1I790CvLTgoNzJm6DYtQ/TPYtZIHl6LTNaMwOqhSt36rZb4e
# uDNyE7hH28yuFSOGC+xVfe2LB+Sa6OAg6yug2PuqY4R34rX8khi+ITSP
# SIG # End signature block
