# ----------------------------------------------------------------------------------------------------------
# FILE         : README.txt
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : README for VxRail STIG Hardening package
# DISCLAIMER   : Please refer to the VxRail STIG Hardening Guide for more details
# ----------------------------------------------------------------------------------------------------------

CHANGE LOG - VxRail STIG Hardening v2.2.000
===========================================
Address the following STIGs:
- Application Security Development STIG V5, Release 2 (published 21 October 2022)
- Network Device Management SRG V4, Release 3 (published 17 May 2023)
- SUSE Linux Enterprise Server (SLES) 15 STIG V1, Release 10 (published 24 April 2023)
- From the VMware vSphere 7.0 vCenter Appliance STIG V1, Release 1 (published 07 Mar 2023)
   - VMware vSphere 7.0 vCenter Appliance RhttpProxy STIG
   - VMware vSphere 7.0 vCenter Appliance Secure Token Service (STS) STIG
   - VMware vSphere 7.0 vCenter Appliance User Interface (UI) STIG
   - VMware vSphere 7.0 vCenter Appliance ESX Agent Manager (EAM) STIG
   - VMware vSphere 7.0 vCenter Appliance Lookup Service STIG
   - VMware vSphere 7.0 vCenter Appliance Performance Charts (Perfcharts) STIG
   - VMware vSphere 7.0 vCenter Appliance Photon Operating System (OS) STIG
   - VMware vSphere 7.0 vCenter Appliance PostgreSQL STIG
   - VMware vSphere 7.0 vCenter Appliance Management Interface (VAMI) STIG
New Functionalities:
- VxRail Manager Health Monitoring after restart
- Copy script file functionality from Workstation to VMs
- Sleep fucntionality enhanced on the PowerCLI screen with progress bar and countdown

CHANGE LOG - VxRail STIG Hardening v2.1.001
===========================================
This release patches the following issues that occurred in 2.1.000:

Issue:      VxRail LCM bundle upload and extraction failure.
Rule:       STIG ID TCAT-AS-000540, Vul ID V-222956
Rule Title: Autodeploy must be disabled.
Cause:      After uploading the LCM bundle, the autoDeploy is required for the extraction process. With this 
            parameter set to false, the extraction failure results in the LCM process being unable to continue.
Workaround: This rule has been disabled. Further information is provided in the VxRail STIG Hardening 2.1.001 guide.

Issue:      VxRail host iDRAC Service Module (iSM) service interruptions.
Rule:       STIG ID ESXI-70-000097, Vul ID V-256448
Rule Title: The ESXi Common Information Model (CIM) service must be disabled.
Cause:      The iDRAC Service Module (iSM) requires the CIM process to be enabled and running.
Workaround: This rule has been disabled. Further information is provided in the VxRail STIG Hardening 2.1.001 guide.
 

CHANGE LOG - VxRail STIG Hardening v2.1.000
===========================================
Address the following STIGs:
- PostgreSQL 9.x STIG V2, Release 3 (published 27 July 2022)
- Apache Tomcat Application Server 9 STIG V2, Release 4 (published 24 January 2022)
- SUSE Linux Enterprise Server (SLES) 15 STIG V1, Release 7 (published 27 July 2022)
- From the VMware vSphere 7.0 STIG V1, Release 1 (published 7 Mar 2023, updated 15 Mar 2023)
  - VMware vSphere 7.0 ESXi STIG
  - VMware vSphere 7.0 vCenter STIG
  - VMware vSphere 7.0 Virtual Machine STIG
New Features
- Choose ESXi Lockdown Level (Normal, Strict or Disable)
- vCenter and VxRail Manager Virtual Machines Startup is now fully automated
- The bash script that hardens the VxRail Manager now places a marker in the log files (web.log and short_term.log) when starting and finishing the script

CHANGE LOG - VxRail STIG Hardening v2.0.001
============================================
Address the following:
- VMware KB 88055, SSH access may fail post upgrade to ESXi 7.0 Update 3d
- Allow VMware ESXi DoD STIG VIB installation only for VxRail 4.x systems
- VMware's dependency on specified PowerCLI version and modules to apply STIG
- Automate (without using the VMWare VIB) - ESXI-70-000008, ESXI-70-000009, ESXI-70-000010, ESXI-70-000012, ESXI-70-000013, ESXI-70-000014, ESXI-70-000015, 
  ESXI-70-000016, ESXI-70-000020, ESXI-70-000021, ESXI-70-000022, ESXI-70-000023, ESXI-70-000025, ESXI-70-000026, ESXI-70-000027, ESXI-70-000033, ESXI-70-000082

CHANGE LOG - VxRail STIG Hardening v2.0.000
===========================================
Address the following updated STIGs:
- Application Security Development STIG V5, Release 1
- Application Server SRG V3, Release 1
- SUSE Linux Enterprise Server (SLES) 12 STIG V2, Release 1 (published 22 January 2021, updated 27 April 2021)
- SUSE Linux Enterprise Server (SLES) 15 STIG V1, Release 2 (published 09 January 2021, updated 27 April 2021)
- From the VMware vSphere 6.7 STIG V1, Release 1 (published 30 March 2021, updated 22 April 2021):
  - VMware vSphere 6.7 ESXi STIG
  - VMware vSphere 6.7 Virtual Machine STIG
- From the VMware vSphere 7.0 STIG, Draft (not published yet by DISA)
  - VMware vSphere 7.0 ESXi STIG
  - VMware vSphere 7.0 vCenter STIG
  - VMware vSphere 7.0 Virtual Machine STIG

Updated script VxRail_STIG_VxRManager.ps1, which now calls the VMware provided PowerShell scripts to remediate the ESXi, vCenter and Virtual Machine components. These script are taken from VMware's git repo dod-compliance-and-automation (commit 4c7b20841c300c6d5e89781c4e5462cb1b67d042) and have small customizations for integration in this VxRail package.

KNOWN ISSUES
============
Issue: vSphere ESXi rule failure.
Rule ID: STIG-ID ESXI-67-000004/ESXI-70-000004 (both Vul ID: V-239261)
Rule Title: Remote logging for ESXi hosts must be configured.
Cause: 
This rule fails, because it compares the current setting of advanced parameter "Syslog.global.logHost" on the ESXi node to the provided syslog server value "syslog". Since the values are different, it will try and update the advanced parameter with the provided value.
The provided value "syslog" is not a valid value for the syslog advanced parameter in ESXi. It expects a UDP or TCP IP address specification.
The resolution of this issue is dependent on a fix in a future VxRail System Software release. Once that release is available, this issue will no longer occur for customers running the fix version.
Workaround: 
If this issue occurs, then execute the Fix-On-Site procedure for this rule, which is provided in the VxRail STIG Hardening 2.0.001 guide.

SHA256 FILE HASHES
==================
The Get-FileHash PowerShell cmdlet can be used to get the SHA256 hash of the package.
This hash can be used to validate the integrity of the files contained in this zip archive.

For example, to obtain the hash at the PowerShell command prompt, run the command as follows:
PS C:\path_to_package> Get-FileHash -Algorithm sha256 VxRail_STIG_Hardening_Package_2.2.000.zip

Algorithm    Hash                                                                   Path
---------    ----                                                                   ----
SHA256       4D8CC8D7C4EE4628E98CD813743B5787516283A23D9DA9130BF0FB62EAA634C8       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\VxRail_STIG.ps1
SHA256       E492992BBDF665688410C3A227FA5396AC113AF46967FD0E9390F7F0B01E18D5       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\VxRail_STIG_VxRManager.sh
SHA256       5A58027BA8B63AB6651AE866D325CF57FB678A5AE85C117EF38885E27909B17A       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\wheelhouse.tar.gz

SHA256       EDD1E48492B961FA2E162FF8EBB2C36C77202B77132529CFE36DDBCA384CDA8C       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\py\applyElementInXMLfile.py
SHA256       EE4A951670BE845C4DA904415DC75B1F3390560C409BDCB437F04CA14CAF6BB4       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\py\applyJvmOpts.py
SHA256       9E6307BCAC900AD9A1138DAC4952005999C865A0740471E0B394D499388513FC       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\py\MonitorVxRailClusterHealthUntilOK.py
SHA256       220B4D4545531A2BD312C75BCC4922CC259069E045C92B65CA8FF20AF67164EA       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\py\removeElementInXMLfile.py
SHA256       9F235165F652BED3F1AD3ADCD3FB98A7D7BCFBA40A1C14B19E6F27EE9F16945A       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\py\setCharacterEncodingFilter.py
SHA256       B78E04705C1030F2F68AF20BD67D9EDF5109F067DAE568B45CD9F7BF7C77E99D       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\py\setKeyOfElementAttributeInXMLfile.py
SHA256       82622134360EF22CAAD8D2A86E4D0753BB83B701D4D12FF61CDC911801DEAC1C       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\py\setSecureFlagForCookiesLookupSvc.py
SHA256       E0906978345830735ABF91A18993CB618CA2E5B5262448DD31C1BFCCAF39841A       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\py\VxRailSTIGLogging.py
SHA256       7C45BA4E36EB47780DE9E9A4D563A21D51087FD1F30BC041011022F55EC3B45C       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\py\vxsec759.py

SHA256       7889246DC79EEC923BE32B8E6CDECB9D40ACF3953DB3EBB14FF17B9CA96D8928       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\vmware-stig\vsphere\6.7\vsphere\powercli\VMware_vSphere_6.7_STIG_ESXi_Remediation-VxRail_STIG.ps1

SHA256       363930E89CD4CB0382567515DC16B4169A8604B21D256783CC2438D69AFCAE29       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\vmware-stig\vsphere\7.0\vsphere\powercli\VMware_vSphere_7.0_STIG_ESXi_Remediation-VxRail_STIG.ps1
SHA256       6544A7E88D225C1AB9696F57415E5FF8C5386FC0518901E1385E89ADB775CFCF       D:\STIG\VxRail_STIG_Hardening_Package_2.2.000\vmware-stig\vsphere\7.0\vsphere\powercli\VMware_vSphere_7.0_STIG_vCenter_Remediation-VxRail_STIG.ps1
