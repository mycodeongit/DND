#!/bin/bash
# ----------------------------------------------------------------------------------------------------------
# FILE         : VxRail_STIG_VxRManager.sh
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : configuration script for SUSE based VxRail Manager system
# DISCLAIMER   : Please refer to the VxRail STIG Hardening Guide for details on what is included
# ----------------------------------------------------------------------------------------------------------
## Change log of VxRail_STIG_VxRManager.sh can be found in VxRail_STIG_VxRManager.modhist.txt

VxRailPackageVersion="2.2.000"
scriptName="VxRail_STIG_VxRManager.sh"

# Check params
while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help)
      echo "$scriptname - STIG harden the VxRail Manager OS configuration"
      echo " "
      echo "$scriptname [options]"
      echo " "
      echo "options:"
      echo "-d, --debug        enable debug (more verbose) output"
      echo "-h, --help         show brief help"
      echo "-v, --version      show package version"
      exit 0
      ;;
    -d|--debug)
      export STIG_LOG_LEVEL='DEBUG'
      shift
      ;;
    -v|--version)
      echo "$scriptname - version $VxRailPackageVersion"
      exit 0
      ;;
    *)
      echo "Error: Unrecognized option specified ($1). Exiting."
      exit 1
      ;;
  esac
done

#########################################################################################
# INIT
#########################################################################################
# console output color codes
red="\033[1;31m"
green="\033[1;32m"
yellow="\033[1;33m"
normal="\033[0;37m"

echo -e "${green}###################################################${normal}"
echo -e "${green}# VxRail STIG Package $VxRailPackageVersion - Hardening VxRM OS - Start #${normal}"
echo -e "${green}###################################################${normal}"

#######################
# Start logging setup #
#######################
# Log entry format:
# "Date and Time"       "Log Level"     "Vulnerability ID(s)"   "Result"        "Log Message"
#
# Setup the script/logfile metadata
# Configure the logfile in same directory as this script
SCRIPT_DIR=$(dirname $0)                   # e.g.: .
SCRIPT_NAME=$(basename $0)                 # e.g.: VxRail_STIG_VxRManager.sh
SCRIPT_BASE="${SCRIPT_NAME%.*}"            # e.g.: VxRail_STIG_VxRManager
SCRIPT_LOGFILE=${SCRIPT_BASE}.log          # e.g.: VxRail_STIG_VxRManager.log
SCRIPT_LOG=$SCRIPT_DIR/${SCRIPT_BASE}.log  # e.g.: ./VxRail_STIG_VxRManager.log
PY_DIR=${SCRIPT_DIR}/py                    # python script location

# log_title_... is passed to the message logging function to indicate log level to be shown
log_title_warn="WARN"
log_title_error="ERROR"
log_title_info="INFO"
log_title_debug="DEBUG"

# log_result_... is used in message logging function
log_result_fail="FAIL"
log_result_success="SUCCESS"
log_result_null="--"


# Function to allow pausing and displaying information, only when in debug mode.
# Enable debug mode, by setting a variable at the Linux command-line before starting the script:
#           export STIG_LOG_LEVEL="DEBUG"
# Input: any parameters that are passed-in will be displayed
# Output: display on screen
function debugpause() {
    if [ "$STIG_LOG_LEVEL" == "$log_title_debug" ]
    then
        read -p "...Debug pause... (press Enter to continue): $*"
    fi
}

# Function to display the current function name and any other information, only when in debug mode.
# Input: - function name
#        - any other parameters
# Output: display on screen
function print_func_name () {
    if [ "$STIG_LOG_LEVEL" == "$log_title_debug" ]
    then
      echo "...Debug... $*"
    fi
}


# --------------------------------------------------------------------------------
# Log information in a csv style format
# Input:
# 1. log_title - just pass in the predefined variable for the required log title
# 2. vuln_id   - if not defined yet pass in e.g. '--'
# 3. result    - result of the test (if n.a. then a value <= -2)
# 4. log_message
# Output: --
# --------------------------------------------------------------------------------
function LOG(){
    date_and_time=$(date +"%Y-%m-%d %H:%M:%S")
    local log_title="$1" ; shift # 1st param
    local vuln_id="$1"   ; shift # 2nd param
    local result="$1"    ; shift # 3rd param
    local log_message="$@" # remaining param

    # Check debug level setting (STIG_LOG_LEVEL is taken from the shell environment)
    if [ "$STIG_LOG_LEVEL" != "$log_title_debug" ]
    then
       # Is not set to debug so do not log if it is a debug level log message
       if [ $log_title == $log_title_debug ]
       then 
          return
       fi
    fi

    if [ $result -ge  1 ]; then log_result="$log_result_fail($result)"; fi
    if [ $result -eq  0 ]; then log_result="$log_result_success"      ; fi
    if [ $result -le -1 ]; then log_result="$log_result_null"         ; fi

    vidPadded=$(printf '%-13s' "$vuln_id")
    llPadded=$(printf '%-9s' "$log_title")
    resPadded=$(printf '%-10s' "$log_result")
    echo -e "$date_and_time\t$llPadded\t$vidPadded\t$resPadded\t$log_message" >> $SCRIPT_LOG
}

# ensure logfile exists and add a header if logfile is new
touch $SCRIPT_LOG
if [[ ! -s $SCRIPT_LOG ]]; then
   # empty log file; add header
   echo -e "Date and Time\t\tLog Level\tVulnerability ID(s)\tResult\tLog Message" >> $SCRIPT_LOG
fi

#####################
# End logging setup #
#####################


#####################
# Declare constants #
#####################
aide_conf_file="/etc/aide.conf"
aide_db_file="/var/lib/aide/aide.db"
aide_cron_weekly="/etc/cron.weekly/aide"
aliases="/etc/aliases"
audisp_remote_conf="/etc/audisp/audisp-remote.conf"
audisp_remote_plugin_conf="/etc/audisp/plugins.d/au-remote.conf"
audispd_zos_remote="/etc/audisp/plugins.d/audispd-zos-remote.conf"
auditd_conf="/etc/audit/auditd.conf"
audit_rules_file="/etc/audit/rules.d/audit.rules"
autologout_path="/etc/profile.d/autologout.sh"
banner_path="/etc/dconf/db/local.d/01-banner-message"
blacklist_conf_file="/etc/modprobe.d/50-blacklist.conf"
common_auth_file="/etc/pam.d/common-auth"
common_account_file="/etc/pam.d/common-account"
common_pwd_file="/etc/pam.d/common-password"
cron_stig_dir="/root/stig_cron"
crontab_file="/etc/crontab"
crontabs_dir="/var/spool/cron/tabs"
cron_root="/var/spool/cron/tabs/root"
etc_issue_file="/etc/issue"
excludeVxRailDirectory="/usr/lib/vmware-marvin"
gdm_banner="/etc/gdm/banner"
gdm_custom="/etc/gdm/custom.conf"
gnome_file="/etc/gdm/Xsession"
group_file="/etc/group"
limits_conf="/etc/security/limits.conf"
login_defs="/etc/login.defs"
motd_path="/etc/motd"
opasswd_file="/etc/security/opasswd"
pam_login_file="/etc/pam.d/login"
pam_pkcs11_conf="/etc/pam_pkcs11/pam_pkcs11.conf"
pam_sudo_file="/etc/pam.d/sudo"
password_auth="/etc/pam.d/password-auth"
password_file="/etc/passwd"
permissions_local="/etc/permissions.local"
pgsql_audit_cap_threshold=75
postgresql_pgdata="/var/lib/pgsql/data"
postgresql_conf="/var/lib/pgsql/data/postgresql.conf"
postgresql_log_dir="/var/lib/pgsql/data/log"
rabbitmqctl="/usr/sbin/rabbitmqctl"
rsyslog_conf="/etc/rsyslog.conf"
short_term_log="/var/log/microservice_log/short.term.log"
sshd_config_file="/etc/ssh/sshd_config"
ssl_keystore_file="server.pfx"
sssd_conf_file="/etc/sssd/sssd.conf"
stig_info="/mystic/stig/info"
subseqbootfile="/opt/vmware/etc/isv/subsequentboot"
sudoers_file="/etc/sudoers"
sudoersd_dir="/etc/sudoers.d"
susefw_file="/etc/sysconfig/SuSEfirewall2"
svc_rabbitmq="/usr/sbin/service rabbitmq-server"
svc_vmwaremarvin="/usr/sbin/service vmware-marvin"
svc_runjars="/usr/sbin/service runjars"
sysctl_99stig_conf="/etc/sysctl.d/99-stig.conf"
sysctl_conf="/etc/sysctl.conf"
system_auth="/etc/pam.d/system-auth"
systemd_conf="/etc/systemd/system.conf"
web_log="/var/log/mystic/web.log"
zypp_conf="/etc/zypp/zypp.conf"
fake_zypp_repo="/etc/zypp/NonExistentZyppRepo"
MonitorVxRailClusterHealthInitialSleep="30s"
VxMIP=$(ifconfig eth0 | grep 'inet ' | sed 's/  */ /g' | cut -d' ' -f3)

# Tomcat variables
tc_catalina_home=/opt/tomcat              # Tomcat default install path
tc_marvin_dir=/usr/lib/vmware-marvin      # Tomcat marvin dir
tc_catalina_base=${tc_marvin_dir}/marvind # Tomcat instance location
tc_context_file=$tc_catalina_base/conf/context.xml                              # context file
tc_webapp_lcm_context_file=$tc_catalina_base/webapps/lcm/META-INF/context.xml   # context file
tc_localhost_lcm_context_file=$tc_catalina_base/conf/Catalina/localhost/lcm.xml # context file
tc_props_file=$tc_catalina_base/conf/catalina.properties
tc_server_file=$tc_catalina_base/conf/server.xml
tc_svr_props_file=org/apache/catalina/util/ServerInfo.properties
tc_setenv_file=$tc_catalina_base/bin/setenv.sh
tc_web_file=$tc_catalina_base/conf/web.xml
tc_web_namespace='http://java.sun.com/xml/ns/javaee'
tc_service_file=/usr/lib/systemd/system/vmware-marvin.service
tc_jars_dir=/usr/share/java/tomcat
tc_catalina_jar=$tc_jars_dir/catalina.jar

# Python subscripts
# - a function module can be called for different rules
# - a rule module is only called for one particular rule
VxRailSTIGLoggingFile=$PY_DIR/VxRailSTIGLogging.py # logging module
applyElementInXMLfile=$PY_DIR/applyElementInXMLfile.py                         # function module
applyJvmOpts=$PY_DIR/applyJvmOpts.py                                           # function module
removeElementInXMLfile=$PY_DIR/removeElementInXMLfile.py                       # function module
setKeyOfElementAttributeInXMLfile=$PY_DIR/setKeyOfElementAttributeInXMLfile.py # function module
vxsec759=$PY_DIR/vxsec759.py                                                   # rule module
MonitorVxRailClusterHealthUntilOK=$PY_DIR/MonitorVxRailClusterHealthUntilOK.py               # function module

########################
# Initialize variables #
########################
restartMarvinFlag=0  # At end, this flag is checked to see if a restart of VMware Marvin service is required

# Return code from get_vuln_id_optval function:
VID_MAP_OK=0 # vuln_id found in maptable
VID_MAP_NA=1 # no vuln_id found in maptable

# --------------------------------------------------------------------------------
# Set the vulnerability mapping
# This is set using normal string assignment.
# Alternatively, it can also be done as follows:
#   # vxsecmap=`cat <<EOF
#   a b c
#   :
#   EOF`
#
# This mapping contains the following columns:
# > VxRail vulnerability id
# > OS map, consisting of:
#   - OS [name + major version] column
#   - optional extra value column, can be used for simple (value) differences in remediation
#
# If another OS becomes available, simply add an additional OS map (i.e. 2 columns) to the table.
# The rest of the script needs no adjustment.
# The OS column title names are used to map the OS, so always ensure these are accurate.
#
vxsecmapsep="|"
vxsecmap="# VxRail vulnerability mapping
# VXRAIL-ID | SLES15 | 15-optval | SLES12 | 12-optval
# --------- | ------ | --------- | ------ | ---------
# ------------------------------------
# SUSE Linux STIG
# ------------------------------------
VXSEC001 | V-234801 |  | V-222386 |
VXSEC002 | V-234800 |  | V-217101 |
VXSEC003 | V-234802 |  | V-217102 |
VXSEC004 | V-234806 |  | V-217103 |
VXSEC005 | V-234803 |  | V-217104 |
VXSEC006 | V-234808 |  | V-217105 |
VXSEC007 | V-234809 |  | V-217106 |
VXSEC008 | V-234810 |  | V-217107 |
VXSEC009 | V-234811 |  | V-217108 |
VXSEC010 | V-234812 |  | V-217109 |
VXSEC011 | V-234813 |  | V-217110 |
VXSEC012 | V-234814 |  | V-217111 |
VXSEC013 | V-234853 |  | V-217112 |
VXSEC014 | V-234868 |  | V-217113 |
VXSEC015 | V-234867 |  | V-217114 |
VXSEC016 | V-234982 |  | V-217116 |
VXSEC017 | V-234882 |  | V-217117 |
VXSEC018 | V-234883 |  | V-217118 |
VXSEC019 | V-234884 |  | V-217119 |
VXSEC020 | V-234896 |  | V-217120 |
VXSEC021 | V-234885 |  | V-217121 |
VXSEC022 | V-234825 |  | V-217122 |
VXSEC024 | V-234887 |  | V-217123 |
VXSEC025 | V-234886 |  | V-217124 |
VXSEC026 | V-234888 |  | V-217126 |
VXSEC027 | V-234895 |  | V-217127 |
VXSEC028 | V-234889 |  | V-217128 |
VXSEC029 | V-234890 |  | V-217129 |
VXSEC030 | V-234891 |  | V-217130 |
VXSEC031 | V-234892 |  | V-217131 |
VXSEC032 | V-234893 |  | V-217132 |
VXSEC033 | V-234894 |  | V-217133 |
VXSEC034 | V-234897 |  | V-217134 |
VXSEC035 | V-234872 |  | V-217135 |
VXSEC036 | V-234871 |  | V-217136 |
VXSEC037 | V-234866 |  | V-217137 |
VXSEC038 | V-234983 |  | V-217138 |
VXSEC040 | V-235031 |  | V-217139 |
VXSEC041 | V-234873 |  | V-217140 |
VXSEC042 | V-234984 |  | V-217141 |
VXSEC043 | V-234985 |  | V-217142 |
VXSEC044 | V-234859 |  | V-217143 |
VXSEC045 | V-234819 |  | V-217144 |
VXSEC046 | V-234820 |  | V-217145 |
VXSEC047 | V-234831 |  | V-217146 |
VXSEC048 | V-234828 |  | V-217147 |
VXSEC049 | V-234851 |  | V-217148 |
VXSEC050 | V-234864 |  | V-217149 |
VXSEC051 | V-234986 |  | V-217150 |
VXSEC052 | V-234987 |  | V-217151 |
VXSEC053 | V-234962 |  | V-217152 |
VXSEC054 | V-234852 |  | V-217153 |
VXSEC055 | V-234863 |  | V-217154 |
VXSEC056 | V-234856 |  | V-217155 |
VXSEC057 | V-234823 |  | V-217156 |
VXSEC058 | V-234848 |  | V-217158 |
VXSEC059 | V-234988 |  | V-217159 |
VXSEC060 | V-235030 |  | V-217161 |
VXSEC061 | V-234874 |  | V-217162 |
VXSEC062 | V-234822 |  | V-217163 |
VXSEC063 | V-234876 |  | V-217164 |
VXSEC064 | V-234857 |  | V-217166 |
VXSEC065 | V-234858 |  | V-217167 |
VXSEC066 | V-235028 |  | V-217168 |
VXSEC067 | V-235029 |  | V-217169 |
VXSEC068 | V-234991 |  | V-217170 |
VXSEC069 | V-234880 |  | V-217171 |
VXSEC070 | V-234992 |  | V-217172 |
VXSEC071 | V-234993 |  | V-217173 |
VXSEC072 | V-234994 |  | V-217174 |
VXSEC073 | V-234995 |  | V-217175 |
VXSEC074 | V-234996 |  | V-217176 |
VXSEC075 | V-234997 |  | V-217177 |
VXSEC076 | V-234998 |  | V-217178 |
VXSEC077 | V-234999 |  | V-217179 |
VXSEC078 | V-235000 |  | V-217180 |
VXSEC079 | V-235001 |  | V-217181 |
VXSEC080 | V-235002 |  | V-217182 |
VXSEC081 | V-235003 |  | V-217183 |
VXSEC082 | V-235004 |  | V-217184 |
VXSEC083 | V-235005 |  | V-217185 |
VXSEC084 | V-234980 |  | V-217186 |
VXSEC086 | V-234833 |  | V-217188 |
VXSEC087 | V-235006 |  | V-217189 |
VXSEC088 | V-234964 |  | V-217190 |
VXSEC089 | V-234904 |  | V-217191 |
VXSEC090 | V-234965 |  | V-217192 |
VXSEC091 | V-234969 |  | V-217193 |
VXSEC092 | V-234956 |  | V-217194 |
VXSEC093 | V-234957 |  | V-217195 |
VXSEC094 | V-234958 |  | V-217196 |
VXSEC095 | V-234966 |  | V-217197 |
VXSEC096 | V-234967 |  | V-217198 |
VXSEC097 | V-234968 |  | V-217199 |
VXSEC098 | V-234978 |  | V-217200 |
VXSEC099 | V-234979 |  | V-217201 |
VXSEC100 | V-234959 |  | V-217202 |
VXSEC101 | V-234961 |  | V-217203 |
VXSEC102 | V-234899 |  | V-217205 |
VXSEC103 | V-234900 |  | V-217206 |
VXSEC104 | V-234901 |  | V-217207 |
VXSEC105 | V-234902 |  | V-217208 |
VXSEC106 | V-234963 |  | V-217209 |
VXSEC107 | V-234954 |  | V-217210 |
VXSEC108 | V-234955 |  | V-217211 |
VXSEC109 | V-234933 |  | V-217212 |
VXSEC110 | V-234934 |  | V-217213 |
VXSEC111 | V-234935 |  | V-217214 |
VXSEC112 | V-234936 |  | V-217215 |
VXSEC113 | V-234905 |  | V-217216 |
VXSEC114 | V-234940 |  | V-217217 |
VXSEC115 | V-234921 |  | V-217218 |
VXSEC116 | V-234922 |  | V-217219 |
VXSEC117 | V-234918 |  | V-217220 |
VXSEC118 | V-234919 |  | V-217221 |
VXSEC119 | V-234920 |  | V-217222 |
VXSEC120 | V-234924 |  | V-217223 |
VXSEC121 | V-234925 |  | V-217224 |
VXSEC122 | V-234926 |  | V-217225 |
VXSEC123 | V-234927 |  | V-217226 |
VXSEC125 | V-234928 |  | V-217227 |
VXSEC126 | V-234929 |  | V-217228 |
VXSEC127 | V-234930 |  | V-217229 |
VXSEC128 | V-234914 |  | V-217230 |
VXSEC129 | V-234960 |  | V-217231 |
VXSEC130 | V-234931 |  | V-217232 |
VXSEC131 | V-234915 |  | V-217233 |
VXSEC132 | V-234916 |  | V-217234 |
VXSEC133 | V-234917 |  | V-217235 |
VXSEC134 | V-234906 |  | V-217236 |
VXSEC135 | V-234907 |  | V-217237 |
VXSEC136 | V-234908 |  | V-217238 |
VXSEC137 | V-234909 |  | V-217239 |
VXSEC138 | V-234903 |  | V-217240 |
VXSEC139 | V-234941 |  | V-217241 |
VXSEC140 | V-234942 |  | V-217242 |
VXSEC141 | V-234943 |  | V-217243 |
VXSEC142 | V-234944 |  | V-217244 |
VXSEC143 | V-234945 |  | V-217245 |
VXSEC144 | V-234946 |  | V-217246 |
VXSEC145 | V-234947 |  | V-217247 |
VXSEC146 | V-234948 |  | V-217248 |
VXSEC147 | V-234910 |  | V-217249 |
VXSEC148 | V-234911 |  | V-217250 |
VXSEC149 | V-234949 |  | V-217251 |
VXSEC150 | V-234912 |  | V-217252 |
VXSEC151 | V-234950 |  | V-217253 |
VXSEC152 | V-234951 |  | V-217254 |
VXSEC153 | V-234952 |  | V-217255 |
VXSEC154 | V-234953 |  | V-217256 |
VXSEC155 |          |  | V-217257 |
VXSEC156 | V-234818 |  | V-217258 |
VXSEC158 | V-234807 |  | V-217260 |
VXSEC159 | V-234821 |  | V-217261 |
VXSEC160 | V-235009 |  | V-217276 |
VXSEC161 | V-234805 |  | V-217263 |
VXSEC162 | V-234860 |  | V-217264 |
VXSEC163 | V-234815 |  | V-217265 |
VXSEC164 | V-234881 |  | V-217266 |
VXSEC165 | V-234870 |  | V-217267 |
VXSEC166 | V-235032 |  | V-217268,V-217269 |
VXSEC167 | V-234816 |  | V-217270 |
VXSEC168 | V-234826 |  | V-217271 |
VXSEC169 | V-234827,V-202074 |  | V-217272 |
VXSEC170 | V-235007 |  | V-217274 |
VXSEC171 | V-235008 |  | V-217275 |
VXSEC172 |          |  | V-217262 |
VXSEC173 | V-235010 |  | V-217277 |
VXSEC174 |  |  | V-217278 |
VXSEC175 |  |  | V-217279 |
VXSEC176 |          |  | V-233308 |
VXSEC177 | V-234849 | /etc/chrony.conf | V-217281 | /etc/ntp.conf
VXSEC178 | V-234850 |  | V-217282 |
VXSEC179 | V-234861 |  | V-217283 |
VXSEC180 | V-234862 |  | V-217284 |
VXSEC181 | V-234865 |  | V-217285 |
VXSEC182 | V-234829 |  | V-217286 |
VXSEC183 | V-235014 |  | V-217287 |
VXSEC184 | V-235016 |  | V-217289 |
VXSEC185 |          |  | V-217290 |
VXSEC186 | V-235018 |  | V-217291 |
VXSEC187 | V-235019 |  | V-217292 |
VXSEC188 | V-235022 |  | V-217294 |
VXSEC189 | V-235023 |  | V-217295 |
VXSEC190 |          |  | V-217296 |
VXSEC191 | V-235027 |  | V-217297 |
VXSEC192 | V-234847 |  | V-217298 |
VXSEC193 | V-234854 |  | V-217299 |
VXSEC194 | V-234855 |  | V-217300 |
VXSEC195 | V-234869 |  | V-217301 |
VXSEC196 | V-234817 |  | V-217302 |
VXSEC197 | V-234898 |  | V-217125 |
VXSEC198 | V-234830 | 0 | V-217273 | 1
VXSEC199 | V-235015 |  | V-217288 |
VXSEC200 | V-235021 |  | V-217293 |
VXSEC201 |          |  | V-222385 |
VXSEC202 | V-234981 |  | V-217204 |
VXSEC203 | V-234989 |  | V-217160 |
VXSEC205 | V-235013 |  | V-217280 |
VXSEC207 | V-234804 |  | V-237619 |
VXSEC208 | V-234824 |  |          |
VXSEC209 | V-234832 |  |          |
VXSEC210 | V-234834 |  | V-237607 |
VXSEC211 | V-234835 |  | V-237608 |
VXSEC212 | V-234836 |  | V-237609 |
VXSEC213 | V-234837 |  | V-237610 |
VXSEC214 | V-234838 |  | V-237611 |
VXSEC215 | V-234839 |  | V-237612 |
VXSEC216 | V-234840 |  | V-237613 |
VXSEC217 | V-234841 |  | V-237614 |
VXSEC218 | V-234842 |  | V-237615 |
VXSEC219 | V-234843 |  | V-237616 |
VXSEC220 | V-234844 |  | V-237617 |
VXSEC221 | V-234845 |  | V-237618 |
VXSEC222 | V-234846 |  |          |
VXSEC223 | V-234875 |  | V-237606 |
VXSEC224 | V-234877 |  | V-237603 |
VXSEC225 | V-234878 |  | V-237605 |
VXSEC226 | V-234879 |  | V-237604 |
VXSEC227 | V-234913 |  |          |
VXSEC228 | V-234923 |  |          |
VXSEC229 | V-234932 |  |          |
VXSEC230 | V-234937 |  |          |
VXSEC231 | V-234938 |  |          |
VXSEC232 | V-234939 |  |          |
VXSEC234 | V-234970 |  |          |
VXSEC235 | V-234971 |  |          |
VXSEC236 | V-234972 |  |          |
VXSEC237 | V-234973 |  |          |
VXSEC238 | V-234974 |  |          |
VXSEC239 | V-234975 |  |          |
VXSEC240 | V-234976 |  |          |
VXSEC241 | V-234977 |  |          |
VXSEC242 | V-235017 |  | V-237620 |
VXSEC243 | V-234990 |  |          |
VXSEC246 | V-235024 |  |          |
VXSEC249 | V-235026 |  | V-237623 |
VXSEC250 | V-235025 |  | V-237622 |
VXSEC251 | V-235020 |  | V-237621 |
VXSEC252 | V-251723 |  |          |
VXSEC253 | V-251724 |  |          |
VXSEC254 | V-251725 |  |          |
VXSEC255 | V-256983 |  |          |
VXSEC256 | V-255920 |  |          |
# ------------------------------------
# PostgreSQL STIG
# ------------------------------------
VXSEC551 | V-214048 |  |          |
VXSEC552 | V-214049 |  |          |
VXSEC553 | V-214050 |  |          |
VXSEC554 | V-214051 |  |          |
VXSEC555 | V-214052 |  |          |
VXSEC556 | V-214053 |  |          |
VXSEC557 | V-214054 |  |          |
VXSEC558 | V-214055 |  |          |
VXSEC559 | V-214056 |  |          |
VXSEC560 | V-214057 |  |          |
VXSEC561 | V-214058 |  |          |
VXSEC562 | V-214059 |  |          |
VXSEC563 | V-214060 |  |          |
VXSEC564 | V-214061 |  |          |
VXSEC565 | V-214062 |  |          |
VXSEC566 | V-214063 |  |          |
VXSEC567 | V-214064 |  |          |
VXSEC568 | V-214065 |  |          |
VXSEC569 | V-214066 |  |          |
VXSEC570 | V-214067 |  |          |
VXSEC571 | V-214068 |  |          |
VXSEC572 | V-214069 |  |          |
VXSEC573 | V-214070 |  |          |
VXSEC574 | V-214071 |  |          |
VXSEC575 | V-214072 |  |          |
VXSEC576 | V-214073 |  |          |
VXSEC577 | V-214074 |  |          |
VXSEC578 | V-214075 |  |          |
VXSEC579 | V-214076 |  |          |
VXSEC580 | V-214077 |  |          |
VXSEC581 | V-214078 |  |          |
VXSEC582 | V-214079 |  |          |
VXSEC583 | V-214080 |  |          |
VXSEC584 | V-214081 |  |          |
VXSEC585 | V-214082 |  |          |
VXSEC586 | V-214083 |  |          |
VXSEC587 | V-214084 |  |          |
VXSEC588 | V-214085 |  |          |
VXSEC589 | V-214086 |  |          |
VXSEC590 | V-214087 |  |          |
VXSEC591 | V-214088 |  |          |
VXSEC592 | V-214089 |  |          |
VXSEC593 | V-214090 |  |          |
VXSEC594 | V-214091 |  |          |
VXSEC595 | V-214092 |  |          |
VXSEC596 | V-214093 |  |          |
VXSEC597 | V-214094 |  |          |
VXSEC598 | V-214095 |  |          |
VXSEC599 | V-214096 |  |          |
VXSEC600 | V-214097 |  |          |
VXSEC601 | V-214098 |  |          |
VXSEC602 | V-214099 |  |          |
VXSEC603 | V-214100 |  |          |
VXSEC604 | V-214101 |  |          |
VXSEC605 | V-214102 |  |          |
VXSEC606 | V-214103 |  |          |
VXSEC607 | V-214104 |  |          |
VXSEC608 | V-214105 |  |          |
VXSEC609 | V-214106 |  |          |
VXSEC610 | V-214107 |  |          |
VXSEC611 | V-214108 |  |          |
VXSEC612 | V-214109 |  |          |
VXSEC613 | V-214110 |  |          |
VXSEC614 | V-214111 |  |          |
VXSEC615 | V-214112 |  |          |
VXSEC616 | V-214113 |  |          |
VXSEC617 | V-214114 |  |          |
VXSEC618 | V-214115 |  |          |
VXSEC619 | V-214116 |  |          |
VXSEC620 | V-214117 |  |          |
VXSEC621 | V-214119 |  |          |
VXSEC622 | V-214120 |  |          |
VXSEC623 | V-214121 |  |          |
VXSEC624 | V-214122 |  |          |
VXSEC625 | V-214123 |  |          |
VXSEC626 | V-214124 |  |          |
VXSEC627 | V-214125 |  |          |
VXSEC628 | V-214126 |  |          |
VXSEC629 | V-214127 |  |          |
VXSEC630 | V-214128 |  |          |
VXSEC631 | V-214129 |  |          |
VXSEC632 | V-214130 |  |          |
VXSEC633 | V-214131 |  |          |
VXSEC634 | V-214132 |  |          |
VXSEC635 | V-214133 |  |          |
VXSEC636 | V-214135 |  |          |
VXSEC637 | V-214136 |  |          |
VXSEC638 | V-214137 |  |          |
VXSEC639 | V-214138 |  |          |
VXSEC640 | V-214139 |  |          |
VXSEC641 | V-214140 |  |          |
VXSEC642 | V-214141 |  |          |
VXSEC643 | V-214142 |  |          |
VXSEC644 | V-214143 |  |          |
VXSEC645 | V-214144 |  |          |
VXSEC646 | V-214145 |  |          |
VXSEC647 | V-214146 |  |          |
VXSEC648 | V-214147 |  |          |
VXSEC649 | V-214148 |  |          |
VXSEC650 | V-214149 |  |          |
VXSEC651 | V-214150 |  |          |
VXSEC652 | V-214151 |  |          |
VXSEC653 | V-214152 |  |          |
VXSEC654 | V-214153 |  |          |
VXSEC655 | V-214154 |  |          |
VXSEC656 | V-214155 |  |          |
VXSEC657 | V-214156 |  |          |
VXSEC658 | V-214157 |  |          |
VXSEC659 | V-220321 |  |          |
# ------------------------------------
# Tomcat Application Server STIG
# ------------------------------------
VXSEC751 | V-222926 |  |          |
VXSEC752 | V-222927 |  |          |
VXSEC753 | V-222928 |  |          |
VXSEC754 | V-222929 |  |          |
VXSEC755 | V-222930 |  |          |
VXSEC756 | V-222931 |  |          |
VXSEC757 | V-222932 |  |          |
VXSEC758 | V-222933 |  |          |
VXSEC759 | V-222934 |  |          |
VXSEC760 | V-222935 |  |          |
VXSEC761 | V-222936 |  |          |
VXSEC763 | V-222938 |  |          |
VXSEC764 | V-222939 |  |          |
VXSEC765 | V-222940 |  |          |
VXSEC766 | V-222941 |  |          |
VXSEC767 | V-222942 |  |          |
VXSEC768 | V-222943 |  |          |
VXSEC769 | V-222944 |  |          |
VXSEC770 | V-222945 |  |          |
VXSEC771 | V-222946 |  |          |
VXSEC772 | V-222947 |  |          |
VXSEC773 | V-222948 |  |          |
VXSEC774 | V-222949 |  |          |
VXSEC775 | V-222950 |  |          |
VXSEC776 | V-222951 |  |          |
VXSEC777 | V-222952 |  |          |
VXSEC778 | V-222953 |  |          |
VXSEC779 | V-222954 |  |          |
VXSEC780 | V-222955 |  |          |
VXSEC781 | V-222956 |  |          |
VXSEC782 | V-222957 |  |          |
VXSEC783 | V-222958 |  |          |
VXSEC784 | V-222959 |  |          |
VXSEC785 | V-222960 |  |          |
VXSEC786 | V-222961 |  |          |
VXSEC787 | V-222962 |  |          |
VXSEC788 | V-222963 |  |          |
VXSEC789 | V-222964 |  |          |
VXSEC790 | V-222965 |  |          |
VXSEC791 | V-222966 |  |          |
VXSEC792 | V-222967 |  |          |
VXSEC793 | V-222968 |  |          |
VXSEC794 | V-222969 |  |          |
VXSEC795 | V-222970 |  |          |
VXSEC796 | V-222971 |  |          |
VXSEC797 | V-222973 |  |          |
VXSEC798 | V-222974 |  |          |
VXSEC799 | V-222975 |  |          |
VXSEC800 | V-222976 |  |          |
VXSEC801 | V-222977 |  |          |
VXSEC802 | V-222978 |  |          |
VXSEC803 | V-222979 |  |          |
VXSEC804 | V-222980 |  |          |
VXSEC805 | V-222981 |  |          |
VXSEC806 | V-222982 |  |          |
VXSEC807 | V-222983 |  |          |
VXSEC808 | V-222984 |  |          |
VXSEC809 | V-222985 |  |          |
VXSEC810 | V-222986 |  |          |
VXSEC811 | V-222987 |  |          |
VXSEC812 | V-222988 |  |          |
VXSEC813 | V-222989 |  |          |
VXSEC814 | V-222990 |  |          |
VXSEC815 | V-222991 |  |          |
VXSEC816 | V-222993 |  |          |
VXSEC817 | V-222994 |  |          |
VXSEC818 | V-222995 |  |          |
VXSEC819 | V-222996 |  |          |
VXSEC820 | V-222997 |  |          |
VXSEC821 | V-222998 |  |          |
VXSEC822 | V-222999 |  |          |
VXSEC823 | V-223000 |  |          |
VXSEC824 | V-223001 |  |          |
VXSEC825 | V-223002 |  |          |
VXSEC826 | V-222973,V-223003 |  |          |
VXSEC827 | V-223004 |  |          |
VXSEC828 | V-223005 |  |          |
VXSEC829 | V-223006 |  |          |
VXSEC830 | V-223007 |  |          |
VXSEC831 | V-223008 |  |          |
VXSEC832 | V-223009 |  |          |
VXSEC833 | V-223010 |  |          |
# --------- | ------ | --------- | ------ | ---------"
# VXRAIL-ID | SLES15 | 15-optval | SLES12 | 12-optval

#########################################################################################
# FUNCTIONS
#########################################################################################

# ---------------------------------------------------------------------------------------
# FUNCTION: checkFileExistence
# This function checks if a file exists. If not, it will exit.
# This function should not be used if another code path should be executed if the file 
# does not exist.
# PARAMETERS:
#    1. Name (with path) of file to check
# RETURNS: 
#    --
#
function checkFileExistence() {
   print_func_name ${FUNCNAME[0]} "$@"
   local fileName="$1"
   local err=0 # function's error count
   local msg="" 

   # check file existence
   if [ ! -f $fileName ]; then
      # file doesn't exist: raise error and exit

      msg="Exit - File not found (${fileName})"
      LOG $log_title_error '--' 1 $msg
      echo -e "\n${red}${msg}${normal}\n"

      exit $err
   fi
   LOG $log_title_debug '--' 0 "File exists ($fileName)"
}

# ---------------------------------------------------------------------------------------
# FUNCTION: ensureFileHasUnixLineEndings
# This function ensures that a file has unix style line endings.
# A file copied from Windows to Linux may still have CRLF instead of LF line endings.
# If it has CRLF line endings, it will convert them to LF line endings.
# If this conversion fails, the script will exit.
# PARAMETERS:
#    1. Name (with path) of file for which to check the line endings.
# RETURNS: 
#    --
#
function ensureFileHasUnixLineEndings() {
   print_func_name ${FUNCNAME[0]} "$@"
   local fileName="$1"
   local err=0 # function's error count
   local msg=""

   if file $fileName|grep -q 'with CRLF line terminators'; then 
      # Need to covert to LF file

      msg="File has CRLF line terminators, converting to LF now (${fileName})"
      LOG $log_title_warn '--' 0 $msg
      echo -e "${yellow}${msg}${normal}"

      sed -i $'s/\r$//' $fileName
      ((err=err+$?))

      # If the conversion failed, then we can't continue and need to raise an error
      if [ $err -ne 0 ]; then

         msg="Exit - Converting line endings from CRLF to LF failed ($fileName)"
         LOG $log_title_error '--' $err $msg
         echo -e "\n${red}${msg}${normal}\n"

         exit $err
      fi
   fi
   LOG $log_title_debug '--' 0 "File has LF line endings ($fileName)"
}

# ---------------------------------------------------------------------------------------
# FUNCTION: ensureFileIsExecutable
# This function ensures that a file has execute permission.
# The script checks if the execute permission bit is set for the file.
# If not, it will set the execute permission bit.
# If this fails, the script will exit.
# PARAMETERS:
#    1. Name (with path) of file for which to check the execute permission.
# RETURNS: 
#    --
#
function ensureFileIsExecutable() {
   print_func_name ${FUNCNAME[0]} "$@"
   local fileName="$1"
   local err=0 # function's error count
   local msg=""

   # check permissions
   result=$(find  $fileName  -type f -perm -u=x)

   if [[ -z "$result" ]]; then
      # The file is there, but it doesn't have execute permission

      msg="File has no execute permission, setting now ($fileName)"
      LOG $log_title_warn '--' 0 $msg
      echo -e "${yellow}${msg}${normal}"


      # Try to set the required execute permission
      chmod u+x $fileName
      ((err=err+$?))

      # If the chmod failed, then we can't continue and need to raise an error
      if [ $err -ne 0 ]; then

         msg="Exit - Setting execute permission on file '${fileName}' failed."
         LOG $log_title_error '--' $err $msg
         echo -e "\n${red}${msg}${normal}\n"

         exit $err
      fi
   fi
   LOG $log_title_debug '--' 0 "File has execute permission ($fileName)"
}

# ---------------------------------------------------------------------------------------
# FUNCTION: verifyScriptFile
# This function ensures that a file:
# - exists
# - has unix(LF) line-endings (and not CRLF)
# - is executable
# PARAMETERS:
#    1. Name (with path) of file
# RETURNS: 
#    --
#
function verifyScriptFile() {
   print_func_name ${FUNCNAME[0]} "$@"
   local fileName="$1"

   checkFileExistence           $fileName
   ensureFileHasUnixLineEndings $fileName
   ensureFileIsExecutable       $fileName
}

# ---------------------------------------------------------------------------------------
# FUNCTION: Validate IP address
# PARAMETERS:
#   1. IP address
# RETURNS: 
#   $status (0 if successful, 1 if failed)
#
validate_ip()
{
   ip=$1
   status=1
   print_func_name ${FUNCNAME[0]}

   if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -ge 0 && ${ip[0]} -le 255 && ${ip[1]} -ge 0 && ${ip[1]} -le 255 && \
           ${ip[2]} -ge 0 && ${ip[2]} -le 255 && ${ip[3]} -ge 0 && ${ip[3]} -le 255 ]]
        status=$?
    fi
    return $status
}

# ---------------------------------------------------------------------------------------
# FUNCTION: Ask for input, only accept given parameter
# PARAMETERS:
#   1. option = which other character is accepted (e.g. s or c)
#   2. action = what the other character will do (e.g. skip or change)
# RETURNS: 
#   $answer containing the user's input
#
askEnterOrOptionAction() {
   option="$1"
   action="$2"
   print_func_name ${FUNCNAME[0]}

   answer="x"
   while [ "x$answer" != "x" -a "x$answer" != "x$option" ]
   do
            echo -e "${yellow}Press Enter to continue. Press $option, then Enter to $action${normal}"
            read answer
            answer=$(echo $answer | tr [:upper:] [:lower:])
   done
}

# ---------------------------------------------------------------------------------------
# FUNCTION: Ping the IP address to check if it is reachable
# PARAMETERS:
#   1. IP address
# RETURNS: 
#   $status (0 if successful, 1 if failed)
#
ping_ip()
{
   ip=$1
   print_func_name ${FUNCNAME[0]}

   ping -c1 -W1 $ip > /dev/null 2>&1
   status=$?
   return $status
}

# ---------------------------------------------------------------------------------------
# FUNCTION: validate email address
# Note: This will reject an empty value, so it would effectively make it mandatory.
# PARAMETERS:
#   1. email address
# RETURNS: 
#   $status (0 if successful, 1 if failed)
#
validate_email()
{
   email=$1
   status=1
   print_func_name ${FUNCNAME[0]}

   if [[ "$email" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$ ]]
   then
      echo -e "Email address $email is valid."
      status=0
   else
      echo -e "${red}Email address $email is invalid.\n${normal}"
   fi
   return $status
}

# ---------------------------------------------------------------------------------------
# Function get_ip takes care of getting a valid IP from input/user
# Input:  1. source : [ primary | secondary ]
#         2. name of result variable (without the $ character) to pass the IP address back in
# Output: ip address value (may be empty string)
# NOTE:   Can't echo output to screen here *and* when calling this function assigning the
#         output to a variable like this: result=$(get_ip ...)
#         To get around this, pass in a variable (param #2) that the result can be returned in.
#         So call function e.g.: get_ip 'primary' primary_ip
#         Result is then e.g.: echo "Primary IP is: $primary_ip"
#
get_ip() {
   local source=$1
   local _resultvar=$2
   
    # repeat input prompt we get a good ip address (i.e. err==0)
   local err=1 # force into while loop
   print_func_name ${FUNCNAME[0]}
 
   while [ $err -ne 0 ]; do

      err=0 # new chance of getting it right

      printf "${yellow}Enter the ${source} authoritative DoD time source${normal}: "
      read ip_address

      if [ -z $ip_address ] && [ $source == "secondary" ]
      then
         # empty secondary NTP is accepted
         echo -e "An emtpy ${source} DoD time source is accepted"
         continue # err==0 will end the loop
      fi

      if ! validate_ip $ip_address
      then
         ((err=err+1))
         echo -e "${red}Invalid IP Address format ($ip_address)${normal}"
      else
         #echo -e "Valid IP Address"
         if ! ping_ip $ip_address
         then
            ((err=err+1))
            echo -e "${red}IP ($ip_address) cannot be pinged${normal}"
         fi
      fi
   done
   # return the IP address in given result variable name
   eval $_resultvar="'$ip_address'"
}

# ---------------------------------------------------------------------------------------
# Function to backup a given file to a backup file that includes a timestamp in the filename.
# Input:  1. name of file to backup
#         2. name of result variable (without the $ character) to pass the backup filename back in
# Output: Backup filename
# The target filename will be the given filename appended with '.<timestamp>.bak'
# 
backup_file() {
   local org_file=$1
   local _resultvar=$2
   print_func_name ${FUNCNAME[0]}

   TMS=`date '+%Y%m%d-%H%M%S'`
   bak_file=${org_file}.$TMS.bak
   cp -p $org_file $bak_file

   # return the backup filename in given result variable name
   eval $_resultvar="'$bak_file'"
}

# ---------------------------------------------------------------------------------------
# Function to check if a server is in the ntp conf file and append it if not.
# Input:  1. IP to check
# Output: -
# 
check_append_ntp_server() {
   ip=$1
   print_func_name ${FUNCNAME[0]}

   # ensure ip is in ntp conf file:
   if ! grep "^[[:blank:]]*server[[:blank:]]*$ip" $ntp_conf > /dev/null
   then
      # ip not in file yet; append it now
      echo "server $ip maxpoll 16" >> $ntp_conf
   fi
}

# ---------------------------------------------------------------------------------------
# Function to determine the OS Release that this platform is running on.
# Needs to be called only once, before main processing starts.
# Input:  --
# Output: $VERSION_ID, $SUSEversion, $SUSErelease, $OSrelName
#
function getOSrel() {
   print_func_name ${FUNCNAME[0]}

   # Determine VxRail Manager's platform
   # Check if this is on SLES
   local OSname
   eval `grep '^NAME=".*"' /etc/os-release | sed "s/NAME=/OSname=/"` # set the $OSname (SLES)
   if [ "$OSname" != "SLES" ]
   then
      log_message="Exit - unsupported OS id. \nSupported OS id: SLES. \nOS id found: $ID"
      echo -e "\n${red}$log_message${normal}\n"
      exit 1
   fi

   # Get the version and release number
   # Set the following vars for use in the script: VERSION_ID, SUSEversion, SUSErelease
   eval `grep ^VERSION_ID= /etc/os-release` # get the VERSION_ID
   
   SUSEversion=`echo $VERSION_ID | cut -d. -f1`
   SUSErelease=`echo $VERSION_ID | cut -d. -f2`

   # Compose the OS release name pattern
   # To be used later to find out which column in the vulnerability mapping table 
   # maps to this platform.
   OSrelName=${OSname}${SUSEversion} # e.g. SLES15

   # returning value in variables:
   # - VERSION_ID
   # - SUSEversion
   # - SUSErelease
   # - OSrelName
}

# ---------------------------------------------------------------------------------------
# Function to find the colNr of the column with matching OS Release Name in the vuln mapping
# Needs to be called only once, before main processing starts.
# Input:  OS release name to find
# Output: $colNr
# 
function find_vxsecMap_OSrel_colNr() {
   local OSrelIn="$1"
   print_func_name ${FUNCNAME[0]}

   # Map columns:
   #        # VXRAIL-ID | SLES15 | 15-optval | SLES12 | 12-optval
   # Map index:   0         1         2          3         4    
   # Extract the mapping header
   local vxmapHdr=`echo "$vxsecmap" | head -3 | grep "^# *VXRAIL-ID"` # | sed "s/^\s*${vxsecmapsep}\s*VXRAIL-ID\s//"`

   LOG $log_title_debug '--' -2 "vxmapHdr=$vxmapHdr"

   # Change map header into an array variable
   local oldIFS=$IFS
   IFS=${vxsecmapsep}
   read -a vxmapHdrArr <<<"$vxmapHdr"
   IFS=$oldIFS

   # save the osnames in an array
   local hdrArrCount=${#vxmapHdrArr[*]}

   # loop the title columns to find the column with the matching OS Release
   for ((i=1;i<$hdrArrCount;i++))
   do
      # skip non- OS name columns
      # (each OS column has an extra 'optional value' column - skip those)
      if [ $(($i % 2)) -eq 0 ]; then continue; fi

      local osName=${vxmapHdrArr[$i]}
      if [[ $osName =~ $OSrelIn ]]
      then
         # Found the column with matching OS release name
         colNr=$i

         # end loop
         break
      fi
   done

   # handle not found exception; log error and exit
   if [ -z $colNr ]; then
      log_message="Unexpected OS mapping failure. Could not find OS=\"$OSrelIn\" in mapping table (exiting)"
      LOG $log_title_error '--' -2 $log_message
      echo -e "\n${red}$log_message${normal}\n"
      exit -1
   fi
   LOG $log_title_debug '--' -2 "Mapped OS=$OSrelIn to mapping column=$colNr"

   # returning value in colNr variable
}

# ---------------------------------------------------------------------------------------
# Function to get the vulnerability id and the extra optional value for a given vxsec id.
# Needs to be called once for every vxsecid that is going to be tested.
# The column nr of the platform's release in the vuln mapping is obtained from
# the global variable $colNr.
# Input:
# 1. vxsec id
# Output: $vuln_id, $vuln_optval
# 
function get_vuln_id_optval(){
   local vxsec_id="$1"
   print_func_name ${FUNCNAME[0]} $vxsec_id
   
   if [ "$vxsec_id" == '--' ]; then
      # no need to find a vulnerability id
      vuln_id='--'
   else
      # get the line with the mapping of vulnids for this vxsecid (removing some spaces)
      vxvulnLine=`echo "$vxsecmap" | grep -v "#"| sed -e "s/^  *//" -e "s/  *${mapsep}  */${mapsep}/g" | grep -i "^$vxsec_id"`

      LOG $log_title_debug '--' -2 "vxvulnLine=$vxvulnLine"

      # Get the vulnid that corresponds to the release name of the OS (2 steps)

      # 1. store the items of the found vxsec line in an array
      oldIFS=$IFS
      IFS=${vxsecmapsep}
      read -a vxvulnLineArr <<<"$vxvulnLine"
      IFS=$oldIFS

      # 2. the required colNr is known, so extract the vuln_id and the optional extra value
      vuln_id=${vxvulnLineArr[$colNr]}
      vuln_optval=${vxvulnLineArr[$(($colNr+1))]}

      if [ -z $vuln_optval ]; then vuln_optval='<no value provided>'; fi # visualize empty value

      # handle vid not found error: test not applicable and need to skip this vxsecid
      # VXP-45392 Do not log anything if a vxsec has no applicable vulnerability in the mapping

   fi
   LOG $log_title_debug '--' -2 "Mapped vxsec_id=$vxsec_id to vuln_id=$vuln_id and vuln_optval=$vuln_optval"

   if [ -z $vuln_id ]; then 
      return $VID_MAP_NA # no vid mapping found; test is not applicable
   else
      return $VID_MAP_OK # vid map found ok; run test
   fi
   # returning value in variables: $vuln_id, $vuln_optval
}


# ---------------------------------------------------------------------------------------
# Function to disable any zypper repos that are left enabled.
# Such repos could cause issues if not reachable.
# The zypper repo config files are: /etc/zypp/repos.d/*.repo
# Input:  $vuln_id 
# Output: --
# 
function disable-zypper-repos() {
   print_func_name ${FUNCNAME[0]}

   LOG $log_title_info $vuln_id 0 "Making sure no zypper repositories are in enabled state..."
   # list the defined repos and process line by line
   zypper lr | grep "^ *[0-9]*  *|" | while read repoline
   do
      # extract the required info
      repoId=$(echo "$repoline"|cut -d'|' -f1|xargs)
      repoName=$(echo "$repoline"|cut -d'|' -f3|xargs)
      repoEnabled=$(echo "$repoline"|cut -d'|' -f4|xargs)
      # if it is still enabled, then disable it
      if [ "$repoEnabled" == "Yes" ]; then
          LOG $log_title_warn $vuln_id 0 "- repository $repoName (enabled->disabling)"
          zypper modifyrepo -d $repoId >/dev/null
      else
          LOG $log_title_info $vuln_id 0 "- repository $repoName (disabled->unchanged)"
      fi
   done
}


# ---------------------------------------------------------------------------------------
# Function to ensure RKE2 POD files have valid user and group
# (see VXP-49077, this will done by VxRail bundle in near-future version)
# Input:  $vuln_id 
# Output: $err (returns 0=ok, !0=error)
# 
function setDockerUserAndGroup() {
   print_func_name ${FUNCNAME[0]}
   local err=0

   user=dockeruser
   group=dockergroup
   dockeruid=14625

   # create dockergroup if not exists
   egrep -q "^$group:" $group_file
   if [ $? -ne 0 ]; then
      groupadd -g $dockeruid dockergroup
      res=$?
      ((err=err+$res))
      LOG $log_title_info $vuln_id $res "Created dockergroup user group: $dockeruid"
   fi

   # create dockeruser if not exists
   egrep -q "^$user:" $password_file
   if [ $? -ne 0 ]; then
      # create user and add to group
      useradd dockeruser -u $dockeruid -g $dockeruid >> $SCRIPT_LOG 2>&1
      res=$?
      ((err=err+$res))
      LOG $log_title_info $vuln_id $res "Created dockeruser user: $dockeruid"
   else
      # add user to group
      usermod -a -G dockergroup dockeruser >> $SCRIPT_LOG 2>&1
      res=$?
      ((err=err+$res))
      LOG $log_title_info $vuln_id $res "Ensured user 'dockeruser' is member of group 'dockergroup'"
   fi

   return $err
}


# ---------------------------------------------------------------------------------------
# Function to ensure ESE files have valid user and group
# If the Embedded Service Enabler (ESE) is installed, it may not have a valid user or 
# group yet. In that case derive the user id and create a user and group for it.
# Input:  1. foundUserId
#         2. foundGroupId
#         $vuln_id
# Output: $err (returns 0=ok, !0=error)
# 
function setESEUserAndGroup() {
   print_func_name ${FUNCNAME[0]}
   local err=0

   # Found ESE user and group values (is either an id or a name)
   foundUserId=$1
   foundGroupId=$2
   # Target ESE user and group names
   eseUserName=eseuser
   eseGroupName=esegroup

   # create ESE group if not exists
   egrep -q "^$eseGroupName:" $group_file
   if [ $? -ne 0 ]; then
      # create target group name
      groupadd -g $foundGroupId $eseGroupName >> $SCRIPT_LOG 2>&1
      res=$?
      ((err=err+$res))
      LOG $log_title_info $vuln_id $res "Created ESE group '$eseGroupName' (id: $foundGroupId)"
   fi

   # create ESE user if not exists
   egrep -q "^$eseUserName:" $password_file
   if [ $? -ne 0 ]; then
      # create user and add to group
      useradd $eseUserName -u $foundUserId -g $foundGroupId >> $SCRIPT_LOG 2>&1
      res=$?
      ((err=err+$res))
      LOG $log_title_info $vuln_id $res "Created ESE user $eseUserName (id: $foundUserId)"
   else
      # add user to group
      usermod -a -G $eseGroupName $eseUserName >> $SCRIPT_LOG 2>&1
      res=$?
      ((err=err+$res))
      LOG $log_title_info $vuln_id $res "Ensured user '$eseUserName' is member of group '$eseGroupName'"
   fi

   return $err
}

# ---------------------------------------------------------------------------------------
# Function to create a monitoring script which monitors the disk space under 
# PostgreSQL PGdata directory.
# Input:  1. email_address
# Output: $err (returns 0=ok, !0=error)
# 
function createPostgresqlDiskSpaceMonitorScript() {
   print_func_name ${FUNCNAME[0]}
   local err=0

   email_address=$1
   system_name=$(hostname -f)
   ((err=err+$?))

   # setup the monitor script file content
   file_content="
         #!/bin/bash
         CURRENT=\$(df $postgresql_pgdata | grep / | awk '{ print \$5}' | sed 's/%//g')
         THRESHOLD=$pgsql_audit_cap_threshold

         if [ \$CURRENT -gt \$THRESHOLD ] ; then
            # set up email alert
            msg=\"On the VxRail Manager host $system_name the data directory volume $postgresql_pgdata is almost full. Used: \$CURRENT %\"
            subject=\"VxRail Manager PostgreSQL Disk Space Alert\"
            # send email alert
            echo \"\$msg\" | mail -s \"\$subject\" $email_address
         fi"

   # create the monitor script (remove the initial tab characters and first/empty line)
   echo "$file_content" | sed -e "s/^.\{9\}//g" -e "1d" > $pg_disk_monitor_script_file
   ((err=err+$?))
   chmod 740 $pg_disk_monitor_script_file
   ((err=err+$?))

   return $err
}

# ---------------------------------------------------------------------------------------
# FUNCTION: setUserGroupForFile
# This will get, validate and if needed set the user and/or group of a given file to a given value.
# The name given may be a file or directory name.
# PARAMETERS:
#    1. Vulnerability ID
#    2. Vulnerability title
#    3. name of the file
#    4. required username
#    5. required groupname
# RETURNS:
#    $ferr (0 if successful, >=1 if failed)
#
function setUserGroupForFile() {
   print_func_name ${FUNCNAME[0]} "$@"
   local vuln_id="$1"
   local vuln_title="$2"
   local file_name="$3"
   local reqd_usr=$4
   local reqd_grp=$5
   local ferr=0 # function's error variable to return to the function's caller as the return value

   # Verify that the file exists and determine the type
   if [ -e $file_name ]; then
      # Path exists - Get the type of path
      if [ -h $file_name ]; then
         # it's a symbolic link; check what it's pointing to
         if [ -d ${file_name}/ ]; then obj_type="Directory"; else obj_type="File"; fi
      else
         # it's a directory or a file
         if [ -d ${file_name}  ]; then obj_type="Directory"; else obj_type="File"; fi
      fi
   else
      # Path not found, raise an error and return
      ((ferr=ferr+1))
      log_message="File ownership check failed - file not found: $file_name (NON-COMPLIANT, UNCHANGED)"
      LOG $log_title_error $vuln_id $ferr "$log_message"
      return $ferr
   fi

   # Get the current ownership values (use -L to follow symlinks)
   curr_usr=$(stat -Lc '%U' $file_name); ((ferr=ferr+$?))
   curr_grp=$(stat -Lc '%G' $file_name); ((ferr=ferr+$?))

   # Validate the ownership
   if [[ $curr_usr == $reqd_usr && $curr_grp == $reqd_grp ]]; then
      # COMPLIANT
      log_message="Ownership for $obj_type $file_name is already set to ${curr_usr}:${curr_grp} (COMPLIANT, UNCHANGED)"
      LOG $log_title_info $vuln_id $ferr "$log_message"
   else
      # NOT-COMPLIANT - RECTIFY
      # Check if username was non-compliant
      if [[ $curr_usr != $reqd_usr ]]; then
         # REMEDIATE USER
         chown $reqd_usr $file_name 2>>$SCRIPT_LOG
         ((ferr=ferr+$?))
         log_message="$obj_type ownership(user) for $file_name was set to $curr_usr and has now been rectified to $reqd_usr (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $ferr "$log_message"
      fi
      # Check if groupname was non-compliant
      if [[ $curr_grp != $reqd_grp ]]; then
         # REMEDIATE GROUP
         chgrp $reqd_grp $file_name 2>>$SCRIPT_LOG
         ((ferr=ferr+$?))
         log_message="$obj_type ownership(group) for $file_name was set to $curr_grp and has now been rectified to $reqd_grp (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $ferr "$log_message"
      fi
   fi

   return $ferr
}


# FUNCTION: setUserGroupForFilesInFolder
# This will get, validate and if needed set the ownership of files in a given folder.
# The name given must be a directory name.
# PARAMETERS:
#    1. Vulnerability ID
#    2. Vulnerability title
#    3. dir path (e.g. /foo/bar/)
#    4. file spec (e.g. "*" or "*.jar")
#    5. required username
#    6. required groupname
# RETURNS:
#    $ferr (0 if successful, >=1 if failed)
#
function setUserGroupForFilesInFolder() {
   print_func_name ${FUNCNAME[0]} "$@"
   local vuln_id="$1"
   local vuln_title="$2"
   local dir_name="$3"
   local file_spec="$4"
   local reqd_usr=$5
   local reqd_grp=$6
   local ferr=0 # function's error variable to return to the function's caller as the return value
   local result=""

   # Verify that the directory exists
   if [ ! -d $dir_name ]; then
      # Path not found, raise an error and return
      ((ferr=ferr+1))
      log_message="Directory existence check failed - directory not found: $dir_name (NON-COMPLIANT, UNCHANGED)"
      LOG $log_title_error $vuln_id $ferr "$log_message"
      return $ferr
   fi

   # Need to check all files in this directory
   file_search_arg=${dir_name}/${file_spec}
   LOG $log_title_debug $vuln_id $ferr "file_search_arg = $file_search_arg"
   LOG $log_title_debug $vuln_id $ferr "user:group = $reqd_usr:$reqd_grp"

   # Find any files with incorrect permissions
   nonCompliantFiles=$(find $file_search_arg -follow -maxdepth 0 -type f \( \! -user $reqd_usr -o \! -group $reqd_grp \))
   ((ferr=ferr+$?))
   nonCompliantCount=$(echo "$nonCompliantFiles"|grep -v "^$"|wc -l)
   ((ferr=ferr+$?))

   LOG $log_title_debug $vuln_id $ferr "err=$ferr, nonCompliantCount=$nonCompliantCount, nonCompliantFiles=" $nonCompliantFiles

   # Check compliance
   if [ $nonCompliantCount -eq 0 ]
   then
      # COMPLIANT
      log_message="Ownership of files $dir_name/$file_spec is already set to $reqd_usr:$reqd_grp (COMPLIANT, UNCHANGED)"
      LOG $log_title_info $vuln_id $err "$log_message"
   else
      # NON-COMPLIANT
      # Set correct ownership on non-compliant files
      # Call the ownership function for each file separately,
      # so that each non-compliant file gets logged individually

      for file_name in $nonCompliantFiles
      do
         # Prepare parameters to pass to function:
         #    1. Vulnerability ID
         #    2. Vulnerability title
         #    3. name of the file
         #    4. required username
         #    5. required groupname

         setUserGroupForFile "$vuln_id" "$vuln_title ($file_name)" "$file_name" "$reqd_usr" "$reqd_grp"
         result=$?
         if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi
      done
   fi

   # vuln title in quotes to retain file_spec
   LOG $log_title_info $vuln_id $ferr "$vuln_title"
   return $ferr
}


# ---------------------------------------------------------------------------------------
# FUNCTION: setPermissionForFile
# This will get, validate and if needed set the permissions of a given file to a given value.
# The name given may be a file or directory name.
# PARAMETERS:
#    1. Vulnerability ID
#    2. Vulnerability title
#    3. name of the file
#    4. required permissions in octal notation (integer)
# RETURNS:
#    $ferr (0 if successful, >=1 if failed)
#
function setPermissionForFile() {
   print_func_name ${FUNCNAME[0]} "$@"
   local vuln_id="$1"
   local vuln_title="$2"
   local file_name="$3"
   local file_perms_required=$4 # file permissions in octal spec
   local ferr=0 # function's error variable to return to the function's caller as the return value

   # Verify that the file exists and determine the type
   if [ -e $file_name ]; then
      # Path exists - Get the type of path
      if [ -h $file_name ]; then
         # it's a symbolic link; check what it's pointing to
         if [ -d ${file_name}/ ]; then obj_type="Directory"; else obj_type="File"; fi
      else
         # it's a directory or a file
         if [ -d ${file_name}  ]; then obj_type="Directory"; else obj_type="File"; fi
      fi
   else
      # Path not found, raise an error and return
      ((ferr=ferr+1))
      log_message="File permissions check failed - file not found: $file_name (NON-COMPLIANT, UNCHANGED)"
      LOG $log_title_error $vuln_id $ferr "$log_message"
      return $ferr
   fi

   # Get the current permissions value (use -L to follow symlinks)
   file_perms_current=$(stat -Lc '%a' $file_name)
   ((ferr=ferr+$?))

   # Validate the permissions
   if [ $file_perms_current -eq $file_perms_required ]; then
      # COMPLIANT
      log_message="$obj_type permissions for $file_name are already set to $file_perms_current (COMPLIANT, UNCHANGED)"
      LOG $log_title_info $vuln_id $ferr "$log_message"
   else
      # NOT COMPLIANT - RECTIFY
      chmod $file_perms_required $file_name
      ((ferr=ferr+$?))
      log_message="$obj_type permissions for $file_name were set to $file_perms_current and have now been rectified to $file_perms_required (NON-COMPLIANT, APPLIED:UPDATED)"
      LOG $log_title_info $vuln_id $ferr "$log_message"
   fi

   return $ferr
}

# ---------------------------------------------------------------------------------------
# FUNCTION: setPermissionForFilesInFolder
# This will get, validate and if needed set the permissions of files in a given folder.
# The name given must be a directory name.
# PARAMETERS:
#    1. Vulnerability ID
#    2. Vulnerability title
#    3. dir path (e.g. /foo/bar/)
#    4. file spec (e.g. "*" or "*.jar")
#    5. required permissions in octal notation (integer)
# RETURNS:
#    $ferr (0 if successful, >=1 if failed)
#
function setPermissionForFilesInFolder() {
   print_func_name ${FUNCNAME[0]} "$@"
   local vuln_id="$1"
   local vuln_title="$2"
   local dir_name="$3"
   local file_spec="$4"
   local file_perms_required=$5 # file permissions in octal spec
   local ferr=0 # function's error variable to return to the function's caller as the return value
   local result=""

   # Verify that the directory exists
   if [ ! -d $dir_name ]; then
      # Path not found, raise an error and return
      ((ferr=ferr+1))
      log_message="Directory existence check failed - directory not found: $dir_name (NON-COMPLIANT, UNCHANGED)"
      LOG $log_title_error $vuln_id $ferr "$log_message"
      return $ferr
   fi

   # Need to check all files in this directory
   file_search_arg=${dir_name}/${file_spec}

   # Find any files with incorrect permissions
   nonCompliantFiles=$(find $file_search_arg -follow -maxdepth 0 -type f \( \! -perm $file_permissions_reqd \))
   ((ferr=ferr+$?))
   nonCompliantCount=$(echo "$nonCompliantFiles"|grep -v "^$"|wc -l)
   ((ferr=ferr+$?))

   LOG $log_title_debug $vuln_id $ferr "err=$ferr, nonCompliantCount=$nonCompliantCount, nonCompliantFiles=" $nonCompliantFiles

   # Check compliance
   if [ $nonCompliantCount -eq 0 ]
   then
      # COMPLIANT
      log_message="Permissions of files $dir_name/$file_spec are already set to $file_permissions_reqd (COMPLIANT, UNCHANGED)"
      LOG $log_title_info $vuln_id $err "$log_message"
   else
      # NON-COMPLIANT
      # Set correct permission on non-compliant files
      # Call the permission function for each file separately,
      # so that each non-compliant file gets logged individually

      for file_name in $nonCompliantFiles
      do
         # Prepare parameters to pass to function:
         # 1. Vulnerability ID
         # 2. Vulnerability title
         # 3. name of the file
         # 4. required permissions in octal notation

         setPermissionForFile "$vuln_id" "$vuln_title ($file_name)" "$file_name" "$file_permissions_reqd"
         result=$?
         if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi
      done
   fi

   # vuln title in quotes to retain file_spec
   LOG $log_title_info $vuln_id $ferr "$vuln_title"
   return $ferr
}
# ---------------------------------------------------------------------------------------
# FUNCTION: replaceParamInFile
# This function ensures the given file has a line with format "<paramname><sep><paramvalue>".
# PARAMETERS:
#    1. Vulnerability ID
#    2. Vulnerability title
#    3. file name
#    4. parameter name to search and check
#    5. parameter separator (e.g. "=" or " " etc)
#    6. parameter required value
#    7. change flag variable name (optional)
#       - The function will set the parameter with this passed-in name to 1 if the search parameter 
#         was non-compliant and got changed.
#       - Note that this variable name must be passed-in WITHOUT the $ character at the start!
#       - So if value is e.g. "restartMarvin" then var $restartMarvin will be set to 1 if it was non-compliant/changed.
# RETURNS: 
#    $ferr (0 if successful, >=1 if failed)
#
function replaceParamInFile() {
   print_func_name ${FUNCNAME[0]} "$@"
   local vuln_id="$1"
   local vuln_title="$2"
   local file_name="$3"
   local param_name="$4"
   local param_sep="$5"
   local param_reqd_val="$6"
   # and an optional change flag ($7) may be passed in; see use/assignment further below

   local ferr=0 # function's error variable to return to the function's caller as the return value

   local msg=""
   local searchArg
   local paramLine

   # See if a change flag variable name was passed-in as 6th param value
   if [[ -z $7 ]]; then
      # no var name passed-in; no need to keep track; set a dummy local var (no indirection)
      local changeFlag="dummyValue"
   else
      # a var name was passed-in; set that variable, so it will get the value when assigned (indirection)
      declare -n changeFlag="$7"
      # do not initialize this flag (e.g. to 0 -- it may already have a value to retain)
   fi

   # Verify the file exists
   if [ ! -f $file_name ]; then
      # File not found, raise an error and return
      ferr=1
      msg="File existence check failed - file not found: $file_name (NON-COMPLIANT, UNCHANGED)"
      LOG $log_title_error $vuln_id $ferr "$msg"
      return $ferr
   fi

   # How to find the line with the parameter
   searchArg="^${param_name}${param_sep}"

   # The exact line that is required
   paramLineReqd="${param_name}${param_sep}${param_reqd_val}"

   # FIND parameter entry (and remove any comment from end of line)
   paramLine=$(grep "$searchArg" $file_name | sed "s/\s*#.*$//")
   ((ferr=ferr+$?))

   if [[ -z "$paramLine" ]]; then
   
      # NOT COMPLIANT - RECTIFY
      # Parameter not present yet - append it as a new line
      echo "$paramLineReqd" >> $file_name
      ((ferr=ferr+$?))
      changeFlag=1

      msg="Parameter $param_name was not present yet, this has now been rectified in ${file_name} with value \"$param_reqd_val\" (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $ferr "$msg"

   else
      # Param was already in the file
      # GET
      local paramCurVal=$(echo "$paramLine" | sed "s/${searchArg}//")
      ((ferr=ferr+$?))
      LOG $log_title_debug $vuln_id $ferr "paramCurVal=$paramCurVal"

      # VALIDATE
      if [[ "$paramCurVal" == "$param_reqd_val" ]]; then
         # COMPLIANT
         msg="Parameter $param_name was present and already set correctly in ${file_name} to the value \"$paramCurVal\" (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $ferr "$msg"
      else
         # NOT COMPLIANT - RECTIFY
         # Parameter present with incorrect value - change it in-line
         sed -i "/${searchArg}/c\\${paramLineReqd}" $file_name
         ((ferr=ferr+$?))
         changeFlag=1
         msg="Parameter $param_name was set to \"$paramCurVal\" and now has been rectified in ${file_name} to the new value \"$param_reqd_val\" (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $ferr "$msg"
      fi
   fi

   # Check if a change flag param name was passed in
   if [[ ! -z $7 ]]; then
      LOG $log_title_debug $vuln_id $ferr "Return value $7: $changeFlag"
   fi

   return $ferr
}

# ---------------------------------------------------------------------------------------
# FUNCTION: applyAuditRule
# This function ensures the given audit rule is compliant.
# It checks for the rule in the file /etc/audit/rules.d/audit.rules where they are persisted.
# This function itself does not restart the audit daemon; that is done at the end of the script in VXSEC089.
# PARAMETERS:
#    1. Vulnerability ID
#    2. Vulnerability title
#    3. Audit path          - the path that must be monitored, e.g. $CATALINA_HOME/bin
#    4. Required audit rule - the full rule, e.g. "-w $CATALINA_HOME/bin -p wa -k tomcat"
# RETURNS: 
#    $ferr (0 if successful, >=1 if failed)
#
function applyAuditRule() {
   print_func_name ${FUNCNAME[0]} "$@"
   local vuln_id="$1"
   local vuln_title="$2"
   local audit_path="$3"
   local reqd_rule="$4"

   local ferr=0 # function's error variable to return to the function's caller as the return value

   local msg=""
   local searchArg
   local curr_rule

   # Ensure the file exists
   if [ ! -f $audit_rules_file ]; then
      # File not found, raise an error and return
      ferr=1
      msg="File existence check failed - file not found: $file_name (NON-COMPLIANT, UNCHANGED)"
      LOG $log_title_error $vuln_id $ferr "$msg"
      return $ferr
   fi

   # How to find the audit rule in the file
   searchArg="^-w ${audit_path} "

   # FIND audit rule entry based on the path that must be monitored
   curr_rule=$(grep -- "$searchArg" $audit_rules_file)

   if [[ -z "$curr_rule" ]]; then
   
      # NOT COMPLIANT - RECTIFY
      # Parameter not present yet - append it as a new line
      echo "${reqd_rule}" >> $audit_rules_file
      ((ferr=ferr+$?))

      msg="Audit rule was not present yet, this has now been rectified in ${audit_rules_file} by adding \"$reqd_rule\" (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $ferr "$msg"

   else
      # Param was already in the file
      # GET
      LOG $log_title_debug $vuln_id $ferr "curr_rule=$curr_rule"

      # VALIDATE
      if [[ "$curr_rule" == "$reqd_rule" ]]; then
         # COMPLIANT
         msg="Audit rule was present and already set correctly in ${audit_rules_file} to the value \"$reqd_rule\" (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $ferr "$msg"
      else
         # NOT COMPLIANT - RECTIFY
         # Parameter present with incorrect value - change it in-line
         # (Use delimiter '@' to prevent issues with '/' in paths)
         sed -i "\@${searchArg}@c\\${reqd_rule}" $audit_rules_file
         ((ferr=ferr+$?))
         msg="Audit rule was set to \"$curr_rule\" and now has been rectified in ${audit_rules_file} to the new value \"$reqd_rule\" (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $ferr "$msg"
      fi
   fi

   return $ferr
}

# ---------------------------------------------------------------------------------------
# FUNCTION: setParamInFile
# This will get, validate and if needed set a parameter to a value in a file.
# The resulting parameter setting will look like: <paramName><paramSep><paramValue>
# Examples:
#       aaa=123      - given separator '='
#       aaa:123      - given separator ':'
#       aaa 123      - given separator ' '
#       aaa = 123    - given separator ' = '
# PARAMETERS:
#    1. Vulnerability ID
#    2. Vulnerability title
#    3. Action (check or apply)
#    4. filepath
#    5. parameter name
#    6. parameter separator
#    7. parameter value
# RETURNS: 
#    $ferr (0 if successful, >=1 if failed)
#
function setParamInFile() {
   print_func_name ${FUNCNAME[0]} "$@"
   local vuln_id="$1"
   local vuln_title="$2"
   local action="$3"
   local param_file="$4"
   local param_name="$5"
   local param_sep="$6"
   local param_val="$7"
   local ferr=0 # function's err count
   local param_found=0 # is the param present in the file

   # --------------------------------------
   # 1. File check
   # --------------------------------------
   # Verify that the file exists and is writable
   if [[ ! -f "$param_file" || ! -w "$param_file" ]]
   then
      # File does not exist or is not writable
      ((ferr=ferr+1))
      log_message="File check failed - exists and writable? $param_file (NON-COMPLIANT, UNCHANGED)"
      LOG $log_title_error $vuln_id $ferr "$log_message"
      return $ferr
   fi

   # --------------------------------------
   # 2. Extract the current parameter value
   # --------------------------------------
   # Check parameter name can be found

   find_spec="^${param_name}${param_sep}.*$" # pattern that finds the line
   LOG $log_title_debug $vuln_id $ferr "find_spec=<${find_spec}>"

   old_line=$(grep "$find_spec" $param_file) # find the existing/old line
   if [ $? -eq 0 ]
   then 
      param_found=1
   fi

   LOG $log_title_debug $vuln_id $ferr "old_line=<${old_line}>"

   # Extract the assigned value
   param_val_found=$(echo "$old_line" | awk -F"$param_sep" '{print $2}')
   LOG $log_title_debug $vuln_id $ferr "param_val_found=$param_val_found"

   # -----------------------
   # 3. Check for compliance
   # -----------------------
   if [ $param_found -eq 1 ] && [ "$param_val" == "$param_val_found" ]
   then
      msg="Parameter '$param_name' already set correctly to '$param_val' in ${param_file} (COMPLIANT, UNCHANGED)"
      LOG $log_title_info $vuln_id $ferr "$msg"
      return 0
   fi

   LOG $log_title_debug $vuln_id 0 "Property $param_name is set incorrect"
   LOG $log_title_debug $vuln_id $ferr "action=$action"

   # ----------------------------------------------------------------
   # 4. Process the action: check or apply
   #    State: Param is not found, or found param is non-compliant
   # ----------------------------------------------------------------
   if [ $action == 'apply' ]
   then
      # APPLY: Make compliant
      new_line="${param_name}${param_sep}${param_val}"
   
      if [ $param_found -eq 1 ]
      then
         # UPDATE - Replace the line in the file
         sed -i "s|$old_line|$new_line|" $param_file
         ((ferr=ferr+$?))
   
         msg="Parameter '$param_name' was set to '$param_val_found' and has now been rectified to '$param_val' in ${param_file} (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $ferr "$msg"
      else
         # INSERT - Add the line to the file
         echo "$new_line" >> $param_file
         ((ferr=ferr+$?))
   
         msg="Parameter '$param_name' is set to '$param_val' and added in ${param_file} (NON-COMPLIANT, APPLIED:INSERTED)"
         LOG $log_title_info $vuln_id $ferr "$msg"
      fi
   else
      # CHECK: Log non-compliance
      if [ $param_found -eq 1 ]
      then
         # param found and not compliant
         msg="Parameter '$param_name' is set incorrectly to '$param_val_found' in ${param_file} (NON-COMPLIANT)"
         LOG $log_title_warn $vuln_id $ferr "$msg"
      else
         # param not found at all
         msg="Parameter '$param_name' was not found in ${param_file} (NON-COMPLIANT)"
         LOG $log_title_warn $vuln_id $ferr "$msg"
      fi
   fi

   return $ferr
}

# ---------------------------------------------------------------------------------------
# FUNCTION: placeMarkerInVxRailLogFiles
# Place a STIG session marker in the VxRail web.log and short.term.log files.
# This will help Escalation Engineer and Support members when analysing log files.
# PARAMETERS:
#    1. sessionPhase (BEGIN | END)
# RETURNS: 
#    <none>
#
function placeMarkerInVxRailLogFiles() {
   	print_func_name ${FUNCNAME[0]} "$@"
	local sessionPhase="$1"
	local msgPhaseWord
	local date_format

	# Determine the word to use for the message written to the log file and place a STIG Hardening session marker in the VxRail log files
	if [ "$sessionPhase" == "BEGIN" ]
	then 
		msgPhaseWord="Starting"
	else 
		msgPhaseWord=" End of "
	fi

	local date_format=$(date +"%F %T.%3N+0000") # use web log timestamp format
       
	echo $date_format $log_title_info "***************************************************"      >> $web_log
	echo $date_format $log_title_info "**** $msgPhaseWord VxRail OS STIG Hardening Session ****" >> $web_log
	echo $date_format $log_title_info "***************************************************"      >> $web_log

	date_format=$(date +"\"%F %T,%3N\"") # use short term log timestamp format

	echo $date_format $log_title_info "***************************************************"      >> $short_term_log
	echo $date_format $log_title_info "**** $msgPhaseWord VxRail OS STIG Hardening Session ****" >> $short_term_log
	echo $date_format $log_title_info "***************************************************"      >> $short_term_log
}

# ####################################################################################################
# ####################################################################################################
# MAIN
# ####################################################################################################
# ####################################################################################################


# Placing a STIG Hardening session marker in the VxRail web.log and short.term.log files
placeMarkerInVxRailLogFiles "BEGIN"

echo "**********************************************" >> $SCRIPT_LOG
echo "*** Start VxRail OS STIG Hardening Process ***" >> $SCRIPT_LOG
echo "**********************************************" >> $SCRIPT_LOG

echo -e "${yellow}Current directory: $(pwd)${normal}"
echo -e "${yellow}Logfile location:  $SCRIPT_LOG${normal}\n"

msg="- VXSEC Mapping count: `echo "$vxsecmap" | grep -v "#" | wc -l`"
LOG $log_title_debug '--' -2 "$msg"

getOSrel                                # returns $OSrelName this platform is running
find_vxsecMap_OSrel_colNr $OSrelName # returns $colNr of this platform in the mapping table

LOG $log_title_debug '--' -2 "OS release name current platform = $OSrelName"
LOG $log_title_debug '--' -2 "Column nr in mapping table=$colNr"

# ----------------------------------------
# Detect and log VxRail (marvin) version
vuln_id="--"
marvin=$(rpm -qa | grep marvin)
log_message="Detected VxRail version: $marvin"
vxrail_version=$(echo $marvin | cut -d'-' -f3)
vxrail_major_version=$(echo $vxrail_version | cut -d'.' -f1)
LOG $log_title_info $vuln_id 0 $log_message

# ----------------------------------------
# Determine if the VxRail version is supported by this STIG package

# Exit script if the VxRail version does not match any supported versions
if [[ ! ($vxrail_major_version == "4" && ($vxrail_version == "4.7.300" || $vxrail_version > "4.7.300"))
   && ! ($vxrail_major_version == "7" && ($vxrail_version == "7.0.131" || $vxrail_version > "7.0.131")) ]]
then
   log_message="Exit - unsupported VxRail version. \nSupported versions: VxRail 4.7.x (4.7.300 or greater) or VxRail 7.0.x (7.0.131 or greater). \nVersion found: VxRail $vxrail_version"
   LOG $log_title_error $vuln_id 1 $log_message
   echo -e "\n${red}$log_message${normal}\n"
   exit 1
fi


# ----------------------------------------
# [ VXP-40152 ] Determine if /mystic/stig/info exists with execute permissions
err=0

# Exit script if no file or no execute permissions
log_message="Checking if ${stig_info} exists with execute permissions"
LOG $log_title_info '--' 0 $log_message

if [[ $vxrail_major_version != "4" ]]; then
   # Using stig info since version 7.0
   checkFileExistence     $stig_info
   ensureFileIsExecutable $stig_info
fi

# ----------------------------------------
# Verify availability of required Python files

verifyScriptFile $VxRailSTIGLoggingFile             # Logging module
verifyScriptFile $setKeyOfElementAttributeInXMLfile # Function module
verifyScriptFile $removeElementInXMLfile            # Function module
verifyScriptFile $applyElementInXMLfile             # Function module
verifyScriptFile $vxsec759                          # Rule module
verifyScriptFile $applyJvmOpts                      # Function module
verifyScriptFile $MonitorVxRailClusterHealthUntilOK # Function module

########################################################################################
# Define vCenter Credentials Variable
########################################################################################

echo -en "${green}Enter the vCenter Administrator Username${normal}: "; read vcUsername
while true
do
   echo -en "${green}Enter the vCenter Administrator Password${normal}: "; read -s vcPassword
   echo -en "\n${green}Re-enter the vCenter Administrator Password${normal}: "; read -s vcSecondPassword
   if [ $vcPassword == $vcSecondPassword ]; then
      log_message="vCenter administrator password matches"
      LOG $log_title_info '--' 0 $log_message
      break
   else
      echo -en "\n${red}Passwords not the same, please try again.${normal}\n"
   fi
done

#-------------------------------------------
# [ VXP-43173 ] Apply temp fix on concatenated lines in in the /etc/sysctl.conf 
# Remove it once product team fixes it in the release
# Issue is fixed from 7.0.400
sed -i "s/kernel.printk = 3 4 1 3vm.swappiness=10/kernel.printk = 3 4 1 3\nvm.swappiness=10/g" $sysctl_conf


# ----------------------------------------
# Create directories
# Ensure certain directories exist so that a write to file doesn't fail
#
dirs="  /etc/gdm
        /etc/dconf/db/local.d
        /etc/sssd
        /etc/audit
        /etc/pam_pkcs11
        /etc/zypp"
for dir in $dirs
do
   # proceed to next dir if this dir already exists
   if [ -d $dir ]; then continue; fi
   # dir does not exist yet
   log_message="Creating directory $dir"
   mkdir -p $dir > /dev/null 2>&1
   LOG $log_title_info $vuln_id $? $log_message
done

# ----------------------------------------
# Check if gnome is installed
#
echo -e "\nChecking if gnome is installed"

gnome_check=$(ls /usr/bin/*session* )
if [[ $gnome_check == *"gnome"* ]]; then
   echo -e "gnome is installed."
   gnome_installed=1
else
   echo -e "gnome is NOT installed."
fi

# ----------------------------------------
# Logon settings

# [ VXSEC087 ] The SUSE operating system must be configured to not overwrite Pluggable Authentication Modules (PAM) configuration on package changes.
#
err=0
vxsec_id="VXSEC087"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Remove SUSE soft links for PAM config files"
   # Copy the pam common files to their static locations, removing the symlinks at destination
   for X in /etc/pam.d/common-*-pc
   do 
      cp -p --remove-destination $X ${X:0:-3}
      ((err=err+$?))
   done  

   log_message="Remove SUSE soft links for PAM config files"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC038 ] The SUSE operating system must enforce a delay of at least four seconds between logon prompts following a failed logon attempt - Update /etc/pam.d/common-auth file
#
err=0
vxsec_id="VXSEC038"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Adding 4 second delay between logon prompts in $common_auth_file"
   touch $common_auth_file 

   # Delete any line with pam_faildelay
   sed -i '/pam_faildelay/d' $common_auth_file
   ((err=err+$?))

   # Add a correct pam_faildelay entry
   echo "auth    required    pam_faildelay.so    delay=4000000" >> $common_auth_file
   ((err=err+$?))

   log_message="The SUSE operating system must enforce a delay of at least four seconds between logon prompts following a failed logon attempt ($common_auth_file)"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC041 ] The SUSE operating system must display the date and time of the last successful account logon upon logon.
# Update /etc/pam.d/login
#
err=0
vxsec_id="VXSEC041"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Enable displaying last login details in $pam_login_file"

   touch $pam_login_file

   result=$(grep "pam_lastlog.so" $pam_login_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "session    required    pam_lastlog.so showfailed" >> $pam_login_file
      ((err=err+$?))
   else
      sed -i 's/^[^#]*pam_lastlog.so.*/session     required      pam_lastlog.so showfailed/' $pam_login_file
      ((err=err+$?))
   fi

   log_message="Enable display of last login details in $pam_login_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC015 ] The SUSE operating system must lock an account after three consecutive invalid logon attempts.
# VXP-15095 SLES12 Vul ID: V-77071: Verify that "pam_tally2.so" is configured for all accounts
#
# Check that the system locks a user account after three consecutive failed login attempts 
# using the following command:
# # grep pam_tally2.so /etc/pam.d/common-auth (set in V-81709 function)
# # grep pam_tally2.so /etc/pam.d/common-account
#
# Expected result:
#  /etc/pam.d/common-auth: auth required pam_tally2.so deny=3 (set in V-81709 function)
#  /etc/pam.d/common-account: account required pam_tally2.so deny=3
#
err=0

vxsec_id="VXSEC015"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must lock an account after three consecutive invalid logon attempts."
   touch $common_account_file

   result=$(grep "pam_tally2.so" $common_account_file | grep -v ^[#])
   if [ -z "$result" ]; then
      echo "account required pam_tally2.so deny=3" >> $common_account_file
      echo -e "account required pam_tally2.so deny=3 added to $common_account_file"
   else
      result=$(grep "account required pam_tally2.so" $common_account_file | grep -v ^[#])
      if [ -z "$result" ]; then
         sed -i '/pam_tally2/d' $common_account_file
         ((err=err+$?))
         echo "account required pam_tally2.so deny=3" >> $common_account_file
      else 
         deny_value=$(echo $result | grep "deny")
         if [[ -z "$deny_value" ]]; then
            sed -i "s/pam_tally2.so/pam_tally2.so deny=3/g" $common_account_file
            ((err=err+$?))
         else
            sed -r -i 's/(deny=)[^ ]+/\13/' $common_account_file
            ((err=err+$?))
         fi
         echo -e "Account required pam_tally2.so is already present in $common_account_file"
      fi
   fi

   log_message="Add auth required pam_tally2.so deny=3 in $common_account_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC015 ] The SUSE operating system must lock an account after three consecutive invalid logon attempts.
# Tests below will check pam.d/login, system-auth and password-auth and common-auth - For clarity changes are done one file at a time
#
# [V-81709] Accounts on the SUSE operating system that are subject to three unsuccessful logon attempts within 15 minutes must be locked for the maximum configurable period.
# VXP-15097 SLES12 Vul ID: V-81709: Three unsuccessful logon attempts within 15 minutes must be locked for the maximum configurable period
# VXP-45474 (see VXP comments, item 1) STIG Rule specifies updating common-account and common-auth in vxsec015. The code however also 
#           updates pam-login, password-auth and system-auth. These pam files are related and all kept under vxsec015.
#
# This test checks: pam.d/login
#
err=0
vxsec_id="VXSEC015"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Locking user after 3 unsuccessful attempts in $pam_login_file"

   result=$(grep "pam_tally2" $pam_login_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      cat << EOT >> $pam_login_file
auth   required   pam_tally2.so  deny=3
EOT
      ((err=err+$?))
   else
       sed -i 's/^[^#]*pam_tally2.so.*/auth   required   pam_tally2.so  deny=3/' $pam_login_file
      ((err=err+$?))
   fi

   log_message="Add auth required pam_tally2.so deny=3 in $pam_login_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# [ VXSEC015 cont'd ] The SUSE operating system must lock an account after three consecutive invalid logon attempts.
## Addresses V-81709, others to be backfilled ##
#
# Update pam.d files password-auth, system-auth and common-auth
# This test checks: password-auth
#
err=0
vxsec_id="VXSEC015"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   if [ ! -f $password_auth ]; then touch $password_auth; fi

   sed -i '/pam_faillock.so/d' $password_auth
   ((err=err+$?))
   sed -i '/pam_unix.so/d' $password_auth
   ((err=err+$?))

   cat << EOT >> $password_auth
auth required pam_faillock.so preauth silent audit deny=3 even_deny_root fail_interval=900 unlock_time=900
auth sufficient pam_unix.so try_first_pass
auth [default=die] pam_faillock.so authfail audit deny=3 even_deny_root fail_interval=900 unlock_time=900
account required pam_faillock.so
EOT
   ((err=err+$?))

   log_message="Update $password_auth"
   LOG $log_title_info $vuln_id $err $log_message
fi

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# [ VXSEC015 cont'd ] The SUSE operating system must lock an account after three consecutive invalid logon attempts.
# vuln_id V-81709
#
# Update pam.d files password-auth, system-auth and common-auth
# This test checks: system-auth
#
err=0
vxsec_id="VXSEC015"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   if [ ! -f $system_auth ]; then touch $system_auth; fi

   sed -i '/pam_faillock.so/d' $system_auth
   ((err=err+$?))
   sed -i '/pam_unix.so/d' $system_auth
   ((err=err+$?))

   cat << EOT >> $system_auth
auth required pam_faillock.so preauth silent audit deny=3 even_deny_root fail_interval=900 unlock_time=900
auth sufficient pam_unix.so try_first_pass
auth [default=die] pam_faillock.so authfail audit deny=3 even_deny_root fail_interval=900 unlock_time=900
account required pam_faillock.so
EOT
   ((err=err+$?))

   log_message="Update $system_auth"
   LOG $log_title_info $vuln_id $err $log_message
fi

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# [ VXSEC015 cont'd ] The SUSE operating system must lock an account after three consecutive invalid logon attempts.
# vuln_id V-81709
#
# Update pam.d files password-auth, system-auth and common-auth
# This test checks: common-auth
#
err=0
vxsec_id="VXSEC015"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   if [ ! -f $common_auth_file ]; then touch $common_auth_file; fi

   sed -i '/pam_unix.so/d' $common_auth_file
   ((err=err+$?))
   sed -i '/pam_tally2/d' $common_auth_file
   ((err=err+$?))

   cat << EOT >> $common_auth_file # Warning! This order is prescibed by STIG
auth required pam_tally2.so onerr=fail preauth silent audit deny=3 even_deny_root fail_interval=900 unlock_time=900
auth sufficient pam_unix.so sha512 try_first_pass
auth [default=die] pam_tally2.so authfail audit deny=3 even_deny_root fail_interval=900 unlock_time=900
EOT
   ((err=err+$?))

   log_message="Update $common_auth_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
###################
# Banner settings #
###################

# [ VXSEC004 ] The SUSE operating system must display the Standard Mandatory DoD Notice and Consent Banner until users acknowledge the usage conditions 
# and take explicit actions to log on for further access to the local graphical user interface (GUI).
#
err=0
vxsec_id="VXSEC004"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must display the Standard Mandatory DoD Notice and Consent Banner until users acknowledge the usage conditions and take explicit actions to log on for further access to the local graphical user interface (GUI)."
   # If gnome is installed, apply settings
   #
   if [[ $gnome_installed == 1 ]]; then
      # only need to log/lookup info if gnome is indeed installed

      touch $gnome_file
      echo -e "Enable displaying standard DoD notice if gnome is installed in $gnome_file"

      sed -i "/\#\!\/bin\/sh/a if ! zenity --text-info\n --title \"Consent\"\n --filename=/etc/gdm/banner\n --no-markup\n --checkbox="Accept." 10 10; then\n  sleep 1;\n  exit 1;\nfi" $gnome_file
      ((err=err+$?))

      log_message="The SUSE operating system must display the Standard Mandatory DoD Notice and Consent Banner until users acknowledge the usage conditions and take explicit actions to log on for further access to the local graphical user interface (GUI)"
      LOG $log_title_info $vuln_id $err $log_message
   fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC005 ] The SUSE operating system must display the Standard Mandatory DoD Notice and Consent Banner before granting access via local console.
#
err=0
vxsec_id="VXSEC005"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must display the Standard Mandatory DoD Notice and Consent Banner before granting access via local console."
   bannerValue="You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only.

By using this IS (which includes any device attached to this IS), you consent to the following conditions:

-The USG routinely intercepts and monitors communications on this IS for purposes including, but not limited to, penetration testing, COMSEC monitoring, network operations and defense, personnel misconduct (PM), law enforcement (LE), and counterintelligence (CI) investigations.

-At any time, the USG may inspect and seize data stored on this IS.

-Communications using, or data stored on, this IS are not private, are subject to routine monitoring, interception, and search, and may be disclosed or used for any USG-authorized purpose.

-This IS includes security measures (e.g., authentication and access controls) to protect USG interests--not for your personal benefit or privacy.

-Notwithstanding the above, using this IS does not constitute consent to PM, LE or CI investigative searching or monitoring of the content of privileged communications, or work product, related to personal representation or services by attorneys, psychotherapists, or clergy, and their assistants. Such communications and work product are private and confidential. See User Agreement for details."
   
   if [[ "$OSrelName" == "SLES12" ]]; then
      echo -e "$bannerValue" > $etc_issue_file
      ((err=err+$?))
   fi
   
   if [[ "$OSrelName" == "SLES15" ]]; then
      echo -e "$bannerValue" > $motd_path
      ((err=err+$?))
   fi
   
   log_message="The SUSE operating system must display the Standard Mandatory DoD Notice and Consent Banner before granting access via local console."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC006 ] The SUSE operating system must display a banner before granting local or remote access to the system via a graphical user logon
# Create/update /etc/dconf/db/local.d/01-banner-message
#
err=0
vxsec_id="VXSEC006"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must display a banner before granting local or remote access to the system via a graphical user logon."
   if [[ $gnome_installed == 1 ]]; then
      touch $banner_path
      ((err=err+$?))

      echo -e "Enable displaying banner before local/remote access in $banner_path"

      result=$(grep "^\[org\/gnome\/login-screen\]" $banner_path | grep -v ^[#])
      if [[ -z "$result" ]]; then
         cat <<EOT >> $banner_path  
[org/gnome/login-screen]
banner-message-enable=true
EOT
         ((err=err+$?))
      else
         result=$(grep "^banner-message-enable" $banner_path | grep -v ^[#])
         if [[ -z "$result" ]]; then
            # Insert after org/gnome/login-screen
            sed -i '/\[org\/gnome\/login-screen\]/a banner-message-enable=true' $banner_path
            ((err=err+$?))
         else
            sed -i '/^#/!s/banner-message-enable.*/banner-message-enable=true/g' $banner_path 
            ((err=err+$?))
         fi
      fi
      
      log_message="Enable displaying banner before local/remote access in $banner_path"
      LOG $log_title_info $vuln_id $err $log_message

      # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
      # Update banner-message-text in /etc/dconf/db/local.d/01-banner-message
      # Here we do not look if file exists and [org/gnome/login-screen] exists because they were already taken care
      # of in the previous step (setting of banner-message-enable) 
      err=0

      echo -e "Enable displaying standard DoD notice before granting local/remote access via graphical logon in $banner_path"
      result=$(grep "^banner-message-text" $banner_path | grep -v ^[#])
      if [[ -z "$result" ]]; then
      sed -i "/\[org\/gnome\/login-screen\]/a banner-message-text=$bannerValue" $banner_path
      ((err=err+$?))
      else
      sed -i "s/banner-message-text.*/banner-message-text=$bannerValue/g" $banner_path
      ((err=err+$?))
      fi

      log_message="Enable displaying banner before local/remote access via graphical logon in $banner_path"
      LOG $log_title_info $vuln_id $err $log_message
      
      # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
      dconf update
      err=$?

      log_message="Updating graphical backend configuration system with banner setting"
      LOG $log_title_info $vuln_id $err $log_message
   fi

   # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
   echo -e "Updating $etc_issue_file to contain banner value"
   echo -e $bannerValue > $etc_issue_file
   err=$?

   log_message="Copying banner value to etc issue file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC160 ] The SUSE operating system SSH daemon private host key files must have mode 0640 or less permissive.
# VXP-70642 - This will set the file permissions to a more restrictive 600 (STIG:640 or less)
#
err=0
vxsec_id="VXSEC160" 
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # Prepare parameters to pass to function:
   # 1. Vulnerability ID
   # 2. Vulnerability title
   # 3. Directory path (e.g. /foo/bar/)
   # 4. file spec
   # 5. required permissions in octal notation

   # Rule variables
   vuln_title='The SUSE operating system SSH daemon private host key files must have mode 0640 or less permissive. (STIG:640)'
   dir_name=/etc/ssh/
   file_spec="ssh_host_*_key"
   file_permissions_reqd=600

   setPermissionForFilesInFolder "$vuln_id" "$vuln_title" "$dir_name" "$file_spec" "$file_permissions_reqd"
   result=$?
   if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   LOG $log_title_info $vuln_id $err $vuln_title
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC158 ] The SUSE operating system file /etc/gdm/banner must contain the Standard Mandatory DoD Notice and Consent banner text.
# Update gdm banner
#
err=0
vxsec_id="VXSEC158"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Adding banner text in $gdm_banner"

   echo -e $bannerValue > $gdm_banner    # If file doesn't exist, it is created. If it exists, it is overwritten
   ((err=err+$?))

   log_message="Add banner text in $gdm_banner"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC163 ] The SUSE operating system must log SSH connection attempts and failures to the server.
# Update LogLevel
#
err=0
vxsec_id="VXSEC163"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then
 
   touch $sshd_config_file
   echo -e "Updating log level in $sshd_config_file"

   sed -i '/LogLevel/d' $sshd_config_file
   ((err=err+$?))

   result=$(grep "^LogLevel" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "LogLevel VERBOSE" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/LogLevel.*/LogLevel VERBOSE/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Update log level in $sshd_config_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
####################
# Session settings #
####################

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC009 ] The SUSE operating system must utilize vlock to allow for session locking.
#
err=0
vxsec_id="VXSEC009"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must utilize vlock to allow for session locking."
   zypper -D $fake_zypp_repo search --installed-only --match-exact --provides vlock
   err=$?

   if [ $err != 0 ] ; then
      echo -e "${yellow}Please install kbd to enable session locking.${normal}"

      log_message="REVIEW: Please install kbd to enable session locking"
      LOG $log_title_warn $vuln_id $err $log_message
      ((err=err+$?))
   fi
   
   log_message="The SUSE operating system must utilize vlock to allow for session locking."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC011 ] The SUSE operating system must initiate a session lock after a 15-minute period of inactivity.
# Create/Update autologout.sh
#
err=0
vxsec_id="VXSEC011"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must initiate a session lock after a 15-minute period of inactivity."
   touch $autologout_path
   echo -e "Initiate session lock after 15 minutes in $autologout_path"

   result=$(grep "^TMOUT=" $autologout_path | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "TMOUT=900" >> $autologout_path
      ((err=err+$?))
   else
      sed -i '/^#/!s/TMOUT=.*/TMOUT=900/g' $autologout_path
      ((err=err+$?))
   fi 

   log_message="Add 15-minute timeout to $autologout_path"
   LOG $log_title_info $vuln_id $err $log_message

   # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
   err=0
   result=$(grep "^readonly TMOUT" $autologout_path | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "readonly TMOUT" >> $autologout_path
      ((err=err+$?))

      log_message="Add read-only timeout to $autologout_path"
      LOG $log_title_info $vuln_id $err $log_message
   fi

   # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
   err=0
   result=$(grep "^export TMOUT" $autologout_path | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "export TMOUT" >> $autologout_path
      ((err=err+$?))

      log_message="Add export timeout to $autologout_path"
      LOG $log_title_info $vuln_id $err $log_message
   fi

   # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
   # Update file permissions
   err=0
   chmod +x $autologout_path
   ((err=err+$?))

   log_message="chmod +x $autologout_path"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC014 ] The SUSE operating system must limit the number of concurrent sessions to 10 for all accounts and/or account types.
# Update limits.conf
#
echo -e "Limit concurrent sessions to 10 in $limits_conf"

err=0
vxsec_id="VXSEC014"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must limit the number of concurrent sessions to 10 for all accounts and/or account types."
   touch $limits_conf

   result=$(grep "hard maxlogins" $limits_conf | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "* hard maxlogins 10" >> $limits_conf
      ((err=err+$?))
   else
      sed -i '/hard maxlogins/c\* hard maxlogins 10' $limits_conf
      ((err=err+$?))
   fi

   log_message="Add 10 concurrent session limit to $limits_conf"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
#####################
# Password settings #
#####################
# [ VXSEC021 ] The SUSE operating system must require the change of at least eight (8) of the total number of characters when passwords are changed.
# Add difok=8 in /etc/pam.d/common-password
#
err=0
vxsec_id="VXSEC021"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Update $common_pwd_file to require atleast 8 chars change between old and new password"

   touch $common_pwd_file

   result=$(grep "pam_cracklib.so" $common_pwd_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "password requisite pam_cracklib.so difok=8" >> $common_pwd_file
      ((err=err+$?))
   else
      if [[ $result == *"difok="* ]]; then
         sed -r -i 's/(difok=)[^ ]+/\18/' $common_pwd_file
         ((err=err+$?))
      else
         sed -i "s/pam_cracklib.so/pam_cracklib.so difok=8/g" $common_pwd_file      
         ((err=err+$?))
      fi
   fi

   log_message="Add 8 character change minimum between old and new passwords $common_pwd_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC025 ] The SUSE operating system must configure the Linux Pluggable Authentication Modules (PAM) to only store encrypted representations of passwords.
# Add SHA512 encryption to passwords in /etc/pam.d/common-password
#
echo -e "Enable all account passwords to be hashed with SHA512 in $common_pwd_file"

err=0
vxsec_id="VXSEC025"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must configure the Linux Pluggable Authentication Modules (PAM) to only store encrypted representations of passwords."
   result=$(grep "pam_unix.so" $common_pwd_file | grep -v ^[#])
   if [ -z "$result" ]; then
      echo "password required pam_unix.so sha512" >> $common_pwd_file
      ((err=err+$?))
   else
      newValue=""
      for ii in $result
      do
         if [ "$ii" != sha512 ] && [ "$ii" != nullok ]; then  # Checking for sha512 also so that we can add it explicitly rather than doing
            newValue="$newValue $ii"                          # another grep on newValue and then adding it in
         fi
      done
      newValue="$newValue sha512"
      sed -i "s/$result/$newValue/g" $common_pwd_file
      ((err=err+$?))
   fi

   log_message="Enable all account passwords to be hashed with SHA512 in $common_pwd_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC034 ] The SUSE operating system must prevent the use of dictionary words for passwords.
# 
# Ensure retry=3 is set in /etc/pam.d/common-password
#
err=0
vxsec_id="VXSEC034"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must prevent the use of dictionary words for passwords."
   result=$(grep "pam_cracklib.so" $common_pwd_file | grep -v ^[#])

   retry_value=$(echo $result | grep "retry")
   if [[ -z "$retry_value" ]]; then
      sed -i "s/pam_cracklib.so/pam_cracklib.so retry=3/g" $common_pwd_file
      ((err=err+$?))
   else
      sed -r -i 's/(retry=)[^ ]+/\13/' $common_pwd_file
      ((err=err+$?))
   fi

   log_message="Updated $common_pwd_file to prevent the use of dictionary words for passwords"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC017 ] The SUSE operating system must enforce passwords that contain at least one uppercase character.
#
err=0
vxsec_id="VXSEC017"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must enforce passwords that contain at least one uppercase character."
   result=$(grep "pam_cracklib.so" $common_pwd_file | grep -v ^[#])

   ucredit_value=$(echo $result | grep "ucredit")
   if [[ -z "$ucredit_value" ]]; then
      sed -i "s/pam_cracklib.so/pam_cracklib.so ucredit=-1/g" $common_pwd_file
      ((err=err+$?))
   else
      sed -r -i 's/(ucredit=)[^ ]+/\1-1/' $common_pwd_file
      ((err=err+$?))
   fi

   log_message="Add 1 upper case character minimum requirement in password in $common_pwd_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC018 ] The SUSE operating system must enforce passwords that contain at least one lower-case character.
#
err=0
vxsec_id="VXSEC018"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must enforce passwords that contain at least one lowercase character."
   lcredit_value=$(echo $result | grep "lcredit")
   if [[ -z "$lcredit_value" ]]; then
      sed -i "s/pam_cracklib.so/pam_cracklib.so lcredit=-1/g" $common_pwd_file
      ((err=err+$?))
   else
      sed -r -i 's/(lcredit=)[^ ]+/\1-1/' $common_pwd_file
      ((err=err+$?))
   fi

   log_message="Add 1 lower case character minimum requirement in password in $common_pwd_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------ 
# [ VXSEC019 ] The SUSE operating system must enforce passwords that contain at least one numeric character.
#
err=0
vxsec_id="VXSEC019"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must enforce passwords that contain at least one numeric character."
   dcredit_value=$(echo $result | grep "dcredit")
   if [[ -z "$dcredit_value" ]]; then
      sed -i "s/pam_cracklib.so/pam_cracklib.so dcredit=-1/g" $common_pwd_file
      ((err=err+$?))
   else
      sed -r -i 's/(dcredit=)[^ ]+/\1-1/' $common_pwd_file
      ((err=err+$?))
   fi

   log_message="Add 1 numeric character minimum requirement in password in $common_pwd_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC020 ] The SUSE operating system must enforce passwords that contain at least one special character.
#
err=0
vxsec_id="VXSEC020"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must enforce passwords that contain at least one special character."
   ocredit_value=$(echo $result | grep "ocredit")
   if [[ -z "$ocredit_value" ]]; then
      sed -i "s/pam_cracklib.so/pam_cracklib.so ocredit=-1/g" $common_pwd_file
      ((err=err+$?))
   else
      sed -r -i 's/(ocredit=)[^ ]+/\1-1/' $common_pwd_file
      ((err=err+$?))
   fi

   log_message="Add 1 special character minimum requirement in password in $common_pwd_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC026 ] The SUSE operating system must employ FIPS 140-2-approved cryptographic hashing algorithms for all stored passwords.
# Update SHA_CRYPT_MIN_ROUNDS and SHA_CRYPT_MAX_ROUNDS values
#

err=0
vxsec_id="VXSEC026"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Encrypt all passwords with strong cryptographic hash in file $login_defs"
   touch $login_defs
   stigRuleMinVal=5000

   lines=$(egrep "SHA_CRYPT_(MIN|MAX)_ROUNDS *[0-9]* *$" $login_defs | grep -v "^#")

   #if there are no entries add new entries
   if [ -z "$lines" ]; then
      echo "SHA_CRYPT_MIN_ROUNDS   5000" >> $login_defs
      ((err=err+$?))
   else
      # if there are entries check if SHA_CRYPT values are more than 5000 if not make them 5000
      echo "$lines" | while read line
      do
         set -- ${line}
         checkvar=$1
         checkval=$2
         if [ $checkval -lt 5000 ] ; then
            sed -i "s/^\s*${checkvar}.*$/${checkvar} ${stigRuleMinVal}/g" $login_defs
            ((err=err+$?))
         fi
         set --
      done
   fi

   log_message="The SUSE operating system must employ FIPS 140-2-approved cryptographic hashing algorithms for all stored passwords."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC027 ] The SUSE operating system must employ passwords with a minimum of 15 characters.
# Update minimum length for password
#
err=0
vxsec_id="VXSEC027"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Enforce minimum length of password to be 15 in $common_pwd_file"

   result=$(grep "pam_cracklib.so" $common_pwd_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "password requisite pam_cracklib.so minlen=15" >> $common_pwd_file
      ((err=err+$?))
   else
      if [[ $result == *"minlen="* ]]; then
         sed -r -i 's/(minlen=)[^ ]+/\115/' $common_pwd_file
         ((err=err+$?))
      else
         sed -i "s/pam_cracklib.so/pam_cracklib.so minlen=15/g" $common_pwd_file
         ((err=err+$?))
      fi
   fi
   # Modify /opt/vmware/etc/isv/subsequentboot
   # This block applies to only VxM versions below 4.7.520 or those systems upgraded from below 4.7.520
   if [ $vxrail_major_version == "4" ] ; then
      if [ -f $subseqbootfile ] ; then
         sed -i 's@grep '\''pam_cracklib\\.so'\''$'\''\\tucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1 difok=8'\'' /etc/pam.d/common-password 1>/dev/null@grep '\''pam_cracklib\\.so'\'' /etc/pam.d/common-password 2>/dev/null | grep '\''ucredit=-1'\'' 2>/dev/null | grep '\''lcredit=-1'\'' 2>/dev/null | grep '\''dcredit=-1'\'' 2>/dev/null | grep '\''ocredit=-1'\'' 2>/dev/null | grep '\''difok=8'\'' 2>/dev/null | grep '\''minlen=15'\'' >/dev/null 2>\&1@' $subseqbootfile
         ((err=err+$?))
         sed -i 's/pam_cracklib.so\\tucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1 difok=8/pam_cracklib.so\\tminlen=15 ocredit=-1 dcredit=-1 lcredit=-1 ucredit=-1 difok=8/' $subseqbootfile
         ((err=err+$?))
         log_message="Modify $subseqbootfile to ensure the content in /etc/pam.d/common-password is preserved"
         LOG $log_title_info $vuln_id $err $log_message
      else
         log_message="No change to $subseqbootfile (file does not exist)"
         LOG $log_title_info $vuln_id 0 $log_message
      fi
   fi

   log_message="The SUSE operating system must employ passwords with a minimum of 15 characters"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC028 ] The SUSE operating system must be configured to create or update passwords with a minimum lifetime of 24 hours (1 day).
# Update value of PASS_MIN_DAYS and PASS_MAX_DAYS
#

err=0
vxsec_id="VXSEC028"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Enforce minimum and maximum age of passwords in $login_defs"

   sed -i '/PASS_MIN_DAYS/d' $login_defs
   ((err=err+$?))

   result=$(grep "^PASS_MIN_DAYS" $login_defs | grep -v ^[#])
   if [[ -z "$result" ]]; then
         echo "PASS_MIN_DAYS  1" >> $login_defs
         ((err=err+$?))
      else
         sed -i '/^#/!s/PASS_MIN_DAYS.*/PASS_MIN_DAYS  1/g' $login_defs
         ((err=err+$?))
   fi

   log_message="Add minimum password age of 1 day in $login_defs"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC030 ] The SUSE operating system must employ user passwords with a maximum lifetime of 60 days.
#
err=0
vxsec_id="VXSEC030"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must be configured to create or update passwords with a maximum lifetime of 60 days."
   sed -i '/PASS_MAX_DAYS/d' $login_defs
   ((err=err+$?))

   result=$(grep "^PASS_MAX_DAYS" $login_defs | grep -v ^[#])
   if [[ -z "$result" ]]; then
         echo "PASS_MAX_DAYS  60" >> $login_defs
         ((err=err+$?))
      else
         sed -i '/^#/!s/PASS_MAX_DAYS.*/PASS_MAX_DAYS  60/g' $login_defs
         ((err=err+$?))
   fi

   log_message="Add maximum password age of 60 days in $login_defs"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC060 ] The SUSE operating system default permissions must be defined in such a way that all authenticated users can only read and modify their own files.
#
err=0
vxsec_id="VXSEC060"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system default permissions must be defined in such a way that all authenticated users can only read and modify their own files."
   result=$(grep "^UMASK" $login_defs | grep -v ^[#])
   if [ -z "$result" ]; then
      echo "UMASK   077" >> $login_defs
      ((err=err+$?))
   else
      sed -i '/^#/!s/UMASK.*/UMASK   077/g' $login_defs
      ((err=err+$?))
   fi

   log_message="Add UMASK 077 in $login_defs"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC032 ] The SUSE operating system must employ a password history file.
#
# Create or update timestamps of password history file
#

err=0
vxsec_id="VXSEC032"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Create/update password history file"

   touch $opasswd_file; ((err=err+$?))
   chown root:root $opasswd_file; ((err=err+$?))
   chmod 0600 $opasswd_file; ((err=err+$?))

   log_message="Create/update password history file $opasswd_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC033 ] The SUSE operating system must not allow passwords to be reused for a minimum of five (5) generations.
#
err=0
vxsec_id="VXSEC033"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Prohibit reuse of password for at least 5 generations"

   result=$(grep "pam_pwhistory.so" $common_pwd_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "password requisite pam_pwhistory.so remember=5 use_authtok" >> $common_pwd_file
      ((err=err+$?))
   else
      newValue=""
      for ii in $result
      do
         if [[ "$ii" != *"remember"* ]] && [[ "$ii" != use_authtok ]]; then
            newValue="$newValue $ii"                          
         fi
      done
      newValue="$newValue remember=5 use_authtok"
      sed -i "s/$result/$newValue/g" $common_pwd_file
      ((err=err+$?))
   fi

   log_message="Prohibit reuse of password for at least 5 generations"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC036 ] The SUSE operating system must disable account identifiers (individuals, groups, roles, and devices) after 35 days of inactivity after password expiration.
# Disable accounts after 35 days of password expiry
#
err=0
vxsec_id="VXSEC036"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Disable accounts after 35 days of password expiry"

   useradd -D -f 35
   ((err=err+$?))

   log_message="Disable accounts after 35 days of password expiry"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC197 ] The SUSE operating system must not be configured to allow blank or null passwords.
# Remove nullok options from files in /etc/pam.d/
#
err=0
vxsec_id="VXSEC197"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not be configured to allow blank or null passwords."
   pamd_files=$(find /etc/pam.d/ -type f)

   for ii in $pamd_files
   do
      sed -i 's/nullok //g' $ii
      ((err=err+$?))

      log_message="Remove nullok in $ii"
      LOG $log_title_info $vuln_id $err $log_message
   done
fi

# ------------------------------------------------------------------------------------------------------------------
################
# SSH settings #
################

# [ VXSEC161 ] The SUSE operating system must display the Standard Mandatory DoD Notice and Consent Banner before granting access via SSH.
#
err=0
vxsec_id="VXSEC161"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Enable displaying standard DoD notice before granting access via SSH in $sshd_config_file"

   touch $sshd_config_file

   sed -i '/Banner/d' $sshd_config_file
   ((err=err+$?))

   result=$(grep "^Banner" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "Banner /etc/issue" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/Banner.*/Banner \/etc\/issue/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Enable displaying standard DoD notice before granting access via SSH in $sshd_config_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC167 ] The SUSE operating system must implement DoD-approved encryption to protect the confidentiality of SSH remote connections
#
err=0
vxsec_id="VXSEC167"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Update list of allowed ciphers in $sshd_config_file"

   result=$(grep "^Ciphers" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "Ciphers aes256-ctr,aes192-ctr,aes128-ctr" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/Ciphers.*/Ciphers aes256-ctr,aes192-ctr,aes128-ctr/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Update list of allowed ciphers in $sshd_config_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC168 ] The SUSE operating system SSH daemon must be configured to only use Message Authentication Codes (MACs) 
# employing FIPS 140-2 approved cryptographic hash algorithms.
#
err=0
vxsec_id="VXSEC168"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Update list of allowed MACs in $sshd_config_file"

   result=$(grep "^MACs" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "MACs hmac-sha2-512,hmac-sha2-256" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/MACs.*/MACs hmac-sha2-512,hmac-sha2-256/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Update list of allowed MACs in $sshd_config_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC169 ] The SUSE operating system SSH daemon must be configured with a timeout interval.
# Update ClientAliveInterval to 10 minutes.
# NOTE: NDM rule V-202074 states same but requires 5 minutes. The rule will apply the stricter 5 minutes timeout.
#
err=0
vxsec_id="VXSEC169"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system SSH daemon must be configured with a timeout interval"

   # Rule variables
   vuln_title='The SUSE operating system SSH daemon must be configured with a timeout interval'
   file_name=$sshd_config_file
   param_name="ClientAliveInterval"
   param_sep=" "
   param_reqd_val="300"

   replaceParamInFile "$vuln_id" "$vuln_title" "$file_name" "$param_name" "$param_sep" "$param_reqd_val"
   result=$?
   if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC170 ] The SUSE operating system SSH daemon must be configured to not allow authentication using known hosts authentication.
# Update IgnoreUserKnownHosts
#
err=0
vxsec_id="VXSEC170"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Do not allow SSH daemon to authenticate using known hosts authentication"

   sed -i '/IgnoreUserKnownHosts/d' $sshd_config_file
   ((err=err+$?))

   result=$(grep "^IgnoreUserKnownHosts" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "IgnoreUserKnownHosts yes" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/IgnoreUserKnownHosts.*/IgnoreUserKnownHosts yes/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Disallow SSH daemon to authenticate using known hosts authentication"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC174 ] The SUSE operating system SSH daemon must use privilege separation.
# Update UsePrivilegeSeparation
#
err=0
vxsec_id="VXSEC174"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Enable SSH daemon to use privilege separation"

   sed -i '/UsePrivilegeSeparation/d' $sshd_config_file
   ((err=err+$?))

   result=$(grep "^UsePrivilegeSeparation" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "UsePrivilegeSeparation yes" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/UsePrivilegeSeparation.*/UsePrivilegeSeparation yes/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Enable SSH daemon to use privilege separation"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC176 ] The SUSE operating system SSH daemon prevents remote hosts from connecting to the proxy display.
# Update X11UseLocalhost
#
err=0
vxsec_id="VXSEC176"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system SSH daemon must prevent remote hosts from connecting to the proxy display"

   sed -i '/X11UseLocalhost/d' $sshd_config_file
   ((err=err+$?))

   result=$(grep "^X11UseLocalhost" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "X11UseLocalhost yes" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/X11UseLocalhost.*/X11UseLocalhost yes/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system SSH daemon must prevent remote hosts from connecting to the proxy display"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC198 ] The SUSE operating system for all network connections associated with SSH traffic must immediately terminate at the end of the session or after 10 minutes of inactivity.
# ClientAliveInterval 600 in $sshd_config_file is ensured with VXSEC169
# Update ClientAliveCountMax
# Restart sshd.service is done later under VXP-43177
#
err=0
vxsec_id="VXSEC198"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Enable termination of all network connections after 10 mins of inactivity in $sshd_config_file"

   sed -i '/ClientAliveCountMax/d' $sshd_config_file
   ((err=err+$?))
   
   result=$(grep "^ClientAliveCountMax" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "ClientAliveCountMax $vuln_optval" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/ClientAliveCountMax.*/ClientAliveCountMax $vuln_optval/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Enable termination of all network connections after 10 mins of inactivity in $sshd_config_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC164 ] The SUSE operating system must display the date and time of the last successful account logon upon an SSH logon.
#
err=0
vxsec_id="VXSEC164"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must display the date and time of the last successful account logon upon an SSH logon."
   sed -i '/PrintLastLog/d' $sshd_config_file
   ((err=err+$?))

   result=$(grep "^PrintLastLog" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "PrintLastLog yes" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/PrintLastLog.*/PrintLastLog yes/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Enable display of the date and time of the last successful account logon upon an SSH logon"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC166 ] The SUSE operating system must not allow automatic logon via SSH.
# This rule implementes multiple vulns for SLES12 platform (it includes vuln of former vxsec204).
#
err=0
vxsec_id="VXSEC166"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not allow unattended or automatic logon via SSH."
   # Do not allow *automatic* logon via SSH
   sed -i '/PermitEmptyPasswords/d' $sshd_config_file
   ((err=err+$?))

   result=$(grep "^PermitEmptyPasswords" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "PermitEmptyPasswords no" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/PermitEmptyPasswords.*/PermitEmptyPasswords no/g' $sshd_config_file
      ((err=err+$?))
   fi

   # Do not allow *unattended* logon via SSH
   sed -i '/PermitUserEnvironment/d' $sshd_config_file
   ((err=err+$?))

   result=$(grep "^PermitUserEnvironment" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "PermitUserEnvironment no" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/PermitUserEnvironment.*/PermitUserEnvironment no/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Disallow automatic and unattended logons via SSH"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC173 ] The SUSE operating system SSH daemon must perform strict mode checking of home directory configuration files.
#
err=0
vxsec_id="VXSEC173"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system SSH daemon must perform strict mode checking of home directory configuration files."
   sed -i '/StrictModes/d' $sshd_config_file
   ((err=err+$?))

   result=$(grep "^StrictModes" $sshd_config_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "StrictModes yes" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/StrictModes.*/StrictModes yes/g' $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Add strict mode in $sshd_config_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC175 ] The SUSE operating system SSH daemon must not allow compression or must only allow compression after successful authentication.
# VXP-70652 - Rule deprecated since SLES15 STIG V1R10. No longer mapped in mapping table.
#
err=0
vxsec_id="VXSEC175"
comprValue="delayed" # VXP-41752
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system SSH daemon must not allow compression or must only allow compression after successful authentication."
   result=$(grep -i "^\s*Compression\s" $sshd_config_file)

   if [[ -z "$result" ]]; then
      echo "Compression $comprValue" >> $sshd_config_file
      ((err=err+$?))
   else
      sed -i "s/^\s*Compression\s.*$/Compression $comprValue/ig" $sshd_config_file
      ((err=err+$?))
   fi

   log_message="Disallow compression or must only allow compression after successful authentication"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
#################
# Misc settings #
#################

# [ VXSEC064 ] If Network Security Services (NSS) is being used by the SUSE operating system it must prohibit the use of cached authentications after one day.
# Update memcache time out
#
err=0
vxsec_id="VXSEC064"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Prohibit use of cached authentications after one day in $sssd_conf_file"

   touch $sssd_conf_file

   result=$(grep "^\[nss\]" $sssd_conf_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      cat <<EOT >> $sssd_conf_file
[nss]
memcache_timeout=86400
EOT
      ((err=err+$?))
   else
      result=$(grep "^memcache_timeout" $sssd_conf_file | grep -v ^[#])
      if [[ -z "$result" ]]; then
      # Insert after [nss]
      sed -i '/\[nss\]/a memcache_timeout=86400' $sssd_conf_file
      ((err=err+$?))
      else
      sed -i '/^#/!s/memcache_timeout=.*/memcache_timeout=86400/g' $sssd_conf_file
      ((err=err+$?))
      fi
   fi

   log_message="Prohibit use of cached authentications after one day in $sssd_conf_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC065 ] Prohibit the use of cached off line authentications after one day
#
err=0
vxsec_id="VXSEC065"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Prohibit the use of cached off line authentications after one day in $sssd_conf_file"

   result=$(grep "^\[pam\]" $sssd_conf_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      cat <<EOT >> $sssd_conf_file
[pam]
offline_credentials_expiration=1
EOT
      ((err=err+$?))
   else
      result=$(grep "^offline_credentials_expiration" $sssd_conf_file | grep -v ^[#])
      if [[ -z "$result" ]]; then
      # Insert after [pam]
      sed -i '/\[pam\]/a offline_credentials_expiration=1' $sssd_conf_file
      ((err=err+$?))
      else
      sed -i '/^#/!s/offline_credentials_expiration=.*/offline_credentials_expiration=1/g' $sssd_conf_file
      ((err=err+$?))
      fi
   fi

   log_message="Prohibit the use of cached off line authentications after one day in $sssd_conf_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC056 ] The SUSE operating system must disable the USB mass storage kernel module.
#
# Disable usage of USB devices
# Create file if it does not exist
err=0
vxsec_id="VXSEC056"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Disable usb storage from automounting when connected to host"

   if [[ -e $blacklist_conf_file ]]; then
      sed -i '/usb-storage/d' $blacklist_conf_file
      ((err=err+$?))
      echo "blacklist usb-storage" >> $blacklist_conf_file 
      ((err=err+$?))
   else
      echo "blacklist usb-storage" > $blacklist_conf_file
      ((err=err+$?))
   fi

   log_message="Disable USB storage from automounting when connected to host"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC054 ] The SUSE operating system tool zypper must have gpgcheck enabled.
# Update gpgcheck in /etc/zypp.conf
#
err=0
vxsec_id="VXSEC054"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Updating gpgcheck in $zypp_conf"

   touch $zypp_conf

   sed -i '/gpgcheck/d' $zypp_conf
   ((err=err+$?))

   result=$(grep "^gpgcheck" $zypp_conf | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "gpgcheck = 1" >> $zypp_conf
      ((err=err+$?))
   else
      sed -i '/^#/!s/gpgcheck.*/gpgcheck = 1/g' $zypp_conf
      ((err=err+$?))
   fi

   log_message="Enable gpgcheck in $zypp_conf"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC055 ] The SUSE operating system must remove all outdated software components after updated versions have been installed.
#
err=0
vxsec_id="VXSEC055"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must remove all outdated software components after updated versions have been installed."
   # Remove outdated software components
   sed -i '/upgraderemovedroppedpackages/d' $zypp_conf
   ((err=err+$?))
   result=$(grep -i "upgraderemovedroppedpackages" $zypp_conf | grep -v ^[#])
   if [ -z "$result" ]; then
      echo "solver.upgradeRemoveDroppedPackages = true" >> $zypp_conf
      ((err=err+$?))
   else
      sed -i "s/$result/solver.upgradeRemoveDroppedPackages = true/g" $zypp_conf
      ((err=err+$?))
   fi

   log_message="Setting 'solver.upgradeRemoveDroppedPackages = true in' $zypp_conf"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC057 ] The SUSE operating system must disable the file system automounter unless required.
# Disable file system automounter
#
err=0
vxsec_id="VXSEC057"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Disabling file system automounter"

   zypper -D $fake_zypp_repo info autofs | grep -i "^installed *: *yes"
   res=$?

   if [ $res -eq 0 ]; then
      systemctl stop autofs >/dev/null 2>&1
      ((err=err+$?))

      log_message="systemctl stop autofs"
      LOG $log_title_info $vuln_id $err $log_message

      #  . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
      err=0
      systemctl disable autofs >/dev/null 2>&1
      ((err=err+$?))

      log_message="systemctl disable autofs"
      LOG $log_title_info $vuln_id $err $log_message
   else
      log_message="File system automounter package autofs wasn't found, so disabling autofs was skipped"
      LOG $log_title_info $vuln_id $err $log_message
   fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC177 ] The SUSE operating system clock must, for networked systems, be synchronized to an authoritative DoD time source at least every 24 hours.
# Synchronize OS to an authoritative DoD time source
#
err=0
vxsec_id="VXSEC177"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then
   ntp_conf=$vuln_optval
   echo -e "Synchronize OS to an authoritative DoD time source in $ntp_conf"

   if [[ $vxrail_major_version == "4" ]]; then
      ntp_server_csv=$(psql -U postgres marvin -tc 'select ntp_server_csv from cluster_properties')
   elif [[ $vxrail_major_version == "7" ]]; then
      ntp_server_csv=$(sudo /mystic/stig/info 2>/dev/null | grep ntp_server | grep -v none | cut -d':' -f2)
   fi
   ntp_server_csv=$(echo $ntp_server_csv | sed -e 's/[[:space:]]//')

   # we may have 2 ip's, separated by a comma (and optional whitespace)
   # check if we found a value (ie length > 0 chars long)
   if [[ ${#ntp_server_csv} -gt 0 ]]; then
      ntps_found='yes'
      echo -e "The following NTP server was found in the system configuration: $ntp_server_csv"
      askEnterOrOptionAction 'c' 'change'
      change_server=$answer
   else
      ntps_found='no'
      change_server="c"
   fi

   # At this point this is the truth table with possible scenarios:
   # ---+-------+---------+---------------------------------------------
   #    | ntp-    change- |
   # nr | found   server  | scenario
   # ---+-------+---------+---------------------------------------------
   #  1 |   0   |    0    | Not possible.
   #  2 |   0   |    1    | Enforce setting NTP IPs for the first time
   #  3 |   1   |    0    | User wants to accept the found IPs as-is
   #  4 |   1   |    1    | User wants to change existing NTP IPs
   # ---+-------+---------+---------------------------------------------
   #
   if [ "x$change_server" != "xc" ] && [ "$ntps_found" == "yes" ]; then
      # scenario 3:
      # found NTP, user wants to accept the found IPs as-is; don't ask for IP addresses
      echo -e "${yellow}Existing NTP IP(s) accepted as-is${normal}"

      # Still need to do maxpoll checking:
      # SET primary and (optionally) secondary NTP IP addresses from the retrieved NTP IPs
      # Append a comma to ensure cut -f2 returns empty string if only one IP is in the source string
        primary_ip=$(echo $ntp_server_csv,|cut -d',' -f1)
      secondary_ip=$(echo $ntp_server_csv,|cut -d',' -f2) # will be empty string if only 1 IP was retrieved
   else
      # scenarios 2 and 4:
      # GET primary and secondary NTP IP addresses
      # (pass in the type (prim/sec) of the IP and the variable to return the obtained IP address in)
      get_ip 'primary'   primary_ip
      get_ip 'secondary' secondary_ip
   fi

   # first make backup of original file
   # (pass in the original filename and the variable to return the generated backup filename in)
   backup_file $ntp_conf ntp_conf_bak

   # keep track if NTP configuration failed so we can flag that later
   NTP_setting_failed=0

   # now check all server IPs in the ntp conf file:
   # (1) if a server IP is found which is same as one of the new IPs then ensure maxpoll 16
   # (2) remove old/different server IPs from the file
   serverlines=$(grep "^[[:blank:]]*server " $ntp_conf) # get the set of lines to check

   echo "$serverlines" | while IFS= read -r line
   do
      # continue if empty line - occurs if ntp conf file has no ips yet
      if [ -z "$line" ]; then continue; fi

      # get the ip address which is the 2nd positional parameter on the line
      set $line; ip=$2

      if [ "x$ip" == "x$primary_ip" ] || [ "x$ip" == "x$secondary_ip" ]
      then
         # (1) IP address already in ntp conf file; ensure maxpoll value
         maxpoll_result=$(echo "$line" | grep maxpoll)
         if [[ -z "$maxpoll_result" ]]; then
            # no maxpoll set yet; set (append) it now
            sed -i "s/^${line}$/$line maxpoll 16/g" $ntp_conf
            ((err=err+$?))
         else
            # maxpoll was set; ensure its set to 16, keeping rest of line intact
            # create changed line
            newline=$(echo "$line" | sed 's/maxpoll[[:blank:]]*[[:digit:]]*/maxpoll 16/')
            ((err=err+$?))
            # swap original line for changed line
            sed -i "s/^${line}$/$newline/" $ntp_conf
            ((err=err+$?))
         fi
      else
         # (2) old/different address found; remove from the file
         sed -i "/^${line}$/d" $ntp_conf
         ((err=err+$?))
      fi
   done

   # ensure both new ips are in the file now
   check_append_ntp_server $primary_ip
   if [ ! -z $secondary_ip ]; then check_append_ntp_server $secondary_ip; fi

   # if all good then update the cluster_properties
   if [ $err -eq 0 ]
   then
      if [ $vxrail_major_version == "4" ]
      then
         # Also update the value in the cluster_properties table in marvin database
         # Create the ip address list (csv format)
         ip_address=$primary_ip
         if [ ! -z $secondary_ip ]; then ip_address="${ip_address},${secondary_ip}"; fi
         # Update the database
         psql -U postgres marvin -qc "update cluster_properties set ntp_server_csv='$ip_address'"
         # Confirm in output
         printf "Updated NTP server IP's in system configuration to: "
         psql -U postgres marvin -tc 'select ntp_server_csv from cluster_properties'
      fi
   fi

   if [ $err -gt 0 ]
   then
      # something failed
      NTP_setting_failed=1
      NTP_setting_vulnid=$vuln_id
      echo -e "${red}Setting NTP configuration failed.${normal}"
      # restore file
      echo -e "${yellow}- Restoring original NTP file ($ntp_conf)${normal}"
      mv -f $ntp_conf_bak $ntp_conf
      if [ $vxrail_major_version == "4" ]
      then
         # restore cluster_properties table in database
         echo -e "${yellow}- Restoring original NTP value ($ntp_server_csv) in cluster properties${normal}"
         psql -U postgres marvin -qc "update cluster_properties set ntp_server_csv='$ntp_server_csv'"
      fi
   fi
   echo

   log_message="Synchronize OS to an authoritative DoD time source (ntp $ip_address)"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC181 ] The SUSE operating system must off-load rsyslog messages for networked systems in real time and off-load standalone systems at least weekly.
# Off-load rsyslog messages in real time
#
err=0
vxsec_id="VXSEC181"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Off-load rsyslog messages"

   if [[ $vxrail_major_version == "4" ]]; then
      ip_address=$(psql -U postgres marvin -t -c 'select syslog_server_csv from cluster_properties')
   elif [[ $vxrail_major_version == "7" ]]; then
      ip_address=$(sudo /mystic/stig/info 2>/dev/null | grep syslog_server | grep -v none | cut -d':' -f2)
   fi
   ip_address=$(echo $ip_address | sed -e 's/[[:space:]]//')

   if [[ ${#ip_address} -gt 0 ]]; then
      echo -e "The following syslog server was found in the system configuration: $ip_address"
      askEnterOrOptionAction 'c' 'change'
      change_server=$answer
   else
      change_server="c"
   fi

   if [[ $change_server -eq "c" ]]; then
      printf "${yellow}Enter the IP address of the rsyslog server where the logs should be off-loaded${normal}: "
      read ip_address
   fi

   touch $rsyslog_conf
   ((err=err+$?))

   result=$(grep "*.* @@$ip_address:514" $rsyslog_conf | grep -v ^[#] )
   if [[ -z "$result" ]]; then
      echo -e "\n*.* @@$ip_address:514" >> $rsyslog_conf
      ((err=err+$?))
   fi

   log_message="Off-load rsyslog messages for networked systems in real time"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
##################
# Audit settings #
##################

# [ VXSEC096 ] The SUSE operating system audit event multiplexor must be configured to use Kerberos.
# Enable krb5
#
err=0
vxsec_id="VXSEC096"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Enable krb5 in $audisp_remote_conf"

   touch $audisp_remote_conf # Create file if it does not exist
   ((err=err+$?))

   sed -i '/enable_krb5/d' $audisp_remote_conf
   ((err=err+$?))

   result=$(grep "^enable_krb5" $audisp_remote_conf | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "enable_krb5 = yes" >> $audisp_remote_conf
      ((err=err+$?))
   else
      sed -i '/^#/!s/enable_krb5.*/enable_krb5 = yes/g' $audisp_remote_conf
      ((err=err+$?))
   fi

   log_message="Enable krb5 in $audisp_remote_conf"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC097 ] Audispd must off-load audit records onto a different system or media from the SUSE operating system being audited.
#
err=0
vxsec_id="VXSEC097"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Enable off-loading audit records to server in $audisp_remote_conf"

   # find the remote_server entry and extract the assigned IP
   searchExpr="^\s*remote_server\s*=\s*"
   result=$(sed -n "s/$searchExpr//p" $audisp_remote_conf)

   # check if we found a value
   if [ ! -z $result ]; then
      ip_found='yes'
      echo -e "${yellow}The following remote server IP was found in the $audisp_remote_conf file: '$result'${normal}"
      askEnterOrOptionAction 'c' 'change'
      change_server=$answer
   else
      ip_found='no'
      echo -e "${red}There is no remote server IP set in the $audisp_remote_conf file${normal}"
      change_server='c'
   fi

   if [ "x$change_server" != "xc" ]; then
      echo -e "${yellow}Existing setting accepted as-is${normal}"
      log_message="Leaving audispd remote server unchanged, at: $result"
      LOG $log_title_info $vuln_id 0 $log_message
   else
      # change the server IP - ask user to input the IP

      ipValid=0
      while [ $ipValid -eq 0 ]; do

         printf "${yellow}Enter the IP address of the remote server where the audit logs should be off-loaded${normal}: "
         read ip_address

         if [ -z $ip_address ]; then
            # Accept empty IP
            ipValid=1
         else
            # Validate given IP
            if ! validate_ip $ip_address
            then
               echo -e "${red}Invalid IP Address format ($ip_address)${normal}"
            else
               #Valid IP Address
               if ! ping_ip $ip_address
               then
                  echo -e "${red}IP ($ip_address) cannot be pinged${normal}"
               else
                  # given IP is valid and pingable
                  ipValid=1
               fi
            fi
         fi
      done

      if [ "$ip_found" == "no" ]; then
         # parameter wasnt in file yet - append it
         log_message="Setting new audispd remote server to user input: $ip_address"
         LOG $log_title_info $vuln_id 0 $log_message

         echo "remote_server = $ip_address" >> $audisp_remote_conf
         ((err=err+$?))
      else
         # parameter was already in file - replace it
         log_message="Replacing audispd remote server with user input: $ip_address"
         LOG $log_title_info $vuln_id 0 $log_message

         sed -i "s/${searchExpr}.*$/remote_server = $ip_address/g" $audisp_remote_conf
         ((err=err+$?))
      fi
   fi

   log_message="Audispd must off-load audit records onto a different system or media from the SUSE operating system being audited."
   LOG $log_title_info $vuln_id $err $log_message

   #  . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
   err=0

   result=$(grep "^port = " $audisp_remote_conf)
   if [[ -z "$result" ]]; then
      echo "port = 514" >> $audisp_remote_conf
      ((err=err+$?))
   else
      sed -i 's/^port.*/port = 514/g' $audisp_remote_conf
      ((err=err+$?))
   fi

   log_message="Set port number on audit logs remote server"
   LOG $log_title_info $vuln_id $err $log_message

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC098 ] Update network failure action
#
err=0
vxsec_id="VXSEC098"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Update network failure action in $audisp_remote_conf"

   sed -i '/network_failure_action/d' $audisp_remote_conf
   ((err=err+$?))

   result=$(grep "^network_failure_action" $audisp_remote_conf | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "network_failure_action = syslog" >> $audisp_remote_conf
      ((err=err+$?))
   else
      sed -i '/^#/!s/network_failure_action.*/network_failure_action = syslog/g' $audisp_remote_conf
      ((err=err+$?))
   fi

   log_message="Update network failure action in $audisp_remote_conf"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC091 ] Auditd must notify security personnel when storage volume reaches 75 percent utilization.
# Update space_left number in $auditd_conf
#
err=0
vxsec_id="VXSEC091"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Update space_left number in $auditd_conf"

   space_25_percent=$(expr $(expr $(df -BM  /var/log/audit | tail -1 | tr -s ' ' | cut -d' ' -f2 | sed 's/M//gi') + 3) / 4)
   ((err=err+$?))

   space_left=$(grep -iw space_left $auditd_conf | tr -s ' ' | awk -F' ' '{ print $3 }')
   ((err=err+$?))

   # Logic and set log_message
   if [[ -z "$space_left" ]]; then
      echo "space_left = $space_25_percent" >> $auditd_conf
      log_message="Update space_left = $space_25_percent in $auditd_conf"
      ((err=err+$?))
   elif [[ $space_25_percent -gt $space_left ]]; then
      sed -i "s/^[[:space:]]*space_left[[:space:]]*=[[:space:]]*[[:digit:]]*[[:space:]]*$/space_left = $space_25_percent/g" $auditd_conf
      log_message="Update space_left = $space_25_percent in $auditd_conf"
      ((err=err+$?))
   else
      log_message="Setting of space_left in $auditd_conf is already equal or greater 25% of total space"
   fi

   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC093 ] The Information System Security Officer (ISSO) and System Administrator (SA), at a minimum, 
#              must have mail aliases to be notified of a SUSE operating system audit processing failure.
#
err=0
vxsec_id="VXSEC093"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval


if [ $? -eq $VID_MAP_OK ] ; then

   echo "Configure the auditd service to notify the administrators in the event of a SUSE operating system audit processing failure."

   # first extract any existing root email value from the aliases file
   email_address=$(egrep "^[[:space:]]*root[[:space:]]*:" $aliases|tail -1|xargs|sed 's/^root: //')

   # Prompt user if this value needs to be changed
   if [ ! -z "$email_address" ]; then
      email_found="yes"
      echo -e "The following email was found in the system configuration: $email_address"
      askEnterOrOptionAction 'c' 'change'
      change_answer=$answer
   else
      email_found="no"
      change_answer="c"
   fi

   # At this point this is the truth table with possible scenarios:
   # ---+-------+--------+---------------------------------------------
   #    | value   change |
   # nr | found   answer | scenario
   # ---+-------+--------+---------------------------------------------
   #  1 |   0   |    0   | Not possible.
   #  2 |   0   |    1   | Enforce setting value for the first time
   #  3 |   1   |    0   | User wants to accept the found value as-is
   #  4 |   1   |    1   | User wants to change existing value
   # ---+-------+--------+---------------------------------------------
   
   if [ "x$change_answer" != "xc" ] && [ "$email_found" == "yes" ]; then
      # scenario 3:
      # found email, user wants to accept the found value as-is; don't ask for new value
      echo -e "${yellow}Existing email accepted as-is${normal}"
   else
      # scenarios 2 and 4:
      # prompt for a new/replacement value

      res=1 # prompt until the email validation is successful
      until [ $res -eq 0 ]
      do
         echo -en "${yellow}Enter the email address where administrators should be notified${normal}: "
         read email_address

         if [ -z $email_address ]; then
            # Does the user want to leave it blank (i.e. enter it later manually)?
            leave_blank=x
            until [[ $leave_blank = [YyNn] ]]
            do
               echo -e "${yellow}If the email address is left blank, it must be set manually after the hardening session (in $aliases)${normal}"
               echo -en "${yellow}Leave the email address blank (y/n)?${normal} "
               read leave_blank
            done
            if [[ $leave_blank = [Yy] ]]; then
               vxsec093_incorrect_email=1
               email_address="TBD_email_address@some_domain.com"
               res=0 # leave the until loop
            else
               vxsec093_incorrect_email=0
            fi
         else
            validate_email $email_address
            res=$?
         fi
      done

      # Apply change to the aliases file
      # Extract the relevant line
      root_line=$(egrep "^[[:space:]]*root[[:space:]]*:" $aliases|tail -1)
      if [[ -z $root_line ]]; then
         # not found - append
         echo "root: $email_address" >> $aliases
         ((err=err+$?))
      else
         # found - replace
         sed -i "s/^${root_line}$/root: $email_address/" $aliases
         ((err=err+$?))
      fi

      # reload
      newaliases
      ((err=err+$?))
   fi
   ((err=err+$?))
   sudo newaliases
   ((err=err+$?))

   log_message="The Information System Security Officer (ISSO) and System Administrator (SA), at a minimum, must have mail aliases to be notified of a SUSE operating system audit processing failure"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC094 ] Auditd must take appropriate action when the SUSE operating system audit storage is full.
# Update disk full action in $auditd_conf
#
err=0
vxsec_id="VXSEC094"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Update disk full action in $auditd_conf"

   result=$(grep "disk_full_action" $auditd_conf)

   if [[ -z "$result" ]]; then
      echo "disk_full_action = syslog" >> $auditd_conf
      ((err=err+$?))
   else
      sed -i 's/^.*disk_full_action.*$/disk_full_action = syslog/g' $auditd_conf
      ((err=err+$?))
   fi

   log_message="Update disk full action in $auditd_conf"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# SUDO RULES
# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# [ VXSEC013 ] The SUSE operating system must reauthenticate users when changing authenticators, roles, or escalating privileges.
# Remove nopasswd and !authenticate from file /etc/sudoers
#
err=0
vxsec_id="VXSEC013"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must reauthenticate users when changing authenticators, roles, or escalating privileges."
   
   # find any offending lines
   result=$(egrep -i '(nopasswd|!authenticate)' $sudoers_file | grep -ve '^\s*#' | egrep -v "($stig_info|$rabbitmqctl|$svc_rabbitmq|$svc_vmwaremarvin|$svc_runjars)")
   
   if [[ ! -z "$result" ]]; then
      # remove all offending lines from the sudoers file
      echo "$result" | while read line
      do
         # remove offending line
         sed -i "\|^${line}|d" $sudoers_file
         res=$?           # for the log message for this line
         ((err=err+$res)) # for the overall result

         # log to file what line was removed
         log_message="$vuln_id: Removed line from ${sudoers_file}: $line"
         LOG $log_title_info $vuln_id $res $log_message
      done
   fi
   
   log_message="The SUSE operating system must reauthenticate users when changing authenticators, roles, or escalating privileges."
   LOG $log_title_info $vuln_id $err $log_message
   
fi

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# [ VXSEC224 ] The SUSE operating system must restrict privilege elevation to authorized personnel.
#
err=0
vxsec_id="VXSEC224"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must restrict privilege elevation to authorized personnel."
   # set of offending lines
   line1="^\s*ALL\s\s*ALL=(ALL)\s\s*ALL"
   line2="^\s*ALL\s\s*ALL=(ALL:ALL)\s\s*ALL"

   for sudofile in $sudoers_file $(ls $sudoersd_dir)
   do
      # find any offending lines
      result=$(grep -e "${line1}" -e "${line2}" $sudofile 2>/dev/null)
      
      if [[ ! -z "$result" ]]; then
         # remove all offending lines from the sudoers file
         echo "$result" | while read line
         do
            # remove offending line
            sed -i "/^${line}/d" $sudofile
            res=$?           # for the log message for this line
            ((err=err+$res)) # for the overall result

            # log to file what line was removed
            log_message="Removed line from ${sudofile}: $line"
            LOG $log_title_info $vuln_id $res $log_message
         done
      fi
   done
   
   log_message="The SUSE operating system must restrict privilege elevation to authorized personnel."
   LOG $log_title_info $vuln_id $err $log_message
   
fi

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# [ VXSEC225 ] The SUSE operating system must require re-authentication when using the "sudo" command
#
err=0
vxsec_id="VXSEC225" 
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must require re-authentication when using the sudo command."
   # set search line
   searchTimeoutPartLine="^\s*Defaults\s\s*timestamp_timeout=" # partial line - search allowing whitespaces
   timeoutPartLine="Defaults timestamp_timeout=" # partial line - for corrections
   timeoutMinutes=0
   timeoutFullLine="${timeoutPartLine}${timeoutMinutes}" # full line - with timeout value

   for sudofile in $sudoers_file $(ls $sudoersd_dir)
   do
      # find timeout line
      # It should be one line only, but just in case add tail to get the last one
      result=$(grep -ie "${searchTimeoutPartLine}" $sudofile 2>/dev/null|tail -1)

      if [[ -z "$result" ]]; then
         # Parameter not found; append it and set it to the required value
         echo "${timeoutFullLine}" >> $sudofile
         ((err=err+$?))
      else
         # Parameter found; check current value
         currValue=$(echo $result | sed 's/^.*=//')

         re='^[0-9]+$' # pattern for a valid value
         if ! [[ $currValue =~ $re ]] ; then
            # It was set to an invalid value

            # Add message to log file
            log_message="sudo timestamp_timeout was set to an invalid value in ${sudofile} ($currValue)"
            LOG $log_title_info $vuln_id 0 $log_message

            # Correct the value in sudoers file
            sed -i "s/^${result}$/${timeoutFullLine}/g" $sudofile
            ((err=err+$?))
         fi
      fi
   done

   log_message='The SUSE operating system must require re-authentication when using the "sudo" command'
   LOG $log_title_info $vuln_id $err $log_message
fi

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# [ VXSEC226 ] The SUSE operating system must use the invoking user's password for privilege escalation when using "sudo".
# The process will look for certain entries in the sudoers files.
# For each entry found, it will fix it in the file where it was found.
# If after processing all lines a parameter is still missing, then it will append it to the default sudoers file.
#
err=0
vxsec_id="VXSEC226" 
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must use the invoking user's password for privilege escalation when using sudo"
   # set the regexp with possible pw names
   pwNameRe='(rootpw|targetpw|runaspw)'

   # find any of the password specification (pwspec) lines in the sudoers files
   # Find all lines starting with 'Defaults ' followed by an optional '!' and then one of the 3 pwspec names.
   # Allow whitespace in the line
   # It can be found in the default sudoers file or in a file under sudoers.d
   # Sort the list, so lines will be ordered by filename
   result=$(egrep -ie "^\s*Defaults\s*(\!|)$pwNameRe\s*" $sudoers_file $sudoersd_dir/* 2>/dev/null | sort)

   # initialize (list of) names that have been seen/fixed
   fixedPwNames=''

   # Read from $result, which is fed to while from the 'done' at the end of the loop,
   # so that the fixedPwNames variable value can be used after (outside) the loop
   while read sudoPwLine
   do
      # continue if empty line - occurs if none are set yet
      if [ -z "$sudoPwLine" ]; then continue; fi

      # extrac the 'raw' (incl whitespace) pwSpec
      rawPwSpec=$(echo "$sudoPwLine"|cut -d: -f2)

      # cleanup excess whitespace to get a clean line
      sudoPwLine=$(echo $sudoPwLine)

      # extract the filename and pwspec from the line
      sudoFile=$(echo $sudoPwLine|cut -d: -f1)
        pwSpec=$(echo $sudoPwLine|cut -d: -f2)

      # extract the pwname:
      # - for use if it needs to be prefixed with the ! character
      pwName=$(echo ${pwSpec}|cut -d' ' -f2)

      # remember that this pwname is seen/fixed (remove optional leading exclamation char)
      fixedPwNames="${fixedPwNames} ${pwName#\!}"

      # check if pwspec is correct/as required
      echo "$pwSpec" | egrep -i "^Defaults \!${pwNameRe}$" > /dev/null
      if [ $? -ne 0 ]
      then
         # this line had no exclamation (!)
         # prepare the new pwSpec
         newPwSpec="Defaults "\!${pwName}

         # Add message to log file
         log_message="Correcting re-auth setting in ${sudoFile} to: $newPwSpec"
         LOG $log_title_info $vuln_id 0 $log_message

         # fix the line in the file
         sed -i "s/^${rawPwSpec}/${newPwSpec}/" $sudoFile
         ((err=err+$?))
      fi
   done < <(echo "$result")

   # Verify that all pwNames have been found/fixed. If not, append to sudoers file
   # Cycle through the list of names, using the pw name regexp
   echo $pwNameRe|sed 's/[()]//g'|tr '|' '\n' | while read pwName
   do
      echo "$fixedPwNames" | grep $pwName > /dev/null
      if [ $? -ne 0 ]
      then
         # this required re-auth spec was not found
         # prepare the new pwSpec
         newPwSpec="Defaults "\!${pwName}

         # Add message to log file
         log_message="Adding missing re-auth setting in ${sudoers_file}: $newPwSpec"
         LOG $log_title_info $vuln_id 0 $log_message

         # this name wasn't seen/fixed yet; append it to the default sudoers file
         echo "${newPwSpec}" >> $sudoers_file
         ((err=err+$?))
      fi
   done

   log_message="The SUSE operating system must use the invoking user's password for privilege escalation when using \"sudo\"."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC227 ] The SUSE operating system must audit all uses of the sudoers file and all files in the /etc/sudoers.d/ directory.
#
err=0
vxsec_id="VXSEC227"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must audit all uses of the sudoers file and all files in the /etc/sudoers.d/ directory."
   result=$(grep -e "^-w /etc/sudoers " $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /etc/sudoers -p wa -k privileged-actions" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i 's/^-w \/etc\/sudoers .*/-w \/etc\/sudoers -p wa -k privileged-actions/' $audit_rules_file
      ((err=err+$?))
   fi
   
   result=$(grep -e "^-w /etc/sudoers.d" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /etc/sudoers.d -p wa -k privileged-actions" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i 's/^-w \/etc\/sudoers.d.*/-w \/etc\/sudoers.d -p wa -k privileged-actions/' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must audit all uses of the sudoers file and all files in the /etc/sudoers.d/ directory."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC253 ] The SUSE operating system must not be configured to bypass password requirements for privilege escalation.
#
err=0
vxsec_id="VXSEC253"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not be configured to bypass password requirements for privilege escalation."

   if test -f "$pam_sudo_file"; then 
      searchArg="pam_succeed_if"
      count=$(grep -c $searchArg $pam_sudo_file) 

      if [[ $count -eq 0 ]]; then 
         log_message="No occurrences of $searchArg found in the file $pam_sudo_file (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $err $log_message

      else 
         # count >= 1
         sed -i "/$searchArg/d" $pam_sudo_file
         ((err=err+$?))
         log_message="Found occurrences of $searchArg in the file $pam_sudo_file. Removed these lines. (NON-COMPLIANT, APPLIED:DELETED)"
         LOG $log_title_info $vuln_id $err $log_message

      fi

   else
      # if the $pam_sudo_file does not exist
      log_message="Expected file not found: $pam_sudo_file"
      LOG $log_title_error $vuln_id 1 $log_message
      echo -e "${red}${log_message}${normal}"

   fi

   log_message="The SUSE operating system must not be configured to bypass password requirements for privilege escalation."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC252 ] The SUSE operating system must specify the default "include" directory for the /etc/sudoers file.
#
err=0
vxsec_id="VXSEC252"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   change_flag=0
   vuln_title="The SUSE operating system must specify the default \"include\" directory for the $sudoers_file file."

   echo -e $vuln_title

   if test -f "$sudoers_file"; then

        # Check 1: Verify the operating system specifies only the default "include" directory for the /etc/sudoers file

        searchArg="^[#@]include.*"
        requiredArg="#includedir $sudoersd_dir"

        count=$(grep -c "$searchArg" $sudoers_file) 
        checkArg=$(grep "$searchArg" $sudoers_file) 
        log_message="Number of include directory lines found in $sudoers_file is: $count"
        LOG $log_title_info $vuln_id $err $log_message

        if [[ $count -eq 0 ]] || [[ $count -eq 1  && "$checkArg" == "$requiredArg" ]]; then

            log_message="The includedir setting found in file $sudoers_file is correct"
            LOG $log_title_info $vuln_id $err $log_message

        else 
            # count > 1 OR 
            # $count=1 and "$checkArg" != "$requiredArg"

            inclDirLine=$(echo "$checkArg" | head -1) # first occurrence
            lineNumber=$(grep -n "$inclDirLine" $sudoers_file | cut -d: -f1) # line number of the first $inclDirLine
            sed -i "/$searchArg/d" $sudoers_file # removing all lines with $searchArg
            ((err=err+$?))
            # re-insert correct includedir setting, at line where first occurrence was found
            sed -i "$lineNumber i $requiredArg" $sudoers_file       
            ((err=err+$?))
            log_message="At least one non-default include directory detected in $sudoers_file and those have been updated"
            LOG $log_title_info $vuln_id $err $log_message
            change_flag=1

        fi

        # Check 2: Verify the operating system does not have nested "include" files or directories within the /etc/sudoers.d directory

        include_files=$(grep -r "$searchArg" $sudoersd_dir | cut -d: -f1 | uniq) #files in $sudoersd_dir containing $searchArg pattern

        if [[ -z "$include_files" ]]; then
            log_message="The $sudoersd_dir directory does not have any nested \"include\" files or directories and no change has been made"
            LOG $log_title_info $vuln_id $err $log_message
            
        else
            # there are $include_files

            for file in $include_files
            do
                sed -i "/$searchArg/d" $file
                ((err=err+$?))
            done
            log_message="At least one nested \"include\" file or directory has been found within the files in the $sudoersd_dir directory and those lines have been removed"
            LOG $log_title_info $vuln_id $err $log_message
            change_flag=1

        fi

    fi

   # Log rule compliancy

   if [[ $change_flag -eq 0 ]]; then
      log_message="$vuln_title (COMPLIANT, UNCHANGED)"
      LOG $log_title_info $vuln_id $err $log_message
   
   else
      # $change_flag = 1
      log_message="$vuln_title (NON-COMPLIANT, APPLIED:UPDATED)"
      LOG $log_title_info $vuln_id $err $log_message
      
   fi

fi

#--------------------------------------------------------------------------------------------------------------------------
# [ VXSEC099 ] Audispd must take appropriate action when the SUSE operating system audit storage is full.
# Update disk full action
#
err=0
vxsec_id="VXSEC099"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Update disk full action in $audisp_remote_conf"

   sed -i '/disk_full_action/d' $audisp_remote_conf
   ((err=err+$?))

   echo "disk_full_action = syslog" >> $audisp_remote_conf
   ((err=err+$?))

   log_message="Update disk full action in $audisp_remote_conf"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC095 ] The audit-audispd-plugins must be installed on the SUSE operating system.
# VXP-15091 SLES12 Vul ID: V-77301; Verify the "au-remote" plugin is enabled

# Enable the "au-remote" plugin
#
err=0
vxsec_id="VXSEC095"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Enable the au-remote plugin in $audisp_remote_plugin_conf"

   # Test if au-remote.conf exists, if not then copy the audispd-zos-remote.conf to au-remote.conf

   if test -f "$audisp_remote_plugin_conf"; then
      echo -e "$audisp_remote_plugin_conf exists"
   else # Create file if it does not exist
      echo -e "$audisp_remote_plugin_conf does not exist"
      echo -e "Creating $audisp_remote_plugin_conf"
      cp -a $audispd_zos_remote $audisp_remote_plugin_conf 2>/dev/null || touch $audisp_remote_plugin_conf
      ((err=err+$?))
   fi

   # Test if the args parameter is active, enabe and set to /etc/audisp/au-remote.conf
   result=$(grep "^args.*" $audisp_remote_plugin_conf | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "args = /etc/audisp/au-remote.conf" >> $audisp_remote_plugin_conf
      ((err=err+$?))
   else
      sed -i '/args/d' $audisp_remote_plugin_conf
      ((err=err+$?))
      echo "args = /etc/audisp/au-remote.conf" >> $audisp_remote_plugin_conf
      ((err=err+$?))
      # sed -i '/^#/!s/args.*/"args = /etc/audisp/audisp-remote.conf"/g' $audisp_remote_plugin_conf
   fi

   # Test if the "au-remote" plugin is active, enable if not
   result=$(grep "active" $audisp_remote_plugin_conf)
   if [[ -z "$result" ]]; then
      echo "active = yes" >> $audisp_remote_plugin_conf
      ((err=err+$?))
   else
      sed -i 's/^.*active.*$/active = yes/g' $audisp_remote_plugin_conf
      ((err=err+$?))
   fi

   log_message="Enable the au-remote plugin in $audisp_remote_plugin_conf"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC100 ] The SUSE operating system must protect audit rules from unauthorized modification.
#
err=0
vxsec_id="VXSEC100"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must protect audit rules from unauthorized modification."
   # Create permissions.local if it does not exist
   touch $permissions_local
   ((err=err+$?))

   # /var/log/audit
   # VXP-47328 - Permission 700 used instead of 600 for file /var/log/audit
   # Using 600 per STIG Rule in the below code, results in an error when running chkstat
   result=$(grep "^/var/log/audit root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/var/log/audit root:root 700" >> $permissions_local
   else
      sed -i '/^#/!s/\/var\/log\/audit root:root.*/\/var\/log\/audit root:root 700/g' $permissions_local
   fi
   ((err=err+$?))

   # /var/log/audit/audit.log
   result=$(grep "^/var/log/audit/audit.log root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/var/log/audit/audit.log root:root 600" >> $permissions_local
   else
      sed -i "/^#/!s/\/var\/log\/audit\/audit.log root:root.*/\/var\/log\/audit\/audit.log root:root 600/g" $permissions_local
   fi
   ((err=err+$?))

   # /etc/audit/audit.rules
   result=$(grep "^/etc/audit/audit.rules root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/etc/audit/audit.rules root:root 640" >> $permissions_local
   else
      sed -i '/^#/!s/\/etc\/audit\/audit.rules root:root.*/\/etc\/audit\/audit.rules root:root 640/g' $permissions_local
   fi
   ((err=err+$?))

   # /etc/audit/rules.d/audit.rules
   result=$(grep "^/etc/audit/rules.d/audit.rules root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/etc/audit/rules.d/audit.rules root:root 640" >> $permissions_local
   else
      sed -i '/^#/!s/\/etc\/audit\/rules.d\/audit.rules root:root.*/\/etc\/audit\/rules.d\/audit.rules root:root 640/g' $permissions_local
   fi
   ((err=err+$?))

   # Set the correct permissions
   # Using 600 per STIG Rule for the /var/log/audit directory results in an error when running chkstat, hence using 700
   chkstat --set $permissions_local
   ((err=err+$?))

   log_message="The SUSE operating system must protect audit rules from unauthorized modification."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC101 ] The SUSE operating system audit tools must have the proper permissions configured to protect against unauthorized access.
#

err=0
vxsec_id="VXSEC101"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system audit tools must have the proper permissions configured to protect against unauthorized access."
   # /usr/sbin/audispd
   result=$(grep "^/usr/sbin/audispd root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/usr/sbin/audispd root:root 0750" >> $permissions_local
   else
      sed -i '/^#/!s/\/usr\/sbin\/audispd root:root.*/\/usr\/sbin\/audispd root:root 0750/g' $permissions_local
   fi
   ((err=err+$?))

   # /usr/sbin/auditctl
   result=$(grep "^/usr/sbin/auditctl root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/usr/sbin/auditctl root:root 0750" >> $permissions_local
   else
      sed -i '/^#/!s/\/usr\/sbin\/auditctl root:root.*/\/usr\/sbin\/auditctl root:root 0750/g' $permissions_local
   fi
   ((err=err+$?))

   # /usr/sbin/auditd
   result=$(grep "^/usr/sbin/auditd root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/usr/sbin/auditd root:root 0750" >> $permissions_local
   else
      sed -i '/^#/!s/\/usr\/sbin\/auditd root:root.*/\/usr\/sbin\/auditd root:root 0750/g' $permissions_local
   fi
   ((err=err+$?))

   # /usr/sbin/ausearch
   result=$(grep "^/usr/sbin/ausearch root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/usr/sbin/ausearch root:root 0755" >> $permissions_local
   else
      sed -i '/^#/!s/\/usr\/sbin\/ausearch root:root.*/\/usr\/sbin\/ausearch root:root 0755/g' $permissions_local
   fi
   ((err=err+$?))

   # /usr/sbin/aureport
   result=$(grep "^/usr/sbin/aureport root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/usr/sbin/aureport root:root 0755" >> $permissions_local
   else
      sed -i '/^#/!s/\/usr\/sbin\/aureport root:root.*/\/usr\/sbin\/aureport root:root 0755/g' $permissions_local
   fi
   ((err=err+$?))

   # /usr/sbin/autrace
   result=$(grep "^/usr/sbin/autrace root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/usr/sbin/autrace root:root 0750" >> $permissions_local
   else
      sed -i '/^#/!s/\/usr\/sbin\/autrace root:root.*/\/usr\/sbin\/autrace root:root 0750/g' $permissions_local
   fi
   ((err=err+$?))

   # /usr/sbin/augenrules
   result=$(grep "^/usr/sbin/augenrules root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/usr/sbin/augenrules root:root 0750" >> $permissions_local
   else
      sed -i '/^#/!s/\/usr\/sbin\/augenrules root:root.*/\/usr\/sbin\/augenrules root:root 0750/g' $permissions_local
   fi
   ((err=err+$?))

   # Set the correct permissions
   chkstat --set $permissions_local
   ((err=err+$?))

   log_message="The SUSE operating system audit tools must have the proper permissions configured to protect against unauthorized access."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC102 ] The SUSE operating system must generate audit records for all account creations, modifications, disabling, and termination events that affect /etc/passwd.
#
err=0
vxsec_id="VXSEC102"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all account creations, modifications, disabling, and termination events that affect /etc/passwd."
   # Create file if it does not exist
   if [[ ! -e $audit_rules_file ]]; then
      touch $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep "^-w /etc/passwd" $audit_rules_file)

   if [[ -z "$result" ]]; then
      echo "-w /etc/passwd -p wa -k account_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/-w \/etc\/passwd.*/-w \/etc\/passwd -p wa -k account_mod/g' $audit_rules_file
      ((err=err+$?))
   fi

   # Restart of auditd.service happens in VXSEC089 towards the end of the script.

   log_message="The SUSE operating system must generate audit records for all account creations, modifications, disabling, and termination events that affect $password_file."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC103 ] Log all modifications to /etc/group
#
err=0
vxsec_id="VXSEC103"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all account creations, modifications, disabling, and termination events that affect /etc/group."
   result=$(grep "^-w /etc/group" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /etc/group -p wa -k account_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/-w \/etc\/group.*/-w \/etc\/group -p wa -k account_mod/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log events that affect /etc/group"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC104 ] Log all modifications to /etc/shadow
#
err=0
vxsec_id="VXSEC104"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all account creations, modifications, disabling, and termination events that affect /etc/shadow."
   result=$(grep "^-w /etc/shadow" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /etc/shadow -p wa -k account_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/-w \/etc\/shadow.*/-w \/etc\/shadow -p wa -k account_mod/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log events that affect /etc/shadow"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC105 ] Log all modifications to /etc/security/opasswd
#
err=0
vxsec_id="VXSEC105"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all account creations, modifications, disabling, and termination events that affect /etc/security/opasswd."
   result=$(grep "^-w /etc/security/opasswd" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /etc/security/opasswd -p wa -k account_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/-w \/etc\/security\/opasswd.*/-w \/etc\/security\/opasswd -p wa -k account_mod/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log events that affect /etc/security/opasswd"
   LOG $log_title_info $vuln_id $err $log_message
fi
# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC231 ] The SUSE operating system must generate audit records for all uses of the rmmod command.
#
err=0
vxsec_id="VXSEC231"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the rmmod command."
   result=$(grep "^-w /sbin/rmmod" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /sbin/rmmod -p x -k modules" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i 's/^-w \/sbin\/rmmod.*/-w \/sbin\/rmmod -p x -k modules/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the rmmod command."
   LOG $log_title_info $vuln_id $err $log_message
fi
# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC107 ] Record all uses of su command
#
err=0
vxsec_id="VXSEC107"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the su command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/su" $audit_rules_file | grep -v ^[#]) 
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/su -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-priv_change" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/su\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-priv_change|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/su" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/su -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-priv_change" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/su\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-priv_change|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of su command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC108 ] Record all uses of sudo command
#
err=0
vxsec_id="VXSEC108"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the sudo command."
   result=$(grep -iw "arch=b32 \-F path=\/usr\/bin\/sudo" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/sudo -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-sudo" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/sudo\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-sudo|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-F path=\/usr\/bin\/sudo" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/sudo -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-sudo" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/sudo\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-sudo|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of sudo command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC228 ] The SUSE operating system must generate audit records for all uses of the lsetxattr system call.
#
err=0
vxsec_id="VXSEC228"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the lsetxattr system call."
   result=$(grep -w "arch=b32 \-S lsetxattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S lsetxattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ lsetxattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S lsetxattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S lsetxattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ lsetxattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the lsetxattr system call."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC229 ] Record all uses of sudoedit command
#
err=0
vxsec_id="VXSEC229"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the sudoedit command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/sudoedit" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/sudoedit -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-sudoedit" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/sudoedit\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-sudoedit|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/sudoedit" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/sudoedit -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-sudoedit" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/sudoedit\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-sudoedit|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of sudoedit command"
   LOG $log_title_info $vuln_id $err $log_message
fi
# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC232 ] The SUSE operating system must generate audit records for all uses of the modprobe command.
#
err=0
vxsec_id="VXSEC232"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the modprobe command."
   result=$(grep "^-w /sbin/modprobe" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /sbin/modprobe -p x -k modules" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i 's/^-w \/sbin\/modprobe.*/-w \/sbin\/modprobe -p x -k modules/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the modprobe command."
   LOG $log_title_info $vuln_id $err $log_message
fi
# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC109 ] Record all uses of chfn command
#
err=0
vxsec_id="VXSEC109"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the chfn command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/chfn" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/chfn -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-chfn" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/chfn\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-chfn|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/chfn" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/chfn -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-chfn" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/chfn\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-chfn|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of chfn command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC110 ] The SUSE operating system must generate audit records for all uses of the mount command.
# Record all uses of mount command
# NOTE: VXP-45312 The 3rd line (with "path=/usr/bin/mount") mentioned in the STIG Check/Fix Text is seen as an
#        inconsistency in the STIG. Ignoring that line.
#
err=0
vxsec_id="VXSEC110"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the mount system call."
   result=$(grep -iw "arch=b32 \-S mount" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k privileged-mount" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ mount\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-mount|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-S mount" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k privileged-mount" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ mount\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-mount|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of mount command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC111 ] The SUSE operating system must generate audit records for all uses of the umount command.
#
# Record all uses of umount command
#
err=0
vxsec_id="VXSEC111"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the umount system call."
   result=$(grep -iw "arch=b32 \-S umount[^2]" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S umount -F auid>=1000 -F auid!=4294967295 -k privileged-umount" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ umount\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-umount|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b32 \-S umount2" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S umount2 -F auid>=1000 -F auid!=4294967295 -k privileged-umount" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ umount2\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-umount|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-S umount2" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S umount2 -F auid>=1000 -F auid!=4294967295 -k privileged-umount" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ umount2\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-umount|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of umount command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC112 ] Record all uses of ssh-agent command
#
err=0
vxsec_id="VXSEC112"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the ssh-agent command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/ssh-agent" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/ssh-agent -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-ssh-agent" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/ssh-agent\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-ssh-agent|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/ssh-agent" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/ssh-agent -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-ssh-agent" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/ssh-agent\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-ssh-agent|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of ssh-agent command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC113 ] Record all uses of ssh-keysign command
#
err=0
vxsec_id="VXSEC113"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the ssh-keysign command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/lib\/ssh\/ssh-keysign" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/lib/ssh/ssh-keysign -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-ssh-keysign" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/lib\/ssh\/ssh-keysign\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-ssh-keysign|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/lib\/ssh\/ssh-keysign" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/lib/ssh/ssh-keysign -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-ssh-keysign" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/lib\/ssh\/ssh-keysign\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-ssh-keysign|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of ssh-keysign command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC115 ] Record all uses of setxattr command
#
err=0
vxsec_id="VXSEC115"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the setxattr system call."
   result=$(grep -w "arch=b32 \-S setxattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S setxattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ setxattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S setxattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S setxattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ setxattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of setxattr command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC116 ] Record all uses of fsetxattr command
#
err=0
vxsec_id="VXSEC116"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the fsetxattr system call."
   result=$(grep -w "arch=b32 \-S fsetxattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S fsetxattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ fsetxattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S fsetxattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S fsetxattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ fsetxattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of fsetxattr command"
   LOG $log_title_info $vuln_id $err $log_message
fi
# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC230 ] The SUSE operating system must generate audit records for all uses of the insmod command.
#
err=0
vxsec_id="VXSEC230"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the insmod command."
   result=$(grep "^-w /sbin/insmod" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /sbin/insmod -p x -k modules" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i 's/^-w \/sbin\/insmod.*/-w \/sbin\/insmod -p x -k modules/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the insmod command."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC117 ] Record all uses of removexattr command
#
err=0
vxsec_id="VXSEC117"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the removexattr system call."
   result=$(grep -w "arch=b32 \-S removexattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S removexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ removexattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S removexattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S removexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ removexattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of removexattr command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC118 ] Record all uses of lremovexattr command
#
err=0
vxsec_id="VXSEC118"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the lremovexattr system call."
   result=$(grep -w "arch=b32 \-S lremovexattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S lremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ lremovexattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S lremovexattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S lremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ lremovexattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of lremovexattr command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC119 ] Record all uses of fremovexattr command
#
err=0
vxsec_id="VXSEC119"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the fremovexattr system call."
   result=$(grep -w "arch=b32 \-S fremovexattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ fremovexattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S fremovexattr" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ fremovexattr\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of fremovexattr command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC120 ] Record all uses of chown command
#
err=0
vxsec_id="VXSEC120"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the chown system call."
   result=$(grep -w "arch=b32 \-S chown" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S chown -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ chown\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S chown" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S chown -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ chown\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of chown command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC121 ] Record all uses of fchown command
#
err=0
vxsec_id="VXSEC121"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the fchown system call."
   result=$(grep -w "arch=b32 \-S fchown" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S fchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ fchown\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S fchown" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S fchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ fchown\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of fchown command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC122 ] Record all uses of lchown command
#
err=0
vxsec_id="VXSEC122"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the lchown system call."
   result=$(grep -w "arch=b32 \-S lchown" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ lchown\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S lchown" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ lchown\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of lchown command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC123 ] Record all uses of fchownat command
#
err=0
vxsec_id="VXSEC123"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the fchownat system call."
   result=$(grep -w "arch=b32 \-S fchownat" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S fchownat -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ fchownat\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S fchownat" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S fchownat -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ fchownat\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of fchownat command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC125 ] The SUSE operating system must generate audit records for all uses of the chmod system call.
#
err=0
vxsec_id="VXSEC125"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the chmod system call."
   result=$(grep -w "arch=b32 \-S chmod" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S chmod -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ chmod\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S chmod" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S chmod -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ chmod\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the chmod system call."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC126 ] Record all uses of fchmod command
#
err=0
vxsec_id="VXSEC126"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the fchmod system call."
   result=$(grep -w "arch=b32 \-S fchmod" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S fchmod -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ fchmod\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S fchmod" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S fchmod -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ fchmod\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of fchmod command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC127 ] Record all uses of fchmodat command
#
err=0
vxsec_id="VXSEC127"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the fchmodat system call."
   result=$(grep -w "arch=b32 \-S fchmodat" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ fchmodat\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S fchmodat" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ fchmodat\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of fchmodat command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC128 ] Record all uses of open command
#
err=0
vxsec_id="VXSEC128"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the open system call."
   result=$(grep -w "arch=b32 \-S open" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S open -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ open\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S open" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S open -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ open\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b32 \-S open" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S open -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ open\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S open" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S open -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ open\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of open command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC129 ] Record all uses of truncate command
#
err=0
vxsec_id="VXSEC129"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the truncate command."
   result=$(grep -w "arch=b32 \-S truncate" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S truncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ truncate\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S truncate" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S truncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ truncate\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b32 \-S truncate" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S truncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ truncate\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S truncate" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S truncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ truncate\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of truncate command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC130 ] Record all uses of ftruncate command
#
err=0
vxsec_id="VXSEC130"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the ftruncate system call."
   result=$(grep -w "arch=b32 \-S ftruncate" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ ftruncate\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S ftruncate" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ ftruncate\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b32 \-S ftruncate" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ ftruncate\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S ftruncate" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ ftruncate\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of ftruncate command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC131 ] Record all uses of creat command
#
err=0
vxsec_id="VXSEC131"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the creat system call."
   result=$(grep -w "arch=b32 \-S creat" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S creat -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ creat\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S creat" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S creat -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ creat\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b32 \-S creat" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S creat -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ creat\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S creat" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S creat -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ creat\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of creat command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC132 ] Record all uses of openat command
#
err=0
vxsec_id="VXSEC132"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the openat system call."
   result=$(grep -w "arch=b32 \-S openat" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S openat -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ openat\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S openat" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S openat -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ openat\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b32 \-S openat" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S openat -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ openat\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S openat" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S openat -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ openat\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of openat command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC133 ] Record all uses of open_by_handle_at command
#
err=0
vxsec_id="VXSEC133"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the open_by_handle_at system call."
   result=$(grep -w "arch=b32 \-S open_by_handle_at" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ open_by_handle_at\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S open_by_handle_at" $audit_rules_file | grep "\-EPERM" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ open_by_handle_at\ \-F\ exit=\-EPERM \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b32 \-S open_by_handle_at" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ open_by_handle_at\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S open_by_handle_at" $audit_rules_file | grep "\-EACCES" | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S open_by_handle_at -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k perm_access" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ open_by_handle_at\ \-F\ exit=\-EACCES \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_access|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of open_by_handle_at command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC134 ] Record all uses of passwd command
#
err=0
vxsec_id="VXSEC134"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the passwd command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/passwd" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/passwd -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-passwd" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/passwd\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-passwd|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/passwd" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/passwd -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-passwd" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/passwd\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-passwd|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of passwd command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC135 ] Record all uses of gpasswd command
#
err=0
vxsec_id="VXSEC135"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the gpasswd command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/gpasswd" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/gpasswd -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-gpasswd" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/gpasswd\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-gpasswd|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/gpasswd" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/gpasswd -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-gpasswd" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/gpasswd\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-gpasswd|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of gpasswd command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC136 ] Record all uses of newgrp command
#
err=0
vxsec_id="VXSEC136"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the newgrp command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/newgrp" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/newgrp -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-newgrp" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/newgrp\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-newgrp|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/newgrp" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/newgrp -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-newgrp" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/newgrp\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-newgrp|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of newgrp command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC137 ] Record all uses of chsh command
#
err=0
vxsec_id="VXSEC137"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the chsh command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/chsh" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/chsh -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-chsh" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/chsh\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-chsh|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/chsh" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/chsh -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-chsh" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/chsh\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-chsh|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of chsh command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC139 ] Record all uses of chmod command
#
err=0
vxsec_id="VXSEC139"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the chmod command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/chmod" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/chmod -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/chmod\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/chmod" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/chmod -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/chmod\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of chmod command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC140 ] Record all uses of setfacl command
#
err=0
vxsec_id="VXSEC140"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the setfacl command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/setfacl" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/setfacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/setfacl\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/setfacl" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/setfacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/setfacl\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of setfacl command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC141 ] Record all uses of chacl command
#
err=0
vxsec_id="VXSEC141"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the chacl command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/chacl" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/chacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/chacl\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/chacl" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/chacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/chacl\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of chacl command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# -------------------------------------------------------------------------------------------------------------------
# [ VXSEC143 ] Record all uses of rm command
#
err=0
vxsec_id="VXSEC143"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the rm command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/rm" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/rm -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/rm\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/rm" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/rm -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/rm\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of rm command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC146 ] Record all uses of passmass command
#
err=0
vxsec_id="VXSEC146"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the passmass command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/passmass" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/passmass -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-passmass" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/passmass\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-passmass|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/passmass" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/passmass -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-passmass" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/passmass\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-passmass|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of passmass command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC147 ] Record all uses of unix_chkpwd command
#
err=0
vxsec_id="VXSEC147"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the unix_chkpwd or unix2_chkpwd commands."
   result=$(grep -w "arch=b32 \-F path=\/sbin\/unix_chkpwd" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/sbin/unix_chkpwd -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-unix-chkpwd" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/sbin\/unix_chkpwd\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-unix-chkpwd|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/sbin\/unix_chkpwd" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/sbin/unix_chkpwd -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-unix-chkpwd" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/sbin\/unix_chkpwd\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-unix-chkpwd|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of unix_chkpwd command"
   LOG $log_title_info $vuln_id $err $log_message

   #  . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
   # Record all uses of unix2_chkpwd command
   #
   err=0

   result=$(grep -w "arch=b32 \-F path=\/sbin\/unix2_chkpwd" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/sbin/unix2_chkpwd -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-unix2-chkpwd" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/sbin\/unix2_chkpwd\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-unix2-chkpwd|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/sbin\/unix2_chkpwd" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/sbin/unix2_chkpwd -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-unix2-chkpwd" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/sbin\/unix2_chkpwd\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-unix2-chkpwd|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of unix2_chkpwd command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC148 ] Record all uses of chage command
#
err=0
vxsec_id="VXSEC148"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the chage command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/chage" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/chage -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-chage" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/chage\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-chage|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/chage" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/chage -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-chage" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/chage\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-chage|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of chage command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC149 ] Record all uses of usermod command
#
err=0
vxsec_id="VXSEC149"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the usermod command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/sbin\/usermod" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/sbin/usermod -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-usermod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/sbin\/usermod\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-usermod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/sbin\/usermod" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/sbin/usermod -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-usermod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/sbin\/usermod\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-usermod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of usermod command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC150 ] Record all uses of crontab command
#
err=0
vxsec_id="VXSEC150"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the crontab command."
   result=$(grep -w "arch=b32 \-F path=\/usr\/bin\/crontab" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/crontab -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-crontab" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/usr\/bin\/crontab\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-crontab|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/usr\/bin\/crontab" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/crontab -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-crontab" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/usr\/bin\/crontab\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-crontab|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of crontab command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC151 ] Record all uses of pam_timestamp_check command
#
err=0
vxsec_id="VXSEC151"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the pam_timestamp_check command."
   result=$(grep -w "arch=b32 \-F path=\/sbin\/pam_timestamp_check" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/sbin/pam_timestamp_check -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-pam_timestamp_check" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=\/sbin\/pam_timestamp_check\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-pam_timestamp_check|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-F path=\/sbin\/pam_timestamp_check" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/sbin/pam_timestamp_check -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged-pam_timestamp_check" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=\/sbin\/pam_timestamp_check\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ privileged-pam_timestamp_check|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of pam_timestamp_check command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC152 ] Record all uses of delete_module command
#
err=0
vxsec_id="VXSEC152"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the delete_module command."
   result=$(grep -w "arch=b32 \-S delete_module" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S delete_module -F auid>=1000 -F auid!=4294967295 -k unload_module" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ delete_module\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ unload_module|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S delete_module" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S delete_module -F auid>=1000 -F auid!=4294967295 -k unload_module" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ delete_module\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ unload_module|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of delete_module command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC153 ] Record all uses of finit_module command
#
err=0
vxsec_id="VXSEC153"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the finit_module command."
   result=$(grep -w "arch=b32 \-S finit_module" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module-load" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ finit_module\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ module-load|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S finit_module" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S finit_module -F auid>=1000 -F auid!=4294967295 -k module-load" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ finit_module\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ module-load|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of finit_module command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC154 ] Record all uses of init_module command
#
err=0
vxsec_id="VXSEC154"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the init_module command."
   result=$(grep -w "arch=b32 \-S init_module" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S init_module -F auid>=1000 -F auid!=4294967295 -k module-load" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ init_module\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ module-load|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -w "arch=b64 \-S init_module" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S init_module -F auid>=1000 -F auid!=4294967295 -k module-load" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ init_module\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ module-load|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of init_module command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC114 ] Record all uses of /usr/bin/kmod
#
err=0
vxsec_id="VXSEC114"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the /usr/bin/kmod command."
   result=$(grep "^-w /usr/bin/kmod" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /usr/bin/kmod -p x -k modules" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/-w \/usr\/bin\/kmod.*/-w \/usr\/bin\/kmod -p x -k modules/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all uses of /usr/bin/kmod command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC138 ] Log all modifications to /etc/gshadow
#
err=0
vxsec_id="VXSEC138"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the /etc/gshadow command."
   result=$(grep "^-w /etc/gshadow" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /etc/gshadow -p wa -k account_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/-w \/etc\/gshadow.*/-w \/etc\/gshadow -p wa -k account_mod/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all modifications of /etc/gshadow command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC144 ] Log all modifications to /var/log/tallylog
#
err=0
vxsec_id="VXSEC144"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the /var/log/tallylog command."
   result=$(grep "^-w /var/log/tallylog" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /var/log/tallylog -p wa -k logins" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/-w \/var\/log\/tallylog.*/-w \/var\/log\/tallylog -p wa -k logins/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all modifications of /var/log/tallylog command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC145 ] Log all modifications to /var/log/lastlog
#
err=0
vxsec_id="VXSEC145"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the /var/log/lastlog command."
   result=$(grep "^-w /var/log/lastlog" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /var/log/lastlog -p wa -k logins" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/-w \/var\/log\/lastlog.*/-w \/var\/log\/lastlog -p wa -k logins/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all modifications of /var/log/lastlog command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC155 ] Log all modifications to /var/log/faillog
#
err=0
vxsec_id="VXSEC155"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the /var/log/faillog command."
   result=$(grep "^-w /var/log/faillog" $audit_rules_file)
   if [[ -z "$result" ]]; then
      echo "-w /var/log/faillog -p wa -k logins" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i '/^#/!s/-w \/var\/log\/faillog.*/-w \/var\/log\/faillog -p wa -k logins/g' $audit_rules_file
      ((err=err+$?))
   fi

   log_message="Log all modifications of /var/log/faillog command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC086 ] The SUSE operating system must prevent unauthorized users from accessing system error messages.
# Prevent unauthorized modification of system error messages
#
err=0
vxsec_id="VXSEC086"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must prevent unauthorized users from accessing system error messages."
   result=$(grep "^/var/log/messages root:root" $permissions_local | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "/var/log/messages root:root 0640" >> $permissions_local
      ((err=err+$?))
   else
      sed -i '/^#/!s/\/var\/log\/messages root:root.*/\/var\/log\/messages root:root 0640/g' $permissions_local
      ((err=err+$?))
   fi

   log_message="Prevent unauthorized access of /var/log/messages command"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC106 ] The SUSE operating system must generate audit records for all uses of the privileged functions.
# Audit the execution of privileged functions
#
err=0
vxsec_id="VXSEC106"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the privileged functions."
   result=$(grep -iw "arch=b32 \-S execve" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      # insert the b32 rules
      echo "-a always,exit -F arch=b32 -S execve -C uid!=euid -F euid=0 -k setuid" >> $audit_rules_file; ((err=err+$?))
      echo "-a always,exit -F arch=b32 -S execve -C gid!=egid -F egid=0 -k setgid" >> $audit_rules_file; ((err=err+$?))
   else
      # replace the b32 rules
      sed -i '/arch=b32 -S execve/d' $audit_rules_file
      echo "-a always,exit -F arch=b32 -S execve -C uid!=euid -F euid=0 -k setuid" >> $audit_rules_file; ((err=err+$?))
      echo "-a always,exit -F arch=b32 -S execve -C gid!=egid -F egid=0 -k setgid" >> $audit_rules_file; ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-S execve" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      # insert the b64 rules
      echo "-a always,exit -F arch=b64 -S execve -C uid!=euid -F euid=0 -k setuid" >> $audit_rules_file; ((err=err+$?))
      echo "-a always,exit -F arch=b64 -S execve -C gid!=egid -F egid=0 -k setgid" >> $audit_rules_file; ((err=err+$?))
   else
      # replace the b64 rules
      sed -i '/arch=b64 -S execve/d' $audit_rules_file
      echo "-a always,exit -F arch=b64 -S execve -C uid!=euid -F euid=0 -k setuid" >> $audit_rules_file; ((err=err+$?))
      echo "-a always,exit -F arch=b64 -S execve -C gid!=egid -F egid=0 -k setgid" >> $audit_rules_file; ((err=err+$?))
   fi

   log_message="Log all uses of the privileged functions"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC202 ] The SUSE operating system must not disable syscall auditing.
# Ensure the "-a task,never" rule is not statically defined in the /etc/audit/rules.d/audit.rules file.
#
err=0
vxsec_id="VXSEC202"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not disable syscall auditing."
   result=$(grep -v "^#" /etc/audit/rules.d/* | grep -i "a task,never")
   if [[ -z "$result" ]]; then
      echo -e "Confirmed, syscall auditing is not statically defined"
   else
      sed -i '/-a task,never/d' $audit_rules_file
      ((err=err+$?))
      echo -e "Removed static definition disabling syscall auditing"
   fi

   log_message="Log all uses of the privileged functions"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
#################
# AIDE settings #
#################

# [ VXSEC053 ] Protect the integrity of audit tools
# Instead of checking for each entry, remove all audit related entries and add the desired values
# Below is the configuration, Aide initialization is done in the end of the script to allow possible other modifications to be done first.

err=0
vxsec_id="VXSEC053"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Protect the integrity of audit tools in $aide_conf_file"

   touch $aide_conf_file

   result=$(grep "# audit tools" $aide_conf_file)
   if [[ ! -z "$result" ]]; then
      sed -i '/# audit tools/d' $aide_conf_file 
      ((err=err+$?))
   fi 
   sed -i '/\/usr\/sbin\/au/d' $aide_conf_file
   ((err=err+$?))

   cat <<EOT >> $aide_conf_file
# audit tools
/usr/sbin/auditctl p+i+n+u+g+s+b+acl+selinux+xattrs+sha512
/usr/sbin/auditd p+i+n+u+g+s+b+acl+selinux+xattrs+sha512
/usr/sbin/ausearch p+i+n+u+g+s+b+acl+selinux+xattrs+sha512
/usr/sbin/aureport p+i+n+u+g+s+b+acl+selinux+xattrs+sha512
/usr/sbin/autrace p+i+n+u+g+s+b+acl+selinux+xattrs+sha512
/usr/sbin/audispd p+i+n+u+g+s+b+acl+selinux+xattrs+sha512
/usr/sbin/augenrules p+i+n+u+g+s+b+acl+selinux+xattrs+sha512
EOT
   ((err=err+$?))

   log_message="Protect the integrity of audit tools in $aide_conf_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC050 ] The SUSE operating system must notify the System Administrator (SA) when AIDE discovers anomalies in the operation of any security functions.
# This rule *PROVIDES* several $vxsec050_xxx parameters, that will be used later in rule VXSEC049.
# Parameters provided by vxsec050 to vxsec049:
# - vxsec050_aide_cron_file    : which cron file the aide check must be configured in
# - vxsec050_aide_cron_line    : the found cron line that contains the original aide check
# - vxsec050_orig_email_address: the original email address used (if found)
# - vxsec050_email_address     : user-entered new email address
# - vxsec050_cron_action       : does this require a New or Replace action in the cron file
# - vxsec050_leave_as_is       (=1 means user accepted existing value)
# - vxsec050_incorrect_email   (=1 means user decided in vxsec050 to leave the entry of email to be done manually later)
#
err=0
vxsec_id="VXSEC050"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo "Configure where to notify the administrators (which email address) when AIDE discovers anomalies in the operation of any security functions."

   # First extract any already configured aide email from cron.
   # Setup the pattern to use for finding the relevant line:
   sp="[[:space:]]"
   email_pattern="([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})"
   aide_check_email_pattern="/usr/sbin/aide${sp}*--check${sp}*|${sp}*/bin/mail${sp}.*${sp}${email_pattern}${sp}*$"
   
   # find the line and the file it's found in
   aide_cron_lines=$(egrep -H "$aide_check_email_pattern" $crontab_file $aide_cron_weekly $crontabs_dir/* 2>/dev/null | sort | uniq)
   line_count=$(echo "$aide_cron_lines"|grep -v "^$"|wc -l)

   # Determine if it needs an Append or Replace action in the cron file (used by vxsec049)
   if [ $line_count -eq 0 ]; then 
      # none was found; for weekly config, set aide check in this cron file
      vxsec050_aide_cron_file=$aide_cron_weekly
      vxsec050_cron_action='new'
   else
      # entry was found; maintain aide check in this cron file
      vxsec050_aide_cron_file=$(echo "$aide_cron_lines"|tail -1|cut -d: -f1)
      vxsec050_aide_cron_line=$(echo "$aide_cron_lines"|tail -1|cut -d: -f2)
      vxsec050_cron_action='replace'
   fi

   # Log if more than one entry is found
   if [ $line_count -gt 1 ]; then
      # found multiple - log a message
      msg="Multiple aide checks found in cron (using email of the last one, from $vxsec050_aide_cron_file):"
      echo -e "${yellow}${msg}${normal}"
      LOG $log_title_warn $vuln_id 0 "$msg"
      # list out the found lines 
      echo "$aide_cron_lines" | while read cronLine
      do
         msg=$(echo "$cronLine"|sed 's/^/   - /')
         echo "$msg"
         LOG $log_title_warn $vuln_id 0 "$msg"
      done
   fi
   
   # extract email from last line found
   vxsec050_email_address=$(echo "$aide_cron_lines"|tail -1|awk '{print $NF}')
   vxsec050_orig_email_address=$vxsec050_email_address

   # (2) Prompt user if this value needs to be changed
   if [ ! -z "$vxsec050_email_address" ]; then
      email_found="yes"
      msg="The following email was found in cron ($vxsec050_aide_cron_file): $vxsec050_email_address"
      LOG $log_title_info $vuln_id 0 "$msg"
      echo "$msg"
      askEnterOrOptionAction 'c' 'change'
      change_answer=$answer
   else
      email_found="no"
      change_answer="c"
   fi

   # At this point this is the truth table with possible scenarios:
   # ---+-------+--------+---------------------------------------------
   #    | value   change |
   # nr | found   answer | scenario
   # ---+-------+--------+---------------------------------------------
   #  1 |   0   |    0   | Not possible.
   #  2 |   0   |    1   | Enforce setting value for the first time
   #  3 |   1   |    0   | User wants to accept the found value as-is
   #  4 |   1   |    1   | User wants to change existing value
   # ---+-------+--------+---------------------------------------------

   if [ "x$change_answer" != "xc" ] && [ "$email_found" == "yes" ]; then
      # scenario 3:
      # found email, user wants to accept the found value as-is; don't ask for new value
      echo -e "${yellow}Existing email accepted as-is${normal}"
      vxsec050_leave_as_is=1
   else
      # scenarios 2 and 4:
      # prompt for a new/replacement value
      vxsec050_leave_as_is=0

      res=1 # prompt until the email validation is successful
      until [ $res -eq 0 ]
      do
         echo -en "${yellow}Enter the email address where administrators should be notified${normal}: "
         read vxsec050_email_address

         if [ -z $vxsec050_email_address ]; then
            # Does the user want to leave it blank (i.e. enter it later manually)?
            leave_blank=x
            until [[ $leave_blank = [YyNn] ]]
            do
               echo -e "${yellow}If the email address is left blank, it must be set manually after the hardening session (in $vxsec050_aide_cron_file)${normal}"
               echo -en "${yellow}Leave the email address blank (y/n)?${normal} "
               read leave_blank
            done
            if [[ $leave_blank = [Yy] ]]; then
               vxsec050_incorrect_email=1
               vxsec050_email_address="TBD_email_address@some_domain.com"
               res=0 # leave the until loop
            else
               vxsec050_incorrect_email=0
            fi
         else
            validate_email $vxsec050_email_address
            res=$?
         fi
      done
   fi

   log_message="The SUSE operating system must notify the System Administrator (SA) when AIDE discovers anomalies in the operation of any security functions"
   LOG $log_title_info $vuln_id $err $log_message
fi

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# [ VXSEC049 ] Advanced Intrusion Detection Environment (AIDE) must verify the baseline SUSE operating system configuration at least weekly.
# This rule *USES* several $vxsec050_xxx parameters, that are provided by rule VXSEC050.
# Parameters used by vxsec049:
# - vxsec050_aide_cron_file    : which cron file the aide check must be configured in
# - vxsec050_aide_cron_line    : the found cron line that contains the original aide check
# - vxsec050_orig_email_address: the original email address used (if found)
# - vxsec050_email_address     : user-entered new email address
# - vxsec050_cron_action       : does this require a New or Replace action in the cron file
# - vxsec050_leave_as_is       (=1 means user accepted existing value)
#
err=0
vxsec_id="VXSEC049"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # Only perform if (user did not request to leave the value as-is) AND (user did not leave entry of email to be done manually later) in vxsec050
   if [ $vxsec050_leave_as_is -eq 0 ]; then

      echo "AIDE must verify the baseline SUSE operating system configuration at least weekly"

      msg="The provided email will be configured in cron (file: $vxsec050_aide_cron_file, email: $vxsec050_email_address)"
      LOG $log_title_info $vuln_id 0 "$msg"
      echo "$msg"

      if [ $vxsec050_cron_action = 'new' ]
      then
         # no previous entry was found, so cron file is set to be cron.weekly/aide
         # this file can be written to directly, so append a new line
         system_name=$(hostname -f)
         cat << EOT > $vxsec050_aide_cron_file
/usr/sbin/aide --check | /bin/mail -s "$system_name - AIDE integrity check run" $vxsec050_email_address
EOT
         ((err=err+$?))

         chmod +x $vxsec050_aide_cron_file
         ((err=err+$?))
      else
         # replace the email so the new line is prepared
         new_aide_cron_line=$(echo "$vxsec050_aide_cron_line"|sed "s/$vxsec050_orig_email_address/$vxsec050_email_address/")

         # determine if this cron file can be edited directly or is crontab command needed
         if [[ $vxsec050_aide_cron_file =~ '/etc/cron' ]]; then
            # the files in /etc/cron... are editable
            sed -i "s^${vxsec050_aide_cron_line}^${new_aide_cron_line}^" $vxsec050_aide_cron_file
            ((err=err+$?))
         else
            # the files in /var/spool... are not editable; must use the crontab command
            crontab -l | sed "s^${vxsec050_aide_cron_line}^${new_aide_cron_line}^" | crontab - 2>/dev/null
            ((err=err+$?))
         fi
      fi

      log_message="AIDE must verify the baseline SUSE operating system configuration at least weekly (configure cron job in $vxsec050_aide_cron_file)"
      LOG $log_title_info $vuln_id $err $log_message
   fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC051 ] Set acl rule on all files
# [ VXSEC052 ] Set xattrs rule on all files
#
# This captures 2 vxsec-ids in one by configuring the content of the aide-conf-file.
# Makes the vuln retrieval, checking, logging a bit harder as there is only 1 piece of logic for both vxsec ids.
err=0
get_vuln_result=0

# Check both vxsec vuln lookups first and capture the result
vxsec_id="VXSEC051"
vuln_title_051="The SUSE operating system file integrity tool must be configured to verify Access Control Lists (ACLs)"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval
((get_vuln_result=get_vuln_result+$?))
vuln_id_051="$vuln_id"

vxsec_id="VXSEC052"
vuln_title_052="The SUSE operating system file integrity tool must be configured to verify extended attributes"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval
((get_vuln_result=get_vuln_result+$?))
vuln_id_052="$vuln_id"

# If either one was successful (i.e. get_vuln.. function returned success (0) exit code), then execute the logic
if [ $get_vuln_result -lt 2 ] ; then
   # at least one of the two lookups was successful, so execute the logic
   sed -i '/All/d' $aide_conf_file
   ((err=err+$?))

   cat <<EOT >> $aide_conf_file
# Set acl and xattrs rule on all files
All= p+i+n+u+g+s+m+S+sha512+acl+xattrs+selinux
/bin All # apply the custom rule to the files in bin
/sbin All # apply the same custom rule to the files in sbin
EOT
   ((err=err+$?))

   # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
   # if the get_vuln function call for vxsec051 was successful, then log its message
   if [ ! -z $vuln_id_051 ]; then
      echo -e $vuln_title_051
      LOG $log_title_info $vuln_id_051 $err $vuln_title_051
   fi

   # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
   # if the get_vuln function call for vxsec052 was successful, then log its message
   if [ ! -z $vuln_id_052 ]; then
      echo -e $vuln_title_052
      LOG $log_title_info $vuln_id_052 $err $vuln_title_052
   fi
fi

# ------------------------------------------------------------------------------------------------------------------
###############################
## Field Service Remediation ##
###############################

# [ VXSEC006 ]  gnome banner (not used, but prevent false positive)
#
err=0
vxsec_id="VXSEC006"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "configure the banner display before local or remote access to the system via a graphical user logon"
   touch $banner_path; ((err=err+$?))
   echo "[org/gnome/login-screen]"   >> $banner_path; ((err=err+$?))
   echo "banner-message-enable=true" >> $banner_path; ((err=err+$?))

   log_message="Display a banner before local or remote access to the system via a graphical user logon"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC071 ] All SUSE operating system local interactive user home directories must have mode 0750 or less permissive.
#
err=0
vxsec_id="VXSEC071"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Set local interactive user home directories to have mode 0750 or less permissive"
   chmod 0750 /home/mystic
   ((err=err+$?))

   log_message="Set local interactive user home directories to have mode 0750 or less permissive"
   LOG $log_title_info $vuln_id $err $log_message
fi
# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC048 ] The sticky bit must be set on all SUSE operating system world-writable directories.
#
err=0
vxsec_id="VXSEC048"
vuln_title="The sticky bit must be set on all SUSE operating system world-writable directories"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then
   echo -e $vuln_title
   find / \( -path /var/lib/docker -o -path /proc \) -prune -o -perm -2 ! -type d -perm -1000 -ls -exec chmod +t {} \;
   ((err=err+$?))

   LOG $log_title_info $vuln_id $err $vuln_title
fi
# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC073 ] All SUSE operating system local initialization files must have mode 0740 or less permissive.
#
err=0
vxsec_id="VXSEC073"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Set local initialization files must have mode 0740 or less permissive"
   chmod 0740 /home/mystic/.profile
   ((err=err+$?))
   chmod 0740 /home/mystic/.bashrc
   ((err=err+$?))

   log_message="Set local initialization files must have mode 0740 or less permissive"
   LOG $log_title_info $vuln_id $err $log_message
fi
#----------------------------------------------------------------------------------------------------------------------
# [ VXSEC075 ] SUSE local initialization files must not execute world-writable programs
#
err=0
vxsec_id="VXSEC075"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "SUSE local initialization files must not execute world-writable programs"
   #Find the names of all world-writable files   
   wwpfiles=$(find / -xdev -perm -002 -type f -exec ls -d {} \;)
   for wwpfile in $wwpfiles
   do
      #Find any local initialization files user's home directory and see if it references the world-writable file
      localIniFiles=$(find /home/* -maxdepth 1 -type f -name \.\* -exec grep -l $wwpfile {} \;)
      
      if [ ! -z "$localIniFiles" ]; then
         chmod 0755 $wwpfile
         ((err=err+$?))
      fi
   done
   
   log_message="SUSE local initialization files must not execute world-writable programs"
   LOG $log_title_info $vuln_id $err $log_message
   
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC067 ] All SUSE operating system files and directories must have a valid group owner.
#
err=0
vxsec_id="VXSEC067"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "All SUSE operating system files and directories must have a valid group owner"

   # -----------------------------------------------
   # Ensure RKE2 POD files have valid user and group
   # Do before the Find command, as the uid is known.
   setDockerUserAndGroup
   res=$?
   ((err=err+$res))
   if [ $res -ne 0 ]; then
      log_message="Issue detected while setting docker user and group ($res)"
      LOG $log_title_warn $vuln_id $res $log_message
   fi
   # -----------------------------------------------

   # Find filesystem type that '/' is on
   fsTypeName=$(df -T / |tail -1| awk '{print $2}')

   # Find all files/dirs in / filesystem that have no group
   nogroupList=$(find / -fstype $fsTypeName -nogroup 2>/dev/null)

   # -----------------------------------------------
   # Check if the Embedded Service Enabler (ESE) is installed without valid user and group
   # Do after the Find command, as the uid is not certain.

   eseSearchPattern="/home/__ese__"

   # Search and if found extract the uid and gid values
   eseUserGroupId=$(echo "$nogroupList" | grep "$eseSearchPattern$" | head -1 | xargs ls -ld | awk '{print $3,$4}')

   if [ ! -z "$eseUserGroupId" ]; then
      # ese is installed
      setESEUserAndGroup $eseUserGroupId # send without quotes so its seen as 2 positional params
      res=$?
      ((err=err+$res))
      if [ $res -eq 0 ]; then
         # These now have an owner and group, so remove the ese entries from the nogroupList
         nogroupList=$(echo "$nogroupList"|grep -v "$eseSearchPattern")
      else
         log_message="Issue detected while setting ESE user and group ($res)"
         LOG $log_title_warn $vuln_id $res $log_message
      fi
   fi
   # -----------------------------------------------

   # if still entries on the nogroupList then log them for follow-up
   if [ ! -z "$nogroupList" ]; then
      echo "$nogroupList" | while read fileDirName
      do
         # Flag all found items to the user for review
         log_message="REVIEW: Delete or set group ownership on: $fileDirName"
         LOG $log_title_warn $vuln_id 0 $log_message
      done
   fi

   log_message="All SUSE operating system files and directories must have a valid group owner."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC029 ] The SUSE operating system must employ user passwords with a minimum lifetime of 24 hours (1 day).
#
err=0
vxsec_id="VXSEC029"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must employ user passwords with a minimum lifetime of 24 hours (1 day)."
   # The logic needs to change the password expiry to 1 (using: "passwd -n 1 USERNAME") for the following users:
   users=$(awk -F: '($3>=1000)&&($1!="nobody"){print $1}' $password_file)

   for usr in $users
   do
      # check if the user actually exists on the system
      if ! grep -q "^$usr:" $password_file
      then
         # user does not exist
         log_message="passwd: user does not exist - no need to change pwd exiry (user=$usr)"
         LOG $log_title_info $vuln_id 0 $log_message
         echo $log_message
         continue
      fi

      # user exists - change password expiry
      passwd -n 1 $usr 2>/dev/null
      res=$?

      if [ $res -ne 0 ]; then
         log_message="passwd: setting pwd expiry failed (user=$usr)"
         LOG $log_title_info $vuln_id $res $log_message
         echo $log_message
         ((err=err+1))
      fi
   done

   log_message="Set minimum password age to 1 day for all existing user accounts"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC066 ] All SUSE operating system files and directories must have a valid owner.
#
err=0
vxsec_id="VXSEC066"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "All SUSE operating system files and directories must have a valid owner"

   chown mystic /var/spool/mail/mystic*; ((err=err+$?))
   chown root /var/spool/mail/root*; ((err=err+$?))

   # These items are already done in vxsec067:
   # - Ensure RKE2 POD files have valid user and group
   # - Check if the Embedded Service Enabler (ESE) is installed without valid user and group

   # Find filesystem type that '/' is on 
   fsTypeName=$(df -T / |tail -1| awk '{print $2}')

   # Find all files/dirs in / filesystem that have no user
   result=$(find / -fstype $fsTypeName -nouser 2>/dev/null)
   
   # process each found file or directory name
   if [ ! -z "$result" ]; then
      echo "$result" | while read fileDirName
      do
         # Flag all found items to the user for review
         log_message="REVIEW: Delete or set ownership on: $fileDirName"
         LOG $log_title_warn $vuln_id 0 $log_message
      done
   fi

   log_message="All SUSE operating system files and directories must have a valid owner."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC069 ] All SUSE operating system local interactive user accounts, upon creation, must be assigned a home directory.
# Change "CREATE_HOME no" to "CREATE_HOME yes" in /etc/login.defs
#
err=0
vxsec_id="VXSEC069"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "All SUSE operating system local interactive user accounts, upon creation, must be assigned a home directory."
   sed -i 's/^CREATE_HOME.*no$/CREATE_HOME\tyes/' /etc/login.defs
   ((err=err+$?))

   log_message="Assign a home directory to local interactive user accounts"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC061 ] The SUSE operating system must not have unnecessary accounts.
#
err=0
vxsec_id="VXSEC061"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not have unnecessary accounts."
   accounts="games news"
   for account in $accounts
   do
      if grep -q "^$account:" $password_file
      then
         echo "Removing unnecessary account $account"
         userdel -rf $account 2>>$SCRIPT_LOG; ((err=err+$?))
         if grep -q "^$account:" /etc/group
         then
            groupdel $account 2>>$SCRIPT_LOG; ((err=err+$?))
         fi
      else
         log_message="Unnecessary account did not exist (account=$account)"
         LOG $log_title_info $vuln_id 0 $log_message
         echo $log_message
      fi
   done

   log_message="Remove unnecessary accounts"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC031 ] The SUSE operating system enforces a maximum user password age of "60" days or less
# Check and prompt user to update maximum user password age policy
# NOTE: This rule is about *user* accounts. VxRail does not have *user* accounts, so technically this rule is not applicable.
#
err=0
vxsec_id="VXSEC031"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system enforces a maximum user password age of "60" days or less"
   check_password_age()
   {
      print_func_name ${FUNCNAME[0]}
      chkUser=$1
      pwdMaxDays=60 # rule constant
      secsPerDay=86400

      password_age_policy=$(cat /etc/shadow | grep $chkUser | cut -d':' -f5 | sed 's/[[:space:]]//g')
      ((err=err+$?))

      echo ""
      if [[ $password_age_policy == '' ]]; then
         echo "Account $chkUser's password age policy: <blank>"
      else
         echo "Account $chkUser's password age policy: $password_age_policy"
      fi
      ((err=err+$?))

      if [[ $password_age_policy == '' || $password_age_policy == 0 || $password_age_policy -gt 60 ]];
      then
         date_password_changed=$(sudo chage -l $chkUser | grep 'Last password change' | awk -F': ' '{print $2}')
         ((err=err+$?))

         time_now=$(date '+%s')
         ((err=err+$?))

         time_then=$(date '+%s' -d "$date_password_changed")
         ((err=err+$?))

         time_diff=$(expr $time_now - $time_then)
         ((err=err+$?))
         
         day_diff=$(expr $time_diff / $secsPerDay)
         ((err=err+$?))
         
         # Do not prompt user if password (for this system account)) was set/changed today
         if [[ $day_diff -ge 1 ]]; then
            echo "Account $chkUser's password was changed, on $date_password_changed, $day_diff day(s) ago."
   
            echo -e "${yellow}Press Enter to skip this configuration for this account${normal}"
            echo -e "${yellow}Press E and Enter to enforce STIG control on this account (set a maximum password age policy of $pwdMaxDays)${normal}"
            echo -e "${yellow}Press R and Enter to enforce STIG control on this account and reset its password${normal}\n"
            read change_password

            if [[ $change_password = [EeRr] ]]; then
               passwd -x $pwdMaxDays $chkUser
               ((err=err+$?))
            fi
            if [[ $change_password = [Rr] ]]; then
               passwd $chkUser
               ((err=err+$?))
            fi
         fi
      else
         echo "Password age policy for $chkUser is in compliance"
      fi
   }

   check_password_age "root"
   check_password_age "mystic"

   log_message="Check and prompt user to update maximum user password age policy"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC186 ] The SUSE operating system must prevent Internet Protocol version 4 (IPv4) Internet Control Message 
#              Protocol (ICMP) redirect messages from being accepted.
#
err=0
vxsec_id="VXSEC186"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must prevent IPv4 ICMP redirect messages from being accepted."
   result=$(grep "net.ipv4.conf.all.accept_redirects" $sysctl_conf )

   if [[ -z "$result" ]] ; then

      # Line wasnt in the file yet - append it with new line
      sed -i '$a\' $sysctl_conf
      echo -n "net.ipv4.conf.all.accept_redirects=0" >> $sysctl_conf
      sysctl -p -q
      ((err=err+$?))
   else
      # Line was already in the file
      # Check if the line has correct config
      result2=$(echo "$result" |tr -d [:space:] | grep "^net.ipv4.conf.all.accept_redirects=0$")

      if [[ -z "$result2" ]] ; then 
         # The line in file has a different config; 
         # Replace the complete line (c\) in-line, to maintain line order
         sed -i "/net.ipv4.conf.all.accept_redirects/c\net.ipv4.conf.all.accept_redirects=0" $sysctl_conf
         sysctl -p -q
         ((err=err+$?))
      fi
   fi

   log_message="Prevent IPv4 ICMP redirect messages from being accepted"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC187 ] The SUSE operating system must not allow interfaces to accept Internet Protocol version 4 (IPv4) 
#              Internet Control Message Protocol (ICMP) redirect messages by default.
#
err=0
vxsec_id="VXSEC187"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not allow interfaces to accept IPv4 ICMP redirect messages by default."
   result=$(grep "net.ipv4.conf.default.accept_redirects" $sysctl_conf )

   if [[ -z "$result" ]] ;  then
      # Line wasnt in the file yet - append it
      sed -i '$a\' $sysctl_conf
      echo "net.ipv4.conf.default.accept_redirects=0" >> $sysctl_conf
      sysctl -p -q
      ((err=err+$?))
   else
      # Line was already in the file
      # Check if the line has correct config
      result2=$(echo "$result" |tr -d [:space:] | grep "^net.ipv4.conf.default.accept_redirects=0$")

      if [[ -z "$result2" ]] ; then 
         # The line in file has a different config; 
         # Replace the complete line (c\) in-line, to maintain line order
         sed -i "/net.ipv4.conf.default.accept_redirects/c\net.ipv4.conf.default.accept_redirects=0" $sysctl_conf
         sysctl -p -q
         ((err=err+$?))
      fi
   fi

   log_message="Disallow interfaces to accept IPv4 ICMP redirect messages by default"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC188 ] The SUSE operating system must not allow interfaces to send Internet Protocol version 4 (IPv4) 
#              Internet Control Message Protocol (ICMP) redirect messages by default.
#
err=0
vxsec_id="VXSEC188"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not allow interfaces to send IPv4 ICMP redirect messages by default."
   result=$(grep "net.ipv4.conf.default.send_redirects" $sysctl_conf )

   if [[ -z "$result" ]] ;  then
      # Line wasnt in the file yet - append it
      sed -i '$a\' $sysctl_conf
      echo "net.ipv4.conf.default.send_redirects=0" >> $sysctl_conf
      sysctl -p -q
      ((err=err+$?))
   else
      # Line was already in the file
      # Check if the line has correct config
      # echo 'net.ipv4.conf.default.send_redirects=1' | tr -d [:space:] | grep net.ipv4.conf.default.send_redirects=0
      result2=$(echo "$result" |tr -d [:space:] | grep "^net.ipv4.conf.default.send_redirects=0$")

      if [[ -z "$result2" ]] ; then 
         # The line in file has a different config; 
         # Replace the complete line (c\) in-line, to maintain line order
         sed -i "/net.ipv4.conf.default.send_redirects/c\net.ipv4.conf.default.send_redirects=0" $sysctl_conf
         sysctl -p -q
         ((err=err+$?))
      fi
   fi

   log_message="Disallow interfaces to send IPv4 ICMP redirect messages by default"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC189 ] The SUSE operating system must not send Internet Protocol version 4 (IPv4) 
#              Internet Control Message Protocol (ICMP) redirects.
#
err=0
vxsec_id="VXSEC189"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not send IPv4 ICMP redirects."
   result=$(grep "net.ipv4.conf.all.send_redirects" $sysctl_conf )
   
   if [[ -z "$result" ]] ;  then
      # Line wasnt in the file yet - append it
      sed -i '$a\' $sysctl_conf
      echo "net.ipv4.conf.all.send_redirects=0" >> $sysctl_conf
      sysctl -p -q
      ((err=err+$?))

   else
      # Line was already in the file
      # Check if the line has correct config
      result2=$(echo "$result" |tr -d [:space:] | grep "^net.ipv4.conf.all.send_redirects=0$")

      if [[ -z "$result2" ]] ; then 
         # The line in file has a different config; 
         # Replace the complete line (c\) in-line, to maintain line order
         sed -i "/net.ipv4.conf.all.send_redirects/c\net.ipv4.conf.all.send_redirects=0" $sysctl_conf
         sysctl -p -q
         ((err=err+$?))
      fi
   fi

   log_message="Prevent operating system to send IPv4 ICMP redirects"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC200 ] The SUSE operating system must not allow interfaces to accept Internet Protocol version 6 (IPv6) 
#              Internet Control Message Protocol (ICMP) redirect messages by default.
err=0
vxsec_id="VXSEC200"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not allow interfaces to accept IPv6 ICMP redirect messages by default."
   result=$(grep "net.ipv6.conf.default.accept_redirects" $sysctl_conf )

   if [[ -z "$result" ]] ;  then
      # Line wasnt in the file yet - append it
      sed -i '$a\' $sysctl_conf
      echo "net.ipv6.conf.default.accept_redirects=0" >> $sysctl_conf
      sysctl -p -q
      ((err=err+$?))
   else
      # Line was already in the file
      # Check if the line has correct config
      result2=$(echo "$result" |tr -d [:space:] | grep "^net.ipv6.conf.default.accept_redirects=0$")

     if [[ -z "$result2" ]] ; then 
         # The line in file has a different config; 
         # Replace the complete line (c\) in-line, to maintain line order
         sed -i "/net.ipv6.conf.default.accept_redirects/c\net.ipv6.conf.default.accept_redirects=0" $sysctl_conf
         sysctl -p -q
         ((err=err+$?))
      fi
   fi

   log_message="Disallow interfaces to accept IPv6 ICMP redirect messages by default"
   LOG $log_title_info $vuln_id $err $log_message
fi
#--------------------------------------------------------------------------------------------------------------------
# [ VXSEC251 ] The SUSE operating system must prevent Internet Protocol version 6 (IPv6) Internet Control Message Protocol (ICMP) redirect messages from being accepted.
err=0
vxsec_id="VXSEC251"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must prevent IPv6 ICMP redirect messages from being accepted."
   if [ ! -f $sysctl_99stig_conf ]; then touch $sysctl_99stig_conf; fi

   result=$(grep "net.ipv6.conf.all.accept_redirects" $sysctl_99stig_conf )

   if [[ -z "$result" ]] ;  then
      # Line wasnt in the file yet - append it
      sed -i '$a\' $sysctl_99stig_conf
      ((err=err+$?))
      echo "net.ipv6.conf.all.accept_redirects=0" >> $sysctl_99stig_conf
      ((err=err+$?))
      sysctl -q --system
      ((err=err+$?))
   else
      # Line was already in the file
      # Check if the line has correct config
      result2=$(echo "$result" |tr -d [:space:] | grep "^net.ipv6.conf.all.accept_redirects=0$")

     if [[ -z "$result2" ]] ; then
         # The line in file has a different config;
         # Replace the complete line (c\) in-line, to maintain line order
         sed -i "/net.ipv6.conf.all.accept_redirects/c\net.ipv6.conf.all.accept_redirects=0" $sysctl_99stig_conf
         ((err=err+$?))
         sysctl -q --system
         ((err=err+$?))
     fi
   fi

   log_message="The SUSE operating system must prevent Internet Protocol version 6 (IPv6) Internet Control Message Protocol (ICMP) redirect messages from being accepted."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC209 ] The SUSE operating system must generate error messages that provide information necessary for corrective actions without revealing information that could be exploited by adversaries.
#
err=0
vxsec_id="VXSEC209"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate error messages that provide information necessary for corrective actions without revealing information that could be exploited by adversaries."
   find /var/log -perm /137 ! -name '*[bw]tmp' ! -name '*lastlog' -type f -exec chmod 640 '{}' \;
   ((err=err+$?))

   log_message="The SUSE operating system must generate error messages that provide information necessary for corrective actions without revealing information that could be exploited by adversaries."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC212 ] The SUSE operating system library FILES must be OWNED by root.
#
err=0
vxsec_id="VXSEC212"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system library FILES must be OWNED by root."
   # find items to apply the rule to; exclude VxRail system directory
   find /lib /lib64 /usr/lib /usr/lib64 ! -user root -type f | grep -v "$excludeVxRailDirectory" | while read fileItem
   do
      chown root "$fileItem"
      ((err=err+$?))
   done

   log_message="The SUSE operating system library FILES must be OWNED by root"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC213 ] The SUSE operating system library DIRECTORIES must be OWNED by root.
#
err=0
vxsec_id="VXSEC213"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system library DIRECTORIES must be OWNED by root."
   # find items to apply the rule to; exclude VxRail system directory
   find /lib /lib64 /usr/lib /usr/lib64 ! -user root -type d | grep -v "$excludeVxRailDirectory" | while read dirItem
   do
      chown root "$dirItem"
      ((err=err+$?))
   done

   log_message="The SUSE operating system library DIRECTORIES must be OWNED by root"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC214 ] The SUSE operating system library FILES must be GROUP-owned by root.
#
err=0
vxsec_id="VXSEC214"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system library FILES must be GROUP-owned by root."
   # find items to apply the rule to; exclude VxRail system directory
   find /lib /lib64 /usr/lib /usr/lib64 ! -group root -type f | grep -v "$excludeVxRailDirectory" | while read fileItem
   do
      chgrp root "$fileItem"
      ((err=err+$?))
   done

   log_message="The SUSE operating system library FILES must be GROUP-owned by root"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC215 ] The SUSE operating system library DIRECTORIES must be GROUP-owned by root.
#
err=0
vxsec_id="VXSEC215"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system library DIRECTORIES must be GROUP-owned by root."
   # find items to apply the rule to; exclude VxRail system directory
   find /lib /lib64 /usr/lib /usr/lib64 ! -group root -type d | grep -v "$excludeVxRailDirectory" | while read dirItem
   do
      chgrp root "$dirItem"
      ((err=err+$?))
   done

   log_message="The SUSE operating system library DIRECTORIES must be GROUP-owned by root."
   LOG $log_title_info $vuln_id $err $log_message
fi 

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC220 ] The SUSE operating system must have SYSTEM COMMANDS GROUP-owned by root.
#
err=0
vxsec_id="VXSEC220"
err_file="/tmp/vxsec220.tmp"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then
   echo -e "The SUSE operating system must have SYSTEM COMMANDS GROUP-owned by root."
   # Redirecting errors if any to display in the log
   find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -group root -type f -exec chgrp root '{}' \; 2>$err_file
   ((err=err+$?))
   
   if [ -s $err_file ] ; then
      #logging errors
      log_message=`cat $err_file`
      LOG $log_title_warn $vuln_id $err "$log_message"
   fi
   log_message="The SUSE operating system must have SYSTEM COMMANDS GROUP-owned by root."
   LOG $log_title_info $vuln_id $err $log_message
   rm -f $err_file
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC171 ] The SUSE operating system SSH daemon public host key files must have mode 0644 or less permissive.
#
err=0
vxsec_id="VXSEC171"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system SSH daemon public host key files must have mode 0644 or less permissive."
   chmod 0644 /etc/ssh/ssh_host*key.pub
   ((err=err+$?))

   log_message="The SUSE operating system SSH daemon public host key files must have mode 0644 or less permissive."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC207 ] The SUSE operating system must not have the vsftpd package installed if not required for operational support.
#
err=0
vxsec_id="VXSEC207"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not have the vsftpd package installed if not required for operational support."
   # First ensure there are no zypper repos left enabled
   disable-zypper-repos $vuln_id
   
   zypper -D $fake_zypp_repo info vsftpd | grep -i "^installed *: *yes"
   res=$?

   if [ $res -eq 0 ] ; then
      zypper remove vsftpd
      ((err=err+$?))
   fi
   
   log_message="The SUSE operating system must not have the vsftpd package installed if not required for operational support."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC208 ] The SUSE operating system must employ FIPS 140-2 approved cryptographic hashing algorithm for system authentication (system-auth)
#
err=0
vxsec_id="VXSEC208"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must employ FIPS 140-2 approved cryptographic hashing algorithm for system authentication"
   # Ensure that the pam.unix.so entry is always correct
   # Maintain line order, so first see if its already in the file
   result=$(grep "\spam_unix.so\s" $common_auth_file | grep -v "^#")

   if [[ -z "$result" ]]; then
      # Line wasnt in the file yet - append it
      echo "auth required pam_unix.so sha512 try_first_pass" >> $common_auth_file
      ((err=err+$?))
   else
      # Line was already in the file
      # Check if the line has correct config
      # (echo without quotes so every bit of whitespace is reduced to a single space)
      result2=$(echo $result|grep "^auth required pam_unix.so sha512 try_first_pass$")

      if [[ -z "$result2" ]]; then
         # The line in file has a different config; 
         # Replace the complete line (c\) in-line, to maintain line order
         sed -i "/\spam_unix.so\s/c\auth required pam_unix.so sha512 try_first_pass" $common_auth_file
         ((err=err+$?))
      fi
   fi

   # TEMP FIX for VXP-42441:
   # If we leave it like this, logins will get access denied.
   # To fix, put this line in comment: auth [default=die] pam_tally2.so ...
   # (this line may have 1+ spaces or tabs as whitespace)
   sed -i -e "s/auth\s\s*\[default=die\]\s\s*pam_tally2.so/\# VXP-42441 # & /" $common_auth_file
   ((err=err+$?))

   log_message="The SUSE operating system must employ FIPS 140-2 approved cryptographic hashing algorithm for system authentication (system-auth)."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC210 ] The SUSE operating system library files must have mode 0755 or less permissive.
#
err=0
vxsec_id="VXSEC210"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system library files must have mode 0755 or less permissive."
   # find items to apply the rule to; exclude VxRail system directory
   find /lib /lib64 /usr/lib /usr/lib64 -perm /022 -type f | grep -v "$excludeVxRailDirectory" | while read fileItem
   do
      chmod 755 "$fileItem"
      ((err=err+$?))
   done

   log_message="The SUSE operating system library files must have mode 0755 or less permissive."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC165 ] The SUSE operating system must deny direct logons to the root account using remote access via SSH.
#
err=0
vxsec_id="VXSEC165"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must deny direct logons to the root account using remote access via SSH."
   # Delete any line with permitrootlogin
   sed -i '/PermitRootLogin/d' $sshd_config_file
   ((err=err+$?))

   # Add a correct permitrootlogin entry
   echo "PermitRootLogin no" >> $sshd_config_file
   ((err=err+$?))

   log_message="The SUSE operating system must deny direct logons to the root account using remote access via SSH."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC142 ] The SUSE operating system must generate audit records for all uses of the chcon command.
#
err=0
vxsec_id="VXSEC142"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the chcon command."
   result=$(grep -iw "arch=b32 \-F path=\/usr\/bin\/chcon \-F perm=x" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -F path=/usr/bin/chcon -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-F\ path=/usr/bin/chcon\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-F path=\/usr\/bin\/chcon \-F perm=x" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -F path=/usr/bin/chcon -F perm=x -F auid>=1000 -F auid!=4294967295 -k prim_mod" >> $audit_rules_file
      ((err=err+$?))
   else
       sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-F\ path=/usr/bin/chcon\ \-F\ perm=x\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ prim_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the chcon command."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC234 ] The SUSE operating system must generate audit records for all uses of the rename system call.
#
err=0
vxsec_id="VXSEC234"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the rename system call."
   result=$(grep -iw "arch=b32 \-S rename" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S rename -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ rename\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-S rename" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S rename -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ rename\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the rename system call."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC235 ] The SUSE operating system must generate audit records for all uses of the renameat system call.
#
err=0
vxsec_id="VXSEC235"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the renameat system call."
   result=$(grep -iw "arch=b32 \-S renameat" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S renameat -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ renameat\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-S renameat" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S renameat -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ renameat\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the renameat system call."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC236 ] The SUSE operating system must generate audit records for all uses of the renameat2 system call.
#
err=0
vxsec_id="VXSEC236"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the renameat2 system call."
   result=$(grep -iw "arch=b32 \-S renameat2" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S renameat2 -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ renameat2\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-S renameat2" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S renameat2 -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ renameat2\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the renameat2 system call."
   LOG $log_title_info $vuln_id $err $log_message
fi


# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC237 ] The SUSE operating system must generate audit records for all uses of the unlink system call.
#
err=0
vxsec_id="VXSEC237"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the unlink system call."
   result=$(grep -iw "arch=b32 \-S unlink" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S unlink -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ unlink\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-S unlink" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S unlink -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ unlink\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the unlink system call."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC238 ] The SUSE operating system must generate audit records for all uses of the unlinkat system call.
#
err=0
vxsec_id="VXSEC238"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for all uses of the unlinkat system call."
   result=$(grep -iw "arch=b32 \-S unlinkat" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b32 -S unlinkat -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b32\ \-S\ unlinkat\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   result=$(grep -iw "arch=b64 \-S unlinkat" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-a always,exit -F arch=b64 -S unlinkat -F auid>=1000 -F auid!=4294967295 -k perm_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-a always,exit\ \-F\ arch=b64\ \-S\ unlinkat\ \-F\ auid\>=1000\ \-F\ auid!=4294967295\ \-k\ perm_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for all uses of the unlinkat system call."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC243 ]  The SUSE operating system must disable the systemd Ctrl-Alt-Delete burst key sequence.
#
err=0
vxsec_id="VXSEC243"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must disable the systemd Ctrl-Alt-Delete burst key sequence."
   # Delete any line with CtrlAltDelBurstAction
   sed -i '/CtrlAltDelBurstAction/d' $systemd_conf
   ((err=err+$?))

   # Add a correct CtrlAltDelBurstAction entry
   echo "CtrlAltDelBurstAction=none" >> $systemd_conf
   ((err=err+$?))
   
   error=0
   systemctl daemon-reload >/dev/null 2>&1
   ((error=error+$?))

   log_message="Reloading the daemon for the change to take effect"
   LOG $log_title_info $vuln_id $error $log_message

   log_message="The SUSE operating system must disable the systemd Ctrl-Alt-Delete burst key sequence."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC205 ] The SUSE operating system SSH daemon must disable forwarded remote X connections for interactive users, unless to fulfill documented and validated mission requirements.
#
err=0
vxsec_id="VXSEC205"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system SSH daemon must disable forwarded remote X connections for interactive users, unless to fulfill documented and validated mission requirements."
   # Delete any line with X11Forwarding
   sed -i '/X11Forwarding/d' $sshd_config_file
   ((err=err+$?))

   # Add a correct X11Forwarding entry
   echo "X11Forwarding no" >> $sshd_config_file
   ((err=err+$?))

   log_message="The SUSE operating system SSH daemon must disable forwarded remote X connections for interactive users, unless to fulfill documented and validated mission requirements."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC239 ] The SUSE operating system must generate audit records for the /run/utmp file.
#
err=0
vxsec_id="VXSEC239"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for the /run/utmp file."
   result=$(grep -iw "/run/utmp" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-w /run/utmp -p wa -k login_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-w /run/utmp\ \-p\ wa\ \-k\ login_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for the /run/utmp file."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC092 ] The Information System Security Officer (ISSO) and System Administrator (SA), at a minimum, must be alerted of a SUSE operating system audit processing failure event.
#
err=0
vxsec_id="VXSEC092"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # ---------------------------------------------------------
   # 0. Set rule values
   # ---------------------------------------------------------
   action='apply' 
   vuln_title='The Information System Security Officer (ISSO) and System Administrator (SA), at a minimum, must be alerted of a SUSE operating system audit processing failure event.'
   param_name="action_mail_acct"
   param_sep=" = "
   param_val="root"

   # ---------------------------------------------------------
   # 1. Perform the compliance action on the parameters
   # ---------------------------------------------------------
   # This requires checking/applying a parameter assignment in a file, for which we use a function.
   # The function does the full compliance check and logging

   # Prepare parameters to pass to function:
   # 1. Vulnerability ID
   # 2. Vulnerability title
   # 3. Action (check or apply)
   # 4. filepath
   # 5. parameter name
   # 6. parameter separator
   # 7. parameter value

   setParamInFile "$vuln_id" "$vuln_title" "$action" "$auditd_conf" "$param_name" "$param_sep" "$param_val"
   res=$?
   if [ $res -eq 0 ]; then 
      LOG $log_title_info $vuln_id $res $vuln_title
   else
      LOG $log_title_warn $vuln_id $res "Error received from function (result=$res)"
   fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC240 ] The SUSE operating system must generate audit records for the /var/log/wtmp file.
#
err=0
vxsec_id="VXSEC240"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for the /var/log/wtmp file."
   result=$(grep -iw "/var/log/wtmp" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-w /var/log/wtmp -p wa -k login_mod" >> $audit_rules_file
      ((err=err+$?))
   else     
      sed -i -e "s|$result|\-w /var/log/wtmp \-p\ wa\ \-k\ login_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for the /var/log/wtmp file."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC241 ] The SUSE operating system must generate audit records for the /var/log/btmp file.
#
err=0
vxsec_id="VXSEC241"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must generate audit records for the /var/log/btmp file."
   result=$(grep -iw "/var/log/btmp" $audit_rules_file | grep -v ^[#])
   if [[ -z "$result" ]]; then
      echo "-w /var/log/btmp -p wa -k login_mod" >> $audit_rules_file
      ((err=err+$?))
   else
      sed -i -e "s|$result|\-w /var/log/btmp \-p\ wa\ \-k\ login_mod|" $audit_rules_file
      ((err=err+$?))
   fi

   log_message="The SUSE operating system must generate audit records for the /var/log/btmp file."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC059 ] The SUSE operating system must disable the x86 Ctrl-Alt-Delete key sequence.
#
err=0
vxsec_id="VXSEC059"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must disable the x86 Ctrl-Alt-Delete key sequence."
   # Disable the ctrl-alt-del key sequence
   systemctl disable ctrl-alt-del.target
   ((err=err+$?))

   # Mask the ctrl-alt-del key sequence
   systemctl mask ctrl-alt-del.target
   ((err=err+$?))

   # Restart the daemon so changes take effect
   systemctl daemon-reload
   ((err=err+$?))

   log_message="The SUSE operating system must disable the x86 Ctrl-Alt-Delete key sequence."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC016 ] The SUSE operating system must enforce a delay of at least four seconds between logon prompts following a failed logon attempt - Update /etc/login.defs file
err=0

vxsec_id="VXSEC016"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Adding 4 second delay between logon prompts in $login_defs"

   touch $login_defs 

   result=$(grep "FAIL_DELAY" $login_defs )

   if [[ -z "$result" ]] ; then

      # Line wasnt in the file yet - append it
      echo "FAIL_DELAY   4" >> $login_defs
      sysctl -p -q
      ((err=err+$?))
   else
      # Line was already in the file
      # Check if the line has correct config (use xargs to trim spaces)
      result2=$(echo "$result" |tr -s ' ' | xargs | grep "^FAIL_DELAY 4$")

      if [[ -z "$result2" ]] ; then 
         # The line in file has a different config; 
         # Replace the complete line (c\) in-line, to maintain line order
         sed -i "/FAIL_DELAY/c\FAIL_DELAY   4" $login_defs
         sysctl -p -q
         ((err=err+$?))
      fi
   fi

   log_message="The SUSE operating system must enforce a delay of at least four seconds between logon prompts following a failed logon attempt ($login_defs)"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC156 ] The SUSE operating system must not have the telnet-server package installed.
#
err=0
vxsec_id="VXSEC156"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "The SUSE operating system must not have the telnet-server package installed."
   zypper -D $fake_zypp_repo info telnet-server | grep -i "^installed *: *yes"
   res=$?

   if [ $res -eq 0 ] ; then
      zypper remove telnet-server
      ((err=err+$?))
   fi
   
   log_message="The SUSE operating system must not have the telnet-server package installed."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC172 ] The SUSE operating system must against or limit the effects of DoS attacks. 
#
err=0
vxsec_id="VXSEC172"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "Limit the effects of DoS attacks in $susefw_file"
   if [[ -e $susefw_file ]]; then
      result=$(grep "^FW_SERVICES_ACCEPT_EXT" $susefw_file)
      if [[ -z "$result" ]]; then
         echo "FW_SERVICES_ACCEPT_EXT=\"0/0,tcp,22,,hitcount=3,blockseconds=60,recentname=ssh\"" >> $susefw_file
         ((err=err+$?))
         systemctl restart SuSEfirewall2.service
         ((err=err+$?))
         sleep 3s
      else
         sed -i '/^#/!s/FW_SERVICES_ACCEPT_EXT.*/FW_SERVICES_ACCEPT_EXT=\"0\/0,tcp,22,,hitcount=3,blockseconds=60,recentname=ssh\"/g' $susefw_file
         ((err=err+$?))
         systemctl restart SuSEfirewall2.service
         ((err=err+$?))
         sleep 3s
      fi
   else
      echo "FW_SERVICES_ACCEPT_EXT=\"0/0,tcp,22,,hitcount=3,blockseconds=60,recentname=ssh\"" > $susefw_file
      ((err=err+$?))
      systemctl restart SuSEfirewall2.service
      ((err=err+$?))
      sleep 3s
   fi

   log_message="Limit the effects of DoS attacks in $susefw_file"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC255 ] The SUSE operating system must be configured to allow sending email notifications of unauthorized configuration changes to designated personnel.
#
err=0
vxsec_id="VXSEC255"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo "The SUSE operating system must be configured to allow sending email notifications of unauthorized configuration changes to designated personnel."
   
   zypper -D $fake_zypp_repo info mailx | grep -i "^installed *: *yes"
   res=$?

   if [ $res -eq 0 ] ; then
      log_message="mailx package is already installed on the system (COMPLIANT, UNCHANGED)."
      LOG $log_title_info $vuln_id $err $log_message
   else
      log_message="mailx package is NOT installed on this system, Other rules may depend on this. System Administrator(SA) to take action. (NON-COMPLIANT, UNCHANGED)"
      LOG $log_title_warn $vuln_id $err $log_message
   fi
   
   log_message="The SUSE operating system must be configured to allow sending email notifications of unauthorized configuration changes to designated personnel."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC256 ] The SUSE operating system SSH server must be configured to use only FIPS-validated key exchange algorithms.
#
err=0
vxsec_id="VXSEC256"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo "The SUSE operating system SSH server must be configured to use only FIPS-validated key exchange algorithms."

   req_value="KexAlgorithms ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group-exchange-sha256"
   search_arg="KexAlgorithms "
   result=$(grep -i ^$search_arg $sshd_config_file)
   if [[ -z "$result" ]]; then
      # Entry not found - insert
      echo "$req_value" >> $sshd_config_file
      ((err=err+$?))
      log_message="Parameter KexAlgorithms was not present in ${sshd_config_file}, this has been corrected ... (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $err $log_message
   else
      # Entry found - check for compliance
      if [[ $result == $req_value ]] ; then
         # Entry found and is correct - no action
         log_message="Parameter KexAlgorithms was present and already set correctly in ${sshd_config_file} to the value $req_value (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $err $log_message
      else
         # Entry found is incorrect - update
         sed -i "s|^${search_arg}.*$|${req_value}|g" $sshd_config_file
         ((err=err+$?))
         log_message="Parameter KexAlgorithms was set to $result and has now been rectified in ${sshd_config_file} ... (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $err $log_message
      fi
   fi

   log_message="The SUSE operating system SSH server must be configured to use only FIPS-validated key exchange algorithms."
   LOG $log_title_info $vuln_id $err $log_message
fi

################################################################
##### PostgreSQL rules                                     #####
##### PostgreSQL rules                                     #####
################################################################

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC556 ] PostgreSQL must provide non-privileged users with error messages that provide information necessary for corrective actions without revealing information that could be exploited by adversaries.
#
err=0
vxsec_id="VXSEC556"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   required_value="error"
   result=$(grep -i "^client_min_messages" $postgresql_conf)
   if [[ -z "$result" ]]; then
      # not present; so insert into file
      echo "client_min_messages=error" >> $postgresql_conf
      ((err=err+$?))
      log_message="Parameter client_min_messages was not present in ${postgresql_conf}, setting it now ... (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $err $log_message
   else
      # already present; ensure the value is correct
      curr_value=$(echo $result | sed 's/^.*=//' | cut -d " " -f 1)
      ((err=err+$?))

      if [ ${curr_value^^} == "ERROR" ] ; then
         log_message="Parameter client_min_messages was present and already set correctly in ${postgresql_conf} to the value $curr_value (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $err $log_message
      else
         sed -i "s/^\s*client_min_messages=.*$/client_min_messages=$required_value/g" $postgresql_conf
         ((err=err+$?))
         log_message="Parameter client_min_messages was set to $curr_value and now has been rectified in ${postgresql_conf} to the new value $required_value (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $err $log_message
      fi
   fi

   log_message="PostgreSQL must provide non-privileged users with error messages that provide information necessary for corrective actions without revealing information that could be exploited by adversaries."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC558 ] PostgreSQL must limit privileges to change functions and triggers, and links to software external to PostgreSQL.
# [ Partial Implementation ] - remaining part of the Vulnerability is Met by Default.
#
err=0
vxsec_id="VXSEC558"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   pgconf_fileperms_required=600
   pgconf_fileperms_current=$(stat -c '%a' $postgresql_conf)
   
   if [ $pgconf_fileperms_current -eq $pgconf_fileperms_required ]; then
      log_message="File permission for $postgresql_conf is already $pgconf_fileperms_required (COMPLIANT, UNCHANGED)"
      LOG $log_title_info $vuln_id $err $log_message
   else
      chmod $pgconf_fileperms_required $postgresql_conf
      ((err=err+$?))
      log_message="File permission for $postgresql_conf was changed from $pgconf_fileperms_current to $pgconf_fileperms_required (NON-COMPLIANT, APPLIED:UPDATED)"
      LOG $log_title_info $vuln_id $err $log_message
   fi

   log_message="PostgreSQL must limit privileges to change functions and triggers, and links to software external to PostgreSQL."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC571 ] The audit information produced by PostgreSQL must be protected from unauthorized deletion.
# [ VXSEC653 ] PostgreSQL must protect its audit configuration from unauthorized modification.
# [ Partial Implementation ] - remaining part of the Vulnerability is Met by Default.
#
err=0
vxsec_id="VXSEC571"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   log_fileperms_required="0600"
   result=$(grep -i "^log_file_mode=" $postgresql_conf)
   
   if [[ -z "$result" ]]; then
      # not present; so insert into file
      echo "log_file_mode=$log_fileperms_required" >> $postgresql_conf
      ((err=err+$?))
      log_message="Parameter log_file_mode was not present in ${postgresql_conf}, setting it now ... (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $err $log_message
   else
      # already present; ensure the value is correct
      curr_value=$(echo $result | sed 's/^.*=//')
      ((err=err+$?))

      if [[ "x$curr_value" == "x$log_fileperms_required" ]] ; then
         log_message="Parameter log_file_mode was present and already set correctly in ${postgresql_conf} to the value $curr_value (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $err $log_message
      else
         sed -i "/^#/!s/log_file_mode=.*/log_file_mode=$log_fileperms_required/g" $postgresql_conf
         ((err=err+$?))
         log_message="Parameter log_file_mode was set to $curr_value and now has been rectified in ${postgresql_conf} to the new value $log_fileperms_required (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $err $log_message
      fi
   fi

   log_message="The audit information produced by PostgreSQL must be protected from unauthorized deletion."
   LOG $log_title_info $vuln_id $err $log_message
   
   #Adding logging for VXSEC653
   vxsec_id="VXSEC653"
   get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval
   log_message="PostgreSQL must protect its audit configuration from unauthorized modification."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC586 ] - The audit information produced by PostgreSQL must be protected from unauthorized read access.
# [ Partial Implementation ] - remaining part of the Vulnerability is Met by VXSEC571/VXSEC653.
#
err=0
vxsec_id="VXSEC586"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   log_dir_value="'"$postgresql_log_dir"'"
   result=$(grep -i "^log_directory=" $postgresql_conf)
      
      if [[ -z "$result" ]]; then
         # not present; so insert into file
         echo "log_directory=$log_dir_value" >> $postgresql_conf
         ((err=err+$?))
         log_message="Parameter log_directory was not present in ${postgresql_conf}, setting it now ... (NON-COMPLIANT, APPLIED:INSERTED)"
         LOG $log_title_info $vuln_id $err $log_message
      else
         # already present; ensure the value is correct
         curr_value=$(echo $result | sed "s/^.*=//")
         ((err=err+$?))

         if [[ "x$curr_value" == "x$log_dir_value" ]] ; then
            log_message="log_directory was present and already set correctly in ${postgresql_conf} to the value $curr_value (COMPLIANT, UNCHANGED)"
            LOG $log_title_info $vuln_id $err $log_message
         else
            sed -i "s|^log_directory=.*$|log_directory=$log_dir_value|" $postgresql_conf
            ((err=err+$?))
            log_message="Parameter log_directory was set to $curr_value and now has been rectified in ${postgresql_conf} to the new value $postgresql_log_dir (NON-COMPLIANT, APPLIED:UPDATED)"
            LOG $log_title_info $vuln_id $err $log_message
         fi
      fi

   log_message="The audit information produced by PostgreSQL must be protected from unauthorized read access."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC590 ] PostgreSQL must generate audit records when unsuccessful logons or connection attempts occur.
# [ Partial Implementation ] - remaining part of the Vulnerability is Met by VXSEC639/VXSEC643
#
err=0
vxsec_id="VXSEC590"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   required_value="on"
   result=$(grep -i "^log_connections=" $postgresql_conf)
   if [[ -z "$result" ]]; then
      # not present; so insert into file
      echo "log_connections=$required_value" >> $postgresql_conf
      ((err=err+$?))
      log_message="Parameter log_connections was not present in ${postgresql_conf}, setting it now ... (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $err $log_message
   else
      # already present; ensure the value is correct
      curr_value=$(echo $result | sed 's/^.*=//')
      ((err=err+$?))

      if [ ${curr_value^^} == ${required_value^^} ] ; then
         log_message="log_connections was present and already set correctly in ${postgresql_conf} to the value $curr_value (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $err $log_message
      else
         sed -i "/^#/!s/^log_connections=.*/log_connections=$required_value/g" $postgresql_conf
         ((err=err+$?))
         log_message="Parameter log_connections was set to $curr_value and now has been rectified in ${postgresql_conf} to the new value $required_value (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $err $log_message
      fi
   fi

   log_message="PostgreSQL must generate audit records when unsuccessful logons or connection attempts occur."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC591 ] PostgreSQL must generate audit records showing starting and ending time for user access to the database(s).
# [ Partial Implementation ] - remaining part of the Vulnerability is Met by VXSEC639/VXSEC643/VXSEC590
#
err=0
vxsec_id="VXSEC591"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   required_value="on"
   result=$(grep -i "^log_disconnections=" $postgresql_conf)
   if [[ -z "$result" ]]; then
      # not present; so insert into file
      echo "log_disconnections=$required_value" >> $postgresql_conf
      ((err=err+$?))
      log_message="Parameter log_disconnections was not present in ${postgresql_conf}, setting it now ... (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $err $log_message
   else
      # already present; ensure the value is correct
      curr_value=$(echo $result | sed 's/^.*=//')
      ((err=err+$?))

      if [ ${curr_value^^} == ${required_value^^} ] ; then
         log_message="log_disconnections was present and already set correctly in ${postgresql_conf} to the value $curr_value (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $err $log_message
      else
         sed -i "/^#/!s/^log_disconnections=.*/log_disconnections=$required_value/g" $postgresql_conf
         ((err=err+$?))
         log_message="Parameter log_disconnections was set to $curr_value and now has been rectified in ${postgresql_conf} to the new value $required_value (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $err $log_message
      fi
   fi

   log_message="PostgreSQL must generate audit records showing starting and ending time for user access to the database(s)."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC627 ] PostgreSQL must produce audit records containing sufficient information to establish the sources (origins) of the events.
# [ Partial Implementation ] - remaining part of the Vulnerability is Met by VXSEC639/VXSEC643
#
err=0
vxsec_id="VXSEC627"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   required_value="on"
   result=$(grep -i "^log_hostname=" $postgresql_conf)
   if [[ -z "$result" ]]; then
      # not present; so insert into file
      echo "log_hostname=$required_value" >> $postgresql_conf
      ((err=err+$?))
      log_message="Parameter log_hostname was not present in ${postgresql_conf}, setting it now ... (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $err $log_message
   else
      # already present; ensure the value is correct
      curr_value=$(echo $result | sed 's/^.*=//')
      ((err=err+$?))

      if [ ${curr_value^^} == ${required_value^^} ] ; then
         log_message="log_hostname was present and already set correctly in ${postgresql_conf} to the value $curr_value (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $err $log_message
      else
         sed -i "/^#/!s/^log_hostname=.*/log_hostname=$required_value/g" $postgresql_conf
         ((err=err+$?))
         log_message="Parameter log_hostname was set to $curr_value and now has been rectified in ${postgresql_conf} to the new value $required_value (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $err $log_message
      fi
   fi

   log_message="PostgreSQL must produce audit records containing sufficient information to establish the sources (origins) of the events."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC635 ] The system must provide a warning to appropriate support staff when allocated audit record 
# storage volume reaches 75% of maximum audit record storage capacity.
#
err=0
vxsec_id="VXSEC635"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   msg="Configuring the audit record storage capacity monitor for PostgreSQL. This monitor will notify appropriate support staff in the event that the storage volume reaches $pgsql_audit_cap_threshold% of maximum capacity."
   echo $msg
   LOG $log_title_info $vuln_id $err "$msg"
   # check if stig related cron directory exists and create if not
   # The cron_stig_dir directory will be used as a common place to store all cron jobs created by VxRail_STIG_VxRManager.sh
   if [ ! -d $cron_stig_dir ]; then
      mkdir -p $cron_stig_dir > /dev/null 2>&1
   fi
   chmod 744 $cron_stig_dir
   pg_disk_monitor_script_file="$cron_stig_dir/postgresql_disk_space.sh"

   if [ -f $pg_disk_monitor_script_file ]; then 
      # first extract any existing email value from the script file
      email_address=$(grep \@ $pg_disk_monitor_script_file | awk '{print $NF}')
   fi

   # Prompt user if this value needs to be changed
   if [ ! -z "$email_address" ]; then
      email_found="yes"
      echo -e "The following email was found in the PostgreSQL disk space monitoring script: $email_address"
      askEnterOrOptionAction 'c' 'change'
      change_answer=$answer
   else
      email_found="no"
      change_answer="c"
   fi

   # At this point this is the truth table with possible scenarios:
   # ---+-------+--------+---------------------------------------------
   #    | value   change |
   # nr | found   answer | scenario
   # ---+-------+--------+---------------------------------------------
   #  1 |   0   |    0   | Not possible.
   #  2 |   0   |    1   | Enforce setting value for the first time
   #  3 |   1   |    0   | User wants to accept the found value as-is
   #  4 |   1   |    1   | User wants to change existing value
   # ---+-------+--------+---------------------------------------------
   
   if [ "x$change_answer" != "xc" ] && [ "$email_found" == "yes" ]; then
      # scenario 3:
      # found email, user wants to accept the found value as-is; don't ask for new value
      echo -e "${yellow}Existing email accepted as-is${normal}"
   else
      # scenarios 2 and 4:
      # prompt for a new/replacement value

      res=1 # prompt until the email validation is successful
      until [ $res -eq 0 ]
      do
         echo -en "${yellow}Enter an email address where PostgreSQL administrators should be notified when the allocated audit record storage volume reaches ${pgsql_audit_cap_threshold}% capacity${normal}: "
         read email_address

         if [ -z $email_address ]; then
            # Does the user want to leave it blank (i.e. enter it later manually)?
            leave_blank=x
            until [[ $leave_blank = [YyNn] ]]
            do
               echo -e "${yellow}If the email address is left blank, it must be set manually after the hardening session (in $pg_disk_monitor_script_file)${normal}"
               echo -en "${yellow}Leave the email address blank (y/n)?${normal} "
               read leave_blank
            done
            if [[ $leave_blank = [Yy] ]]; then
               vxsec635_incorrect_email=1
               email_address="TBD_email_address@some_domain.com"
               res=0 # leave the until loop
            else
               vxsec635_incorrect_email=0
            fi
         else
            validate_email $email_address
            res=$?
         fi
      done
   fi

   # create a monitoring shell script file with required file permissions and configuring email address
   createPostgresqlDiskSpaceMonitorScript $email_address
   ((err=err+$?))

   #enabling crontab to run the monitoring script once in every 15 mins
   required_value='*/15 * * * *'
   req_val_escaped=$(echo "$required_value"| sed 's/*/\\*/g')
   search_arg_escaped=$(echo "$pg_disk_monitor_script_file"| sed 's/*/\\*/g')
   result=$(grep -i "$search_arg_escaped" $cron_root 2>/dev/null)

   if [ -z "$result" ]; then
      # not present; so insert into file
      echo "$required_value " "$pg_disk_monitor_script_file" >> $cron_root
      ((err=err+$?))
      log_message="cron job for $pg_disk_monitor_script_file was not present in $cron_root, setting it now ... (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $err $log_message
   else
      # already present; ensure the value is set to run once in every 15 mins
      curr_value=$(echo "$result" | cut -d " " -f 1-5)
      ((err=err+$?))

      if [[ "x$curr_value" == "x$required_value" ]] ; then
         log_message="cron job for $pg_disk_monitor_script_file was present and already set correctly to the value "$curr_value" in $cron_root (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $err "$log_message"
      else
         sed -i "s|^.*${search_arg_escaped}.*$|$req_val_escaped $search_arg_escaped|" $cron_root
         ((err=err+$?))
         log_message="cron job for $pg_disk_monitor_script_file was set to "$curr_value" and now has been rectified in $cron_root to the new value "$required_value" (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $err "$log_message"
      fi
   fi

   log_message="The system must provide a warning to appropriate support staff when allocated audit record storage volume reaches 75% of maximum audit record storage capacity."
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC639 ] PostgreSQL must produce audit records containing sufficient information 
# to establish what type of events occurred.
# [ VXSEC643 ] PostgreSQL must produce audit records containing time stamps to establish when the events occurred.
# [ VXSEC595 ] PostgreSQL must generate audit records when successful logons or connections occur.
# [ VXSEC606 ] PostgreSQL must generate audit records when concurrent logons/connections by the same user from different workstations occur.
# [ Partial Implementation ] - remaining part of the Vulnerability is Met by VXSEC590/VXSEC591
#
err=0
vxsec_id="VXSEC639"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # VXSEC643 requires us to have %m instead of the %t value - %m additionally displays seconds in the timestamp %t value
   required_value="'%m [%p]: [%l-1] [%c] [%h] [%a] [%r] user=%u,db=%d '"
   req_val_escaped=$(echo "$required_value"| sed 's/%/\\%/g')
   ((err=err+$?))
   result=$(grep -i "^log_line_prefix=" $postgresql_conf)
   
   if [[ -z "$result" ]]; then
      # not present; so insert into file
      echo "log_line_prefix=$required_value" >> $postgresql_conf
      ((err=err+$?))
      log_message="Parameter log_line_prefix was not present in ${postgresql_conf}, setting it now ... (NON-COMPLIANT, APPLIED:INSERTED)"
      LOG $log_title_info $vuln_id $err $log_message
   else
      # already present; ensure the value is correct
      curr_value=$(echo "$result" | sed 's/^log_line_prefix=//')
      ((err=err+$?))

      if [ "$curr_value" == "$required_value" ] ; then
         log_message="Parameter log_line_prefix was present and already set correctly in ${postgresql_conf} to the value "$curr_value" (COMPLIANT, UNCHANGED)"
         LOG $log_title_info $vuln_id $err "$log_message"
      else
         sed -i "s/^log_line_prefix=.*$/log_line_prefix=$req_val_escaped/g" $postgresql_conf
         ((err=err+$?))
         log_message="Parameter log_line_prefix was set to "$curr_value" and has now been rectified in ${postgresql_conf} to the new value "$required_value" (NON-COMPLIANT, APPLIED:UPDATED)"
         LOG $log_title_info $vuln_id $err "$log_message"
      fi
   fi

   log_message="PostgreSQL must produce audit records containing sufficient information to establish what type of events occurred."
   LOG $log_title_info $vuln_id $err $log_message

   #Adding logging for VXSEC643
   vxsec_id="VXSEC643"
   get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval
   log_message="PostgreSQL must produce audit records containing time stamps to establish when the events occurred."
   LOG $log_title_info $vuln_id $err $log_message

   #Adding logging for VXSEC595
   vxsec_id="VXSEC595"
   get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval
   log_message="PostgreSQL must generate audit records when successful logons or connections occur."
   LOG $log_title_info $vuln_id $err $log_message

   #Adding logging for VXSEC606
   vxsec_id="VXSEC606"
   get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval
   log_message="PostgreSQL must generate audit records when concurrent logons/connections by the same user from different workstations occur."
   LOG $log_title_info $vuln_id $err $log_message
fi


################################################################
##### Tomcat rules                                         #####
##### Tomcat rules                                         #####
################################################################

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC752 ] Secured connectors must be configured to use strong encryption ciphers
# This is set by default, except for a 'HTTP' connector in the server.xml file.
# Since that connector is not used, the connect can be removed instead.
#
err=0
vxsec_id="VXSEC752"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_server_file)
   # 6. element name to find
   # 7. attribute name to identify the correct element by
   # 8. attribute value

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='Secured connectors must be configured to use strong encryption ciphers'  # 4. vuln title
   inElem='Connector'                   # 6. element name to find
   inElemAttrName='port'               # 7. attribute name to identify the correct element by
   inElemAttrValue='${bio.http.port}'  # 8. attribute value

   $removeElementInXMLfile "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_server_file" "$inElem" "$inElemAttrName" "$inElemAttrValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC757 ] Cookies must have secure flag set
#
err=0
vxsec_id="VXSEC757"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_web_file)
   # 6. element name to find (parent)
   # 7. XML section which should be applied inside the provided element name (child)
   # 8. existence check (True/False) - check/insert only, no compare/update

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='Cookies must have secure flag set'  # 4. vuln title
   inElem='session-config'                         # 6. element name to find

   # 7. full element section as XML (with the web.xml namespace)
   applyElemNsXML="<cookie-config><http-only>true</http-only><secure>true</secure></cookie-config>"

   checkExistenceOnly="False"                      # 8. Existence only or also content?

   $applyElementInXMLfile "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_web_file" "$inElem" "$applyElemNsXML" "$checkExistenceOnly"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi


   # Adding logging for VXSEC758 Cookies must have http-only flag set

   # transfer result of vxsec757
   vuln_id_vxsec757=$vuln_id
   if [ $result -ge 2 ]; then err=$result; fi

   # log same result for vxsec758
   vxsec_id="VXSEC758"
   get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval
   log_message="Cookies must have http-only flag set (implemented by $vuln_id_vxsec757)"
   LOG $log_title_info $vuln_id $err $log_message

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC759 ] DefaultServlet must be set to readonly for PUT and DELETE
#
err=0
vxsec_id="VXSEC759"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_web_file)

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='DefaultServlet must be set to readonly for PUT and DELETE'  # 4. vuln title

   $vxsec759 "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_web_file"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC768 ] ${tc_catalina_base}/logs folder permissions must be set to 750
#
err=0
vxsec_id="VXSEC768"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires checking (file or directory) permissions, for which we use a function.

   # Prepare parameters to pass to function:
   # 1. Vulnerability ID
   # 2. Vulnerability title
   # 3. name of the directory
   # 4. required permissions in octal notation

   # Rule variables
   vuln_title="${tc_catalina_base}/logs folder permissions must be set to 750"
   dir_name="${tc_catalina_base}/logs"
   dir_permissions=750

   setPermissionForFile "$vuln_id" "$vuln_title" "$dir_name" "$dir_permissions"
   result=$?

   if [ $result -eq 0 ]; then 
      LOG $log_title_info $vuln_id $result $vuln_title
   else
      LOG $log_title_warn $vuln_id $result "Error received from function ($result)"
   fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC769 ] Files in the ${tc_catalina_base}/logs/ folder must have their permissions set to 640
#
err=0
vxsec_id="VXSEC769"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # Prepare parameters to pass to function:
   # 1. Vulnerability ID
   # 2. Vulnerability title
   # 3. Directory path (e.g. /foo/bar/)
   # 4. file spec
   # 5. required permissions in octal notation

   # Rule variables
   vuln_title="Files in the ${tc_catalina_base}/logs/ folder must have their permissions set to 640"
   dir_name=${tc_catalina_base}/logs/
   file_spec="*"
   file_permissions_reqd=640

   setPermissionForFilesInFolder "$vuln_id" "$vuln_title" "$dir_name" "$file_spec" "$file_permissions_reqd"
   result=$?
   if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC770 ] Files in the ${tc_catalina_base}/conf/ folder must have their permissions set to 640
# This will set the file permissions to a more restrictive 600, per the guidance of VxRail ENG.
#
err=0
vxsec_id="VXSEC770"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # Prepare parameters to pass to function:
   # 1. Vulnerability ID
   # 2. Vulnerability title
   # 3. Directory path (e.g. /foo/bar/)
   # 4. file spec
   # 5. required permissions in octal notation

   # Rule variables
   vuln_title="Files in the ${tc_catalina_base}/conf/ folder must have their permissions set to 600 (STIG:640)"
   dir_name=${tc_catalina_base}/conf/
   file_spec="*"
   file_permissions_reqd=600

   setPermissionForFilesInFolder "$vuln_id" "$vuln_title" "$dir_name" "$file_spec" "$file_permissions_reqd"
   result=$?
   if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC772 ] Jar files in the $CATALINA_HOME/bin/ folder must have their permissions set to 400 (STIG:640)
# On guidance of VxRail ENG, first ownership of the directory and files in bin are set to tcserver:pivotal,
# and then permissions of the jar files can be restricted even further to just 400.
#
err=0
vxsec_id="VXSEC772"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # First ensure the ownership is correct, before restricting file permissions

   # Rule variables
   vuln_title='Jar files in the $CATALINA_HOME/bin/ folder must have their permissions set to 400 (STIG:640)'
   dir_name="$tc_catalina_home/bin"
   file_spec="*"
   reqdUsr='tcserver'
   reqdGrp='pivotal'

   echo "$vuln_title"

   LOG $log_title_info $vuln_id $err "First ensure ownership of directory $dir_name is set to $reqdUsr:$reqdGrp"
   setUserGroupForFile "$vuln_id" "$vuln_title" "$dir_name" "$reqdUsr" "$reqdGrp"
   ((err=err+$?)); if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   LOG $log_title_info $vuln_id $err "Second ensure ownership of files ($file_spec) in directory $dir_name is set to $reqdUsr:$reqdGrp"
   setUserGroupForFilesInFolder "$vuln_id" "$vuln_title" "$dir_name" "$file_spec" "$reqdUsr" "$reqdGrp"
   ((err=err+$?)); if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   # Now that ownership is correct, file permissions can be restricted

   # Rule variables
   file_spec="*.jar"
   file_permissions_reqd=400

   LOG $log_title_info $vuln_id $err "Now that directory and file ownership is correct, permissions of the jar files can be restricted"
   setPermissionForFilesInFolder "$vuln_id" "$vuln_title" "$dir_name" "$file_spec" "$file_permissions_reqd"
   ((err=err+$?))
   if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC773 ] $CATALINA_HOME/bin folder permissions must be set to 500 (STIG:750)
# On guidance of VxRail ENG, first ownership of the folder is set to tcserver:pivotal
# and then permissions on the directory an be restricted even further to just 500.
#
err=0
vxsec_id="VXSEC773"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires checking (file or directory) permissions, for which we use a function.

   # Prepare parameters to pass to function:
   # 1. Vulnerability ID
   # 2. Vulnerability title
   # 3. name of the directory
   # 4. required permissions in octal notation

   # Rule variables
   vuln_title='$CATALINA_HOME/bin folder permissions must be set to 500 (STIG:750)'
   dir_name="$tc_catalina_home/bin"
   reqdUsr='tcserver'
   reqdGrp='pivotal'
   dir_permissions=500

   echo "$vuln_title"

   LOG $log_title_info $vuln_id $err "First ensure ownership of directory $dir_name is set to $reqdUsr:$reqdGrp"
   setUserGroupForFile "$vuln_id" "$vuln_title" "$dir_name" "$reqdUsr" "$reqdGrp"
   ((err=err+$?)); if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   # Now that ownership is correct, directory permissions can be restricted

   # Rule variables
   dir_permissions=500

   LOG $log_title_info $vuln_id $err "Now that directory ownership is correct, directory permissions can be restricted"
   setPermissionForFile "$vuln_id" "$vuln_title" "$dir_name" "$dir_permissions"
   result=$?

   if [ $result -eq 0 ]; then
      LOG $log_title_info $vuln_id $result $vuln_title
   else
      LOG $log_title_warn $vuln_id $result "Error received from function ($result)"
   fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC774 ] Tomcat user UMASK must be set to 0027
#
err=0
vxsec_id="VXSEC774"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # Rule variables
   vuln_title='Tomcat user UMASK must be set to 0027'
   file_name=$tc_service_file
   param_name="Environment=UMASK"
   param_sep="="
   param_reqd_val="0027"

   replaceParamInFile "$vuln_id" "$vuln_title" "$file_name" "$param_name" "$param_sep" "$param_reqd_val" restartMarvinFlag
   result=$?
   if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC776 ] The shutdown port must be disabled
#
err=0
vxsec_id="VXSEC776"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # Rule variables
   vuln_title='The shutdown port must be disabled'
   file_name=$tc_props_file
   param_name="base.shutdown.port"
   param_sep="="
   param_reqd_val="-1"

   replaceParamInFile "$vuln_id" "$vuln_title" "$file_name" "$param_name" "$param_sep" "$param_reqd_val" restartMarvinFlag
   result=$?
   if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC777 ] Unapproved connectors must be disabled
# There may still be a connector that is configured for HTTP instead of HTTPS.
# If so, then that connector can be removed. It is probably already removed by VXSEC752 though.
#
err=0
vxsec_id="VXSEC777"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_server_file)
   # 6. element name to find
   # 7. attribute name to identify the correct element by
   # 8. attribute value

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='Unapproved connectors must be disabled'  # 4. vuln title
   inElem='Connector'                   # 6. element name to find
   inElemAttrName='port'               # 7. attribute name to identify the correct element by
   inElemAttrValue='${bio.http.port}'  # 8. attribute value

   $removeElementInXMLfile "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_server_file" "$inElem" "$inElemAttrName" "$inElemAttrValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC780 ] The deployXML attribute must be set to false in hosted environments
# VxRail ENG guidance: To enable deployXML and prevent issues, set the flag to false in the server.xml file, and
# copy the context file from webapp LCM to catalina localhost.
#
err=0
vxsec_id="VXSEC780"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

#Disabling rule VXSEC780 - This setting impacts VxRail LCM upgrades
vuln_title='The deployXML attribute must be set to false in hosted environments'
msg="...Skipping disabled control Vulnerability ID:$vuln_id with Title: $vuln_title"
echo "$msg"
LOG $log_title_warn $vuln_id 0 "$msg"
get_vuln_id_optval 'VXSEC780disabled' # force a $? that is not VID_MAP_OK (i.e. not 0)

if [ $? -eq $VID_MAP_OK ] ; then

   # Steps:
   # 1. Set deployXML to false in $CATALINA_BASE/conf/server.xml
   # 2. Now copy (or link?) the LCM context file ($CATALINA_BASE/webapps/lcm/META-INF/context.xml) to $CATALINA_BASE/conf/Catalina/localhost/lcm.xml

   # Step 1/2. Set deployXML to false in $CATALINA_BASE/conf/server.xml
   # This requires parsing and modifying an XML file, for which we use a Python script.
   LOG $log_title_info $vuln_id $err 'Step 1/2. Set deployXML to false in $CATALINA_BASE/conf/server.xml'

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_server_file)
   # 6. element name to find
   # 7. attribute name to identify the correct element by
   # 8. attribute value
   # 9. key name of the attribute to check for compliance
   # 10.key value

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='The deployXML attribute must be set to false in hosted environments' # 4. vuln title
   inElem='Host'                            # 6. element name to find
   inElemAttrName='name'                    # 7. attribute name to identify the correct element by
   inElemAttrValue='localhost'              # 8. attribute value
   keyName='deployXML'                      # 9. key name of the attribute to check for compliance
   keyValue='false'                         # 10.key value

   $setKeyOfElementAttributeInXMLfile "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_server_file" "$inElem" "$inElemAttrName" "$inElemAttrValue" "$keyName" "$keyValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi

   # Step 2/2. Link the LCM context file
   # NOTE: If we can't link the file, but need to copy the file instead, then this rule must be run as last
   # Tomcat rule, because if a later rule updates the source file, then the target would miss the update.
   LOG $log_title_info $vuln_id $err "Step 2/2. Link the LCM context file (from $tc_webapp_lcm_context_file to $tc_localhost_lcm_context_file)"
   ln -sf $tc_webapp_lcm_context_file $tc_localhost_lcm_context_file
   ((err=err+$?))

   LOG $log_title_info $vuln_id $err "$vuln_title"
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC781 ] Autodeploy must be disabled
#
err=0
vxsec_id="VXSEC781"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval 

# Disabling rule VXSEC781 - see VxR STIG v2.1.001 Known Issue re LCM
vuln_title='Autodeploy must be disabled'
msg="...Skipping disabled control Vulnerability ID:$vuln_id with Title: $vuln_title"
echo "$msg"
LOG $log_title_warn $vuln_id 0 "$msg" 
get_vuln_id_optval 'VXSEC781disabled' # force a $? that is not VID_MAP_OK (i.e. not 0)

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_server_file)
   # 6. element name to find
   # 7. attribute name to identify the correct element by
   # 8. attribute value
   # 9. key name of the attribute to check for compliance
   # 10.key value

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='Autodeploy must be disabled' # 4. vuln title
   inElem='Host'                            # 6. element name to find
   inElemAttrName='name'                    # 7. attribute name to identify the correct element by
   inElemAttrValue='localhost'              # 8. attribute value
   keyName='autoDeploy'                     # 9. key name of the attribute to check for compliance
   keyValue='false'                         # 10.key value

   $setKeyOfElementAttributeInXMLfile "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_server_file" "$inElem" "$inElemAttrName" "$inElemAttrValue" "$keyName" "$keyValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC792 ] Keystore file must be protected
# On guidance of VxRail ENG, first ownership of the folder /etc/vmware-marvin and subdirectory ssl
# is set to root:pivotal, with dir permission 750. Then the keystore file (server.pfx) is also set to
# owernership root:pivotal and file permission 640.
#
err=0
vxsec_id="VXSEC792"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires checking (file or directory) permissions, for which we use a function.

   # Rule variables
   vuln_title='Keystore file must be protected'
   reqdUsr='root'
   reqdGrp='pivotal'

   echo "$vuln_title"

   # 1. Set ownership and permission for /etc/vmware-marvin

   # Function variables
   dir_name="/etc/vmware-marvin"
   dir_permissions=750

   LOG $log_title_info $vuln_id $err "1/3: First ensure ownership of directory $dir_name is set to $reqdUsr:$reqdGrp with permission $dir_permissions"

   setUserGroupForFile "$vuln_id" "$vuln_title" "$dir_name" "$reqdUsr" "$reqdGrp"
   ((err=err+$?)); if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   setPermissionForFile "$vuln_id" "$vuln_title" "$dir_name" "$dir_permissions"
   ((err=err+$?)); if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   # 2. Set ownership and permission for /etc/vmware-marvin/ssl

   # Function variables
   dir_name="/etc/vmware-marvin/ssl"
   dir_permissions=750
   LOG $log_title_info $vuln_id $err "2/3: Next ensure ownership of directory $dir_name is set to $reqdUsr:$reqdGrp with permission $dir_permissions"

   setUserGroupForFile "$vuln_id" "$vuln_title" "$dir_name" "$reqdUsr" "$reqdGrp"
   ((err=err+$?)); if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   setPermissionForFile "$vuln_id" "$vuln_title" "$dir_name" "$dir_permissions"
   ((err=err+$?)); if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   # 3. Set ownership and permission for the keystore

   # Function variables
   file_name="/etc/vmware-marvin/ssl/$ssl_keystore_file"
   file_permissions=640
   LOG $log_title_info $vuln_id $err "3/3: Now protect the keyfile - ensure ownership of the keystore file $file_name is set to $reqdUsr:$reqdGrp with permission $file_permissions"

   setUserGroupForFile "$vuln_id" "$vuln_title" "$file_name" "$reqdUsr" "$reqdGrp"
   ((err=err+$?)); if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   setPermissionForFile "$vuln_id" "$vuln_title" "$file_name" "$file_permissions"
   result=$?
   ((err=err+result))

   if [ $result -eq 0 ]; then
      LOG $log_title_info $vuln_id $err $vuln_title
   else
      LOG $log_title_warn $vuln_id $result "Error received from function ($result)"
   fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC793 ] Tomcat must use FIPS-validated ciphers on secured connectors
#
err=0
vxsec_id="VXSEC793"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_server_file)
   # 6. element name to find
   # 7. attribute name to identify the correct element by
   # 8. attribute value
   # 9. key name of the attribute to check for compliance
   # 10.key value

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='Tomcat must use FIPS-validated ciphers on secured connectors' # 4. vuln title
   inElem='Listener'                                                         # 6. element name to find
   inElemAttrName='className'                                                # 7. attribute name to identify the correct element by
   inElemAttrValue='org.apache.catalina.core.AprLifecycleListener'           # 8. attribute value
   keyName='FIPSMode'                                                        # 9. key name of the attribute to check for compliance
   keyValue='on'                                                             # 10.key value

   $setKeyOfElementAttributeInXMLfile "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_server_file" "$inElem" "$inElemAttrName" "$inElemAttrValue" "$keyName" "$keyValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC802 ] Tomcat server version must not be sent with warnings and errors
#
err=0
vxsec_id="VXSEC802"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # ---------------------------------------------------------
   # 0. Set rule values
   # ---------------------------------------------------------
   action='apply' 
   vuln_title='Tomcat server version must not be sent with warnings and errors'

   # ---------------------------------------------------------
   # 1. Extract the properties file from the jar file
   #    Overwrite the file it if already exists (not expected)
   # ---------------------------------------------------------
   unzip -o $tc_catalina_jar $tc_svr_props_file >> $SCRIPT_LOG 2>&1
   ((err=err+$?))
   LOG $log_title_debug $vuln_id $err "Unzipped properties file ($tc_svr_props_file) from the jar file ($tc_catalina_jar)"

   # ---------------------------------------------------------
   # 2. Perform the compliance action on the parameters
   # ---------------------------------------------------------
   # This requires checking/applying a parameter assignment in a file, for which we use a function.
   # The function does the full compliance check and logging

   # Prepare parameters to pass to function:
   # 1. Vulnerability ID
   # 2. Vulnerability title
   # 3. Action (check or apply)
   # 4. filepath
   # 5. parameter name
   # 6. parameter separator
   # 7. parameter value

   # First parameter to check in file: server.info
   setParamInFile "$vuln_id" "$vuln_title" "$action" "$tc_svr_props_file" "server.info" "=" "Standard Server"
   res=$?
   if [ $res -eq 0 ]; then 
      LOG $log_title_info $vuln_id $res $vuln_title
   else
      LOG $log_title_warn $vuln_id $res "Error received from function (result=$res)"
   fi

   # Second parameter to check in file: server.number
   setParamInFile "$vuln_id" "$vuln_title" "$action" "$tc_svr_props_file" "server.number" "=" "1.2.3.4"
   res=$?
   if [ $res -eq 0 ]; then 
      LOG $log_title_info $vuln_id $res $vuln_title
   else
      LOG $log_title_warn $vuln_id $res "Error received from function (result=$res)"
   fi

   # -------------------------------------------------
   # 3. zip the properties file back into the jar file
   # -------------------------------------------------
   zip $tc_catalina_jar $tc_svr_props_file >> $SCRIPT_LOG 2>&1
   res=$?
   ((err=err+res))

   if [ $res -eq 0 ]
   then
      LOG $log_title_info $vuln_id $err "Successfully zipped the properties file ($tc_svr_props_file) into the jar file ($tc_catalina_jar)"
   else
      # Zip failed!
      LOG $log_title_error $vuln_id $err "Failed to zip the properties file ($tc_svr_props_file) back into the jar file ($tc_catalina_jar) (result=$res)"
   fi

   # ----------------------------------
   # 4. Cleanup - delete extracted file
   # ----------------------------------
   baseDir=$(echo $tc_svr_props_file|cut -d/ -f1) # Extract 1st dir from e.g. org/apache/...etc...
   LOG $log_title_debug $vuln_id $err "Cleanup temporary extracted file. Removing from base of directory path using: rm -rf $baseDir"
   rm -rf $baseDir >> $SCRIPT_LOG 2>&1
   res=$?
   ((err=err+res))

   if [ $res -eq 0 ]
   then
      LOG $log_title_debug $vuln_id $err "Successfully removed the temporary extracted properties file ($tc_svr_props_file)"
   else
      LOG $log_title_warn $vuln_id $err "Failed to remove the temporary extracted properties filepath ($tc_svr_props_file) (result=$res)"
   fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC804 ] LockOutRealms must be used for management of Tomcat
#
err=0
vxsec_id="VXSEC804"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_web_file)
   # 6. element name to find (parent)
   # 7. XML section which should be applied inside the provided element name (child)
   # 8. existence check (True/False) - check/insert only, no compare/update

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='LockOutRealms must be used for management of Tomcat'  # 4. vuln title
   inElem='Engine'                                                   # 6. element name to find

   # 7. full element section as XML
   applyElemNsXML='<Realm className="org.apache.catalina.realm.LockOutRealm"></Realm>'

   checkExistenceOnly="True"                                         # 8. Existence only or also content?

   $applyElementInXMLfile "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_server_file" "$inElem" "$applyElemNsXML" "$checkExistenceOnly"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC805 ] LockOutRealms failureCount attribute must be set to 5 failed logins for admin users
#
err=0
vxsec_id="VXSEC805"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_server_file)
   # 6. element name to find
   # 7. attribute name to identify the correct element by
   # 8. attribute value
   # 9. key name of the attribute to check for compliance
   # 10.key value

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='LockOutRealms failureCount attribute must be set to 5 failed logins for admin users' # 4. vuln title
   inElem='Realm'                                           # 6. element name to find
   inElemAttrName='className'                               # 7. attribute name to identify the correct element by
   inElemAttrValue='org.apache.catalina.realm.LockOutRealm' # 8. attribute value
   keyName='failureCount'                                   # 9. key name of the attribute to check for compliance
   keyValue='5'                                             # 10.key value

   $setKeyOfElementAttributeInXMLfile "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_server_file" "$inElem" "$inElemAttrName" "$inElemAttrValue" "$keyName" "$keyValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC806 ] LockOutRealms lockOutTime attribute must be set to 600 seconds (10 minutes) for admin users
#
err=0
vxsec_id="VXSEC806"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. name of xml file ($tc_server_file)
   # 6. element name to find
   # 7. attribute name to identify the correct element by
   # 8. attribute value
   # 9. key name of the attribute to check for compliance
   # 10.key value

   # assign params that are not known yet, which are specific to this vulnerability control
   vuln_title='LockOutRealms lockOutTime attribute must be set to 600 seconds (10 minutes) for admin users'
   inElem='Realm'                                           # 6. element name to find
   inElemAttrName='className'                               # 7. attribute name to identify the correct element by
   inElemAttrValue='org.apache.catalina.realm.LockOutRealm' # 8. attribute value
   keyName='lockOutTime'                                    # 9. key name of the attribute to check for compliance
   keyValue='600'                                           # 10.key value

   $setKeyOfElementAttributeInXMLfile "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$tc_server_file" "$inElem" "$inElemAttrName" "$inElemAttrValue" "$keyName" "$keyValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC821 ] Changes to $CATALINA_HOME/bin/ folder must be logged
#
err=0
vxsec_id="VXSEC821"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # Rule variables
   vuln_title='Changes to $CATALINA_HOME/bin/ folder must be logged'
   audit_path="$tc_catalina_home/bin"
   reqd_rule="-w $audit_path -p wa -k tomcat"

   applyAuditRule "$vuln_id" "$vuln_title" "$audit_path" "$reqd_rule"
   result=$?
   if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC811 ] $CATALINA_BASE/conf/ folder must be owned by root,  group tomcat
# This will instead keep the directory ownership set to tcserver:pivotal, after checking with VxRail ENG.
#
err=0
vxsec_id="VXSEC811"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires checking (file or directory) permissions, for which we use a function.

   # Rule variables
   vuln_title='$CATALINA_BASE/conf/ folder must be owned by tcserver, group pivotal (STIG:root/tomcat)'
   srcdir=$tc_catalina_base/conf/
   reqdUsr='tcserver'
   reqdGrp='pivotal'

   echo "$vuln_title"

   setUserGroupForFile "$vuln_id" "$vuln_title" "$srcdir" "$reqdUsr" "$reqdGrp"
   result=$?

   if [ $result -eq 0 ]; then
      LOG $log_title_info $vuln_id $result $vuln_title
   else
      LOG $log_title_warn $vuln_id $result "Error received from function ($result)"
   fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC814 ] $CATALINA_BASE/temp/ folder permissions must be set to 750
# On guidance of VxRail ENG, first ensure ownership of the folder is set to tcserver:pivotal, then dir permission 750 is set.
#
err=0
vxsec_id="VXSEC814"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires checking (file or directory) permissions, for which we use a function.

   # Rule variables
   vuln_title='$CATALINA_BASE/temp/ folder permissions must be set to 750'
   srcdir=$tc_catalina_base/temp/
   reqdUsr='tcserver'
   reqdGrp='pivotal'
   dir_permissions=750

   echo "$vuln_title"

   LOG $log_title_info $vuln_id $err "First ensure ownership of directory $srcdir is set to $reqdUsr:$reqdGrp"
   setUserGroupForFile "$vuln_id" "$vuln_title" "$srcdir" "$reqdUsr" "$reqdGrp"
   ((err=err+$?)); if [ $err -ne 0 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

   LOG $log_title_info $vuln_id $err "Next ensure permissions on directory $dir_name are set to $dir_permissions"
   setPermissionForFile "$vuln_id" "$vuln_title" "$srcdir" "$dir_permissions"
   result=$?
   ((err=err+result))

   if [ $result -eq 0 ]; then
      LOG $log_title_info $vuln_id $err $vuln_title
   else
      LOG $log_title_warn $vuln_id $result "Error received from function ($result)"
   fi
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC822 ] Changes to $CATALINA_BASE/conf/ folder must be logged
#
err=0
vxsec_id="VXSEC822"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # Rule variables
   vuln_title='Changes to $CATALINA_BASE/conf/ folder must be logged'
   audit_path="$tc_catalina_base/conf"
   reqd_rule="-w $audit_path -p wa -k tomcat"

   applyAuditRule "$vuln_id" "$vuln_title" "$audit_path" "$reqd_rule"
   result=$?
   if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC823 ] Changes to $CATALINA_HOME/lib/ folder must be logged
#
err=0
vxsec_id="VXSEC823"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # Rule variables
   vuln_title='Changes to $CATALINA_HOME/lib/ folder must be logged'
   audit_path="$tc_catalina_home/lib"
   reqd_rule="-w $audit_path -p wa -k tomcat"

   applyAuditRule "$vuln_id" "$vuln_title" "$audit_path" "$reqd_rule"
   result=$?
   if [ $result -ge 1 ]; then LOG $log_title_warn $vuln_id $result "Error received from function ($result)"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC825 ] STRICT_SERVLET_COMPLIANCE must be set to true
#
err=0
vxsec_id="VXSEC825"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

# Disabling rule VXSEC825 - This setting impacts VxRail
vuln_title='STRICT_SERVLET_COMPLIANCE must be set to true'
msg="...Skipping disabled control Vulnerability ID:$vuln_id with Title: $vuln_title"
echo "$msg"
LOG $log_title_warn $vuln_id 0 "$msg" 
get_vuln_id_optval 'VXSEC825disabled' # force a $? that is not VID_MAP_OK (i.e. not 0)

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires a call to a function that was implemented in a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. Action (check or apply)
   # 6. name of settings file where JVM_OPTS is set
   # 7. parm name
   # 8. parm value

   # assign params that are not yet known yet, which are specific to this vulnerability control
   vuln_title='STRICT_SERVLET_COMPLIANCE must be set to true'  # 4. vuln title
   action='apply'                                              # 5. check or apply
   #                                                           # 6. $tc_setenv_file
   parmName='-Dorg.apache.catalina.STRICT_SERVLET_COMPLIANCE'  # 7. parameter name
   parmValue='true'                                            # 8. parameter value

   $applyJvmOpts "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$action" "$tc_setenv_file" "$parmName" "$parmValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC826 ] RECYCLE_FACADES must be set to true
#
err=0
vxsec_id="VXSEC826"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. Action (check or apply)
   # 6. name of settings file where JVM_OPTS is set
   # 7. parm name
   # 8. parm value

   # assign params that are not yet known yet, which are specific to this vulnerability control
   vuln_title='RECYCLE_FACADES must be set to true'            # 4. vuln title
   action='apply'                                              # 5. check or apply
   #                                                           # 6. $tc_setenv_file
   parmName='-Dorg.apache.catalina.connector.RECYCLE_FACADES'  # 7. parameter name
   parmValue='true'                                            # 8. parameter value

   $applyJvmOpts "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$action" "$tc_setenv_file" "$parmName" "$parmValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC827 ] ALLOW_BACKSLASH must be set to false
#
err=0
vxsec_id="VXSEC827"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. Action (check or apply)
   # 6. name of settings file where JVM_OPTS is set
   # 7. parm name
   # 8. parm value

   # assign params that are not yet known yet, which are specific to this vulnerability control
   vuln_title='ALLOW_BACKSLASH must be set to false'           # 4. vuln title
   action='apply'                                              # 5. check or apply
   #                                                           # 6. $tc_setenv_file
   parmName='-D.org.apache.catalina.connector.ALLOW_BACKSLASH' # 7. parameter name
   parmValue='false'                                           # 8. parameter value

   $applyJvmOpts "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$action" "$tc_setenv_file" "$parmName" "$parmValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC828 ] ENFORCE_ENCODING_IN_GET_WRITER must be set to true
#
err=0
vxsec_id="VXSEC828"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # This requires parsing and modifying an XML file, for which we use a Python script.

   # Prepare parameters to pass to Python script
   # 1. Vulnerability ID
   # 2. Log file name
   # 3. stig log level
   # 4. Vulnerability title
   # 5. Action (check or apply)
   # 6. name of settings file where JVM_OPTS is set
   # 7. parm name
   # 8. parm value

   # assign params that are not yet known yet, which are specific to this vulnerability control
   vuln_title='ENFORCE_ENCODING_IN_GET_WRITER must be set to true'                    # 4. vuln title
   action='apply'                                                                     # 5. check or apply
   #                                                                                  # 6. $tc_setenv_file
   parmName='-Dorg.apache.catalina.connector.response.ENFORCE_ENCODING_IN_GET_WRITER' # 7. parameter name
   parmValue='true'                                                                   # 8. parameter value

   $applyJvmOpts "$vuln_id" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$vuln_title" "$action" "$tc_setenv_file" "$parmName" "$parmValue"
   result=$?

   if [ $result -eq 1 ]; then restartMarvinFlag=1; fi
   if [ $result -ge 2 ]; then LOG $log_title_debug $vuln_id $result "Error received from subprocess"; fi

fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC833 ] The application server must alert the SA and ISSO, at a minimum, in the event of a log processing failure
#
err=0
vxsec_id="VXSEC833"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   # ---------------------------------------------------------
   # 0. Set rule values
   # ---------------------------------------------------------
   action='apply' 
   vuln_title='The application server must alert the SA and ISSO, at a minimum, in the event of a log processing failure'
   param_name="action_mail_acct"
   param_sep=" = "
   param_val="root"

   # ---------------------------------------------------------
   # 1. Perform the compliance action on the parameters
   # ---------------------------------------------------------
   # This requires checking/applying a parameter assignment in a file, for which we use a function.
   # The function does the full compliance check and logging

   # Prepare parameters to pass to function:
   # 1. Vulnerability ID
   # 2. Vulnerability title
   # 3. Action (check or apply)
   # 4. filepath
   # 5. parameter name
   # 6. parameter separator
   # 7. parameter value

   setParamInFile "$vuln_id" "$vuln_title" "$action" "$auditd_conf" "$param_name" "$param_sep" "$param_val"
   res=$?
   if [ $res -eq 0 ]; then 
      LOG $log_title_info $vuln_id $res $vuln_title
   else
      LOG $log_title_warn $vuln_id $res "Error received from function (result=$res)"
   fi
fi

#######################################################################
##### Restarting ALL services                                     #####
##### Restarting ALL services                                     #####
#######################################################################

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC159 ] SUSE operating system must be configured to prohibit or restrict the use of functions, ports, protocols, 
# and/or services as defined in the PPSM CAL and vulnerability assessments
#
err=0
vxsec_id="VXSEC159"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo "SUSE operating system must be configured to prohibit or restrict the use of functions, ports, protocols, and/or services as defined in the PPSM CAL and vulnerability assessments"
   if [[ "$OSrelName" == "SLES15" ]]; then
      echo -e "\n${yellow}Restarting firewalld service\n${normal}"
      result=$(systemctl is-enabled firewalld.service)

      if [[ "$result" == "enabled" ]]; then
         systemctl restart firewalld.service
         ((err=err+$?))
         sleep 3s     
      else
         systemctl enable firewalld.service
         ((err=err+$?))
         systemctl restart firewalld.service
         ((err=err+$?))
         sleep 3s
      fi
      # Workaround for VxRail Plugin Issue after firewall restart - VXP-66694
      if [[ ("$vxrail_major_version" == "7" && ("$vxrail_version" == "7.0.370" || $vxrail_version > "7.0.370")) ]]; then
         log_message="Rebooting cilium. Supported versions: VxRail 7.0.x (7.0.370 or greater). Version found: VxRail $vxrail_version"
         LOG $log_title_info $vuln_id $err $log_message
         echo "Version found: VxRail $vxrail_version"
         kubectl delete pod -n kube-system -l k8s-app=cilium
         ((err=err+$?))
         echo "Cilium pod redeployed"
      fi
   fi
   
   if [[ "$OSrelName" == "SLES12" ]]; then
      echo -e "\n${yellow}Restarting SuSEfirewall2 service\n${normal}"
      result=$(systemctl is-enabled SuSEfirewall2.service)
      if [[ "$result" == "enabled" ]]; then
         systemctl restart SuSEfirewall2.service
         ((err=err+$?))
         sleep 3s     
      else
         systemctl enable SuSEfirewall2.service
         ((err=err+$?))
         systemctl restart SuSEfirewall2.service
         ((err=err+$?))
         sleep 3s
      fi
   fi     
   
   log_message="SUSE operating system must be configured to prohibit or restrict the use of functions, ports, protocols, and/or services"
   LOG $log_title_info $vuln_id $err $log_message
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXSEC089 ] SUSE operating system audit records must contain information to establish what type of events occurred, 
#              the source of events, where events occurred, and the outcome of events.
#
err=0
vxsec_id="VXSEC089"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then

   echo -e "\n${yellow}Restarting auditd service\n${normal}"

   result=$(systemctl is-enabled auditd.service)

   if [ "$result" == "enabled" ]; then
      systemctl restart auditd.service
      ((err=err+$?))
      sleep 3s     
   else
      systemctl enable auditd.service
      ((err=err+$?))
      systemctl restart auditd.service
      ((err=err+$?))
      sleep 3s
   fi

   log_message=" SUSE operating system audit records must contain information to establish what type of events occurred, the source of events, where events occurred, and the outcome of events"
   LOG $log_title_info $vuln_id $err $log_message
fi


# ------------------------------------------------------------------------------------------------------------------
# [ VXP-43177 ] Restart sshd.service
#
echo -e "\n${yellow}Restarting sshd services\n${normal}"
result=$(systemctl is-enabled sshd.service)

if [ "$result" == "enabled" ]; then
   systemctl restart sshd.service
   sleep 3s
else
   systemctl enable sshd.service
   systemctl restart sshd.service
   sleep 3s
fi


# ------------------------------------------------------------------------------------------------------------------
# [ VXP-41794 ] Aide settings to be verified, service enabled and started. Also see VXSEC053 further back.
#
err=0
vxsec_id="VXSEC053"
get_vuln_id_optval $vxsec_id # returns $vuln_id and $vuln_optval

if [ $? -eq $VID_MAP_OK ] ; then
   # Check that the config file is valid
   result=$(aide --config-check 2>&1)
   ((err=err+$?))

   if [[ -z "$result" ]]; then
      # Config file was valid; initialize the aide database
      echo "Aide is being initialized, this can take around 2-3 minutes or more..."
      aide -i
      ((err=err+$?))
      echo

      # Move the initialized db file in place
      mv ${aide_db_file}.new $aide_db_file
      ((err=err+$?))
      
      log_message="Aide settings were initialized."
      LOG $log_title_info $vuln_id $err $log_message
   else
      log_message="Aide configuration is incorrect, Please take action."
      LOG $log_title_error $vuln_id $err $log_message
   fi
   
fi

# ------------------------------------------------------------------------------------------------------------------
# [ VXP-62479 ] Restart postgreSQL service
#
echo -e "\n${yellow}Restarting postgreSQL services\n${normal}"
systemctl restart postgresql.service
sleep 3s

# ------------------------------------------------------------------------------------------------------------------
# Restart VMware Marvin service (Tomcat AS)
#
if [ $restartMarvinFlag -eq 1 ]; then
   echo -e "\n${yellow}Restarting VMware Marvin service${normal}"
   systemctl stop  vmware-marvin >> $SCRIPT_LOG 2>&1
   systemctl start vmware-marvin >> $SCRIPT_LOG 2>&1
   systemctl daemon-reload >> $SCRIPT_LOG 2>&1
   echo -e "${yellow}It may take a bit more time for the VxRail Plug-in in vCenter to become fully responsive again.\n${normal}"
else
   echo -e "\n${green}Restarting VMware Marvin service not required\n${normal}"
fi

# ------------------------------------------------------------------------------------------------------------------
# Checking the VxRail Manager Health/Plug-in Status 

   echo -e "${yellow}Checking (and if needed waiting) for the VxRail Plug-in in vCenter to be fully up and responsive...\n${normal}"
   sleep $MonitorVxRailClusterHealthInitialSleep

   # VXP-71922 Added a loop for checking the VxRail Manager Health/Plug-in Status in the Bash Script until the status is OK
   while true
   do
      outputString=`$MonitorVxRailClusterHealthUntilOK "--" "$SCRIPT_LOG" "$STIG_LOG_LEVEL" "$VxMIP" ${vcUsername} "${vcPassword}"`
      if [[ $outputString =~ '200' ]]; then
         tail -n 2 $SCRIPT_LOG
         echo -e "${green}VxRail Plug-in in vCenter is fully up and responsive...\n${normal}"
         break
      else
         tail -n 1 $SCRIPT_LOG
         echo -e "${red}VxRail Plug-in in vCenter is not fully up and responsive...Re-checking the status\n${normal}"
      fi
   done
# ------------------------------------------------------------------------------------------------------------------
# Check values are all set
if [[ $vxsec050_incorrect_email == 1 ]]; then
   echo -e "\n${yellow}Please update the value of email in $vxsec050_aide_cron_file manually.\n${normal}"
   LOG $log_title_warn "--" 1 "Please update the value of email in $vxsec050_aide_cron_file manually.\n"
fi
if [[ $vxsec093_incorrect_email == 1 ]]; then
   echo -e "\n${yellow}Please update the value of root's email in $aliases manually.\n${normal}"
   LOG $log_title_warn "--" 1 "Please update the value of root's email in $aliases manually.\n"
fi
if [[ $vxsec635_incorrect_email == 1 ]]; then
   echo -e "\n${yellow}Please update the value of email in $pg_disk_monitor_script_file manually.\n${normal}"
   LOG $log_title_warn "--" 1 "Please update the value of email in $pg_disk_monitor_script_file manually.\n"
fi
if [[ $NTP_setting_failed == 1 ]]; then
   echo -e "\n${yellow}$NTP_setting_vulnid Please update the value of time source in $ntp_conf manually.\n${normal}"
   LOG $log_title_warn "--" 1 "Please update the value of time source in $ntp_conf manually.\n"
fi

# Placing a STIG Hardening session marker in the VxRail web.log and short.term.log files
placeMarkerInVxRailLogFiles "END"

echo "********************************************" >> $SCRIPT_LOG
echo "*** End VxRail OS STIG Hardening Process ***" >> $SCRIPT_LOG
echo "********************************************" >> $SCRIPT_LOG

echo -e "${yellow}Current directory: $(pwd)${normal}"
echo -e "${yellow}Logfile location:  $SCRIPT_LOG${normal}"

echo -e "${green}#################################################${normal}"
echo -e "${green}# VxRail STIG Package - Hardening VxRM OS - End #${normal}"
echo -e "${green}#################################################${normal}"

#########################################################################################
# END
#########################################################################################

