#!/usr/bin/python
# ----------------------------------------------------------------------------------------------------------
# FILE         : MonitorVxRailClusterHealthuntilOK.py
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : Monitor the VxRail Health UI status through the API calls until the status is OK
# ----------------------------------------------------------------------------------------------------------

import sys
import time
import requests
import ssl
from VxRailSTIGLogging import *

# ----------------------------------------
# --- check input arguments
# ----------------------------------------
argCount     = len(sys.argv) - 1  # First argument (arg[0]) is always script name
argCountReqd = 6

if argCount == argCountReqd:
    
  # sys.argv[0] = file name of this python script
  # sys.argv[1] = vulnerability id
  # sys.argv[2] = log file name
  # sys.argv[3] = debug mode ('DEBUG', otherwise an empty string)
  VxMIP      = sys.argv[4]
  user       = sys.argv[5]
  password   = sys.argv[6]

else:
  vxrStigLog('ERROR', 'FAIL', f"Incorrect number of parameters (received {argCount}, requires {argCountReqd})")
  sys.exit(2)

# --- List all params when in debug mode
vxrStigLog('DEBUG', '--', f"param1={sys.argv[1]}")
vxrStigLog('DEBUG', '--', f"param2={sys.argv[2]}")
vxrStigLog('DEBUG', '--', f"param3={sys.argv[3]}")
vxrStigLog('DEBUG', '--', f"param4={sys.argv[4]}")
vxrStigLog('DEBUG', '--', f"param5={sys.argv[5]}")
vxrStigLog('DEBUG', '--', f"param6={sys.argv[6]}")

# disable warnings from SSL Check
if not sys.warnoptions:
    import warnings
    warnings.simplefilter("ignore")

# ----------------------------------------------------------------------------------------------------
def main():

    sleepSecs  = 30
    method     = 'GET'
    url        = f'https://{VxMIP}/rest/vxm/v1/system-health'
    headers    = {'Content-type': 'application/json'}
    creds      = (user, password)
    parameters = None
    resultOk   = 200
    exitCode   = 1 # by default, set to fail

    try:
        result = 999 # initialize for while condition

        while result != resultOk:
           response = requests.get(url, verify=False, headers=headers, auth=creds, json=parameters, timeout=30)
           result = response.status_code
           #vxrStigLog('INFO',  '--', f'{(response)}') 
           vxrStigLog('DEBUG', '--', f'API Call result text: {(response.text)}')
           vxrStigLog('INFO',  '--', f'API Call result: {(result)}')
            
           if (result != resultOk):
               msg = f"Status code is not OK ({result} instead of {resultOk}), entering sleep for {sleepSecs} seconds"
               vxrStigLog('INFO','--', msg) 
               print(msg)
               time.sleep (sleepSecs)
           else:
              msg = f"Status code is OK ({resultOk})"
              vxrStigLog('INFO','--', msg)
              print(msg) 
              exitCode=0 # success

        # end while

        sys.exit(exitCode)

    except Exception as err:
        vxrStigLog('ERROR', '--', err)
        sys.exit(exitCode)

# ----------------------------------------------------------------------------------------------------
# Start program
#SSL Check and Pass
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

if __name__ == "__main__":
    main()
