#!/usr/bin/python
# ----------------------------------------------------------------------------------------------------------
# FILE         : setCharacterEncodingFilter.py
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : V-256765 - The Security Token Service is set to use the 'setCharacterEncodingFilter' filter.
# ----------------------------------------------------------------------------------------------------------
# Parameters:
# 1. vuln-id                    (only used in VxRailSTIGLogging module)
# 2. Log file name to append to (only used in VxRailSTIGLogging module)
# 3. debug mode                 (only used in VxRailSTIGLogging module)
# ----------------------------------------------------------------------------------------------------------


# ----------------------------------------
# --- Import required modules ------------
# ----------------------------------------
import subprocess
import sys
import logging
from lxml import etree
from VxRailSTIGLogging import *        # Import * brings its contents in the current module.

# ----------------------------------------
# --- check input arguments
# ----------------------------------------
argCount     = len(sys.argv) - 1  # First argument (arg[0]) is always script name
argCountReqd = 4

if argCount == argCountReqd:
  # sys.argv[0] = file name of this python script
  # sys.argv[1] = vulnerability id
  # sys.argv[2] = log file name
  # sys.argv[3] = debug mode ('DEBUG', otherwise an empty string)
  vulnTitle     = sys.argv[4]  # e.g. 'The Security Token Service is set to use the 'setCharacterEncodingFilter' filter.'
else:
  vxrStigLog('ERROR', 'FAIL', f"Incorrect number of parameters (received {argCount}, requires {argCountReqd})")
  sys.exit()

# --- List all params when in debug mode
vxrStigLog('DEBUG', '--', f"param1={sys.argv[1]}")
vxrStigLog('DEBUG', '--', f"param2={sys.argv[2]}")
vxrStigLog('DEBUG', '--', f"param3={sys.argv[3]}")
vxrStigLog('DEBUG', '--', f"param4={vulnTitle}")

# Define Web XML File path
vCSAUsrLibVmwareSsoStsConfwebXmlFilePath= "/usr/lib/vmware-sso/vmware-sts/conf/web.xml"

# Flag will be set to True if child node needs to be added into <web-app> node to make compliant
filterFlag          = False
filterMappingFlag   = False

# ----------------------------------------
# ---------- Load the XML file -----------
# ----------------------------------------
parser = etree.XMLParser(remove_blank_text=True)
tree = etree.parse(vCSAUsrLibVmwareSsoStsConfwebXmlFilePath, parser)
    
# Get the root element
root = tree.getroot()

# Check if the root element has <web-app> node
if root.tag != "{http://java.sun.com/xml/ns/javaee}web-app":
    vxrStigLog('ERROR', 'FAIL', f"'<web-app>' node not found, please ensure web.xml file is well structured and '<web-app>' node is available.")
    sys.exit()

# Check command for <filter-mapping> child node in <web-app> node
filterMappingCommand = 'xmllint --format "{}" | sed \'2 s/xmlns=".*"//g\' | xmllint --xpath \'/web-app/filter-mapping/filter-name[text()="setCharacterEncodingFilter"]/parent::filter-mapping\' -'.format(vCSAUsrLibVmwareSsoStsConfwebXmlFilePath)

# Execute the check command and capture its output in filterMappingOutput variable
try:
    filterMappingOutput = subprocess.check_output(filterMappingCommand, shell=True, stderr=subprocess.DEVNULL).decode('utf-8')
    vxrStigLog('DEBUG', '--', filterMappingOutput.strip())
    
except subprocess.CalledProcessError as e:
    filterMappingOutput = ""
    vxrStigLog('DEBUG', '--', e)

# Check command for <filter> child node in <web-app> node
filterCommand = 'xmllint --format {} | sed \'2 s/xmlns=".*"//g\' | xmllint --xpath \'/web-app/filter/filter-name[text()="setCharacterEncodingFilter"]/parent::filter\' -'.format(vCSAUsrLibVmwareSsoStsConfwebXmlFilePath)

# Execute the check command and capture its output in filterOutput variable
try:
    filterOutput = subprocess.check_output(filterCommand, shell=True, stderr=subprocess.DEVNULL).decode('utf-8')
    vxrStigLog('DEBUG', '--', filterOutput.strip())
   
except subprocess.CalledProcessError as e:
    filterOutput = ""
    vxrStigLog('DEBUG', '--', e)

# Create <filter-mapping> child node inside the <web-app> node if the filterMappingOutput is empty or "XPath set is empty" for <filter-mapping>.
if not filterMappingOutput.strip() or "XPath set is empty" in filterMappingOutput:
    filter_mapping = etree.Element("filter-mapping")
    filter_name = etree.SubElement(filter_mapping, "filter-name")
    filter_name.text = "setCharacterEncodingFilter"
    url_pattern = etree.SubElement(filter_mapping, "url-pattern")
    url_pattern.text = "/*"
    
    root.append(filter_mapping)

    # Save the modified XML file
    tree.write(vCSAUsrLibVmwareSsoStsConfwebXmlFilePath, pretty_print=True, encoding="UTF-8", xml_declaration=True)
    
    # Set the flag to true
    filterMappingFlag = True

# Create <filter> child node inside the <web-app> node if the filterOutput is empty or "XPath set is empty" for <filter>".
if not filterOutput.strip() or "XPath set is empty" in filterOutput:
    filter_node = etree.Element("filter")
    filter_name = etree.SubElement(filter_node, "filter-name")
    filter_name.text = "setCharacterEncodingFilter"
    filter_class = etree.SubElement(filter_node, "filter-class")
    filter_class.text = "org.apache.catalina.filters.SetCharacterEncodingFilter"

    # Create the <init-param> elements
    init_param1 = etree.SubElement(filter_node, "init-param")
    param_name1 = etree.SubElement(init_param1, "param-name")
    param_name1.text = "encoding"
    param_value1 = etree.SubElement(init_param1, "param-value")
    param_value1.text = "UTF-8"

    init_param2 = etree.SubElement(filter_node, "init-param")
    param_name2 = etree.SubElement(init_param2, "param-name")
    param_name2.text = "ignore"
    param_value2 = etree.SubElement(init_param2, "param-value")
    param_value2.text = "true"

    async_supported = etree.SubElement(filter_node, "async-supported")
    async_supported.text = "true"

    root.append(filter_node)

    # Save the modified XML file
    tree.write(vCSAUsrLibVmwareSsoStsConfwebXmlFilePath, pretty_print=True, encoding="UTF-8", xml_declaration=True)
    
    # Set the flag to true
    filterFlag = True

# Print the compliant message based on the flag
if filterFlag or filterMappingFlag:
    vxrStigLog('INFO', '--', f"The Security Token Service is not set to use the 'setCharacterEncodingFilter' filter. (NON-COMPLIANT, APPLIED:INSERTED)")
    vxrStigLog('INFO', '--', f"Success {vulnTitle}")
elif not filterFlag and not filterMappingFlag:
    vxrStigLog('INFO', '--', f"The Security Token Service is already set to use the 'setCharacterEncodingFilter' filter. (COMPLIANT, UNCHANGED)")
    vxrStigLog('INFO', '--', f"Success {vulnTitle}")
#End