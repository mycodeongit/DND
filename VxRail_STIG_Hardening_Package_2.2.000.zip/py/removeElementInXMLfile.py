#!/usr/bin/python
# ----------------------------------------------------------------------------------------------------------
# FILE         : removeElementInXMLfile.py
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : Removes an element of given type if it has a given attribute name/value.
# ----------------------------------------------------------------------------------------------------------
# Parameters:
# 1. vuln-id                    (only used in VxRailSTIGLogging module)
# 2. Log file name to append to (only used in VxRailSTIGLogging module)
# 3. debug mode                 (only used in VxRailSTIGLogging module)
# 4. vuln-title
# 5. name of xml file
# 6. element name to find (multiple may exist)
# 7. attribute name  to identify the correct element by
# 8. attribute value to identify the correct element by
#
# RETURN VALUE:
# The return code (from sys.exit(n)) will indicate if the file was 
# updated and thus if the Marvin service needs to be restarted.
# - exit == 0 : NO marvin restart 
# - exit == 1 : marvin restart required
# - exit >  1 : error
# ----------------------------------------------------------------------------------------------------------


# ----------------------------------------
# --- import required modules ------------
# ----------------------------------------
import os
import sys
import logging
import xml.etree.ElementTree as ET

scriptPath = os.path.dirname(__file__) # Extract the directory path of the script.
sys.path.insert(0,scriptPath)          # Search the script path first when importing modules.
from VxRailSTIGLogging import *        # Import * brings its contents in the current module.

# ----------------------------------------
# --- check input arguments --------------
# ----------------------------------------
argCount     = len(sys.argv) - 1  # First argument (arg[0]) is always script name
argCountReqd = 8

if argCount == argCountReqd:

  # sys.argv[0] = file name of this python script
  # sys.argv[1] = vulnerability id
  # sys.argv[2] = log file name
  # sys.argv[3] = debug mode ('DEBUG', otherwise an empty string)
  vulnTitle        = sys.argv[4]  # e.g. 'Tomcat must use FIPS-validated ciphers on secured connectors'
  keyFile          = sys.argv[5]  # e.g. '/usr/lib/vmware-marvin/marvind/conf/server.xml'
  elemName         = sys.argv[6]  # e.g. 'Listener'
  inElemAttrName   = sys.argv[7]  # e.g. 'className'
  inElemAttrValue  = sys.argv[8]  # e.g. 'org.apache.catalina.core.AprLifecycleListener'

else:

  vxrStigLog('ERROR', 'FAIL', f"Incorrect number of parameters (received {argCount}, requires {argCountReqd})")
  sys.exit(2)

# --- List all params when in debug mode
vxrStigLog('DEBUG', '--', f"param1={sys.argv[1]}")
vxrStigLog('DEBUG', '--', f"param2={sys.argv[2]}")
vxrStigLog('DEBUG', '--', f"param3={sys.argv[3]}")
vxrStigLog('DEBUG', '--', f"param4={vulnTitle}")
vxrStigLog('DEBUG', '--', f"param5={keyFile}")
vxrStigLog('DEBUG', '--', f"param6={elemName}")
vxrStigLog('DEBUG', '--', f"param7={inElemAttrName}")
vxrStigLog('DEBUG', '--', f"param8={inElemAttrValue}")

isFile = os.path.isfile(keyFile)
if not isFile:
  vxrStigLog('ERROR', 'FAIL', f"XML file not found ({keyFile})")
  sys.exit(3)

# ----------------------------------------
# --- Read the xml file ------------------
# ----------------------------------------
tree = ET.parse(keyFile)
root = tree.getroot()

# ----------------------------------------
# --- Parse the xml tree -----------------
# ----------------------------------------
elemFound   = False
keyFoundVal = None
for child in root.iter(elemName):
  vxrStigLog('DEBUG', '--', f"Element attributes = {child.attrib}")

  elemAttribValue = child.get(inElemAttrName)

  if elemAttribValue == inElemAttrValue:
    # -------------------------------
    # --- Found the element to delete
    # -------------------------------
    elemFound = True

    # Find the parent from where the child must be removed
    parentFindString=".//" + elemName + "[@" + inElemAttrName + '="' + inElemAttrValue + '"]...'
    parent = root.find(parentFindString)

    vxrStigLog('DEBUG', '--', f"Child  = {child}")
    vxrStigLog('DEBUG', '--', f"parentFindString = {parentFindString}")
    vxrStigLog('DEBUG', '--', f"Parent = {parent}")

    break

# --------------------------------------
# --- Remove the element if it was found
# --------------------------------------
valuesChangedFlag = False # only re-write the file if modified to make compliant

if elemFound:
  # ---------------------------------
  # --- Element found (non-compliant)
  # ---------------------------------
  parent.remove(child)
  vxrStigLog('INFO', '--', f'Element "{elemName}" with {inElemAttrName}=={inElemAttrValue} found in "{keyFile}", removing it now ... (NON-COMPLIANT, APPLIED:DELETED)')
  valuesChangedFlag = True
else:
  # ---------------------------------
  # --- Element not found (compliant)
  # ---------------------------------
  vxrStigLog('INFO', '--', f'Element "{elemName}" with {inElemAttrName}=={elemAttribValue} not found in "{keyFile}" (COMPLIANT, UNCHANGED)')
  
# -------------------------------
# --- Logging and re-writing file
# -------------------------------
if valuesChangedFlag:
  vxrStigLog('DEBUG', '--', f'Updating file "{keyFile}"')
  tree.write(keyFile, encoding='utf-8', xml_declaration=True)
  exitValue = 1  # restart marvin required
else:
  vxrStigLog('DEBUG', '--', f'File unchanged "{keyFile}"')
  exitValue = 0  # restart marvin not required

# --- Log the final result message with the title for this vulnerability
vxrStigLog('INFO', 'SUCCESS', vulnTitle)

vxrStigLog('DEBUG', '--', f'python script exitValue : {exitValue}')
sys.exit(exitValue)

# end
