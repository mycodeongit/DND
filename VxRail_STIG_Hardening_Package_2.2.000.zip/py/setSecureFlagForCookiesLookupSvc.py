#!/usr/bin/python
# ---------------------------------------------------------------------------------
# FILE         : setSecureFlagForCookiesLookupSvc.py
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : V-256736 - Lookup Service must set the secure flag for cookies.
# ---------------------------------------------------------------------------------
# Parameters:
# 1. vuln-id                    (only used in VxRailSTIGLogging module)
# 2. Log file name to append to (only used in VxRailSTIGLogging module)
# 3. debug mode                 (only used in VxRailSTIGLogging module)
# ---------------------------------------------------------------------------------


# ----------------------------------------
# --- Import required modules ------------
# ----------------------------------------
import subprocess
import sys
import logging
from lxml import etree
from VxRailSTIGLogging import *        # Import * brings its contents in the current module.

# ----------------------------------------
# --- check input arguments
# ----------------------------------------
argCount     = len(sys.argv) - 1  # First argument (arg[0]) is always script name
argCountReqd = 4

if argCount == argCountReqd:
  # sys.argv[0] = file name of this python script
  # sys.argv[1] = vulnerability id
  # sys.argv[2] = log file name
  # sys.argv[3] = debug mode ('DEBUG', otherwise an empty string)
  vulnTitle     = sys.argv[4]  # e.g. 'Lookup Service must set the secure flag for cookies.'
else:
  vxrStigLog('ERROR', 'FAIL', f"Incorrect number of parameters (received {argCount}, requires {argCountReqd})")
  sys.exit()

# --- List all params when in debug mode
vxrStigLog('DEBUG', '--', f"param1={sys.argv[1]}")
vxrStigLog('DEBUG', '--', f"param2={sys.argv[2]}")
vxrStigLog('DEBUG', '--', f"param3={sys.argv[3]}")
vxrStigLog('DEBUG', '--', f"param4={vulnTitle}")

# Define Web XML File path
vCSAUsrLibVmwareLookupSvcConfwebXmlFilePath= "/usr/lib/vmware-lookupsvc/conf/web.xml"

# ----------------------------------------
# ---------- Load the XML file -----------
# ----------------------------------------
parser = etree.XMLParser(remove_blank_text=True)
tree = etree.parse(vCSAUsrLibVmwareLookupSvcConfwebXmlFilePath, parser)
    
# Get the root element
root = tree.getroot()

# Check if the root element has <web-app> node
if root.tag != "{http://java.sun.com/xml/ns/javaee}web-app":
    vxrStigLog('ERROR', 'FAIL', f"'<web-app>' node not found, please ensure web.xml file is well structured and '<web-app>' node is available.")
    sys.exit()

# Check command for <session-config> child node in <web-app> node
sessionConfigCommand = 'xmllint --format {} | sed \'s/xmlns=".*"//g\' | xmllint --xpath \'/web-app/session-config/cookie-config\' -'.format(vCSAUsrLibVmwareLookupSvcConfwebXmlFilePath)

# Execute the check command and capture its output in sessionConfigOutput variable
try:
    sessionConfigOutput = subprocess.check_output(sessionConfigCommand, shell=True, stderr=subprocess.DEVNULL).decode('utf-8')
    vxrStigLog('DEBUG', '--', sessionConfigOutput.strip())
    
except subprocess.CalledProcessError as e:
    sessionConfigOutput = ""
    vxrStigLog('DEBUG', '--', e)

# Create <filter-mapping> child node inside the <web-app> node if the sessionConfigOutput is empty or "XPath set is empty" for <filter-mapping>.
if not sessionConfigOutput.strip() or "XPath set is empty" in sessionConfigOutput:
    # Find the <session-config> node
    session_config = root.find(".//{http://java.sun.com/xml/ns/javaee}session-config")

    # If <session-config> node is not found, raise an error and exit
    if session_config is None:
        vxrStigLog('ERROR', 'FAIL', f"'<session-config>' node not found, please ensure web.xml file has the '<session-config>' node.")
        sys.exit()

    # Check if the <cookie-config> node is already present under <session-config>
    cookie_config = session_config.find(".//{http://java.sun.com/xml/ns/javaee}cookie-config")
    if cookie_config is None:
        # If <cookie-config> node is not present, create and insert it
        cookie_config = etree.Element("{http://java.sun.com/xml/ns/javaee}cookie-config")
        http_only = etree.SubElement(cookie_config, "{http://java.sun.com/xml/ns/javaee}http-only")
        http_only.text = "true"
        secure = etree.SubElement(cookie_config, "{http://java.sun.com/xml/ns/javaee}secure")
        secure.text = "true"
        session_config.append(cookie_config)

        # Save the modified XML file
        tree.write(vCSAUsrLibVmwareLookupSvcConfwebXmlFilePath, pretty_print=True, encoding="UTF-8", xml_declaration=True)
        
        # Print the compliant message
        vxrStigLog('INFO', '--', f"Lookup Service hasn't set the secure flag for cookies. (NON-COMPLIANT, APPLIED:INSERTED)")
        vxrStigLog('INFO', '--', f"Success {vulnTitle}")

    else:
        vxrStigLog('INFO', '--', f"Lookup Service has already set the secure flag for cookies. (COMPLIANT, UNCHANGED)")
        vxrStigLog('INFO', '--', f"Success {vulnTitle}")

else:
    vxrStigLog('INFO', '--', f"Lookup Service has already set the secure flag for cookies. (COMPLIANT, UNCHANGED)")
    vxrStigLog('INFO', '--', f"Success {vulnTitle}")
#End
