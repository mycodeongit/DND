#!/usr/bin/python
# ----------------------------------------------------------------------------------------------------------
# FILE         : vxsec759.py
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : Apply Tomcat Application Server STIG, vulnerability id V-222934.
#                Title: DefaultServlet must be set to readonly for PUT and DELETE.
#                This rule is quite specific and less suitable for generalizing/parameterizing.
#                Tried using xpath specification for more direct/targeted seach instead of
#                using a loop, but the xml.etree.Elementtree module doesn't support much of
#                unfortunately.
# ----------------------------------------------------------------------------------------------------------
# Parameters:
# 1. vuln-id                    (only used in VxRailSTIGLogging module)
# 2. Log file name to append to (only used in VxRailSTIGLogging module)
# 3. debug mode                 (only used in VxRailSTIGLogging module)
# 4. vuln-title
# 5. name of xml file
#
# RETURN VALUE:
# The return code (from sys.exit(n)) will indicate if the file was 
# updated and thus if the Marvin service needs to be restarted.
# - exit == 0 : NO marvin restart 
# - exit == 1 : marvin restart required
# - exit >  1 : error
# ----------------------------------------------------------------------------------------------------------


# ----------------------------------------
# --- import required modules
# ----------------------------------------
import os
import sys
import logging
import xml.etree.ElementTree as ET

scriptPath = os.path.dirname(__file__) # Extract the directory path of the script.
sys.path.insert(0,scriptPath)          # Search the script path first when importing modules.
from VxRailSTIGLogging import *        # Import * brings its contents in the current module.

# ----------------------------------------
# --- check input arguments
# ----------------------------------------
argCount     = len(sys.argv) - 1  # First argument (arg[0]) is always script name
argCountReqd = 5

if argCount == argCountReqd:
  # sys.argv[0] = file name of this python script
  # sys.argv[1] = vulnerability id
  # sys.argv[2] = log file name
  # sys.argv[3] = debug mode ('DEBUG', otherwise an empty string)
  vulnTitle        = sys.argv[4]  # e.g. ' DefaultServlet must be set to readonly for PUT and DELETE'
  keyFile          = sys.argv[5]  # e.g. '/usr/lib/vmware-marvin/marvind/conf/web.xml'
else:
  vxrStigLog('ERROR', 'FAIL', f"Incorrect number of parameters (received {argCount}, requires {argCountReqd})")
  sys.exit(2)

# --- List all params when in debug mode
vxrStigLog('DEBUG', '--', f"param1={sys.argv[1]}")
vxrStigLog('DEBUG', '--', f"param2={sys.argv[2]}")
vxrStigLog('DEBUG', '--', f"param3={sys.argv[3]}")
vxrStigLog('DEBUG', '--', f"param4={vulnTitle}")
vxrStigLog('DEBUG', '--', f"param5={keyFile}")

# --- List all params when in debug mode
#vxrStigLog('DEBUG', '--', f"param1={sys.argv[1]}")

# ----------------------------------------
# --- initialize
# ----------------------------------------
inParentElemName    = 'servlet'
inParentHasNode     = 'servlet-name'
inParentHasNodeText = 'default'
inFindNodeType      = 'init-param'
inNodeNameNode      = 'param-name'
inNodeValueNode     = 'param-value'
inParamName         = 'readonly'
inParamValue        = 'true'

inParamXMLStr='<init-param><param-name>readonly</param-name><param-value>true</param-value></init-param>'
inParamElem=ET.fromstring(inParamXMLStr)

isFile = os.path.isfile(keyFile)
if not isFile:
  vxrStigLog('ERROR', 'FAIL', f"XML file not found ({keyFile})")
  sys.exit(3)


# =========================================================
# MAIN
# =========================================================

# ----------------------------------------
# --- Read and parse the xml file
# ----------------------------------------
tree = ET.parse(keyFile)
root = tree.getroot()

# ------------------------------------
# Extract any namespaces from the file
# ------------------------------------
# A file may have a namespace (e.g. web.xml) and some may not (e.g. server.xml).
# Extract namespaces from the file.
nsDict = dict([node for _, node in ET.iterparse(keyFile,events=['start-ns'])])
vxrStigLog('DEBUG', '--', f"Namespace dict: {nsDict}")

# The default namespace will be in nsDict[''].
# If none used, then the dict is empty. In that case, set an empty string namespace.
ns = {'':''} if nsDict == {} else nsDict
vxrStigLog('DEBUG', '--', f"Found namespace(s): {ns}")

# Add namespace 'default' pointing to the default namespace
ns['default'] = ns['']

# Build the string for specifying the namespace in the find/findall command.
# If there is a namespace, then it needs to be wrapped in curly brackets.
# If there is no namespace, then the spec can be an empty string.
nsSpec = '' if ns['default']=='' else "{"+ns['default']+"}"
vxrStigLog('DEBUG', '--', f"Set nsSpec: {nsSpec}")

# ----------------------------------------
# Find all parents
# ----------------------------------------
vxrStigLog('DEBUG', '--', f"Finding the parent element {inParentElemName}")

# It is not certain that the parent will be under root: use xpath with double slash
parentFindString = nsSpec+inParentElemName
vxrStigLog('DEBUG', '--', f"parentFindString = {parentFindString}")

# find the parent element
parentList=root.findall(parentFindString)
parentCount = len(parentList)
vxrStigLog('DEBUG', '--', f"Found parentList entries ({parentCount}): {parentList}")

# Fail if none or more than one are found
if parentCount == 0 :
  vxrStigLog('ERROR', '--', f'Parents of type "{inParentElemName}" not found in source file "{keyFile}"')
  vxrStigLog('ERROR', 'FAIL', vulnTitle)
  sys.exit(4)

# ----------------------------------------
# Find the 'default' parent
# ----------------------------------------
vxrStigLog('DEBUG', '--', f"Found {parentCount} parents. Now find the '{inParentHasNodeText}' parent")

defaultParentFound = False
paramFound         = False

for parent in parentList:

  vxrStigLog('DEBUG', '--', f"Next parent in list: {parent.tag}")

  # Find out if this parent has a given node with a given text
  findSpec=nsSpec+inParentHasNode
  child = parent.find(findSpec)

  if child.text == inParentHasNodeText:
    defaultParentFound = True
    vxrStigLog('DEBUG', '--', f"Found correct parent: {parent.tag}")

    # FIND INIT-PARAM inParamName (e.g. 'readonly')
    vxrStigLog('DEBUG', '--', f"Finding child node '{inFindNodeType}' with '{inParamName}' set to '{inParamValue}'")
    params = parent.findall(nsSpec+inFindNodeType)

    for param in params:
      pname = param.find(nsSpec+inNodeNameNode).text
      pval  = param.find(nsSpec+inNodeValueNode).text
      vxrStigLog('DEBUG', '--', f"Next param in list: '{pname}'")
      if pname == inParamName:
        paramFound = True
        vxrStigLog('DEBUG', '--', f"Found correct param: '{pname}'")
        break
    break

if not defaultParentFound:
  vxrStigLog('ERROR', '--', f'Required parent "{inParentElemName}" with "{inParentHasNode}" is "{inParentHasNodeText}" not found in source file "{keyFile}"')
  vxrStigLog('ERROR', 'FAIL', vulnTitle)
  sys.exit(4)

# ----------------------------------------
# CHECK STATE AND MAKE COMPLIANT
# ----------------------------------------
valuesChangedFlag = False

if not paramFound:
  # INSERT INIT-PARAM SECTION
  vxrStigLog('DEBUG', '--', f'Node "{inFindNodeType}" with "{inParamName}" was not found')
  vxrStigLog('INFO', '--', f'Applying "{inFindNodeType}" with "{inParamName}" set to "{inParamValue}" (NON-COMPLIANT, APPLIED:INSERTED)')
  parent.append(inParamElem)
  valuesChangedFlag = True

if paramFound:
  # COMPARE
  if pval == inParamValue:
    vxrStigLog('INFO', '--', f'Element "{inFindNodeType}" with "{inParamName}" set to "{inParamValue}" was found in "{keyFile}" (COMPLIANT, UNCHANGED)')
  else:
    vxrStigLog('INFO', '--', f'Applying "{inFindNodeType}" changing "{inParamName}" from "{pval}" to "{inParamValue}" in "{keyFile}" (NON-COMPLIANT, APPLIED:UPDATED)')
    parent.remove(param)
    parent.append(inParamElem)
    valuesChangedFlag = True

# ==============================
# Logging and re-writing file
# ==============================
if valuesChangedFlag:
  vxrStigLog('DEBUG', '--', f'Updating file "{keyFile}"')

  # No need for namespace anymore. This also prevents the 
  # namespace written with every element in the file.
  ET.register_namespace("",ns['default'])

  # Write the XML back to file
  tree.write(keyFile, encoding='utf-8')

  exitValue = 1  # restart marvin required

else:
  vxrStigLog('DEBUG', '--', f'File unchanged "{keyFile}"')
  exitValue = 0  # restart marvin not required

# --- Log the final result message with the title for this vulnerability
vxrStigLog('INFO', 'SUCCESS', vulnTitle)

vxrStigLog('DEBUG', '--', f'python script exitValue : {exitValue}')
sys.exit(exitValue)

# end
