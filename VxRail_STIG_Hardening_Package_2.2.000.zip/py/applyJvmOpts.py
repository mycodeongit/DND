#!/usr/bin/python
# ----------------------------------------------------------------------------------------------------------
# FILE         : applyJvmOpts.py
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : Apply options in the JVM_OPTS environment variable in the Tomcat AS environment file.
#                It is required that the line with variable JVM_OPTS looks like: JVM_OPTS="....."
#                An assignment inside "....." looks like: <parmname>=<parmvalue>
#                Assignments are space-separated.
# ----------------------------------------------------------------------------------------------------------
# Parameters:
# 1. vuln-id                    (only used in VxRailSTIGLogging module)
# 2. Log file name to append to (only used in VxRailSTIGLogging module)
# 3. STIG log level             (only used in VxRailSTIGLogging module)
# 4. vuln-title
# 5. action
# 6. name of settings file where JVM_OPTS is set
# 7. parm name
# 8. parm value
#
# RETURN VALUE:
# The return code (from sys.exit(n)) will indicate if the file was 
# updated and thus if the Marvin service needs to be restarted.
# - exit == 0 : NO marvin restart 
# - exit == 1 : marvin restart required
# - exit >  1 : error
# ----------------------------------------------------------------------------------------------------------


# ----------------------------------------
# --- import required modules
# ----------------------------------------
import os
import re
import sys
import logging

scriptPath = os.path.dirname(__file__) # Extract the directory path of the script.
sys.path.insert(0,scriptPath)          # Search the script path first when importing modules.
from VxRailSTIGLogging import *        # Import * brings its contents in the current module.

# ----------------------------------------
# --- check input arguments
# ----------------------------------------
argCount     = len(sys.argv) - 1  # First argument (arg[0]) is always script name
argCountReqd = 8

if argCount == argCountReqd:
  # sys.argv[0] = file name of this python script
  # sys.argv[1] = vulnerability id
  # sys.argv[2] = log file name
  # sys.argv[3] = debug mode ('DEBUG', otherwise an empty string)
  vulnTitle     = sys.argv[4]  # e.g. 'ENFORCE_ENCODING_IN_GET_WRITER must be set to true'
  action        = sys.argv[5]  # e.g. 'check' | 'apply'
  envFile       = sys.argv[6]  # e.g. '/usr/lib/vmware-marvin/marvind/bin/setenv.xml'
  parmName      = sys.argv[7]  # e.g. '-Dorg.apache.catalina.connector.response.ENFORCE_ENCODING_IN_GET_WRITER'
  parmValue     = sys.argv[8]  # e.g. 'true'
else:
  vxrStigLog('ERROR', 'FAIL', f"Incorrect number of parameters (received {argCount}, requires {argCountReqd})")
  sys.exit(2)

# --- List all params when in debug mode
vxrStigLog('DEBUG', '--', f"param1={sys.argv[1]}")
vxrStigLog('DEBUG', '--', f"param2={sys.argv[2]}")
vxrStigLog('DEBUG', '--', f"param3={sys.argv[3]}")
vxrStigLog('DEBUG', '--', f"param4={sys.argv[4]}")
vxrStigLog('DEBUG', '--', f"param5={sys.argv[5]}")
vxrStigLog('DEBUG', '--', f"param6={sys.argv[6]}")
vxrStigLog('DEBUG', '--', f"param7={sys.argv[7]}")
vxrStigLog('DEBUG', '--', f"param7={sys.argv[8]}")

# ----------------------------------------
# Initialize
# ----------------------------------------
exitValue = 0

vxrStigLog('DEBUG', '--', f"Existence test file: {envFile}")
isFile = os.path.isfile(envFile)
if not isFile:
  vxrStigLog('ERROR', 'FAIL', f"Tomcat environment config file not found ({envFile})")
  sys.exit(3)


# --------------------------------------------------
# FUNCTION:    doCompliance
# DESCRIPTION: Check a rule for compliance. Optionally apply the rule.
# Input:
#   1. action - This can be 'check' or 'apply'.
# Output:
#   exitValue - This indicates if the file was updated and thus
#               if the Marvin service needs to be restarted.
# - exit == 0 : NO marvin restart 
# - exit == 1 : marvin restart required
# - exit >  1 : error
# --------------------------------------------------
def doCompliance(action):

  if action != 'check' and action != 'apply':
    vxrStigLog('ERROR', 'FAIL', f"Unexpected compliance action specified ({action})")
    sys.exit(4)

  # Open file and read all lines
  vxrStigLog('DEBUG', '--', f"Reading environment file: {envFile}")
  with open(envFile,"r") as inFile:
    lines = inFile.readlines()

  newLines         = ""
  linesChanged     = False
  jvmOptsLineFound = False

  # Find the line for the JVM_OPTS
  for line in lines:

    # How can we recognize the required line?
    jvmOptsArg = 'JVM_OPTS=".*"'

    if (re.match( jvmOptsArg, line )):

      # Found the JVM_OPTS line
      vxrStigLog('DEBUG', '--', f"Found the line")
      jvmOptsLineFound = True

      # Set the assignment search argument and the correct/new assignment
      assignmentSearchArg = f'{parmName}=([^ "]+)'    # take chars until you meet a space or quote
      newAssignment       = f"{parmName}={parmValue}"

      # See if the parameter is already assinged in the line
      foundAssignmentObj = re.search( assignmentSearchArg, line )

      if foundAssignmentObj:

        # Parameter assignment is already present
        vxrStigLog('DEBUG', '--', f"Found the assignment for {parmName}")

        # Extract the result
        foundAssignment = foundAssignmentObj.group()  # e.g. -aaa=123
        foundValue      = foundAssignmentObj.group(1) # e.g. 123

        vxrStigLog('DEBUG', '--', f"Found assignment: {foundAssignment}")
        vxrStigLog('DEBUG', '--', f"Found value     : {foundValue}")

        if foundValue == parmValue:

          # Parameter {parmName} is already assigned the correct value
          vxrStigLog('INFO', '--', f"Parameter {parmName} is set correctly in file {envFile} (COMPLIANT)")

        else:
          # Parameter {parmName} is NOT assigned the correct value
          if action == 'check':
            # CHECK
            vxrStigLog('INFO', '--', f"Parameter {parmName} is set to {foundValue} in file {envFile} (NON-COMPLIANT)")
          else:
            # APPLY - UPDATE
            line         = re.sub(foundAssignment, newAssignment, line)
            linesChanged = True
            vxrStigLog('DEBUG', '--', f"Line (update): {line}")
            vxrStigLog('INFO', '--', f"Applying parameter {parmName}={parmValue} (from {foundValue}) in file {envFile} (NON-COMPLIANT, APPLIED:UPDATED)")

      else:

        # Parameter assignment is NOT present
        vxrStigLog('DEBUG', '--', f"Did not find the assignment for {parmName}")

        if action == 'check':
          # CHECK
          vxrStigLog('INFO', '--', f"Parameter {parmName} assignment not found in file {envFile} (NON-COMPLIANT)")
        else:
          # APPLY - INSERT
          oldLineStart = f'JVM_OPTS="'
          newLineStart = f'JVM_OPTS="{newAssignment} '
          line         = line.replace(oldLineStart, newLineStart)
          linesChanged = True
          vxrStigLog('DEBUG', '--', f"Line (insert): {line}")
          vxrStigLog('INFO', '--', f"Applying parameter {parmName}={parmValue} in file {envFile} (NON-COMPLIANT, APPLIED:INSERTED)")

    # Only need to capture lines (changed or not) when applying a rule,
    # so that the new set of lines can be written back to file when done
    if action == 'apply':
      newLines = newLines + line

  # Was the line found in the file?
  if not jvmOptsLineFound:
    vxrStigLog('ERROR', 'FAIL', f"JVM_OPTS not found in environment file ({envFile})")
    sys.exit(5)

  # Rewrite all lines but only changes were applied
  if linesChanged:
    vxrStigLog('DEBUG', '--', f"Rewriting environment file: {envFile}")
    with open(envFile,"w") as outFile:
      outFile.writelines(newLines)

    exitValue = 1  # restart marvin required
  else:
    exitValue = 0  # restart marvin not required

  return exitValue

# =========================================================
# MAIN
# =========================================================
# Check or apply this vulnerability for compliance
exitValue = doCompliance(action)

# --- Log the final result message with the title for this vulnerability
vxrStigLog('INFO', 'SUCCESS', vulnTitle)

vxrStigLog('DEBUG', '--', f'python script exitValue : {exitValue}')
sys.exit(exitValue)

# end
