#!/usr/bin/python
# ----------------------------------------------------------------------------------------------------------
# FILE         : applyElementInXMLfile.py
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : Applies an element under another -unique- given element
#                Can check for only existence of element -or- can also check element content,
#                depending on the existence check flag that is passed in.
#                The inputfile may optionally use an XML namespace.
# ----------------------------------------------------------------------------------------------------------
# Parameters:
# 1. vuln-id                    (only used in VxRailSTIGLogging module)
# 2. Log file name to append to (only used in VxRailSTIGLogging module)
# 3. debug mode                 (only used in VxRailSTIGLogging module)
# 4. vuln-title
# 5. name of xml file
# 6. element name to find (must be unique and must exist)
# 7. element to insert/apply (full section, as String)
# 8. existence check flag (true only checks element existence; false also checks element content)
#
# RETURN VALUE:
# The return code (from sys.exit(n)) will indicate if the file was 
# updated and thus if the Marvin service needs to be restarted.
# - exit == 0 : NO marvin restart 
# - exit == 1 : marvin restart required
# - exit >  1 : error
# ----------------------------------------------------------------------------------------------------------


# ----------------------------------------
# --- import required modules ------------
# ----------------------------------------
import os
import sys
import logging
import xml.etree.ElementTree as ET
import re

scriptPath = os.path.dirname(__file__) # Extract the directory path of the script.
sys.path.insert(0,scriptPath)          # Search the script path first when importing modules.
from VxRailSTIGLogging import *        # Import * brings its contents in the current module.

# ----------------------------------------
# --- check input arguments --------------
# ----------------------------------------
argCount     = len(sys.argv) - 1  # First argument (arg[0]) is always script name
argCountReqd = 8

if argCount == argCountReqd:

  # sys.argv[0] = file name of this python script
  # sys.argv[1] = vulnerability id
  # sys.argv[2] = log file name
  # sys.argv[3] = debug mode ('DEBUG', otherwise an empty string)
  vulnTitle        = sys.argv[4]  # e.g. 'Tomcat must use FIPS-validated ciphers on secured connectors'
  keyFile          = sys.argv[5]  # e.g. '/usr/lib/vmware-marvin/marvind/conf/server.xml'
  elemName         = sys.argv[6]  # e.g. 'session-config'
  applyElemString  = sys.argv[7]  # e.g. '<cookie-config> <http-only>true</http-only> <secure>true</secure> </cookie-config>'
  existenceCheck   = sys.argv[8]  # e.g. 'True' or 'False'

else:

  vxrStigLog('ERROR', 'FAIL', f"Incorrect number of parameters (received {argCount}, requires {argCountReqd})")
  sys.exit(2)

# --- List all params when in debug mode
vxrStigLog('DEBUG', '--', f"param1={sys.argv[1]}")
vxrStigLog('DEBUG', '--', f"param2={sys.argv[2]}")
vxrStigLog('DEBUG', '--', f"param3={sys.argv[3]}")
vxrStigLog('DEBUG', '--', f"param4={vulnTitle}")
vxrStigLog('DEBUG', '--', f"param5={keyFile}")
vxrStigLog('DEBUG', '--', f"param6={elemName}")
vxrStigLog('DEBUG', '--', f"param7={applyElemString}")
vxrStigLog('DEBUG', '--', f"param8={existenceCheck}")

isFile = os.path.isfile(keyFile)
if not isFile:
  vxrStigLog('ERROR', 'FAIL', f"XML file not found ({keyFile})")
  sys.exit(3)

# =========================================================
# Functions
# =========================================================

# --------------------------------------------------
# FUNCTION: remove_ns_from_xml_string
# DESCRIPTION: 
#   Remove any namespace info from a given XML string.
# --------------------------------------------------
def remove_ns_from_xml_string(xmlStr):

  vxrStigLog('DEBUG', '--', f"Function start: remove_ns_from_xml_string")
  vxrStigLog('DEBUG', '--', f"Input : {xmlStr}")

  # 1. Remove any whitespace
  xmlStr = xmlStr.rstrip()
  #vxrStigLog('DEBUG', '--', f"step1: {xmlStr}")

  # 2. Remove any XML layout formatting
  xmlStr = re.sub(">\n*\s*<","><", xmlStr)
  #vxrStigLog('DEBUG', '--', f"step2: {xmlStr}")

  # 3. Remove any namespace definition (if file uses them): "xmlns=..."
  xmlStr = re.sub(" xmlns:ns0=\".*\">",">", xmlStr)
  #vxrStigLog('DEBUG', '--', f"step3: {xmlStr}")

  # 4. Remove any namespace tags (if file uses them): "ns0:"
  xmlStr = re.sub("<ns0:" ,"<" , xmlStr )
  xmlStr = re.sub("</ns0:","</", xmlStr)

  vxrStigLog('DEBUG', '--', f"Result: {xmlStr}")
  vxrStigLog('DEBUG', '--', "Function end")
  return xmlStr

# --------------------------------------------------
# FUNCTION: cleanup_empty_lines_in_file
# DESCRIPTION:
#   With the version of the xml.etree.ElementTree module at time of writing,
#   not all elements of the XML input will end up as elements of the parsed tree. 
#   (See https://docs.python.org/3/library/xml.etree.elementtree.html)
#   Currently, this module skips over any XML comments, processing instructions, 
#   and document type declarations in the input. This means that lines with
#   such content (like comment) become empty lines in the newly written file.
#   To prevent big gaps, empty lines are removed in the next step.
# --------------------------------------------------
def cleanup_empty_lines_in_file(inFile):

  # Read and strip the file
  with open(keyFile) as xmlfile:
    lines = [line for line in xmlfile if line.strip() is not ""]

  # Write stripped content back to file
  with open(keyFile, "w") as xmlfile:
    xmlfile.writelines(lines)


# =========================================================
# MAIN
# =========================================================

# ----------------------------------------
# --- Read and parse the xml file --------
# ----------------------------------------
tree = ET.parse(keyFile)
root = tree.getroot()

# =========================================================
# Find the elements
# =========================================================

# ------------------------------------
# Extract any namespaces from the file
# ------------------------------------
# A file may have a namespace (e.g. web.xml) and some may not (e.g. server.xml).
# Extract namespaces from the file.
nsDict = dict([node for _, node in ET.iterparse(keyFile,events=['start-ns'])])
vxrStigLog('DEBUG', '--', f"nsDict: {nsDict}")

# The default namespace will be in nsDict[''].
# If none used, then the dict is empty. In that case, set an empty string namespace.
ns = {'':''} if nsDict == {} else nsDict
vxrStigLog('DEBUG', '--', f"ns: {ns}")

# Add namespace 'default' pointing to the default namespace
ns['default'] = ns['']

# Build the string for specifying the namespace in the find/findall command.
# If there is a namespace, then it needs to be wrapped in curly brackets.
# If there is no namespace, then the spec can be an empty string.
nsSpec = '' if ns['default']=='' else "{"+ns['default']+"}"

vxrStigLog('DEBUG', '--', f"Found namespace(s): {ns}")
vxrStigLog('DEBUG', '--', f"Set nsSpec: {nsSpec}")

# ---------------------------------------------------------
# Find the parent (under where the element must be applied)
# ---------------------------------------------------------
vxrStigLog('DEBUG', '--', f"Finding the parent element {elemName}")

# It is not certain that the parent will be under root: use xpath with double slash
parentFindString = ".//" + nsSpec + elemName
vxrStigLog('DEBUG', '--', f"parentFindString = {parentFindString}")

# find the parent element
parentList = root.findall(parentFindString, ns)
parentCount = len(parentList)
vxrStigLog('DEBUG', '--', f"Found parentList entries ({parentCount}): {parentList}")

# Fail if none or more than one are found
if parentCount == 0 :
  vxrStigLog('ERROR', '--', f'Element "{elemName}" not found in source file "{keyFile}"')
  vxrStigLog('ERROR', 'FAIL', vulnTitle)
  sys.exit(4)
if parentCount > 1 :
  vxrStigLog('ERROR', '--', f'Element "{elemName}" found more than once ({parentCount}x) in source file "{keyFile}"')
  vxrStigLog('ERROR', 'FAIL', vulnTitle)
  sys.exit(5)

# One element found - take it out of the list
parent = parentList[0]

# -------------------------
# Find the element to apply
# -------------------------
# First parse the given apply String
applyElem = ET.fromstring(applyElemString)
vxrStigLog('DEBUG', '--', f"Parsed apply elem: {applyElem}")

# This will give the tag (and namespace if used) to look for
# Example tag '{http://java.sun.com/xml/ns/javaee}session-timeout'
# Find the element using the tag
vxrStigLog('DEBUG', '--', f"Apply element tag: {applyElem.tag}")

# The given apply string =may= have an attribute (e.g. className=...)
# that needs to be included in the find statement to narrow the search
# using an XPATH specification.
# The attribute (if provided) will be in the attrib dict, and we need to 
# obtain the name and value. That is done by changing the dict to a list
# and using the first element. 
# A dict is unordered, so if multiple attribs are provided this will
# produce the key+value of the attrib that happens to come up first.
# If no attribs given, then the XPATH spec will be empty.
# If attribs given, then the XPATH spec look like: '[@name="value"]'
attrList=list(applyElem.attrib)
xPathSpec='' if attrList==[] else '[@'+attrList[0]+'="'+applyElem.attrib[attrList[0]]+'"]'

elemFindString = nsSpec + applyElem.tag + xPathSpec
vxrStigLog('DEBUG', '--', f"elemFindString = {elemFindString}")

elemList = parent.findall(elemFindString, ns)
elemCount = len(elemList)
vxrStigLog('DEBUG', '--', f"Found elemList {elemList}")

# Fail if more than one are found
if elemCount > 1:
  vxrStigLog('ERROR', '--', f'Element "{applyElem.tag}" found more than once ({elemCount}x) in source file "{keyFile}"')
  vxrStigLog('ERROR', 'FAIL', vulnTitle)
  sys.exit(6)

# ==============================
# Check compliance
# ==============================
valuesChangedFlag = False # only re-write the file if modified to make compliant
elemsEqual = False # init

if elemCount == 0: 
  # Element not found
  vxrStigLog('INFO', '--', f'Element "{applyElem.tag}" not found in "{keyFile}"')
else:
  # Element found - take it out of the list
  foundElem = elemList[0]

  # Now have 2 XML elements:
  # 1. What was provided on input      (applyElem)
  # 2. What was found under the parent (foundElem)

  # Is it only an element *existence* check, 
  # or does the element *content* need to be identical as well?

  if existenceCheck.casefold() == "true":
    # Existence check is sufficient for compliance
    elemsEqual = True
    vxrStigLog('INFO', '--', f'Element "{applyElem.tag}" found in "{keyFile}" (COMPLIANT, UNCHANGED)')

  else:
    # Convert both elements to an XML string
    applyElemString = ET.tostring(applyElem,encoding="unicode")
    foundElemString = ET.tostring(foundElem,encoding="unicode")

    # Cleanup the string so they can be compared
    applyElemStrClean = remove_ns_from_xml_string(applyElemString)
    foundElemStrClean = remove_ns_from_xml_string(foundElemString)

    vxrStigLog('DEBUG', '--', f"Clean found string: {foundElemStrClean}")
    vxrStigLog('DEBUG', '--', f"Clean apply string: {applyElemStrClean}")
  
    # COMPARE THE GIVEN AND FOUND XML STRINGS
    elemsEqual = (applyElemStrClean == foundElemStrClean)
    vxrStigLog('DEBUG', '--', f"Given and Found elements equal? {elemsEqual}")
  
    if elemsEqual:
      vxrStigLog('INFO', '--', f'Element "{applyElem.tag}" found with correct content in "{keyFile}" (COMPLIANT, UNCHANGED)')
    else:
      vxrStigLog('INFO', '--', f'Element "{applyElem.tag}" found with different content in "{keyFile}": {foundElemStrClean}"')

      # remove the found/non-compliant entry from the parent
      vxrStigLog('DEBUG', '--', f"Removing the found non-compliant element")
      parent.remove(foundElem)


# If it didn't exist yet, or if they weren't equal, then apply it
if elemCount == 0 or not elemsEqual:

  # Log if this was an insert or update operation
  op = "INSERTED" if elemCount == 0 else "UPDATED"
  vxrStigLog('INFO', '--', f'Applying element "{applyElem.tag}" content in "{keyFile}" (NON-COMPLIANT, APPLIED:{op})')

  # apply the entry under the parent
  parent.append(applyElem)
  valuesChangedFlag = True

# ==============================
# Logging and re-writing file
# ==============================
if valuesChangedFlag:
  vxrStigLog('DEBUG', '--', f'Updating file "{keyFile}"')

  # No need for namespace anymore. This also prevents the 
  # namespace written with every element in the file.
  ET.register_namespace("",ns['default'])

  # Write the XML back to file
  tree.write(keyFile, encoding='utf-8')

  # Cleanup empty lines in file
  cleanup_empty_lines_in_file(keyFile)

  exitValue = 1  # restart marvin required

else:
  vxrStigLog('DEBUG', '--', f'File unchanged "{keyFile}"')
  exitValue = 0  # restart marvin not required

# --- Log the final result message with the title for this vulnerability
vxrStigLog('INFO', 'SUCCESS', vulnTitle)

vxrStigLog('DEBUG', '--', f'python script exitValue : {exitValue}')
sys.exit(exitValue)

# end
