#!/usr/bin/python
# ----------------------------------------------------------------------------------------------------------
# FILE         : setKeyOfElementAttributeInXMLfile.py
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : Sets a key of an element with a certain attribute to a given value.
# ----------------------------------------------------------------------------------------------------------
# Parameters:
# 1. vuln-id                    (only used in VxRailSTIGLogging module)
# 2. Log file name to append to (only used in VxRailSTIGLogging module)
# 3. debug mode                 (only used in VxRailSTIGLogging module)
# 4. vuln-title
# 5. name of xml file
# 6. element name to find (multiple may exist)
# 7. attribute name  to identify the correct element by
# 8. attribute value to identify the correct element by
# 9. key name of the attribute to check for compliance
# 10.key value
#
# RETURN VALUE:
# The return code (from sys.exit(n)) will indicate if the file was 
# updated and thus if the Marvin service needs to be restarted.
# - exit == 0 : NO marvin restart 
# - exit == 1 : marvin restart required
# - exit >  1 : error
# ----------------------------------------------------------------------------------------------------------


# ----------------------------------------
# --- import required modules ------------
# ----------------------------------------
import os
import sys
import logging
import xml.etree.ElementTree as ET

scriptPath = os.path.dirname(__file__) # Extract the directory path of the script.
sys.path.insert(0,scriptPath)          # Search the script path first when importing modules.
from VxRailSTIGLogging import *        # Import * brings its contents in the current module.

# ----------------------------------------
# --- check input arguments --------------
# ----------------------------------------
argCount     = len(sys.argv) - 1  # First argument (arg[0]) is always script name
argCountReqd = 10

if argCount == argCountReqd:

  # sys.argv[0] = file name of this python script
  # sys.argv[1] = vulnerability id
  # sys.argv[2] = log file name
  # sys.argv[3] = debug mode ('DEBUG', otherwise an empty string)
  vulnTitle        = sys.argv[4]  # e.g. 'Tomcat must use FIPS-validated ciphers on secured connectors'
  keyFile          = sys.argv[5]  # e.g. '/usr/lib/vmware-marvin/marvind/conf/server.xml'
  elemName         = sys.argv[6]  # e.g. 'Listener'
  inElemAttrName   = sys.argv[7]  # e.g. 'className'
  inElemAttrValue  = sys.argv[8]  # e.g. 'org.apache.catalina.core.AprLifecycleListener'
  keyName          = sys.argv[9]  # e.g. 'FIPSMode'
  keyValue         = sys.argv[10] # e.g. 'on'

else:

  vxrStigLog('ERROR', 'FAIL', f"Incorrect number of parameters (received {argCount}, requires {argCountReqd})")
  sys.exit(2)

# --- List all params when in debug mode
vxrStigLog('DEBUG', '--', f"param1={sys.argv[1]}")
vxrStigLog('DEBUG', '--', f"param2={sys.argv[2]}")
vxrStigLog('DEBUG', '--', f"param3={sys.argv[3]}")
vxrStigLog('DEBUG', '--', f"param4={vulnTitle}")
vxrStigLog('DEBUG', '--', f"param5={keyFile}")
vxrStigLog('DEBUG', '--', f"param6={elemName}")
vxrStigLog('DEBUG', '--', f"param7={inElemAttrName}")
vxrStigLog('DEBUG', '--', f"param8={inElemAttrValue}")
vxrStigLog('DEBUG', '--', f"param9={keyName}")
vxrStigLog('DEBUG', '--', f"param10={keyValue}")

isFile = os.path.isfile(keyFile)
if not isFile:
  vxrStigLog('ERROR', 'FAIL', f"XML file not found ({keyFile})")
  sys.exit(3)

# ----------------------------------------
# --- Read the xml file ------------------
# ----------------------------------------
tree = ET.parse(keyFile)
root = tree.getroot()

# ----------------------------------------
# --- Parse the xml tree -----------------
# ----------------------------------------
elemFound   = False
keyFoundVal = None
for elem in root.iter(elemName):
  #vxrStigLog('DEBUG', '--', f"Element attributes = {elem.attrib}")

  elemAttribValue = elem.get(inElemAttrName)

  if elemAttribValue == inElemAttrValue:
    # ---------------------------
    # --- Found the right element
    # ---------------------------
    elemFound = True                # the containing element was found
    keyFoundVal = elem.get(keyName) # remember the element's key value
    vxrStigLog('DEBUG', '--', f'Element found by attribute "{inElemAttrName}" value "{elemAttribValue}"')
    break

# -----------------------------
# --- Inspect the found element
# -----------------------------
valuesChangedFlag = False # only re-write the file if modified to make compliant

if elemFound:
  if keyFoundVal == None:
    # -----------------------
    # --- Attribute not found
    # -----------------------
    vxrStigLog('INFO', '--', f'Attribute "{keyName}" was not present in "{keyFile}", setting it now ... (NON-COMPLIANT, APPLIED:INSERTED)')
    elem.set(keyName,keyValue)
    valuesChangedFlag = True
  else:
    vxrStigLog('DEBUG', '--', f'Attribute FOUND: keyName "{keyName}" value "{keyFoundVal}"')
  
    # check value of found key
    if keyFoundVal != keyValue:
      # ---------------------------------------------
      # --- Attribute found, with non-compliant value
      # ---------------------------------------------
      vxrStigLog('INFO', '--', f'Attribute "{keyName}" was set to "{keyFoundVal}" and has now been rectified in "{keyFile}" to the new value "{keyValue}" (NON-COMPLIANT, APPLIED:UPDATED)')
      elem.set(keyName,keyValue)
      valuesChangedFlag = True
    else:
      # -----------------------------------------
      # --- Attribute found, with compliant value
      # -----------------------------------------
      vxrStigLog('INFO', '--', f'Attribute "{keyName}" was present and already set correctly in to the value "{keyValue}" (COMPLIANT, UNCHANGED)')
  
  # -------------------------------
  # --- Logging and re-writing file
  # -------------------------------
  if valuesChangedFlag:
    vxrStigLog('DEBUG', '--', f'Updating file "{keyFile}"')
    tree.write(keyFile, encoding='utf-8', xml_declaration=True)
    exitValue = 1  # restart marvin required
  else:
    vxrStigLog('DEBUG', '--', f'File unchanged "{keyFile}"')
    exitValue = 0  # restart marvin not required
  
  # --- Log the final result message with the title for this vulnerability
  vxrStigLog('INFO', 'SUCCESS', vulnTitle)
else:
  vxrStigLog('ERROR', '--', f'Element "{inElemAttrValue}" not found in source file "{keyFile}"')
  vxrStigLog('ERROR', 'FAIL', vulnTitle)
  exitValue = 4

vxrStigLog('DEBUG', '--', f'python script exitValue : {exitValue}')
sys.exit(exitValue)

# end
