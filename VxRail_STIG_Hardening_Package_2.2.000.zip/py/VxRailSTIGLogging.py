#!/usr/bin/python
# ----------------------------------------------------------------------------------------------------------
# FILE         : VxRailSTIGLogging.py
# COPYRIGHT    : Copyright 2023 Dell Inc. or its subsidiaries. All Rights Reserved
# AUTHOR       : VxRail Engineering Security Team
# DESCRIPTION  : VxRail STIG logging module for python scripts
# ----------------------------------------------------------------------------------------------------------
#
# Change log - STIG 2.2.000
# VXP-71258 - Unknown params in logging.basicConfig when logging not called using vxrStigLog function.
#
# Module that configures the logging functionality and
# can be called using "from VxRailSTIGLogging import *"
# by the calling script, so that all content becomes 
# available in the calling script its environment.
#
# This module sets up:
# * Assigns the default/common parameters:
#     1. vulnerability-id
#     2. logfile name
#     3. debug mode (log level)
# * The logfile and message format
# * Function vxrStigLog: 
#     - writes a log message to both console and log file
#
# ----------------------------------------
# --- import required modules ------------
# ----------------------------------------
import sys
import logging

# ----------------------------------------
# --- Set default params.
# --- These are always the first 3 parameters of any python script that uses this module.
# --- This modules is fully imported; the params that were passed to the calling program
# --- are available here as well. This allows using them in the setup of the logging.
# ----------------------------------------
vulnid     = sys.argv[1]
logFile    = sys.argv[2]
debugMode  = sys.argv[3]

# ----------------------------------------
# Setup Logfile
# - use passed-in vulnerability id
# - use passed-in log file name
# - use passed-in debugMode to set the log level
# - append to the given logfile
# ----------------------------------------
if debugMode == 'DEBUG': 
  logLevel=logging.DEBUG
else:
  logLevel=logging.INFO

# Note that vulnid is known here. fresult is not and must be
# passed to the logging using the "extra{...}" dict parameter.

FORMAT='%(asctime)s\t%(message)s'

logging.basicConfig(level=logLevel,
                    filename=logFile,
                    filemode='a',
                    format=FORMAT,
                    datefmt='%Y-%m-%d %H:%M:%S'
                   )

# -----------------------------------------------
# FUNCTION: vxrStigLog
# Write a log message to console and the log file
# -----------------------------------------------
def vxrStigLog(flevel, fresult, fmsg):

  # Setup the message format
  # Cant do that in FORMAT param because if logging is done without using this 
  # function (but using the default way) then these extra params will not be known
  tab='\t'
  fullMsg=f"{flevel}\t{vulnid}\t{fresult}\t{fmsg}"

  # print to console
  # If its a debug message then only print it if running in debug mode
  if debugMode == 'DEBUG' or flevel.casefold() != "debug":
    print(f"{fullMsg}")

  if   flevel.casefold() == "debug":    logging.debug(    f"{fullMsg}" )
  elif flevel.casefold() == "info":     logging.info(     f"{fullMsg}" )
  elif flevel.casefold() == "warning":  logging.warning(  f"{fullMsg}" )
  elif flevel.casefold() == "error":    logging.error(    f"{fullMsg}" )
  elif flevel.casefold() == "critical": logging.critical( f"{fullMsg}" )
  else:
    print(f"ERROR: UNKNOWN MESSAGE LEVEL ({flevel}) - UNABLE TO WRITE THE FOLLOWING MESSAGE TO THE LOGFILE")
    print(f"Log message: {fullMsg}")

# end
